"""Seed test data: two tenants + three users (ENV-guarded)

Revision ID: 002
Revises: 001
Create Date: 2026-06-27

"""
from typing import Sequence, Union
import os

import sqlalchemy as sa
from alembic import op

revision: str = "002"
down_revision: Union[str, None] = "001"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

_TENANT_A = "00000000-0000-4000-a000-000000000001"
_TENANT_B = "00000000-0000-4000-a000-000000000002"


def _seed_active() -> bool:
    return os.environ.get("BUCHUNG_ATAKAN_SEED_TEST_DATA") == "1"


def upgrade() -> None:
    if not _seed_active():
        return

    from pwdlib import PasswordHash

    ph = PasswordHash.recommended()
    pw_hash = ph.hash("testpassword123")

    conn = op.get_bind()

    conn.execute(
        sa.text("""
            INSERT INTO unternehmen (id, name) VALUES
                (:id_a, 'Test GmbH A'),
                (:id_b, 'Test GmbH B')
            ON CONFLICT (id) DO NOTHING
        """),
        {"id_a": _TENANT_A, "id_b": _TENANT_B},
    )

    conn.execute(
        sa.text("""
            INSERT INTO benutzer (id, unternehmen_id, benutzername, hashed_password, rolle)
            VALUES
                (gen_random_uuid(), :tid_a, 'admin_a', :pw, 'UNTERNEHMEN_ADMIN'),
                (gen_random_uuid(), :tid_a, 'leser_a', :pw, 'LESER'),
                (gen_random_uuid(), :tid_b, 'admin_b', :pw, 'UNTERNEHMEN_ADMIN')
            ON CONFLICT (benutzername) DO NOTHING
        """),
        {"tid_a": _TENANT_A, "tid_b": _TENANT_B, "pw": pw_hash},
    )


def downgrade() -> None:
    if not _seed_active():
        return

    conn = op.get_bind()
    conn.execute(
        sa.text("DELETE FROM benutzer WHERE benutzername IN ('admin_a', 'leser_a', 'admin_b')")
    )
    conn.execute(
        sa.text("DELETE FROM unternehmen WHERE id IN (:id_a, :id_b)"),
        {"id_a": _TENANT_A, "id_b": _TENANT_B},
    )
