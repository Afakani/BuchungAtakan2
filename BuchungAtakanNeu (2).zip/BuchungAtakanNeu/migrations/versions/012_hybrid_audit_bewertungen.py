"""Hybrid-Audit-Bewertungen und Dokumentklasse — Phase 07-03A (HYB-17/18)

Revision ID: 012
Revises: 011
Create Date: 2026-07-02

Additiv, kein Drop:
  hybrid_statusentscheidungen.dokument_klasse — nullable, Altzeilen bleiben NULL.
  hybrid_audit_bewertungen                    — append-only Auditbewertung je
                                                 HybridStatusentscheidung, ausschliesslich
                                                 strukturierte Booleanfelder, kein Freitext.

hybrid_audit_bewertungen: ENABLE RLS, FORCE RLS, Policy auf app.current_tenant.
Mehrere Bewertungen pro Statusentscheidung sind erlaubt (append-only, kein Update/Delete
durch die Anwendung); bewertet_am + id bestimmen die neueste Bewertung.
"""
from alembic import op
import sqlalchemy as sa

revision = "012"
down_revision = "011"
branch_labels = None
depends_on = None

_APP_ROLE = "buchungatakan_app"
_DOKUMENT_KLASSEN = ("TEXT_PDF", "SCAN_PDF", "SONDERFORMAT", "UNBEKANNT")


def _enable_rls(table: str) -> None:
    op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
    op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
    op.execute(
        f"CREATE POLICY tenant_isolation ON {table} "
        f"USING (unternehmen_id::text = current_setting('app.current_tenant', true))"
    )
    op.execute(
        f"GRANT SELECT, INSERT, UPDATE, DELETE, TRUNCATE ON TABLE {table} TO {_APP_ROLE}"
    )


def upgrade() -> None:
    # --- hybrid_statusentscheidungen.dokument_klasse ---
    op.add_column(
        "hybrid_statusentscheidungen",
        sa.Column("dokument_klasse", sa.Text(), nullable=True),
    )
    op.create_check_constraint(
        "ck_hybrid_statusentscheidungen_dokument_klasse",
        "hybrid_statusentscheidungen",
        sa.text("dokument_klasse IN ('" + "', '".join(_DOKUMENT_KLASSEN) + "') OR dokument_klasse IS NULL"),
    )

    # --- hybrid_audit_bewertungen ---
    op.create_table(
        "hybrid_audit_bewertungen",
        sa.Column(
            "id", sa.UUID(),
            server_default=sa.text("gen_random_uuid()"), nullable=False,
        ),
        sa.Column("unternehmen_id", sa.UUID(), nullable=False),
        sa.Column("hybrid_statusentscheidung_id", sa.UUID(), nullable=False),
        sa.Column("rechnungsnummer_korrekt", sa.Boolean(), nullable=False),
        sa.Column("rechnungsdatum_korrekt", sa.Boolean(), nullable=False),
        sa.Column("gesamtbetrag_korrekt", sa.Boolean(), nullable=False),
        sa.Column("lieferant_korrekt", sa.Boolean(), nullable=False),
        sa.Column("steuerwerte_korrekt", sa.Boolean(), nullable=False),
        sa.Column("empfaenger_korrekt", sa.Boolean(), nullable=False),
        sa.Column(
            "bewertet_am", sa.DateTime(timezone=True),
            server_default=sa.func.now(), nullable=False,
        ),
        sa.ForeignKeyConstraint(["unternehmen_id"], ["unternehmen.id"]),
        sa.ForeignKeyConstraint(
            ["hybrid_statusentscheidung_id"], ["hybrid_statusentscheidungen.id"], ondelete="CASCADE"
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        "ix_hybrid_audit_bewertungen_unternehmen_id",
        "hybrid_audit_bewertungen", ["unternehmen_id"],
    )
    op.create_index(
        "ix_hybrid_audit_bewertungen_hybrid_statusentscheidung_id",
        "hybrid_audit_bewertungen", ["hybrid_statusentscheidung_id"],
    )
    _enable_rls("hybrid_audit_bewertungen")


def downgrade() -> None:
    op.drop_table("hybrid_audit_bewertungen")
    op.drop_constraint(
        "ck_hybrid_statusentscheidungen_dokument_klasse",
        "hybrid_statusentscheidungen", type_="check",
    )
    op.drop_column("hybrid_statusentscheidungen", "dokument_klasse")
