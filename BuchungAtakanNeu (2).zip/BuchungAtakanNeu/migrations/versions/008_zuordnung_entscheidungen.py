"""Manuelle Zuordnungsentscheidungen — Felder und BANK-05-Constraint

Revision ID: 008
Revises: 007
Create Date: 2026-06-29

Additive Migration: nur neue Spalten und Indizes, kein Drop, kein Downgrade
von Bestandsdaten. RLS und Policy bleiben unveraendert.

Neue Spalten:
  entschieden_at             TIMESTAMPTZ  — Entscheidungszeitpunkt (nullable)
  entschieden_von_benutzer_id UUID        — FK benutzer.id (nullable, BANK-Benutzerbindung)
  entscheidungsnotiz         TEXT         — optionale Notiz (nullable)

Neuer Partial Unique Index (BANK-05):
  uix_zuordnung_eine_bestaetigte_pro_buchung
  ON zuordnungsvorschlaege (unternehmen_id, bankbuchung_id)
  WHERE status = 'MANUELL_BESTAETIGT'
  → hoechstens eine aktive bestaetigte Zuordnung pro Bankbuchung und Mandant.

Kein neues GRANT: bestehende SELECT/INSERT/UPDATE/DELETE-GRANTs (Migration 007)
decken neue Spalten automatisch ab.
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "008"
down_revision: Union[str, None] = "007"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "zuordnungsvorschlaege",
        sa.Column("entschieden_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.add_column(
        "zuordnungsvorschlaege",
        sa.Column("entschieden_von_benutzer_id", sa.UUID(), nullable=True),
    )
    op.add_column(
        "zuordnungsvorschlaege",
        sa.Column("entscheidungsnotiz", sa.Text(), nullable=True),
    )
    op.create_foreign_key(
        "fk_zuordnung_entschieden_von",
        "zuordnungsvorschlaege",
        "benutzer",
        ["entschieden_von_benutzer_id"],
        ["id"],
    )

    # BANK-05: hoechstens eine MANUELL_BESTAETIGT pro (unternehmen_id, bankbuchung_id)
    op.execute(
        """
        CREATE UNIQUE INDEX uix_zuordnung_eine_bestaetigte_pro_buchung
        ON zuordnungsvorschlaege (unternehmen_id, bankbuchung_id)
        WHERE status = 'MANUELL_BESTAETIGT'
        """
    )


def downgrade() -> None:
    op.execute("DROP INDEX IF EXISTS uix_zuordnung_eine_bestaetigte_pro_buchung")
    op.drop_constraint("fk_zuordnung_entschieden_von", "zuordnungsvorschlaege", type_="foreignkey")
    op.drop_column("zuordnungsvorschlaege", "entscheidungsnotiz")
    op.drop_column("zuordnungsvorschlaege", "entschieden_von_benutzer_id")
    op.drop_column("zuordnungsvorschlaege", "entschieden_at")
