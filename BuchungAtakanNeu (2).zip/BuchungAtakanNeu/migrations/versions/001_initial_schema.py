"""Initial schema: unternehmen, benutzer, installationen

Revision ID: 001
Revises:
Create Date: 2026-06-27

"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "001"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "unternehmen",
        sa.Column("id", sa.UUID(), server_default=sa.text("gen_random_uuid()"), nullable=False),
        sa.Column("name", sa.Text(), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.PrimaryKeyConstraint("id"),
    )

    op.create_table(
        "benutzer",
        sa.Column("id", sa.UUID(), server_default=sa.text("gen_random_uuid()"), nullable=False),
        sa.Column("unternehmen_id", sa.UUID(), nullable=False),
        sa.Column("benutzername", sa.Text(), nullable=False),
        sa.Column("email", sa.Text(), nullable=True),
        sa.Column("hashed_password", sa.Text(), nullable=False),
        sa.Column(
            "rolle",
            sa.Enum(
                "SYSTEM_ADMIN", "UNTERNEHMEN_ADMIN", "BEARBEITER", "LESER",
                name="benutzer_rolle",
            ),
            nullable=False,
        ),
        sa.Column("aktiv", sa.Boolean(), server_default=sa.text("true"), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(["unternehmen_id"], ["unternehmen.id"]),
        sa.PrimaryKeyConstraint("id"),
    )

    op.create_table(
        "installationen",
        sa.Column("id", sa.UUID(), server_default=sa.text("gen_random_uuid()"), nullable=False),
        sa.Column("unternehmen_id", sa.UUID(), nullable=False),
        sa.Column("bezeichnung", sa.Text(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(["unternehmen_id"], ["unternehmen.id"]),
        sa.PrimaryKeyConstraint("id"),
    )

    op.create_index("ix_benutzer_unternehmen_id", "benutzer", ["unternehmen_id"])
    op.create_index("ix_installationen_unternehmen_id", "installationen", ["unternehmen_id"])
    op.create_index("ix_benutzer_benutzername", "benutzer", ["benutzername"], unique=True)


def downgrade() -> None:
    op.drop_index("ix_benutzer_benutzername", table_name="benutzer")
    op.drop_index("ix_installationen_unternehmen_id", table_name="installationen")
    op.drop_index("ix_benutzer_unternehmen_id", table_name="benutzer")
    op.drop_table("installationen")
    op.drop_table("benutzer")
    op.drop_table("unternehmen")
    op.execute("DROP TYPE benutzer_rolle")
