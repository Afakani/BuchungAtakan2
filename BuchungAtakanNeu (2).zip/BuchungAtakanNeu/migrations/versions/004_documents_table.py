"""Dokumenten-Tabelle mit RLS-Policy (CLI-03, CLI-05, CLI-09)

Revision ID: 004
Revises: 003
Create Date: 2026-06-28

Voraussetzung: Migration 003 muss applied sein.
  buchungatakan_app muss existieren und CONNECT-Recht auf die DB haben.

Hinweis: Migration 003 verwendet 'GRANT ON ALL TABLES' -- das gilt nur fuer
  Tabellen, die zum Zeitpunkt des Grants existieren. Diese Migration
  erteilt daher explizit GRANT fuer die neue 'dokumente'-Tabelle.
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "004"
down_revision: Union[str, None] = "003"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "dokumente",
        sa.Column(
            "id",
            sa.UUID(),
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column("unternehmen_id", sa.UUID(), nullable=False),
        sa.Column("installation_id", sa.UUID(), nullable=False),
        sa.Column("sha256", sa.Text(), nullable=False),
        sa.Column("relative_path", sa.Text(), nullable=False),
        sa.Column("dateiname", sa.Text(), nullable=False),
        sa.Column("dateigroesse", sa.Integer(), nullable=False),
        sa.Column("mime_type", sa.Text(), nullable=False),
        sa.Column(
            "verfuegbarkeit",
            sa.Text(),
            server_default="LOCAL_AVAILABLE",
            nullable=False,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(["installation_id"], ["installationen.id"]),
        sa.ForeignKeyConstraint(["unternehmen_id"], ["unternehmen.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "unternehmen_id", "sha256", name="uq_dokument_tenant_sha256"
        ),
    )
    op.create_index("ix_dokumente_unternehmen_id", "dokumente", ["unternehmen_id"])
    op.create_index("ix_dokumente_installation_id", "dokumente", ["installation_id"])

    conn = op.get_bind()
    conn.execute(sa.text(
        "GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE dokumente TO buchungatakan_app"
    ))
    conn.execute(sa.text("ALTER TABLE dokumente ENABLE ROW LEVEL SECURITY"))
    conn.execute(sa.text("ALTER TABLE dokumente FORCE ROW LEVEL SECURITY"))
    conn.execute(sa.text("""
        CREATE POLICY dokumente_tenant_isolation ON dokumente
            USING (
                unternehmen_id::text = current_setting('app.current_tenant', true)
            )
    """))


def downgrade() -> None:
    conn = op.get_bind()
    conn.execute(sa.text("DROP POLICY IF EXISTS dokumente_tenant_isolation ON dokumente"))
    op.drop_index("ix_dokumente_installation_id", table_name="dokumente")
    op.drop_index("ix_dokumente_unternehmen_id", table_name="dokumente")
    op.drop_table("dokumente")
