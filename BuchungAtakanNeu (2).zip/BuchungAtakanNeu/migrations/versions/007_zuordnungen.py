"""Zuordnungsvorschlaege fuer Bankbuchung-Rechnungs-Matching (BANK-04/08/09)

Revision ID: 007
Revises: 006
Create Date: 2026-06-29

Voraussetzung: Migration 006 muss applied sein.
  buchungatakan_app muss existieren.

Signale als JSON gespeichert: kleinste sichere Loesung fuer Paket 2.
  Vorteil: kein zusaetzliches Tabellen-JOIN fuer Signal-Anzeige.
  Nachteil: kein Index auf einzelne Signalfelder.
  Fuer Paket 2 ausreichend.
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "007"
down_revision: Union[str, None] = "006"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

_APP_ROLE = "buchungatakan_app"


def upgrade() -> None:
    op.create_table(
        "zuordnungsvorschlaege",
        sa.Column("id", sa.UUID(), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("unternehmen_id", sa.UUID(), nullable=False),
        sa.Column("bankbuchung_id", sa.UUID(), nullable=False),
        sa.Column("rechnung_id", sa.UUID(), nullable=False),
        sa.Column("score", sa.Integer(), nullable=False),
        sa.Column("status", sa.Text(), nullable=False),
        # JSON: Liste von Signal-Dicts {typ, beschreibung, punkte}
        sa.Column("positive_signale", sa.JSON(), nullable=False, server_default=sa.text("'[]'::json")),
        sa.Column("negative_signale", sa.JSON(), nullable=False, server_default=sa.text("'[]'::json")),
        sa.Column("matcher_version", sa.Text(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.ForeignKeyConstraint(["unternehmen_id"], ["unternehmen.id"]),
        sa.ForeignKeyConstraint(["bankbuchung_id"], ["bankbuchungen.id"]),
        sa.ForeignKeyConstraint(["rechnung_id"], ["rechnungen.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "unternehmen_id", "bankbuchung_id", "rechnung_id",
            name="uq_zuordnung_tenant_buchung_rechnung",
        ),
    )
    op.create_index("ix_zuordnungsvorschlaege_unternehmen_id", "zuordnungsvorschlaege", ["unternehmen_id"])
    op.create_index("ix_zuordnungsvorschlaege_bankbuchung_id", "zuordnungsvorschlaege", ["bankbuchung_id"])
    op.create_index("ix_zuordnungsvorschlaege_rechnung_id", "zuordnungsvorschlaege", ["rechnung_id"])
    op.create_index("ix_zuordnungsvorschlaege_status", "zuordnungsvorschlaege", ["status"])

    op.execute(f"GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE zuordnungsvorschlaege TO {_APP_ROLE}")

    op.execute("ALTER TABLE zuordnungsvorschlaege ENABLE ROW LEVEL SECURITY")
    op.execute("ALTER TABLE zuordnungsvorschlaege FORCE ROW LEVEL SECURITY")
    op.execute(
        "CREATE POLICY tenant_isolation ON zuordnungsvorschlaege "
        "USING (unternehmen_id::text = current_setting('app.current_tenant', true))"
    )


def downgrade() -> None:
    op.execute("DROP POLICY IF EXISTS tenant_isolation ON zuordnungsvorschlaege")
    op.drop_index("ix_zuordnungsvorschlaege_status", table_name="zuordnungsvorschlaege")
    op.drop_index("ix_zuordnungsvorschlaege_rechnung_id", table_name="zuordnungsvorschlaege")
    op.drop_index("ix_zuordnungsvorschlaege_bankbuchung_id", table_name="zuordnungsvorschlaege")
    op.drop_index("ix_zuordnungsvorschlaege_unternehmen_id", table_name="zuordnungsvorschlaege")
    op.drop_table("zuordnungsvorschlaege")
