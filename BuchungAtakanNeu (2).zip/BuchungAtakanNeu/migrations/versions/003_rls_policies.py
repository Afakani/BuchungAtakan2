"""RLS-Policies fuer Mandantenisolation (unternehmen, benutzer, installationen)

Revision ID: 003
Revises: 002
Create Date: 2026-06-27

Voraussetzung: Die Rolle 'buchungatakan_app' muss VOR dieser Migration existieren.
  Einmalig manuell als Superuser erstellen:
    CREATE ROLE buchungatakan_app LOGIN PASSWORD '<sicheres_passwort>';
  Diese Migration legt KEIN Passwort fest und erstellt die Rolle NICHT.

Direktzugriff-Modell fuer public.benutzer:
  buchungatakan_app hat KEINEN direkten Tabellenzugriff auf benutzer.
  Nach dem initialen GRANT ON ALL TABLES wird benutzer explizit revoked.
  Zugriff ausschliesslich ueber SECURITY DEFINER-Funktionen (auth_benutzer_by_*),
  die als Migrations-User (BYPASSRLS/Superuser) ausgefuehrt werden.

  auth_benutzer_by_name  -- Login-Lookup (kein Tenant-Filter noetig: benutzername UNIQUE)
  auth_benutzer_by_id    -- Token-Validierung: prueft id + unternehmen_id + aktiv=true
                           (verhindert Cross-Tenant-Lookup mit fremder Benutzer-UUID)
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "003"
down_revision: Union[str, None] = "002"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    conn = op.get_bind()

    # Grundrechte fuer buchungatakan_app auf aktuelle DB.
    # SCHLAEGT FEHL wenn buchungatakan_app nicht existiert (erwuenscht: Voraussetzung klar).
    conn.execute(sa.text("""
        DO $$
        BEGIN
          EXECUTE format(
            'GRANT CONNECT ON DATABASE %I TO buchungatakan_app',
            current_database()
          );
        END $$;
    """))
    conn.execute(sa.text(
        "GRANT SELECT, INSERT, UPDATE, DELETE "
        "ON ALL TABLES IN SCHEMA public TO buchungatakan_app"
    ))
    conn.execute(sa.text(
        "GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO buchungatakan_app"
    ))

    # Direktzugriff auf benutzer entziehen -- buchungatakan_app greift nur
    # ueber die unten definierten SECURITY DEFINER-Funktionen auf benutzer zu.
    conn.execute(sa.text(
        "REVOKE ALL ON TABLE public.benutzer FROM buchungatakan_app"
    ))

    # RLS auf unternehmen (Tenant-Root: id IS der Mandant, kein unternehmen_id-FK).
    conn.execute(sa.text("ALTER TABLE unternehmen ENABLE ROW LEVEL SECURITY"))
    conn.execute(sa.text("ALTER TABLE unternehmen FORCE ROW LEVEL SECURITY"))
    conn.execute(sa.text("""
        CREATE POLICY unternehmen_tenant_isolation ON unternehmen
            USING (id::text = current_setting('app.current_tenant', true))
    """))

    # SECURITY DEFINER: Auth-Lookups auf public.benutzer.
    # search_path = pg_catalog schliesst public aus -- verhindert search_path-Injection.
    # Tabelle immer als public.benutzer schemaqualifiziert referenzieren.
    conn.execute(sa.text("""
        CREATE FUNCTION auth_benutzer_by_name(p_name text)
        RETURNS TABLE(
            id uuid, hashed_password text,
            unternehmen_id uuid, rolle text, aktiv boolean
        )
        LANGUAGE sql SECURITY DEFINER
        SET search_path = pg_catalog
        AS $$
            SELECT id, hashed_password, unternehmen_id, rolle::text, aktiv
            FROM public.benutzer
            WHERE benutzername = p_name;
        $$
    """))
    conn.execute(sa.text("""
        CREATE FUNCTION auth_benutzer_by_id(p_id uuid, p_unternehmen_id uuid)
        RETURNS TABLE(id uuid, unternehmen_id uuid, rolle text, aktiv boolean)
        LANGUAGE sql SECURITY DEFINER
        SET search_path = pg_catalog
        AS $$
            SELECT id, unternehmen_id, rolle::text, aktiv
            FROM public.benutzer
            WHERE id = p_id
              AND unternehmen_id = p_unternehmen_id
              AND aktiv = true;
        $$
    """))
    conn.execute(sa.text("REVOKE ALL ON FUNCTION auth_benutzer_by_name(text) FROM PUBLIC"))
    conn.execute(sa.text("REVOKE ALL ON FUNCTION auth_benutzer_by_id(uuid, uuid) FROM PUBLIC"))
    conn.execute(sa.text(
        "GRANT EXECUTE ON FUNCTION auth_benutzer_by_name(text) TO buchungatakan_app"
    ))
    conn.execute(sa.text(
        "GRANT EXECUTE ON FUNCTION auth_benutzer_by_id(uuid, uuid) TO buchungatakan_app"
    ))

    # RLS auf benutzer: ENABLE ohne FORCE.
    # buchungatakan_app hat ohnehin keinen Direktzugriff (s.o. REVOKE).
    # FORCE wird nicht gesetzt: Migrations-User (Tabellenowner) muss uneingeschraenkt
    # auf benutzer zugreifen koennen (z.B. fuer spaetere Migrationen).
    conn.execute(sa.text("ALTER TABLE benutzer ENABLE ROW LEVEL SECURITY"))
    conn.execute(sa.text("""
        CREATE POLICY benutzer_tenant_isolation ON benutzer
            USING (
                unternehmen_id::text = current_setting('app.current_tenant', true)
            )
    """))

    # RLS auf installationen
    conn.execute(sa.text("ALTER TABLE installationen ENABLE ROW LEVEL SECURITY"))
    conn.execute(sa.text("ALTER TABLE installationen FORCE ROW LEVEL SECURITY"))
    conn.execute(sa.text("""
        CREATE POLICY installationen_tenant_isolation ON installationen
            USING (
                unternehmen_id::text = current_setting('app.current_tenant', true)
            )
    """))


def downgrade() -> None:
    conn = op.get_bind()

    conn.execute(sa.text("DROP POLICY IF EXISTS unternehmen_tenant_isolation ON unternehmen"))
    conn.execute(sa.text("ALTER TABLE unternehmen DISABLE ROW LEVEL SECURITY"))

    conn.execute(sa.text("DROP FUNCTION IF EXISTS auth_benutzer_by_name(text)"))
    conn.execute(sa.text("DROP FUNCTION IF EXISTS auth_benutzer_by_id(uuid, uuid)"))

    # Direktzugriff auf benutzer wiederherstellen (wurde in upgrade() revoked).
    conn.execute(sa.text(
        "GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.benutzer TO buchungatakan_app"
    ))

    conn.execute(sa.text("DROP POLICY IF EXISTS benutzer_tenant_isolation ON benutzer"))
    conn.execute(sa.text("ALTER TABLE benutzer DISABLE ROW LEVEL SECURITY"))

    conn.execute(sa.text("DROP POLICY IF EXISTS installationen_tenant_isolation ON installationen"))
    conn.execute(sa.text("ALTER TABLE installationen DISABLE ROW LEVEL SECURITY"))
    # buchungatakan_app-Rolle wird nicht geloescht (additive Operation auf Cluster-Ebene)
