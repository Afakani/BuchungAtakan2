"""Tenant-Konsistenz: Composite UNIQUE + Composite FK fuer Bank-Tabellen

Revision ID: 009
Revises: 008
Create Date: 2026-06-29

Additive Migration — kein Drop, kein Downgrade von Bestandsdaten.
RLS und bestehende einfache FKs bleiben unveraendert.

Neue Constraints:
  bankkonten:          UNIQUE (id, unternehmen_id)      — als Composite-FK-Ziel
  kontoauszugsimporte: UNIQUE (id, unternehmen_id)      — als Composite-FK-Ziel
  kontoauszugsimporte: FK (bankkonto_id, unternehmen_id) → bankkonten(id, unternehmen_id)
  bankbuchungen:       FK (bankkonto_id, unternehmen_id) → bankkonten(id, unternehmen_id)
  bankbuchungen:       FK (import_id, unternehmen_id)   → kontoauszugsimporte(id, unternehmen_id)

Wirkung: DB lehnt Cross-Tenant-Referenzen ab, auch wenn RLS umgangen wird.
"""
from typing import Sequence, Union

from alembic import op

revision: str = "009"
down_revision: Union[str, None] = "008"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # bankkonten: UNIQUE (id, unternehmen_id) — wird als FK-Ziel benoetigt
    op.create_unique_constraint(
        "uq_bankkonten_id_unternehmen", "bankkonten", ["id", "unternehmen_id"]
    )

    # kontoauszugsimporte: UNIQUE (id, unternehmen_id) — wird als FK-Ziel benoetigt
    op.create_unique_constraint(
        "uq_kontoauszugsimporte_id_unternehmen", "kontoauszugsimporte", ["id", "unternehmen_id"]
    )

    # kontoauszugsimporte → bankkonten (Composite FK: Tenant muss uebereinstimmen)
    op.create_foreign_key(
        "fk_kontoauszugsimporte_bankkonto_tenant",
        "kontoauszugsimporte",
        "bankkonten",
        ["bankkonto_id", "unternehmen_id"],
        ["id", "unternehmen_id"],
    )

    # bankbuchungen → bankkonten (Composite FK: Tenant muss uebereinstimmen)
    op.create_foreign_key(
        "fk_bankbuchungen_bankkonto_tenant",
        "bankbuchungen",
        "bankkonten",
        ["bankkonto_id", "unternehmen_id"],
        ["id", "unternehmen_id"],
    )

    # bankbuchungen → kontoauszugsimporte (Composite FK: Tenant muss uebereinstimmen)
    op.create_foreign_key(
        "fk_bankbuchungen_import_tenant",
        "bankbuchungen",
        "kontoauszugsimporte",
        ["import_id", "unternehmen_id"],
        ["id", "unternehmen_id"],
    )


def downgrade() -> None:
    op.drop_constraint("fk_bankbuchungen_import_tenant", "bankbuchungen", type_="foreignkey")
    op.drop_constraint("fk_bankbuchungen_bankkonto_tenant", "bankbuchungen", type_="foreignkey")
    op.drop_constraint("fk_kontoauszugsimporte_bankkonto_tenant", "kontoauszugsimporte", type_="foreignkey")
    op.drop_constraint("uq_kontoauszugsimporte_id_unternehmen", "kontoauszugsimporte", type_="unique")
    op.drop_constraint("uq_bankkonten_id_unternehmen", "bankkonten", type_="unique")
