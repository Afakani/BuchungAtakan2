"""EC-Sammelzuordnung — Datenmodell Phase 06, Paket 1+2

Revision ID: 010
Revises: 009
Create Date: 2026-06-29

Neue Tabellen (alle additiv, kein Drop, kein Downgrade von Phase-5-Daten):
  ec_belege                  — Einzelne EC-Kartenbelege (betrag_cent INTEGER)
  ec_sammellaeufe            — Protokoll eines Gruppierungslaufs
  ec_sammelzuordnungen       — Vorschlag oder Entscheidung (STARK/UNSICHER/MANUELL_*)
  ec_sammelzuordnung_belege  — Bruecke Zuordnung <-> Beleg (mit Rolle)

Alle Tabellen:
  ENABLE ROW LEVEL SECURITY + FORCE ROW LEVEL SECURITY
  Tenant-Policy analog zu Phase 5
  Composite UNIQUE (id, unternehmen_id) als FK-Ziele
  Composite FKs fuer Cross-Tenant-Sicherheit

Partial Unique Indizes:
  uix_ec_szb_aktive_belegverwendung          — kein Beleg AKTIV in zwei Zuordnungen gleichzeitig
  uix_ec_sammelz_eine_bestaetigte_pro_buchung — max. eine MANUELL_BESTAETIGT pro Buchung
  uix_ec_sammelz_eine_auto_pro_buchung        — max. eine AUTO-Zuordnung pro Buchung (Paket 2)

Paket 2-Spalten in ec_belege:
  bankkonto_id, import_fingerprint, waehrung, dokument_id,
  belegzeit, terminal_id, quell_position, transaktionsreferenz

Paket 2-Spalten in ec_sammelzuordnungen:
  gruppen_fingerprint, bankkonto_id, einzahlung_cent,
  positive_signale, negative_signale, fenster_von, fenster_bis, max_verzoegerung_tage
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "010"
down_revision: Union[str, None] = "009"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

_APP_ROLE = "buchungatakan_app"

_TENANT_POLICY = (
    "USING (unternehmen_id::text = current_setting('app.current_tenant', true))"
)


def _rls(table: str) -> None:
    op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
    op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
    op.execute(
        f"CREATE POLICY tenant_isolation ON {table} {_TENANT_POLICY}"
    )
    op.execute(
        f"GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE {table} TO {_APP_ROLE}"
    )


def upgrade() -> None:
    # bankbuchungen: UNIQUE (id, unternehmen_id) — wird als Composite-FK-Ziel benoetigt
    op.create_unique_constraint(
        "uq_bankbuchungen_id_unternehmen", "bankbuchungen", ["id", "unternehmen_id"]
    )

    # ── ec_belege ─────────────────────────────────────────────────────────────
    op.create_table(
        "ec_belege",
        sa.Column("id", sa.UUID(), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("unternehmen_id", sa.UUID(), nullable=False),
        sa.Column("bankkonto_id", sa.UUID(), nullable=False),
        sa.Column("betrag_cent", sa.Integer(), nullable=False),
        sa.Column("buchungsdatum", sa.Date(), nullable=False),
        sa.Column("zahlungskategorie", sa.Text(), nullable=False, server_default=sa.text("'UNBEKANNT'")),
        sa.Column("original_kategorie", sa.Text(), nullable=True),
        sa.Column("status", sa.Text(), nullable=False, server_default=sa.text("'VERFUEGBAR'")),
        sa.Column("waehrung", sa.Text(), nullable=False, server_default=sa.text("'EUR'")),
        sa.Column("import_fingerprint", sa.Text(), nullable=False),
        sa.Column("quelldatei", sa.Text(), nullable=True),
        sa.Column("quell_position", sa.Text(), nullable=True),
        sa.Column("transaktionsreferenz", sa.Text(), nullable=True),
        sa.Column("terminal_id", sa.Text(), nullable=True),
        sa.Column("belegzeit", sa.Text(), nullable=True),
        sa.Column("dokument_id", sa.UUID(), nullable=True),
        sa.Column("externe_id", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.ForeignKeyConstraint(["unternehmen_id"], ["unternehmen.id"]),
        sa.ForeignKeyConstraint(["bankkonto_id"], ["bankkonten.id"]),
        sa.ForeignKeyConstraint(["dokument_id"], ["dokumente.id"]),
        sa.ForeignKeyConstraint(
            ["bankkonto_id", "unternehmen_id"],
            ["bankkonten.id", "bankkonten.unternehmen_id"],
            name="fk_ec_belege_bankkonto_tenant",
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("id", "unternehmen_id", name="uq_ec_belege_id_unternehmen"),
        sa.UniqueConstraint("unternehmen_id", "import_fingerprint", name="uq_ec_beleg_import_fingerprint"),
    )
    op.create_index("ix_ec_belege_unternehmen_id", "ec_belege", ["unternehmen_id"])
    op.create_index("ix_ec_belege_bankkonto_id", "ec_belege", ["bankkonto_id"])
    op.create_index("ix_ec_belege_buchungsdatum", "ec_belege", ["buchungsdatum"])
    op.create_index("ix_ec_belege_zahlungskategorie", "ec_belege", ["zahlungskategorie"])
    op.create_index("ix_ec_belege_status", "ec_belege", ["status"])
    _rls("ec_belege")

    # ── ec_sammellaeufe ───────────────────────────────────────────────────────
    op.create_table(
        "ec_sammellaeufe",
        sa.Column("id", sa.UUID(), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("unternehmen_id", sa.UUID(), nullable=False),
        sa.Column("bankbuchung_id", sa.UUID(), nullable=False),
        sa.Column("matcher_version", sa.Text(), nullable=False),
        sa.Column(
            "lauf_zeitpunkt",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.ForeignKeyConstraint(["unternehmen_id"], ["unternehmen.id"]),
        sa.ForeignKeyConstraint(["bankbuchung_id"], ["bankbuchungen.id"]),
        sa.ForeignKeyConstraint(
            ["bankbuchung_id", "unternehmen_id"],
            ["bankbuchungen.id", "bankbuchungen.unternehmen_id"],
            name="fk_ec_sammellaeufe_bankbuchung_tenant",
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("id", "unternehmen_id", name="uq_ec_sammellaeufe_id_unternehmen"),
    )
    op.create_index("ix_ec_sammellaeufe_unternehmen_id", "ec_sammellaeufe", ["unternehmen_id"])
    op.create_index("ix_ec_sammellaeufe_bankbuchung_id", "ec_sammellaeufe", ["bankbuchung_id"])
    _rls("ec_sammellaeufe")

    # ── ec_sammelzuordnungen ──────────────────────────────────────────────────
    op.create_table(
        "ec_sammelzuordnungen",
        sa.Column("id", sa.UUID(), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("unternehmen_id", sa.UUID(), nullable=False),
        sa.Column("sammellauf_id", sa.UUID(), nullable=False),
        sa.Column("bankbuchung_id", sa.UUID(), nullable=False),
        sa.Column("bankkonto_id", sa.UUID(), nullable=False),
        sa.Column("gruppen_fingerprint", sa.Text(), nullable=False, server_default=sa.text("''")),
        sa.Column("score", sa.Integer(), nullable=False),
        sa.Column("status", sa.Text(), nullable=False),
        sa.Column("summe_cent", sa.Integer(), nullable=False),
        sa.Column("einzahlung_cent", sa.Integer(), nullable=False, server_default=sa.text("0")),
        sa.Column("differenz_cent", sa.Integer(), nullable=False),
        sa.Column("positive_signale", sa.JSON(), nullable=False, server_default=sa.text("'[]'::json")),
        sa.Column("negative_signale", sa.JSON(), nullable=False, server_default=sa.text("'[]'::json")),
        sa.Column("matcher_version", sa.Text(), nullable=False),
        sa.Column("max_verzoegerung_tage", sa.Integer(), nullable=False, server_default=sa.text("2")),
        sa.Column("fenster_von", sa.Date(), nullable=True),
        sa.Column("fenster_bis", sa.Date(), nullable=True),
        sa.Column("entschieden_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("entschieden_von_benutzer_id", sa.UUID(), nullable=True),
        sa.Column("entscheidungsnotiz", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.ForeignKeyConstraint(["unternehmen_id"], ["unternehmen.id"]),
        sa.ForeignKeyConstraint(["sammellauf_id"], ["ec_sammellaeufe.id"]),
        sa.ForeignKeyConstraint(["bankbuchung_id"], ["bankbuchungen.id"]),
        sa.ForeignKeyConstraint(["bankkonto_id"], ["bankkonten.id"]),
        sa.ForeignKeyConstraint(["entschieden_von_benutzer_id"], ["benutzer.id"]),
        sa.ForeignKeyConstraint(
            ["sammellauf_id", "unternehmen_id"],
            ["ec_sammellaeufe.id", "ec_sammellaeufe.unternehmen_id"],
            name="fk_ec_sammelzuordnungen_sammellauf_tenant",
        ),
        sa.ForeignKeyConstraint(
            ["bankbuchung_id", "unternehmen_id"],
            ["bankbuchungen.id", "bankbuchungen.unternehmen_id"],
            name="fk_ec_sammelzuordnungen_bankbuchung_tenant",
        ),
        sa.ForeignKeyConstraint(
            ["bankkonto_id", "unternehmen_id"],
            ["bankkonten.id", "bankkonten.unternehmen_id"],
            name="fk_ec_sammelzuordnungen_bankkonto_tenant",
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("id", "unternehmen_id", name="uq_ec_sammelzuordnungen_id_unternehmen"),
    )
    op.create_index("ix_ec_sammelzuordnungen_unternehmen_id", "ec_sammelzuordnungen", ["unternehmen_id"])
    op.create_index("ix_ec_sammelzuordnungen_sammellauf_id", "ec_sammelzuordnungen", ["sammellauf_id"])
    op.create_index("ix_ec_sammelzuordnungen_bankbuchung_id", "ec_sammelzuordnungen", ["bankbuchung_id"])
    op.create_index("ix_ec_sammelzuordnungen_bankkonto_id", "ec_sammelzuordnungen", ["bankkonto_id"])
    op.create_index("ix_ec_sammelzuordnungen_status", "ec_sammelzuordnungen", ["status"])

    # Partial Unique Index: hoechstens eine MANUELL_BESTAETIGT pro Buchung
    op.execute("""
        CREATE UNIQUE INDEX uix_ec_sammelz_eine_bestaetigte_pro_buchung
        ON ec_sammelzuordnungen (unternehmen_id, bankbuchung_id)
        WHERE status = 'MANUELL_BESTAETIGT'
    """)

    # Partial Unique Index: hoechstens eine AUTO-Zuordnung (Paket 2, Idempotenz)
    op.execute("""
        CREATE UNIQUE INDEX uix_ec_sammelz_eine_auto_pro_buchung
        ON ec_sammelzuordnungen (unternehmen_id, bankbuchung_id)
        WHERE status NOT IN ('MANUELL_BESTAETIGT', 'MANUELL_ABGELEHNT')
    """)

    _rls("ec_sammelzuordnungen")

    # ── ec_sammelzuordnung_belege ─────────────────────────────────────────────
    op.create_table(
        "ec_sammelzuordnung_belege",
        sa.Column("id", sa.UUID(), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("unternehmen_id", sa.UUID(), nullable=False),
        sa.Column("zuordnung_id", sa.UUID(), nullable=False),
        sa.Column("beleg_id", sa.UUID(), nullable=False),
        sa.Column("rolle", sa.Text(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.ForeignKeyConstraint(["unternehmen_id"], ["unternehmen.id"]),
        sa.ForeignKeyConstraint(["zuordnung_id"], ["ec_sammelzuordnungen.id"]),
        sa.ForeignKeyConstraint(["beleg_id"], ["ec_belege.id"]),
        sa.ForeignKeyConstraint(
            ["zuordnung_id", "unternehmen_id"],
            ["ec_sammelzuordnungen.id", "ec_sammelzuordnungen.unternehmen_id"],
            name="fk_ec_szb_zuordnung_tenant",
        ),
        sa.ForeignKeyConstraint(
            ["beleg_id", "unternehmen_id"],
            ["ec_belege.id", "ec_belege.unternehmen_id"],
            name="fk_ec_szb_beleg_tenant",
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "unternehmen_id", "zuordnung_id", "beleg_id",
            name="uq_ec_szb_zuordnung_beleg",
        ),
    )
    op.create_index("ix_ec_sammelzuordnung_belege_unternehmen_id", "ec_sammelzuordnung_belege", ["unternehmen_id"])
    op.create_index("ix_ec_sammelzuordnung_belege_zuordnung_id", "ec_sammelzuordnung_belege", ["zuordnung_id"])
    op.create_index("ix_ec_sammelzuordnung_belege_beleg_id", "ec_sammelzuordnung_belege", ["beleg_id"])

    # Partial Unique Index: kein Beleg gleichzeitig AKTIV in zwei Zuordnungen
    op.execute("""
        CREATE UNIQUE INDEX uix_ec_szb_aktive_belegverwendung
        ON ec_sammelzuordnung_belege (unternehmen_id, beleg_id)
        WHERE rolle = 'AKTIV'
    """)

    _rls("ec_sammelzuordnung_belege")


def downgrade() -> None:
    op.execute("DROP POLICY IF EXISTS tenant_isolation ON ec_sammelzuordnung_belege")

    op.execute("DROP INDEX IF EXISTS uix_ec_szb_aktive_belegverwendung")
    op.execute("DROP INDEX IF EXISTS ix_ec_sammelzuordnung_belege_beleg_id")
    op.execute("DROP INDEX IF EXISTS ix_ec_sammelzuordnung_belege_zuordnung_id")
    op.execute("DROP INDEX IF EXISTS ix_ec_sammelzuordnung_belege_unternehmen_id")
    op.drop_table("ec_sammelzuordnung_belege")

    op.execute("DROP POLICY IF EXISTS tenant_isolation ON ec_sammelzuordnungen")
    op.execute("DROP INDEX IF EXISTS uix_ec_sammelz_eine_auto_pro_buchung")
    op.execute("DROP INDEX IF EXISTS uix_ec_sammelz_eine_bestaetigte_pro_buchung")
    op.drop_index("ix_ec_sammelzuordnungen_status", table_name="ec_sammelzuordnungen")
    op.drop_index("ix_ec_sammelzuordnungen_bankkonto_id", table_name="ec_sammelzuordnungen")
    op.drop_index("ix_ec_sammelzuordnungen_bankbuchung_id", table_name="ec_sammelzuordnungen")
    op.drop_index("ix_ec_sammelzuordnungen_sammellauf_id", table_name="ec_sammelzuordnungen")
    op.drop_index("ix_ec_sammelzuordnungen_unternehmen_id", table_name="ec_sammelzuordnungen")
    op.drop_table("ec_sammelzuordnungen")

    op.execute("DROP POLICY IF EXISTS tenant_isolation ON ec_sammellaeufe")
    op.drop_index("ix_ec_sammellaeufe_bankbuchung_id", table_name="ec_sammellaeufe")
    op.drop_index("ix_ec_sammellaeufe_unternehmen_id", table_name="ec_sammellaeufe")
    op.drop_table("ec_sammellaeufe")

    op.execute("DROP POLICY IF EXISTS tenant_isolation ON ec_belege")
    op.drop_index("ix_ec_belege_status", table_name="ec_belege")
    op.drop_index("ix_ec_belege_zahlungskategorie", table_name="ec_belege")
    op.drop_index("ix_ec_belege_buchungsdatum", table_name="ec_belege")
    op.drop_index("ix_ec_belege_bankkonto_id", table_name="ec_belege")
    op.drop_index("ix_ec_belege_unternehmen_id", table_name="ec_belege")
    op.drop_table("ec_belege")

    op.drop_constraint("uq_bankbuchungen_id_unternehmen", "bankbuchungen", type_="unique")
