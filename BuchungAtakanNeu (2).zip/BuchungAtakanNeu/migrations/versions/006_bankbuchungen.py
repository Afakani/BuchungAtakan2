"""Bankkonten, Kontoauszugsimporte, Bankbuchungen (BANK-01..03/BANK-10/BANK-11)

Revision ID: 006
Revises: 005
Create Date: 2026-06-29

Voraussetzung: Migration 005 muss applied sein.
  buchungatakan_app muss existieren und CONNECT-Recht haben.

Hinweis: Explizite GRANTs noetig — GRANT ON ALL TABLES aus 003 gilt
  nicht fuer spaeter erstellte Tabellen.
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "006"
down_revision: Union[str, None] = "005"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

_APP_ROLE = "buchungatakan_app"


def upgrade() -> None:
    # --- bankkonten ---
    op.create_table(
        "bankkonten",
        sa.Column("id", sa.UUID(), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("unternehmen_id", sa.UUID(), nullable=False),
        sa.Column("anzeigename", sa.Text(), nullable=False),
        sa.Column("iban_masked", sa.Text(), nullable=True),
        sa.Column("bic", sa.Text(), nullable=True),
        sa.Column("ist_aktiv", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.ForeignKeyConstraint(["unternehmen_id"], ["unternehmen.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_bankkonten_unternehmen_id", "bankkonten", ["unternehmen_id"])

    # --- kontoauszugsimporte ---
    op.create_table(
        "kontoauszugsimporte",
        sa.Column("id", sa.UUID(), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("unternehmen_id", sa.UUID(), nullable=False),
        sa.Column("bankkonto_id", sa.UUID(), nullable=False),
        sa.Column("quell_referenz", sa.Text(), nullable=True),
        sa.Column("import_fingerprint", sa.Text(), nullable=True),
        sa.Column("zeitraum_von", sa.Date(), nullable=True),
        sa.Column("zeitraum_bis", sa.Date(), nullable=True),
        sa.Column("buchungen_uebergeben", sa.Integer(), nullable=False, server_default=sa.text("0")),
        sa.Column("buchungen_uebernommen", sa.Integer(), nullable=False, server_default=sa.text("0")),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.ForeignKeyConstraint(["unternehmen_id"], ["unternehmen.id"]),
        sa.ForeignKeyConstraint(["bankkonto_id"], ["bankkonten.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_kontoauszugsimporte_unternehmen_id", "kontoauszugsimporte", ["unternehmen_id"])
    op.create_index("ix_kontoauszugsimporte_bankkonto_id", "kontoauszugsimporte", ["bankkonto_id"])

    # --- bankbuchungen ---
    # betrag_cent ist INTEGER — kein REAL, kein FLOAT (BANK-10)
    op.create_table(
        "bankbuchungen",
        sa.Column("id", sa.UUID(), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("unternehmen_id", sa.UUID(), nullable=False),
        sa.Column("bankkonto_id", sa.UUID(), nullable=False),
        sa.Column("import_id", sa.UUID(), nullable=False),
        sa.Column("buchungsdatum", sa.Date(), nullable=False),
        sa.Column("wertstellungsdatum", sa.Date(), nullable=True),
        sa.Column("betrag_cent", sa.Integer(), nullable=False),
        sa.Column("waehrung", sa.Text(), nullable=False, server_default=sa.text("'EUR'")),
        sa.Column("verwendungszweck", sa.Text(), nullable=True),
        sa.Column("gegenpartei_name", sa.Text(), nullable=True),
        sa.Column("gegenpartei_iban", sa.Text(), nullable=True),
        sa.Column("gegenpartei_bic", sa.Text(), nullable=True),
        sa.Column("externe_buchungs_id", sa.Text(), nullable=True),
        sa.Column("dedup_fingerprint", sa.Text(), nullable=False),
        sa.Column("klassifikation", sa.Text(), nullable=False, server_default=sa.text("'MATCHBAR'")),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.ForeignKeyConstraint(["unternehmen_id"], ["unternehmen.id"]),
        sa.ForeignKeyConstraint(["bankkonto_id"], ["bankkonten.id"]),
        sa.ForeignKeyConstraint(["import_id"], ["kontoauszugsimporte.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("dedup_fingerprint", name="uq_bankbuchung_fingerprint"),
    )
    op.create_index("ix_bankbuchungen_unternehmen_id", "bankbuchungen", ["unternehmen_id"])
    op.create_index("ix_bankbuchungen_bankkonto_id", "bankbuchungen", ["bankkonto_id"])
    op.create_index("ix_bankbuchungen_import_id", "bankbuchungen", ["import_id"])
    op.create_index("ix_bankbuchungen_buchungsdatum", "bankbuchungen", ["buchungsdatum"])
    op.create_index("ix_bankbuchungen_klassifikation", "bankbuchungen", ["klassifikation"])

    # GRANTs fuer buchungatakan_app (explizit, da GRANT ON ALL TABLES aus 003 nicht greift)
    for table in ("bankkonten", "kontoauszugsimporte", "bankbuchungen"):
        op.execute(f"GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE {table} TO {_APP_ROLE}")

    # RLS: ENABLE + FORCE + Tenant-Isolation-Policy
    for table in ("bankkonten", "kontoauszugsimporte", "bankbuchungen"):
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
        op.execute(
            f"CREATE POLICY tenant_isolation ON {table} "
            f"USING (unternehmen_id::text = current_setting('app.current_tenant', true))"
        )


def downgrade() -> None:
    for table in ("bankkonten", "kontoauszugsimporte", "bankbuchungen"):
        op.execute(f"DROP POLICY IF EXISTS tenant_isolation ON {table}")

    op.drop_index("ix_bankbuchungen_klassifikation", table_name="bankbuchungen")
    op.drop_index("ix_bankbuchungen_buchungsdatum", table_name="bankbuchungen")
    op.drop_index("ix_bankbuchungen_import_id", table_name="bankbuchungen")
    op.drop_index("ix_bankbuchungen_bankkonto_id", table_name="bankbuchungen")
    op.drop_index("ix_bankbuchungen_unternehmen_id", table_name="bankbuchungen")
    op.drop_table("bankbuchungen")

    op.drop_index("ix_kontoauszugsimporte_bankkonto_id", table_name="kontoauszugsimporte")
    op.drop_index("ix_kontoauszugsimporte_unternehmen_id", table_name="kontoauszugsimporte")
    op.drop_table("kontoauszugsimporte")

    op.drop_index("ix_bankkonten_unternehmen_id", table_name="bankkonten")
    op.drop_table("bankkonten")
