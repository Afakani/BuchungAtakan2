"""Hybrid-Rechnungsextraktion — Phase 07-01 (HYB-07/08)

Revision ID: 011
Revises: 010
Create Date: 2026-07-01

Neue Tabellen (alle additiv, kein Drop):
  hybrid_erkennungslaeufe      — Protokoll eines Provider-Laufs
  hybrid_kandidaten            — HybridKandidat mit vollstaendiger Herkunft
  hybrid_konflikte             — Explizite Konflikte zwischen Kandidaten
  hybrid_statusentscheidungen  — Statusentscheidung je Erkennungslauf

Alle Tabellen: ENABLE RLS, FORCE RLS, Policy auf app.current_tenant.
erkennungslauf_id nullable (Verlinkung auf Phase-04 Erkennungslaeufe optional).
"""
from alembic import op
import sqlalchemy as sa

revision = "011"
down_revision = "010"
branch_labels = None
depends_on = None

_APP_ROLE = "buchungatakan_app"


def _enable_rls(table: str) -> None:
    op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
    op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
    op.execute(
        f"CREATE POLICY tenant_isolation ON {table} "
        f"USING (unternehmen_id::text = current_setting('app.current_tenant', true))"
    )
    op.execute(
        f"GRANT SELECT, INSERT, UPDATE, DELETE, TRUNCATE ON TABLE {table} TO {_APP_ROLE}"
    )


def upgrade() -> None:
    # --- hybrid_erkennungslaeufe ---
    op.create_table(
        "hybrid_erkennungslaeufe",
        sa.Column(
            "id", sa.UUID(),
            server_default=sa.text("gen_random_uuid()"), nullable=False,
        ),
        sa.Column("unternehmen_id", sa.UUID(), nullable=False),
        sa.Column("erkennungslauf_id", sa.UUID(), nullable=True),
        sa.Column("provider_name", sa.Text(), nullable=False),
        sa.Column("provider_version", sa.Text(), nullable=True),
        sa.Column("laufstatus", sa.Text(), nullable=False),
        sa.Column("fehlercode", sa.Text(), nullable=True),
        sa.Column("lauf_dauer_ms", sa.Integer(), nullable=True),
        sa.Column("seiten_anzahl", sa.Integer(), nullable=True),
        sa.Column(
            "created_at", sa.DateTime(timezone=True),
            server_default=sa.func.now(), nullable=False,
        ),
        sa.ForeignKeyConstraint(["unternehmen_id"], ["unternehmen.id"]),
        sa.ForeignKeyConstraint(
            ["erkennungslauf_id"], ["erkennungslaeufe.id"], ondelete="CASCADE"
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        "ix_hybrid_erkennungslaeufe_unternehmen_id",
        "hybrid_erkennungslaeufe", ["unternehmen_id"],
    )
    op.create_index(
        "ix_hybrid_erkennungslaeufe_erkennungslauf_id",
        "hybrid_erkennungslaeufe", ["erkennungslauf_id"],
    )
    _enable_rls("hybrid_erkennungslaeufe")

    # --- hybrid_kandidaten ---
    op.create_table(
        "hybrid_kandidaten",
        sa.Column(
            "id", sa.UUID(),
            server_default=sa.text("gen_random_uuid()"), nullable=False,
        ),
        sa.Column("unternehmen_id", sa.UUID(), nullable=False),
        sa.Column("hybrid_erkennungslauf_id", sa.UUID(), nullable=False),
        sa.Column("feld", sa.Text(), nullable=False),
        sa.Column("rohwert", sa.Text(), nullable=False),
        sa.Column("normwert", sa.Text(), nullable=True),
        sa.Column("methode", sa.Text(), nullable=False),
        sa.Column("provider_name", sa.Text(), nullable=False),
        sa.Column("provider_version", sa.Text(), nullable=True),
        sa.Column("confidence", sa.Numeric(4, 3), nullable=False),
        sa.Column("seite", sa.Integer(), nullable=True),
        sa.Column("bbox_json", sa.Text(), nullable=True),
        sa.Column("validierungsbefund", sa.Text(), nullable=True),
        sa.Column("konflikt_gruppe", sa.Text(), nullable=True),
        sa.Column("auswahl_status", sa.Text(), nullable=True),
        sa.Column("auswahl_grund", sa.Text(), nullable=True),
        sa.Column(
            "created_at", sa.DateTime(timezone=True),
            server_default=sa.func.now(), nullable=False,
        ),
        sa.ForeignKeyConstraint(["unternehmen_id"], ["unternehmen.id"]),
        sa.ForeignKeyConstraint(
            ["hybrid_erkennungslauf_id"], ["hybrid_erkennungslaeufe.id"], ondelete="CASCADE"
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        "ix_hybrid_kandidaten_unternehmen_id",
        "hybrid_kandidaten", ["unternehmen_id"],
    )
    op.create_index(
        "ix_hybrid_kandidaten_hybrid_erkennungslauf_id",
        "hybrid_kandidaten", ["hybrid_erkennungslauf_id"],
    )
    _enable_rls("hybrid_kandidaten")

    # --- hybrid_konflikte ---
    op.create_table(
        "hybrid_konflikte",
        sa.Column(
            "id", sa.UUID(),
            server_default=sa.text("gen_random_uuid()"), nullable=False,
        ),
        sa.Column("unternehmen_id", sa.UUID(), nullable=False),
        sa.Column("erkennungslauf_id", sa.UUID(), nullable=True),
        sa.Column("feld", sa.Text(), nullable=False),
        sa.Column("konflikt_gruppe", sa.Text(), nullable=True),
        sa.Column("kandidaten_ids_json", sa.Text(), nullable=True),
        sa.Column(
            "created_at", sa.DateTime(timezone=True),
            server_default=sa.func.now(), nullable=False,
        ),
        sa.ForeignKeyConstraint(["unternehmen_id"], ["unternehmen.id"]),
        sa.ForeignKeyConstraint(
            ["erkennungslauf_id"], ["erkennungslaeufe.id"], ondelete="CASCADE"
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        "ix_hybrid_konflikte_unternehmen_id",
        "hybrid_konflikte", ["unternehmen_id"],
    )
    op.create_index(
        "ix_hybrid_konflikte_erkennungslauf_id",
        "hybrid_konflikte", ["erkennungslauf_id"],
    )
    _enable_rls("hybrid_konflikte")

    # --- hybrid_statusentscheidungen ---
    op.create_table(
        "hybrid_statusentscheidungen",
        sa.Column(
            "id", sa.UUID(),
            server_default=sa.text("gen_random_uuid()"), nullable=False,
        ),
        sa.Column("unternehmen_id", sa.UUID(), nullable=False),
        sa.Column("erkennungslauf_id", sa.UUID(), nullable=True),
        sa.Column("hybrid_status", sa.Text(), nullable=False),
        sa.Column("gruende_json", sa.Text(), nullable=True),
        sa.Column(
            "pflichtfelder_ok", sa.Boolean(),
            server_default=sa.text("false"), nullable=False,
        ),
        sa.Column("math_validierung_ok", sa.Boolean(), nullable=True),
        sa.Column(
            "konflikt_frei", sa.Boolean(),
            server_default=sa.text("false"), nullable=False,
        ),
        sa.Column("confidence_ausreichend", sa.Boolean(), nullable=True),
        sa.Column(
            "created_at", sa.DateTime(timezone=True),
            server_default=sa.func.now(), nullable=False,
        ),
        sa.ForeignKeyConstraint(["unternehmen_id"], ["unternehmen.id"]),
        sa.ForeignKeyConstraint(
            ["erkennungslauf_id"], ["erkennungslaeufe.id"], ondelete="CASCADE"
        ),
        sa.UniqueConstraint(
            "unternehmen_id", "erkennungslauf_id", name="uq_hybrid_status_lauf"
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        "ix_hybrid_statusentscheidungen_unternehmen_id",
        "hybrid_statusentscheidungen", ["unternehmen_id"],
    )
    op.create_index(
        "ix_hybrid_statusentscheidungen_erkennungslauf_id",
        "hybrid_statusentscheidungen", ["erkennungslauf_id"],
    )
    _enable_rls("hybrid_statusentscheidungen")


def downgrade() -> None:
    op.drop_table("hybrid_statusentscheidungen")
    op.drop_table("hybrid_konflikte")
    op.drop_table("hybrid_kandidaten")
    op.drop_table("hybrid_erkennungslaeufe")
