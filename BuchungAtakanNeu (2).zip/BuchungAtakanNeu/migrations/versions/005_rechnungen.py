"""Rechnungen, Erkennungslaeufe, RechnungsKandidaten (RECH-01..09)

Revision ID: 005
Revises: 004
Create Date: 2026-06-28

Voraussetzung: Migration 004 muss applied sein.
  buchungatakan_app muss existieren und CONNECT-Recht haben.

Hinweis: Explizite GRANTs noetig — GRANT ON ALL TABLES aus 003 gilt
  nicht fuer spaeter erstellte Tabellen.
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "005"
down_revision: Union[str, None] = "004"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

_APP_ROLE = "buchungatakan_app"


def upgrade() -> None:
    # --- rechnungen ---
    op.create_table(
        "rechnungen",
        sa.Column("id", sa.UUID(), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("unternehmen_id", sa.UUID(), nullable=False),
        sa.Column("dokument_id", sa.UUID(), nullable=False),
        sa.Column("rechnungsnummer", sa.Text(), nullable=True),
        sa.Column("rechnungsdatum", sa.Text(), nullable=True),
        sa.Column("gesamtbetrag", sa.Numeric(12, 2), nullable=True),
        sa.Column("nettobetrag", sa.Numeric(12, 2), nullable=True),
        sa.Column("steuerbetrag", sa.Numeric(12, 2), nullable=True),
        sa.Column("waehrung", sa.Text(), nullable=True),
        sa.Column("zahlungsart", sa.Text(), nullable=True),
        sa.Column("lieferant_name", sa.Text(), nullable=True),
        sa.Column("status", sa.Text(), nullable=False, server_default="NEU"),
        sa.Column("version_lfd_nr", sa.Integer(), nullable=False, server_default=sa.text("1")),
        sa.Column("ist_aktiv", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.ForeignKeyConstraint(["unternehmen_id"], ["unternehmen.id"]),
        sa.ForeignKeyConstraint(["dokument_id"], ["dokumente.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("unternehmen_id", "rechnungsnummer", "version_lfd_nr", name="uq_rechnung_tenant_nr_version"),
    )
    op.create_index("ix_rechnungen_unternehmen_id", "rechnungen", ["unternehmen_id"])
    op.create_index("ix_rechnungen_dokument_id", "rechnungen", ["dokument_id"])
    op.create_index("ix_rechnungen_rechnungsnummer", "rechnungen", ["rechnungsnummer"])

    # --- erkennungslaeufe ---
    op.create_table(
        "erkennungslaeufe",
        sa.Column("id", sa.UUID(), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("unternehmen_id", sa.UUID(), nullable=False),
        sa.Column("dokument_id", sa.UUID(), nullable=False),
        sa.Column("rechnung_id", sa.UUID(), nullable=True),
        sa.Column("extraktion_status", sa.Text(), nullable=False),
        sa.Column("extraktion_confidence", sa.Numeric(4, 3), nullable=True),
        sa.Column("fehler", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.ForeignKeyConstraint(["unternehmen_id"], ["unternehmen.id"]),
        sa.ForeignKeyConstraint(["dokument_id"], ["dokumente.id"]),
        sa.ForeignKeyConstraint(["rechnung_id"], ["rechnungen.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_erkennungslaeufe_unternehmen_id", "erkennungslaeufe", ["unternehmen_id"])
    op.create_index("ix_erkennungslaeufe_dokument_id", "erkennungslaeufe", ["dokument_id"])
    op.create_index("ix_erkennungslaeufe_rechnung_id", "erkennungslaeufe", ["rechnung_id"])

    # --- rechnungs_kandidaten ---
    op.create_table(
        "rechnungs_kandidaten",
        sa.Column("id", sa.UUID(), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("unternehmen_id", sa.UUID(), nullable=False),
        sa.Column("erkennungslauf_id", sa.UUID(), nullable=False),
        sa.Column("feld", sa.Text(), nullable=False),
        sa.Column("rohwert", sa.Text(), nullable=False),
        sa.Column("normwert", sa.Text(), nullable=True),
        sa.Column("methode", sa.Text(), nullable=False),
        sa.Column("quelle", sa.Text(), nullable=False),
        sa.Column("confidence", sa.Numeric(4, 3), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.ForeignKeyConstraint(["unternehmen_id"], ["unternehmen.id"]),
        sa.ForeignKeyConstraint(["erkennungslauf_id"], ["erkennungslaeufe.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_rechnungs_kandidaten_unternehmen_id", "rechnungs_kandidaten", ["unternehmen_id"])
    op.create_index("ix_rechnungs_kandidaten_erkennungslauf_id", "rechnungs_kandidaten", ["erkennungslauf_id"])

    # GRANTs fuer buchungatakan_app (explizit noetig, da GRANT ON ALL TABLES aus 003 nicht greift)
    op.execute(f"GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE rechnungen TO {_APP_ROLE}")
    op.execute(f"GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE erkennungslaeufe TO {_APP_ROLE}")
    op.execute(f"GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE rechnungs_kandidaten TO {_APP_ROLE}")

    # RLS: ENABLE + FORCE + Tenant-Isolation-Policy
    for table in ("rechnungen", "erkennungslaeufe", "rechnungs_kandidaten"):
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
        op.execute(
            f"CREATE POLICY tenant_isolation ON {table} "
            f"USING (unternehmen_id::text = current_setting('app.current_tenant', true))"
        )


def downgrade() -> None:
    for table in ("rechnungen", "erkennungslaeufe", "rechnungs_kandidaten"):
        op.execute(f"DROP POLICY IF EXISTS tenant_isolation ON {table}")

    op.drop_index("ix_rechnungs_kandidaten_erkennungslauf_id", table_name="rechnungs_kandidaten")
    op.drop_index("ix_rechnungs_kandidaten_unternehmen_id", table_name="rechnungs_kandidaten")
    op.drop_table("rechnungs_kandidaten")

    op.drop_index("ix_erkennungslaeufe_rechnung_id", table_name="erkennungslaeufe")
    op.drop_index("ix_erkennungslaeufe_dokument_id", table_name="erkennungslaeufe")
    op.drop_index("ix_erkennungslaeufe_unternehmen_id", table_name="erkennungslaeufe")
    op.drop_table("erkennungslaeufe")

    op.drop_index("ix_rechnungen_rechnungsnummer", table_name="rechnungen")
    op.drop_index("ix_rechnungen_dokument_id", table_name="rechnungen")
    op.drop_index("ix_rechnungen_unternehmen_id", table_name="rechnungen")
    op.drop_table("rechnungen")
