"""Alembic-Migrationsumgebung.

URL-Prioritaet (hoechste zuerst):
  1. Explizit per alembic_cfg.set_main_option("sqlalchemy.url", ...) gesetzt.
  2. ALEMBIC_DATABASE_URL Umgebungsvariable.
  3. settings.DATABASE_URL (App-Konfiguration).

Regel: Eine explizit gesetzte sqlalchemy.url wird NICHT mit settings.DATABASE_URL
ueberschrieben. Sicherheitsguard in migration_guard.py prueft Ziel vor jeder Migration.
"""
import os
from logging.config import fileConfig

from alembic import context
from sqlalchemy import engine_from_config, pool

from apps.server.config import settings
import apps.server.models  # noqa: F401 — registers all ORM tables in Base.metadata
from apps.server.models.base import Base
from migrations.migration_guard import pruefe_migrationsziel, zu_psycopg2_url

config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

target_metadata = Base.metadata


def get_ziel_url() -> str:
    """Fallback-URL wenn keine explizite sqlalchemy.url per set_main_option gesetzt.

    Prioritaet: ALEMBIC_DATABASE_URL > settings.DATABASE_URL.
    Wird nur aufgerufen wenn cfg['sqlalchemy.url'] leer ist.
    """
    url = os.environ.get("ALEMBIC_DATABASE_URL") or settings.DATABASE_URL
    return zu_psycopg2_url(url)


def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url") or get_ziel_url()
    pruefe_migrationsziel(url)
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    cfg = config.get_section(config.config_ini_section, {})
    # Prioritaet 1: explizit per alembic_cfg.set_main_option gesetzte sqlalchemy.url.
    # Prioritaet 2: get_ziel_url() (ALEMBIC_DATABASE_URL oder settings.DATABASE_URL).
    # Explizit gesetzte URL wird NICHT ueberschrieben.
    if not cfg.get("sqlalchemy.url"):
        cfg["sqlalchemy.url"] = get_ziel_url()
    pruefe_migrationsziel(cfg["sqlalchemy.url"])
    connectable = engine_from_config(cfg, prefix="sqlalchemy.", poolclass=pool.NullPool)
    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
