"""Sicherheitsguard fuer Alembic-Migrationen.

Isoliertes Modul ohne Alembic-Kontext-Abhaengigkeit -- vollstaendig unit-testbar.

Regeln (nur wenn TEST_DATABASE_URL gesetzt):
  - Migrationsziel-DB muss 'test' im Namen enthalten.
  - Migrationsziel-DB muss exakt der TEST_DATABASE_URL-DB entsprechen.
  - Guard gibt DB-Namen aus, niemals vollstaendige URL oder Passwort.

Ohne TEST_DATABASE_URL: kein Guard (normaler CLI-Betrieb).
"""
import logging
import os
import re

log = logging.getLogger("alembic.env")


def db_name_aus_url(url: str) -> str:
    """Extrahiert DB-Namen aus URL -- ohne Credentials, ohne Schema, ohne Query."""
    return url.split("?")[0].rstrip("/").rsplit("/", 1)[-1]


def zu_psycopg2_url(url: str) -> str:
    """Konvertiert asyncpg-URL zu psycopg2-URL (fuer synchrone Alembic-Verbindung)."""
    return re.sub(r"^postgresql(\+asyncpg)?://", "postgresql+psycopg2://", url)


def pruefe_migrationsziel(ziel_url: str) -> None:
    """Sicherheitsguard: prueft Ziel-DB vor jeder Migration.

    Gibt nur den DB-Namen aus (kein Passwort, keine vollstaendige URL).
    Wirft RuntimeError bei erkannter Fehlkonfiguration.

    Ohne TEST_DATABASE_URL: kein Guard (normaler manueller CLI-Betrieb).
    Mit TEST_DATABASE_URL:
      - Ziel-DB-Name muss 'test' enthalten.
      - Ziel-DB muss exakt TEST_DATABASE_URL-DB entsprechen.
    """
    db_name = db_name_aus_url(ziel_url)
    log.info("Alembic Migrationsziel: %s", db_name)

    test_url = os.environ.get("TEST_DATABASE_URL")
    if not test_url:
        return

    test_db = db_name_aus_url(test_url)

    if "test" not in db_name.lower():
        raise RuntimeError(
            f"SICHERHEITSFEHLER: TEST_DATABASE_URL gesetzt, aber Migrationsziel "
            f"'{db_name}' enthaelt kein 'test'. "
            f"Entwicklungsdatenbank nicht migrieren -- Ziel-URL pruefen."
        )

    if db_name != test_db:
        raise RuntimeError(
            f"SICHERHEITSFEHLER: TEST_DATABASE_URL zeigt auf '{test_db}', "
            f"Migrationsziel ist aber '{db_name}'. "
            f"Explizit korrekte Ziel-URL per set_main_option oder ALEMBIC_DATABASE_URL setzen."
        )
