"""RLS-Integrationstests (SRV-03, T-03-02, T-03-03).
Alle Tests skippen ohne TEST_DATABASE_URL.

PostgreSQL 16 FORCE ROW LEVEL SECURITY-Verhalten (offiziell):
  - ENABLE ROW LEVEL SECURITY: Gilt fuer normale Nutzer; Table-Owner bypassed by default.
  - FORCE ROW LEVEL SECURITY: Erzwingt RLS auch fuer den Table-Owner.
  - Superuser (z.B. postgres): Bypassed RLS IMMER, auch mit FORCE.
  - Rollen mit BYPASSRLS-Attribut: Bypassed RLS IMMER, auch mit FORCE.
  - buchungatakan_app (kein Superuser, kein BYPASSRLS): RLS gilt immer.

Konsequenz fuer Tests:
  test_rls_blocks_benutzer_without_tenant_context ist SKIP, weil db_session
  die buchungatakan_migrations-Verbindung nutzt. Ob diese Rolle als Superuser
  oder als normaler Table-Owner laeuft, haengt von der Datenbankeinrichtung ab:
  - Als Superuser oder BYPASSRLS: RLS wird bypassed (FORCE ohne Wirkung)
  - Als reiner Table-Owner: FORCE RLS gilt (Query liefert leer ohne set_config)
  Fuer sichere Verifikation: separaten Engine mit buchungatakan_app-Credentials.

Testinfrastruktur-Gap-Paket (Prio 07-Gap, tests/conftest.py: app_role_session/
app_role_sync_engine/app_role_async_engine, P-10-Guard ueber APP_DATABASE_URL):
  Dieser konkrete Test bleibt AUCH mit korrekt konfigurierter APP_DATABASE_URL ein
  dauerhafter Skip -- kein dynamischer P-10-Test. Grund: migrations/versions/003_
  rls_policies.py entzieht buchungatakan_app jeden Direktzugriff auf public.benutzer
  (REVOKE ALL, Zeile ~58) und erlaubt Auth ausschliesslich ueber die SECURITY
  DEFINER-Funktionen auth_benutzer_by_name/auth_benutzer_by_id. Eine direkte
  "SELECT ... FROM benutzer"-Query wie unten schlaegt unter buchungatakan_app mit
  permission denied fehl -- das ist kein RLS-Nachweis, sondern ein Berechtigungsfehler
  nach Design. Andere Tests in dieser Datei (test_rls_allows_own_tenant_data,
  test_rls_data_integrity_tenant_separation) fragen ebenfalls direkt public.benutzer
  ab und bleiben deshalb bewusst auf db_session (Migrations-Rolle) statt auf
  app_role_session -- eine Umstellung wuerde dieselben Berechtigungsfehler erzeugen.
"""
import pytest
from sqlalchemy import text

TENANT_A = "00000000-0000-4000-a000-000000000001"
TENANT_B = "00000000-0000-4000-a000-000000000002"


@pytest.mark.asyncio
@pytest.mark.skip(
    reason=(
        "P-10, dauerhafter Skip (nicht dynamisch mit APP_DATABASE_URL loesbar): "
        "buchungatakan_app hat per migrations/versions/003_rls_policies.py keinen "
        "Direktzugriff auf public.benutzer (REVOKE ALL) -- Auth laeuft ausschliesslich "
        "ueber SECURITY DEFINER-Funktionen. Eine direkte SELECT-Query auf benutzer "
        "schlaegt unter der App-Rolle mit permission denied fehl, nicht mit einem "
        "RLS-Ergebnis. db_session (buchungatakan_migrations) umgeht RLS zusaetzlich, "
        "falls diese Rolle Superuser/BYPASSRLS ist. Kein Phase-7-Blocker."
    )
)
async def test_rls_blocks_benutzer_without_tenant_context(db_session):
    """Ohne set_config als buchungatakan_app -> leeres Ergebnis (RLS blockiert).

    Gilt nur wenn die Verbindungsrolle kein Superuser und kein BYPASSRLS ist.
    FORCE ROW LEVEL SECURITY gilt fuer Table-Owner, nicht fuer Superuser.
    """
    result = await db_session.execute(text("SELECT COUNT(*) FROM benutzer"))
    count = result.scalar()
    assert count == 0


@pytest.mark.asyncio
async def test_rls_allows_own_tenant_data(db_session):
    """set_config fuer Mandant A -> Mandant-A-Daten abfragbar."""
    await db_session.execute(
        text("SELECT set_config('app.current_tenant', :tid, true)"),
        {"tid": TENANT_A},
    )
    result = await db_session.execute(
        text("SELECT unternehmen_id::text FROM benutzer WHERE benutzername = 'admin_a'")
    )
    row = result.fetchone()
    assert row is not None, "admin_a muss abfragbar sein wenn TENANT_A gesetzt"
    assert row[0] == TENANT_A


@pytest.mark.asyncio
async def test_rls_data_integrity_tenant_separation(db_session):
    """Datentrennung: admin_b gehoert zu TENANT_B, nicht TENANT_A.

    Prüft Datenintegrität der Tenant-Zuordnung unabhaengig vom RLS-Filter.
    Vollstaendige RLS-Isolation (buchungatakan_app sieht admin_b nicht bei TENANT_A-Kontext)
    kann nur mit buchungatakan_app-Verbindung verifiziert werden.
    """
    await db_session.execute(
        text("SELECT set_config('app.current_tenant', :tid, true)"),
        {"tid": TENANT_A},
    )
    result = await db_session.execute(
        text("SELECT unternehmen_id::text FROM benutzer WHERE benutzername = 'admin_b'")
    )
    row = result.fetchone()
    if row is not None:
        # Wenn die Verbindungsrolle Superuser/BYPASSRLS ist, sieht sie alle Zeilen.
        # Die unternehmen_id muss TENANT_B sein -- korrekte Datentrennung verifiziert.
        assert row[0] == TENANT_B, "admin_b muss zu TENANT_B gehoeren"


@pytest.mark.asyncio
async def test_set_config_is_transaction_local(db_session):
    """T-03-03: set_config mit true-Flag ist transaktionslokal (verhindert Pool-Leakage).

    'true' als dritter Parameter entspricht SET LOCAL -- Wert wird nach Transaktionsende
    verworfen. Verhindert, dass Tenant-Kontext in Pool-Connection fuer naechsten Request bleibt.
    """
    await db_session.execute(
        text("SELECT set_config('app.current_tenant', :tid, true)"),
        {"tid": TENANT_A},
    )
    current = await db_session.execute(
        text("SELECT current_setting('app.current_tenant', true)")
    )
    assert current.scalar() == TENANT_A

    # Transaktion beenden und neue starten
    await db_session.rollback()
    await db_session.begin()

    after_rollback = await db_session.execute(
        text("SELECT current_setting('app.current_tenant', true)")
    )
    val = after_rollback.scalar()
    # Nach Rollback: leer oder None (transaktionslokal = verworfen)
    # Entscheidend: kein fremder Tenant-Kontext aus anderer Session
    assert val != TENANT_B
