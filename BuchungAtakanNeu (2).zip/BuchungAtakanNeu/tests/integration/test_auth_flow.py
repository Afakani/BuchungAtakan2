"""Integrationstests Auth-Flow (SRV-01, SRV-02, SRV-08, SRV-10).
Alle Tests skippen ohne TEST_DATABASE_URL.
"""
import pytest
import jwt as pyjwt
from sqlalchemy import text

TENANT_A = "00000000-0000-4000-a000-000000000001"
TENANT_B = "00000000-0000-4000-a000-000000000002"


async def _login(client, username: str, password: str) -> str:
    resp = await client.post(
        "/api/v1/auth/login",
        data={"username": username, "password": password},
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    assert resp.status_code == 200, f"Login fehlgeschlagen: {resp.text}"
    return resp.json()["access_token"]


@pytest.mark.asyncio
async def test_seed_data_exists(db_session):
    """SRV-01: Seed-Daten vorhanden.

    benutzer: prueft via auth_benutzer_by_name (SECURITY DEFINER, umgeht ENABLE RLS).
    unternehmen: hat FORCE RLS -- je Mandant separate Transaktion mit Tenant-Kontext.
    """
    # benutzer via SECURITY DEFINER (buchungatakan_migrations als Ausfuehrender, umgeht ENABLE RLS)
    for benutzername in ("admin_a", "leser_a", "admin_b"):
        r = await db_session.execute(
            text("SELECT COUNT(*) FROM auth_benutzer_by_name(:n)"), {"n": benutzername}
        )
        assert r.scalar() == 1, f"Benutzer '{benutzername}' fehlt in Testdatenbank"

    # unternehmen: FORCE RLS erfordert je Mandant eigene Transaktion mit Kontext
    await db_session.rollback()
    for tenant_id, expected_name in [(TENANT_A, "Test GmbH A"), (TENANT_B, "Test GmbH B")]:
        await db_session.execute(
            text("SELECT set_config('app.current_tenant', :tid, true)"), {"tid": tenant_id}
        )
        r = await db_session.execute(
            text("SELECT name FROM unternehmen WHERE id = :id"), {"id": tenant_id}
        )
        row = r.fetchone()
        assert row is not None and row[0] == expected_name, (
            f"Unternehmen '{expected_name}' (id={tenant_id}) fehlt"
        )
        await db_session.rollback()


@pytest.mark.asyncio
async def test_login_admin_a_returns_jwt(http_client):
    """SRV-02: Login liefert JWT."""
    token = await _login(http_client, "admin_a", "testpassword123")
    assert len(token) > 20
    assert token.count(".") == 2  # JWT-Format: header.payload.sig


@pytest.mark.asyncio
async def test_jwt_contains_unternehmen_id(http_client):
    """SRV-02: JWT-Payload enthaelt korrekte unternehmen_id und rolle."""
    token = await _login(http_client, "admin_a", "testpassword123")
    payload = pyjwt.decode(token, options={"verify_signature": False})
    assert payload["unternehmen_id"] == TENANT_A
    assert payload["rolle"] == "UNTERNEHMEN_ADMIN"
    assert "sub" in payload


@pytest.mark.asyncio
async def test_jwt_contains_no_db_credentials(http_client):
    """SRV-10: JWT-Payload enthaelt keine DB-Zugangsdaten."""
    token = await _login(http_client, "admin_a", "testpassword123")
    payload = pyjwt.decode(token, options={"verify_signature": False})
    payload_str = str(payload).lower()
    assert "database_url" not in payload_str
    assert "secret_key" not in payload_str
    forbidden = {"password", "hashed_password", "database_url", "secret_key"}
    assert not forbidden.intersection(payload.keys())


@pytest.mark.asyncio
async def test_wrong_password_returns_401(http_client):
    """SRV-08: Falsches Passwort -> 401 ohne interne Details."""
    resp = await http_client.post(
        "/api/v1/auth/login",
        data={"username": "admin_a", "password": "FALSCH"},
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    assert resp.status_code == 401
    body = resp.text.lower()
    assert "sql" not in body
    assert "password" not in body
    assert "testpassword" not in body


@pytest.mark.asyncio
async def test_nonexistent_user_returns_401(http_client):
    """SRV-08: Nicht-vorhandener User -> gleiche 401-Antwort."""
    resp = await http_client.post(
        "/api/v1/auth/login",
        data={"username": "niemand", "password": "xyz"},
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    assert resp.status_code == 401
    data = resp.json()
    assert "detail" in data


@pytest.mark.asyncio
async def test_get_eigenes_unternehmen(http_client):
    """Mandantengeschuetzter Endpunkt gibt eigenes Unternehmen zurueck."""
    token = await _login(http_client, "admin_a", "testpassword123")
    resp = await http_client.get(
        "/api/v1/unternehmen/me",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["name"] == "Test GmbH A"
    assert data["id"] == TENANT_A
