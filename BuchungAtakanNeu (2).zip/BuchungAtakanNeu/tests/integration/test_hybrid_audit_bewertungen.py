"""Integrationstests Auditbewertungen und Statistikdaten (07-03A, HYB-17/18).

Nutzt Migration-012-Tabellen (hybrid_audit_bewertungen, dokument_klasse).
"""
import uuid

import pytest
from sqlalchemy import text as sa_text

from apps.server.models.dokument import Dokument
from apps.server.models.hybrid_extraktion import HybridStatusentscheidung
from apps.server.models.installationen import Installation
from apps.server.models.rechnung import Erkennungslauf, Rechnung
from apps.server.repositories.hybrid import HybridAuditRepository, HybridStatusentscheidungRepository
from apps.server.services.hybrid_audit_service import HybridAuditService
from packages.core.invoice_extraction.hybrid_audit import AuditBewertungFelder

TENANT_A = uuid.UUID("00000000-0000-4000-a000-000000000001")
TENANT_B = uuid.UUID("00000000-0000-4000-a000-000000000002")


async def _tenant(session, tenant_id: uuid.UUID) -> None:
    await session.execute(sa_text("SELECT set_config('app.current_tenant', :tid, true)"), {"tid": str(tenant_id)})


async def _erstelle_erkennungslauf(
    session, tenant_id: uuid.UUID, lieferant_name: str | None = None
) -> uuid.UUID:
    installation = Installation(unternehmen_id=tenant_id)
    session.add(installation)
    await session.flush()

    dokument = Dokument(
        unternehmen_id=tenant_id,
        installation_id=installation.id,
        sha256=f"test-{uuid.uuid4().hex}",
        relative_path="test/rechnung.pdf",
        dateiname="rechnung.pdf",
        dateigroesse=1,
        mime_type="application/pdf",
    )
    session.add(dokument)
    await session.flush()

    rechnung_id = None
    if lieferant_name is not None:
        rechnung = Rechnung(
            unternehmen_id=tenant_id,
            dokument_id=dokument.id,
            lieferant_name=lieferant_name,
        )
        session.add(rechnung)
        await session.flush()
        rechnung_id = rechnung.id

    erkennungslauf = Erkennungslauf(
        unternehmen_id=tenant_id,
        dokument_id=dokument.id,
        rechnung_id=rechnung_id,
        extraktion_status="OK",
    )
    session.add(erkennungslauf)
    await session.flush()
    return erkennungslauf.id


async def _erstelle_statusentscheidung(
    session,
    tenant_id: uuid.UUID,
    erkennungslauf_id: uuid.UUID | None = None,
    dokument_klasse: str | None = None,
    hybrid_status: str = "OK",
) -> uuid.UUID:
    entscheidung = HybridStatusentscheidung(
        unternehmen_id=tenant_id,
        erkennungslauf_id=erkennungslauf_id,
        hybrid_status=hybrid_status,
        pflichtfelder_ok=True,
        konflikt_frei=True,
        dokument_klasse=dokument_klasse,
    )
    session.add(entscheidung)
    await session.flush()
    return entscheidung.id


def _felder(**overrides) -> AuditBewertungFelder:
    defaults = dict(
        rechnungsnummer_korrekt=True,
        rechnungsdatum_korrekt=True,
        gesamtbetrag_korrekt=True,
        lieferant_korrekt=True,
        steuerwerte_korrekt=True,
        empfaenger_korrekt=True,
    )
    defaults.update(overrides)
    return AuditBewertungFelder(**defaults)


@pytest.mark.asyncio
async def test_haba_append_only_zwei_posts_erzeugen_zwei_zeilen(db_session):
    await _tenant(db_session, TENANT_A)
    statusentscheidung_id = await _erstelle_statusentscheidung(db_session, TENANT_A)
    await db_session.commit()

    service = HybridAuditService()
    await _tenant(db_session, TENANT_A)
    await service.bewerte(db_session, TENANT_A, statusentscheidung_id, _felder())
    await _tenant(db_session, TENANT_A)
    await service.bewerte(db_session, TENANT_A, statusentscheidung_id, _felder(steuerwerte_korrekt=False))

    await _tenant(db_session, TENANT_A)
    rows = (await db_session.execute(sa_text(
        "SELECT id FROM hybrid_audit_bewertungen WHERE hybrid_statusentscheidung_id = :sid"
    ), {"sid": str(statusentscheidung_id)})).fetchall()
    assert len(rows) == 2


@pytest.mark.asyncio
async def test_haba_keine_bestehende_zeile_wird_veraendert(db_session):
    await _tenant(db_session, TENANT_A)
    statusentscheidung_id = await _erstelle_statusentscheidung(db_session, TENANT_A)
    await db_session.commit()

    service = HybridAuditService()
    await _tenant(db_session, TENANT_A)
    erste = await service.bewerte(db_session, TENANT_A, statusentscheidung_id, _felder())
    erste_id = erste.id

    await _tenant(db_session, TENANT_A)
    await service.bewerte(db_session, TENANT_A, statusentscheidung_id, _felder(rechnungsnummer_korrekt=False))

    await _tenant(db_session, TENANT_A)
    row = (await db_session.execute(sa_text(
        "SELECT rechnungsnummer_korrekt FROM hybrid_audit_bewertungen WHERE id = :id"
    ), {"id": str(erste_id)})).fetchone()
    assert row[0] is True, "Erste Bewertung darf durch spaetere nicht veraendert werden"


@pytest.mark.asyncio
async def test_haba_latest_endpunkt_liefert_neueste_bewertung(db_session):
    await _tenant(db_session, TENANT_A)
    statusentscheidung_id = await _erstelle_statusentscheidung(db_session, TENANT_A)
    await db_session.commit()

    service = HybridAuditService()
    await _tenant(db_session, TENANT_A)
    await service.bewerte(db_session, TENANT_A, statusentscheidung_id, _felder())
    await _tenant(db_session, TENANT_A)
    zweite = await service.bewerte(
        db_session, TENANT_A, statusentscheidung_id, _felder(gesamtbetrag_korrekt=False)
    )

    await _tenant(db_session, TENANT_A)
    neueste = await service.neueste_bewertung(db_session, TENANT_A, statusentscheidung_id)
    assert neueste.id == zweite.id
    assert neueste.gesamtbetrag_korrekt is False


@pytest.mark.asyncio
async def test_haba_dokument_klasse_wird_bei_neuen_laeufen_persistiert(db_session):
    await _tenant(db_session, TENANT_A)
    statusentscheidung_id = await _erstelle_statusentscheidung(
        db_session, TENANT_A, dokument_klasse="TEXT_PDF"
    )
    await db_session.commit()

    await _tenant(db_session, TENANT_A)
    row = (await db_session.execute(sa_text(
        "SELECT dokument_klasse FROM hybrid_statusentscheidungen WHERE id = :id"
    ), {"id": str(statusentscheidung_id)})).fetchone()
    assert row[0] == "TEXT_PDF"


@pytest.mark.asyncio
async def test_haba_altzeilen_mit_null_dokument_klasse_bleiben_gueltig(db_session):
    await _tenant(db_session, TENANT_A)
    statusentscheidung_id = await _erstelle_statusentscheidung(db_session, TENANT_A, dokument_klasse=None)
    await db_session.commit()

    await _tenant(db_session, TENANT_A)
    row = (await db_session.execute(sa_text(
        "SELECT dokument_klasse FROM hybrid_statusentscheidungen WHERE id = :id"
    ), {"id": str(statusentscheidung_id)})).fetchone()
    assert row[0] is None


@pytest.mark.asyncio
async def test_haba_statistik_verwendet_neueste_bewertung(db_session):
    """dimensionen=() aggregiert global ueber ALLE Statusentscheidungen des Mandanten --
    in der geteilten Testdatenbank (kein Truncate zwischen Tests innerhalb des Moduls)
    wuerden andere Tests in dieser Datei den Nenner verfaelschen. Isolierung ueber eine
    fuer diesen Test eindeutige dokument_klasse + Gruppierung danach, statt ueber die
    (in dieser Datei sonst ungenutzte) Annahme einer leeren Tabelle."""
    await _tenant(db_session, TENANT_A)
    statusentscheidung_id = await _erstelle_statusentscheidung(
        db_session, TENANT_A, dokument_klasse="SONDERFORMAT"
    )
    await db_session.commit()

    service = HybridAuditService()
    await _tenant(db_session, TENANT_A)
    await service.bewerte(db_session, TENANT_A, statusentscheidung_id, _felder())  # gesamtergebnis_korrekt=True
    await _tenant(db_session, TENANT_A)
    await service.bewerte(
        db_session, TENANT_A, statusentscheidung_id, _felder(rechnungsnummer_korrekt=False)
    )  # neueste -> gesamtergebnis_korrekt=False

    await _tenant(db_session, TENANT_A)
    gruppen = await service.statistik(db_session, TENANT_A, dimensionen=("dokument_klasse",))
    gruppe = next(g for g in gruppen if g.dimensionswerte == ("SONDERFORMAT",))
    assert gruppe.anzahl == 1
    q = gruppe.richtigkeitsquote
    assert (q.zaehler, q.nenner) == (0, 1), "Statistik muss die neueste, nicht die erste Bewertung verwenden"


@pytest.mark.asyncio
async def test_haba_anbietergruppierung_nutzt_rechnungen_lieferant_name(db_session):
    await _tenant(db_session, TENANT_A)
    erkennungslauf_id = await _erstelle_erkennungslauf(db_session, TENANT_A, lieferant_name="Muster Lieferant GmbH")
    await _erstelle_statusentscheidung(db_session, TENANT_A, erkennungslauf_id=erkennungslauf_id)
    await db_session.commit()

    await _tenant(db_session, TENANT_A)
    service = HybridAuditService()
    gruppen = await service.statistik(db_session, TENANT_A, dimensionen=("anbieter",))
    anbieter_werte = {g.dimensionswerte[0] for g in gruppen}
    assert "Muster Lieferant GmbH" in anbieter_werte


@pytest.mark.asyncio
async def test_haba_fehlender_anbieter_wird_unbekannt(db_session):
    await _tenant(db_session, TENANT_A)
    await _erstelle_statusentscheidung(db_session, TENANT_A, erkennungslauf_id=None)
    await db_session.commit()

    await _tenant(db_session, TENANT_A)
    service = HybridAuditService()
    gruppen = await service.statistik(db_session, TENANT_A, dimensionen=("anbieter",))
    anbieter_werte = {g.dimensionswerte[0] for g in gruppen}
    assert "UNBEKANNT" in anbieter_werte


@pytest.mark.asyncio
async def test_haba_tenant_b_sieht_bewertungen_von_tenant_a_nicht(app_role_session):
    """Laeuft ueber die App-Rolle (buchungatakan_app, kein Superuser/BYPASSRLS) --
    P-10-Skip ohne APP_DATABASE_URL. Ueber db_session (TEST_DATABASE_URL, moeglicherweise
    privilegiert) waere diese scharfe Assertion nicht aussagekraeftig."""
    await _tenant(app_role_session, TENANT_A)
    statusentscheidung_id = await _erstelle_statusentscheidung(app_role_session, TENANT_A)
    await app_role_session.commit()

    service = HybridAuditService()
    await _tenant(app_role_session, TENANT_A)
    await service.bewerte(app_role_session, TENANT_A, statusentscheidung_id, _felder())

    await _tenant(app_role_session, TENANT_B)
    row = (await app_role_session.execute(sa_text(
        "SELECT id FROM hybrid_audit_bewertungen WHERE hybrid_statusentscheidung_id = :sid"
    ), {"sid": str(statusentscheidung_id)})).fetchone()
    assert row is None, "Tenant B darf Auditbewertungen von Tenant A nicht sehen (RLS)"


@pytest.mark.asyncio
async def test_haba_tenant_b_kann_statusentscheidung_von_tenant_a_nicht_bewerten(db_session):
    from fastapi import HTTPException

    await _tenant(db_session, TENANT_A)
    statusentscheidung_id = await _erstelle_statusentscheidung(db_session, TENANT_A)
    await db_session.commit()

    await _tenant(db_session, TENANT_B)
    service = HybridAuditService()
    with pytest.raises(HTTPException) as exc_info:
        await service.bewerte(db_session, TENANT_B, statusentscheidung_id, _felder())
    assert exc_info.value.status_code == 404
