"""Integrationstests Hybrid-Rechnungsextraktion — Phase 07-01 (HYB-07/08).

HY01: hybrid_erkennungslauf persistieren
HY02: hybrid_kandidaten persistieren
HY03: hybrid_konflikte persistieren
HY04: hybrid_statusentscheidung persistieren
HY05: Tenant-Isolation — Tenant B sieht keine Daten von Tenant A
HY06: Migration 011 — Tabellen vorhanden
HY07: Migration 011 — RLS aktiv
HY08: Migration 011 — FORCE RLS aktiv
HY09: alembic check bleibt sauber nach Migration 011
"""
import pytest
from sqlalchemy import text as sa_text

TENANT_A = "00000000-0000-4000-a000-000000000001"
TENANT_B = "00000000-0000-4000-a000-000000000002"

_HYBRID_TABELLEN = [
    "hybrid_erkennungslaeufe",
    "hybrid_kandidaten",
    "hybrid_konflikte",
    "hybrid_statusentscheidungen",
]


# ---------------------------------------------------------------------------
# Hilfs-Fixture: sync engine fuer direkte SQL-Operationen
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def sync_engine(apply_migrations):
    from sqlalchemy import create_engine
    from sqlalchemy.engine import make_url
    from tests.conftest import TEST_DB_URL

    url = make_url(TEST_DB_URL).set(drivername="postgresql+psycopg2").render_as_string(hide_password=False)
    engine = create_engine(url)
    yield engine
    engine.dispose()


def _set_tenant(conn, tenant_id: str) -> None:
    conn.execute(sa_text("SELECT set_config('app.current_tenant', :tid, true)"), {"tid": tenant_id})


def _insert_hybrid_erkennungslauf(conn, tenant_id: str, provider: str = "pdfplumber") -> str:
    row = conn.execute(
        sa_text(
            "INSERT INTO hybrid_erkennungslaeufe "
            "(unternehmen_id, provider_name, laufstatus) "
            "VALUES (:uid, :prov, 'success') RETURNING id"
        ),
        {"uid": tenant_id, "prov": provider},
    ).fetchone()
    return str(row[0])


# ---------------------------------------------------------------------------
# HY06: Tabellen vorhanden
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("tabelle", _HYBRID_TABELLEN)
def test_tabelle_vorhanden(tabelle, sync_engine):
    """HY06: Alle vier Hybrid-Tabellen existieren nach Migration 011."""
    with sync_engine.connect() as conn:
        result = conn.execute(sa_text("""
            SELECT table_name FROM information_schema.tables
            WHERE table_schema = 'public' AND table_name = :t
        """), {"t": tabelle})
        assert result.fetchone() is not None, f"Tabelle '{tabelle}' fehlt"


# ---------------------------------------------------------------------------
# HY07/HY08: RLS und FORCE RLS aktiv
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("tabelle", _HYBRID_TABELLEN)
def test_rls_aktiv(tabelle, sync_engine):
    """HY07: relrowsecurity=true fuer alle Hybrid-Tabellen."""
    with sync_engine.connect() as conn:
        row = conn.execute(sa_text("""
            SELECT relrowsecurity FROM pg_class
            WHERE relname = :t AND relkind = 'r'
        """), {"t": tabelle}).fetchone()
        assert row is not None, f"Tabelle '{tabelle}' nicht in pg_class"
        assert row[0] is True, f"RLS nicht aktiv fuer '{tabelle}'"


@pytest.mark.parametrize("tabelle", _HYBRID_TABELLEN)
def test_force_rls_aktiv(tabelle, sync_engine):
    """HY08: relforcerowsecurity=true fuer alle Hybrid-Tabellen."""
    with sync_engine.connect() as conn:
        row = conn.execute(sa_text("""
            SELECT relforcerowsecurity FROM pg_class
            WHERE relname = :t AND relkind = 'r'
        """), {"t": tabelle}).fetchone()
        assert row is not None
        assert row[0] is True, f"FORCE RLS nicht aktiv fuer '{tabelle}'"


# ---------------------------------------------------------------------------
# HY01: hybrid_erkennungslauf persistieren
# ---------------------------------------------------------------------------

def test_hybrid_erkennungslauf_persistieren(sync_engine):
    """HY01: Erkennungslauf einfuegen und wiederfinden."""
    with sync_engine.begin() as conn:
        _set_tenant(conn, TENANT_A)
        run_id = _insert_hybrid_erkennungslauf(conn, TENANT_A)
        row = conn.execute(sa_text(
            "SELECT provider_name, laufstatus FROM hybrid_erkennungslaeufe WHERE id = :rid"
        ), {"rid": run_id}).fetchone()
        assert row is not None
        assert row[0] == "pdfplumber"
        assert row[1] == "success"
        conn.execute(sa_text("DELETE FROM hybrid_erkennungslaeufe WHERE id = :rid"), {"rid": run_id})


# ---------------------------------------------------------------------------
# HY02: hybrid_kandidaten persistieren
# ---------------------------------------------------------------------------

def test_hybrid_kandidaten_persistieren(sync_engine):
    """HY02: Kandidat einfuegen und wiederfinden, CASCADE loeschen."""
    with sync_engine.begin() as conn:
        _set_tenant(conn, TENANT_A)
        run_id = _insert_hybrid_erkennungslauf(conn, TENANT_A)
        conn.execute(sa_text(
            "INSERT INTO hybrid_kandidaten "
            "(unternehmen_id, hybrid_erkennungslauf_id, feld, rohwert, methode, provider_name, confidence) "
            "VALUES (:uid, :rid, 'invoice_number', 'RE-001', 'regex_label', 'pdfplumber', 0.9)"
        ), {"uid": TENANT_A, "rid": run_id})
        row = conn.execute(sa_text(
            "SELECT feld, confidence FROM hybrid_kandidaten WHERE hybrid_erkennungslauf_id = :rid"
        ), {"rid": run_id}).fetchone()
        assert row is not None
        assert row[0] == "invoice_number"
        # CASCADE: erkennungslauf loeschen entfernt kandidaten
        conn.execute(sa_text("DELETE FROM hybrid_erkennungslaeufe WHERE id = :rid"), {"rid": run_id})
        remaining = conn.execute(sa_text(
            "SELECT id FROM hybrid_kandidaten WHERE hybrid_erkennungslauf_id = :rid"
        ), {"rid": run_id}).fetchone()
        assert remaining is None


# ---------------------------------------------------------------------------
# HY03: hybrid_konflikte persistieren
# ---------------------------------------------------------------------------

def test_hybrid_konflikte_persistieren(sync_engine):
    """HY03: Konflikt einfuegen und wiederfinden."""
    with sync_engine.begin() as conn:
        _set_tenant(conn, TENANT_A)
        conn.execute(sa_text(
            "INSERT INTO hybrid_konflikte "
            "(unternehmen_id, feld, konflikt_gruppe) "
            "VALUES (:uid, 'total_amount', 'GRP-1')"
        ), {"uid": TENANT_A})
        row = conn.execute(sa_text(
            "SELECT feld FROM hybrid_konflikte WHERE unternehmen_id = :uid AND konflikt_gruppe = 'GRP-1'"
        ), {"uid": TENANT_A}).fetchone()
        assert row is not None
        assert row[0] == "total_amount"
        conn.execute(sa_text(
            "DELETE FROM hybrid_konflikte WHERE unternehmen_id = :uid AND konflikt_gruppe = 'GRP-1'"
        ), {"uid": TENANT_A})


# ---------------------------------------------------------------------------
# HY04: hybrid_statusentscheidung persistieren
# ---------------------------------------------------------------------------

def test_hybrid_statusentscheidung_persistieren(sync_engine):
    """HY04: Statusentscheidung einfuegen und wiederfinden."""
    with sync_engine.begin() as conn:
        _set_tenant(conn, TENANT_A)
        conn.execute(sa_text(
            "INSERT INTO hybrid_statusentscheidungen "
            "(unternehmen_id, hybrid_status, pflichtfelder_ok, konflikt_frei) "
            "VALUES (:uid, 'OK', true, true)"
        ), {"uid": TENANT_A})
        row = conn.execute(sa_text(
            "SELECT hybrid_status FROM hybrid_statusentscheidungen "
            "WHERE unternehmen_id = :uid AND hybrid_status = 'OK'"
        ), {"uid": TENANT_A}).fetchone()
        assert row is not None
        conn.execute(sa_text(
            "DELETE FROM hybrid_statusentscheidungen WHERE unternehmen_id = :uid AND hybrid_status = 'OK'"
        ), {"uid": TENANT_A})


# ---------------------------------------------------------------------------
# HY05: Tenant-Isolation
# ---------------------------------------------------------------------------

def test_tenant_isolation_hybrid_erkennungslaeufe(app_role_sync_engine):
    """HY05: Tenant B sieht keine Erkennungslaeufe von Tenant A.

    Laeuft ueber die App-Rolle (buchungatakan_app, kein Superuser/BYPASSRLS) --
    P-10-Skip ohne APP_DATABASE_URL. Ueber TEST_DATABASE_URL (moeglicherweise
    privilegiert, z.B. postgres) waere diese scharfe Assertion nicht aussagekraeftig.
    """
    with app_role_sync_engine.begin() as conn:
        # Tenant A einfuegen
        _set_tenant(conn, TENANT_A)
        run_id = _insert_hybrid_erkennungslauf(conn, TENANT_A)

        # Tenant B context — darf run von A nicht sehen (RLS)
        _set_tenant(conn, TENANT_B)
        row = conn.execute(sa_text(
            "SELECT id FROM hybrid_erkennungslaeufe WHERE id = :rid"
        ), {"rid": run_id}).fetchone()
        assert row is None, "Tenant B sieht Erkennungslauf von Tenant A — RLS-Fehler"

        # Cleanup als A
        _set_tenant(conn, TENANT_A)
        conn.execute(sa_text("DELETE FROM hybrid_erkennungslaeufe WHERE id = :rid"), {"rid": run_id})


# ---------------------------------------------------------------------------
# HY09: alembic check
# ---------------------------------------------------------------------------

def test_alembic_check_nach_migration_011(apply_migrations):
    """HY09: Alembic check bleibt sauber — ORM und Migration sind synchron."""
    from alembic import command
    from alembic.config import Config
    from sqlalchemy.engine import make_url
    from tests.conftest import TEST_DB_URL

    sync_url = make_url(TEST_DB_URL).set(drivername="postgresql+psycopg2").render_as_string(hide_password=False)
    alembic_cfg = Config("alembic.ini")
    alembic_cfg.set_main_option("sqlalchemy.url", sync_url)
    command.check(alembic_cfg)
