"""Integrationstests Rechnungs-API — PostgreSQL + RLS (RECH-03/06/08/09/11).

Abgedeckte Anforderungen:
  Req 1:  Rechnung via API anlegen
  Req 2:  Liste + Detail abrufen
  Req 3:  Neuere Version aktiv
  Req 4:  Gleiches Datum → last-write-wins
  Req 5:  Ältere Version gespeichert, aber inaktiv
  Req 6:  Liste/Matching nur aktive Version
  Req 7:  Fremder Mandant → 404 (keine Datenlecks)
  Req 8:  Erkennungsläufe mandantengetrennt
  Req 9:  Rechnungskandidaten mandantengetrennt
  Req 10: API- und DB-Sicht stimmig

Keine Mocks. Keine direkten RLS-Bypässe. unternehmen_id ausschließlich aus JWT.
"""
import pytest
from decimal import Decimal
from uuid import uuid4

from sqlalchemy import text

TENANT_A = "00000000-0000-4000-a000-000000000001"
TENANT_B = "00000000-0000-4000-a000-000000000002"


# ── Hilfs-Funktionen ─────────────────────────────────────────────────────────

async def _login(client, username: str, password: str) -> str:
    resp = await client.post(
        "/api/v1/auth/login",
        data={"username": username, "password": password},
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    assert resp.status_code == 200, f"Login fehlgeschlagen: {resp.text}"
    return resp.json()["access_token"]


def _auth(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


def _unique_rn() -> str:
    """Eindeutige Rechnungsnummer pro Aufruf, vermeidet UNIQUE-Kollisionen."""
    return f"INT-{uuid4().hex[:8].upper()}"


async def _create_dok(db_session, tenant_id: str) -> str:
    """Legt Installation + Dokument an. Gibt dokument_id (str) zurück.

    Jeder Aufruf erzeugt neue UUIDs (idempotent über unique sha256).
    Tenant-Kontext via set_config, Commit beendet die Transaktion.
    """
    sha = f"int-test-{uuid4().hex}"
    await db_session.execute(
        text("SELECT set_config('app.current_tenant', :tid, true)"), {"tid": tenant_id}
    )
    r = await db_session.execute(
        text(
            "INSERT INTO installationen (id, unternehmen_id) "
            "VALUES (gen_random_uuid(), :uid) RETURNING id"
        ),
        {"uid": tenant_id},
    )
    install_id = r.scalar()
    r = await db_session.execute(
        text(
            "INSERT INTO dokumente "
            "(id, unternehmen_id, installation_id, sha256, "
            " relative_path, dateiname, dateigroesse, mime_type) "
            "VALUES (gen_random_uuid(), :uid, :iid, :sha, "
            "        'test/dok.pdf', 'dok.pdf', 1024, 'application/pdf') "
            "RETURNING id"
        ),
        {"uid": tenant_id, "iid": install_id, "sha": sha},
    )
    dok_id = str(r.scalar())
    await db_session.commit()
    return dok_id


async def _create_lauf(db_session, tenant_id: str, dok_id: str) -> str:
    """Legt Erkennungslauf in DB an. Gibt id (str) zurück."""
    await db_session.execute(
        text("SELECT set_config('app.current_tenant', :tid, true)"), {"tid": tenant_id}
    )
    r = await db_session.execute(
        text(
            "INSERT INTO erkennungslaeufe "
            "(id, unternehmen_id, dokument_id, extraktion_status, extraktion_confidence, fehler) "
            "VALUES (gen_random_uuid(), :uid, :did, 'ABGESCHLOSSEN', 0.92, NULL) "
            "RETURNING id"
        ),
        {"uid": tenant_id, "did": dok_id},
    )
    lauf_id = str(r.scalar())
    await db_session.commit()
    return lauf_id


async def _create_kandidat(db_session, tenant_id: str, lauf_id: str) -> str:
    """Legt Rechnungskandidat an. Gibt id (str) zurück."""
    await db_session.execute(
        text("SELECT set_config('app.current_tenant', :tid, true)"), {"tid": tenant_id}
    )
    r = await db_session.execute(
        text(
            "INSERT INTO rechnungs_kandidaten "
            "(id, unternehmen_id, erkennungslauf_id, "
            " feld, rohwert, normwert, methode, quelle, confidence) "
            "VALUES (gen_random_uuid(), :uid, :lid, "
            "        'gesamtbetrag', '119,00', '119.00', 'regex', 'pdf_text', 0.900) "
            "RETURNING id"
        ),
        {"uid": tenant_id, "lid": lauf_id},
    )
    kandidat_id = str(r.scalar())
    await db_session.commit()
    return kandidat_id


# ── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture
async def tok_a(http_client):
    """JWT für admin_a (TENANT_A)."""
    return await _login(http_client, "admin_a", "testpassword123")


@pytest.fixture
async def tok_b(http_client):
    """JWT für admin_b (TENANT_B)."""
    return await _login(http_client, "admin_b", "testpassword123")


@pytest.fixture
async def dok_a(db_session):
    """Installation + Dokument für TENANT_A."""
    return await _create_dok(db_session, TENANT_A)


@pytest.fixture
async def dok_b(db_session):
    """Installation + Dokument für TENANT_B."""
    return await _create_dok(db_session, TENANT_B)


# ── Tests ─────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_rechnung_anlegen_liste_und_detail(tok_a, http_client, dok_a):
    """Req 1, 2, 10: Anlegen → Liste → Detail — Felder stimmig, kein unternehmen_id-Leak."""
    rn = _unique_rn()

    resp = await http_client.post(
        "/api/v1/rechnungen",
        json={
            "dokument_id": dok_a,
            "rechnungsnummer": rn,
            "rechnungsdatum": "15.03.2024",
            "gesamtbetrag": "119.00",
            "waehrung": "EUR",
        },
        headers=_auth(tok_a),
    )
    assert resp.status_code == 201, f"POST fehlgeschlagen: {resp.text}"
    data = resp.json()
    rechnung_id = data["id"]
    assert data["rechnungsnummer"] == rn
    assert data["ist_aktiv"] is True
    assert data["version_lfd_nr"] == 1
    assert data["status"] == "NEU"
    assert data["waehrung"] == "EUR"
    assert "unternehmen_id" not in data  # SRV-05: nie in Antwort

    # Req 2: Liste enthält die neue Rechnung
    resp = await http_client.get("/api/v1/rechnungen", headers=_auth(tok_a))
    assert resp.status_code == 200
    assert rechnung_id in [r["id"] for r in resp.json()]

    # Req 2 + 10: Detail stimmt mit Anlegen-Antwort überein
    resp = await http_client.get(f"/api/v1/rechnungen/{rechnung_id}", headers=_auth(tok_a))
    assert resp.status_code == 200
    detail = resp.json()
    assert detail["id"] == rechnung_id
    assert detail["rechnungsnummer"] == rn
    assert Decimal(detail["gesamtbetrag"]) == Decimal("119.00")
    assert detail["ist_aktiv"] is True
    assert detail["version_lfd_nr"] == 1


@pytest.mark.asyncio
async def test_versioning_neueres_datum_aktiv_aelteres_inaktiv(
    tok_a, http_client, db_session, dok_a
):
    """Req 3, 5, 6, 10: V2 (neueres Datum) aktiv, V1 inaktiv gespeichert, Liste nur V2."""
    rn = _unique_rn()

    # V1: älteres Datum
    resp = await http_client.post(
        "/api/v1/rechnungen",
        json={"dokument_id": dok_a, "rechnungsnummer": rn, "rechnungsdatum": "01.01.2024"},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 201, resp.text
    v1_id = resp.json()["id"]
    assert resp.json()["ist_aktiv"] is True

    # V2: neueres Datum → V1 deaktiviert (RECH-08), Req 3
    resp = await http_client.post(
        "/api/v1/rechnungen",
        json={"dokument_id": dok_a, "rechnungsnummer": rn, "rechnungsdatum": "15.06.2024"},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 201, resp.text
    v2 = resp.json()
    v2_id = v2["id"]
    assert v2["ist_aktiv"] is True
    assert v2["version_lfd_nr"] == 2

    # Req 6: aktive Liste enthält V2, nicht V1
    resp = await http_client.get("/api/v1/rechnungen", headers=_auth(tok_a))
    aktive_ids = [r["id"] for r in resp.json()]
    assert v2_id in aktive_ids
    assert v1_id not in aktive_ids

    # Req 5 + 10: DB-Direktabfrage — V1 inaktiv, V2 aktiv
    await db_session.execute(
        text("SELECT set_config('app.current_tenant', :tid, true)"), {"tid": TENANT_A}
    )
    result = await db_session.execute(
        text(
            "SELECT id::text, ist_aktiv, version_lfd_nr "
            "FROM rechnungen WHERE rechnungsnummer = :rn ORDER BY version_lfd_nr"
        ),
        {"rn": rn},
    )
    rows = result.fetchall()
    await db_session.rollback()

    assert len(rows) == 2, f"Erwartet 2 Versionen, gefunden: {len(rows)}"
    by_id = {r[0]: (r[1], r[2]) for r in rows}
    assert by_id[v1_id] == (False, 1), "V1 muss inaktiv sein (Req 5)"
    assert by_id[v2_id] == (True, 2),  "V2 muss aktiv sein (Req 10)"


@pytest.mark.asyncio
async def test_versioning_gleiches_datum_last_write_wins(tok_a, http_client, dok_a):
    """Req 4: Gleiche Rechnungsnummer + gleiches Datum → letzter Import gewinnt (RECH-08)."""
    rn = _unique_rn()
    datum = "15.03.2024"

    resp = await http_client.post(
        "/api/v1/rechnungen",
        json={"dokument_id": dok_a, "rechnungsnummer": rn, "rechnungsdatum": datum, "waehrung": "EUR"},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 201, resp.text
    v1_id = resp.json()["id"]

    # V2 gleicher Rechnungsnummer + gleiches Datum → V2 gewinnt
    resp = await http_client.post(
        "/api/v1/rechnungen",
        json={"dokument_id": dok_a, "rechnungsnummer": rn, "rechnungsdatum": datum, "waehrung": "USD"},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 201, resp.text
    v2 = resp.json()
    assert v2["ist_aktiv"] is True
    assert v2["version_lfd_nr"] == 2
    assert v2["waehrung"] == "USD"

    resp = await http_client.get("/api/v1/rechnungen", headers=_auth(tok_a))
    aktive_ids = [r["id"] for r in resp.json()]
    assert v2["id"] in aktive_ids
    assert v1_id not in aktive_ids


@pytest.mark.asyncio
async def test_fremder_mandant_detail_404(tok_a, tok_b, http_client, dok_a):
    """Req 7: Tenant B → exakt 404 auf Rechnung von Tenant A; keine Daten in Fehlerantwort."""
    rn = _unique_rn()

    resp = await http_client.post(
        "/api/v1/rechnungen",
        json={"dokument_id": dok_a, "rechnungsnummer": rn},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 201, resp.text
    rechnung_id = resp.json()["id"]

    # Tenant B: Detail → 404
    resp = await http_client.get(f"/api/v1/rechnungen/{rechnung_id}", headers=_auth(tok_b))
    assert resp.status_code == 404
    assert rn not in resp.text       # keine Rechnungsdaten in Fehlerantwort
    assert TENANT_A not in resp.text  # kein Mandant-A-Leak

    # Tenant B: Liste zeigt Rechnung von Tenant A nicht
    resp = await http_client.get("/api/v1/rechnungen", headers=_auth(tok_b))
    assert resp.status_code == 200
    assert rechnung_id not in [r["id"] for r in resp.json()]


@pytest.mark.asyncio
async def test_erkennungslaeufe_isolation(
    tok_a, tok_b, http_client, db_session, dok_a, dok_b
):
    """Req 8: Erkennungsläufe mandantengetrennt — A sieht nur eigene, B → 404 auf fremde."""
    rn_a = _unique_rn()
    rn_b = _unique_rn()

    # Erkennungslauf A + Rechnung A
    lauf_a_id = await _create_lauf(db_session, TENANT_A, dok_a)
    resp = await http_client.post(
        "/api/v1/rechnungen",
        json={"dokument_id": dok_a, "rechnungsnummer": rn_a, "erkennungslauf_id": lauf_a_id},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 201, resp.text
    rechnung_a_id = resp.json()["id"]

    # Erkennungslauf B + Rechnung B
    lauf_b_id = await _create_lauf(db_session, TENANT_B, dok_b)
    resp = await http_client.post(
        "/api/v1/rechnungen",
        json={"dokument_id": dok_b, "rechnungsnummer": rn_b, "erkennungslauf_id": lauf_b_id},
        headers=_auth(tok_b),
    )
    assert resp.status_code == 201, resp.text

    # Tenant A: nur eigener Lauf sichtbar
    resp = await http_client.get(
        f"/api/v1/rechnungen/{rechnung_a_id}/erkennungslaeufe",
        headers=_auth(tok_a),
    )
    assert resp.status_code == 200
    laeufe = resp.json()
    assert len(laeufe) == 1
    assert laeufe[0]["id"] == lauf_a_id
    assert lauf_b_id not in [l["id"] for l in laeufe]

    # Tenant B: 404 bei Erkennungsläufen der fremden Rechnung (Req 8)
    resp = await http_client.get(
        f"/api/v1/rechnungen/{rechnung_a_id}/erkennungslaeufe",
        headers=_auth(tok_b),
    )
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_kandidaten_isolation(
    tok_a, tok_b, http_client, db_session, dok_a, dok_b
):
    """Req 9: Rechnungskandidaten mandantengetrennt — A sieht nur eigene, B → 404 auf fremde."""
    rn_a = _unique_rn()
    rn_b = _unique_rn()

    # Setup Tenant A: Lauf + Rechnung + Kandidat
    lauf_a_id = await _create_lauf(db_session, TENANT_A, dok_a)
    resp = await http_client.post(
        "/api/v1/rechnungen",
        json={"dokument_id": dok_a, "rechnungsnummer": rn_a, "erkennungslauf_id": lauf_a_id},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 201, resp.text
    rechnung_a_id = resp.json()["id"]
    kandidat_a_id = await _create_kandidat(db_session, TENANT_A, lauf_a_id)

    # Setup Tenant B: Lauf + Rechnung + Kandidat
    lauf_b_id = await _create_lauf(db_session, TENANT_B, dok_b)
    resp = await http_client.post(
        "/api/v1/rechnungen",
        json={"dokument_id": dok_b, "rechnungsnummer": rn_b, "erkennungslauf_id": lauf_b_id},
        headers=_auth(tok_b),
    )
    assert resp.status_code == 201, resp.text
    await _create_kandidat(db_session, TENANT_B, lauf_b_id)

    # Tenant A: nur eigener Kandidat sichtbar
    resp = await http_client.get(
        f"/api/v1/rechnungen/{rechnung_a_id}/kandidaten",
        headers=_auth(tok_a),
    )
    assert resp.status_code == 200
    kandidaten = resp.json()
    assert len(kandidaten) == 1
    assert kandidaten[0]["id"] == kandidat_a_id

    # Tenant B: 404 (Rechnung gehört nicht zu Tenant B)
    resp = await http_client.get(
        f"/api/v1/rechnungen/{rechnung_a_id}/kandidaten",
        headers=_auth(tok_b),
    )
    assert resp.status_code == 404
