"""Integrationstests fuer Schema und Alembic-Migrationen (SRV-06, SRV-07).
Alle Tests skippen ohne TEST_DATABASE_URL.
"""
import os

import pytest
from sqlalchemy import text


@pytest.mark.asyncio
async def test_schema_has_benutzer_unternehmen_id(db_session):
    """SRV-06: benutzer.unternehmen_id existiert als UUID-Spalte."""
    result = await db_session.execute(text("""
        SELECT data_type FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = 'benutzer'
          AND column_name = 'unternehmen_id'
    """))
    row = result.fetchone()
    assert row is not None, "Spalte benutzer.unternehmen_id fehlt"
    assert row[0] == "uuid"


@pytest.mark.asyncio
async def test_schema_has_installationen_unternehmen_id(db_session):
    """SRV-06: installationen.unternehmen_id existiert als UUID-Spalte."""
    result = await db_session.execute(text("""
        SELECT data_type FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = 'installationen'
          AND column_name = 'unternehmen_id'
    """))
    row = result.fetchone()
    assert row is not None, "Spalte installationen.unternehmen_id fehlt"
    assert row[0] == "uuid"


@pytest.mark.asyncio
async def test_schema_has_benutzer_index(db_session):
    """SRV-06: ix_benutzer_unternehmen_id Index vorhanden."""
    result = await db_session.execute(text("""
        SELECT indexname FROM pg_indexes
        WHERE tablename = 'benutzer'
          AND indexname = 'ix_benutzer_unternehmen_id'
    """))
    assert result.fetchone() is not None, "Index ix_benutzer_unternehmen_id fehlt"


def test_migration_idempotent(apply_migrations):
    """SRV-07: Zweiter alembic upgrade head laeuft fehlerfrei."""
    from alembic import command
    from alembic.config import Config
    from sqlalchemy.engine import make_url

    test_url = os.environ.get("TEST_DATABASE_URL")
    alembic_cfg = Config("alembic.ini")
    # render_as_string(hide_password=False) statt str() --
    # str() maskiert Passwort als '***'; explizite URL muss verbindungsfaehig sein.
    sync_url = make_url(test_url).set(drivername="postgresql+psycopg2").render_as_string(hide_password=False)
    alembic_cfg.set_main_option("sqlalchemy.url", sync_url)
    command.upgrade(alembic_cfg, "head")  # Zweiter Lauf -- muss No-Op sein


def test_alembic_check_passes(apply_migrations):
    """SRV-07: alembic check -- kein offener Delta zwischen ORM und Schema."""
    from alembic import command
    from alembic.config import Config
    from sqlalchemy.engine import make_url

    test_url = os.environ.get("TEST_DATABASE_URL")
    alembic_cfg = Config("alembic.ini")
    sync_url = make_url(test_url).set(drivername="postgresql+psycopg2").render_as_string(hide_password=False)
    alembic_cfg.set_main_option("sqlalchemy.url", sync_url)
    command.check(alembic_cfg)


def test_migration_guard_zielt_auf_test_db(apply_migrations):
    """Guard: explizite Test-URL passiert pruefe_migrationsziel ohne Fehler."""
    from migrations.migration_guard import pruefe_migrationsziel
    from sqlalchemy.engine import make_url

    test_url = os.environ.get("TEST_DATABASE_URL")
    sync_url = make_url(test_url).set(drivername="postgresql+psycopg2").render_as_string(hide_password=False)
    # Kein RuntimeError erwartet
    pruefe_migrationsziel(sync_url)


def test_migration_guard_lehnt_dev_db_ab(apply_migrations):
    """Guard: Ziel-URL ohne 'test' im DB-Namen wird abgelehnt wenn TEST_DATABASE_URL gesetzt."""
    import pytest
    from migrations.migration_guard import pruefe_migrationsziel

    fake_dev_url = "postgresql+psycopg2://u:p@localhost:5432/buchungatakan"
    with pytest.raises(RuntimeError, match="SICHERHEITSFEHLER"):
        pruefe_migrationsziel(fake_dev_url)
