"""Synthetischer Reporttest — Phase 06, Paket 3.

Prueft das Zusammenspiel aller EC-Komponenten mit vollstaendig synthetischen Daten.
Keine echten Dateinamen, Inhalte, Hashes oder Credentials.

Szenarien:
  R01: Jede synthetische EC_EINZAHLUNG erscheint genau einmal in der Zuordnungsliste
  R02: Status-Verteilung korrekt (STARK, UNSICHER, OFFENE_PERIODE)
  R03: Score, Belegsumme, Differenz, Einzahlungssumme stimmen
  R04: Zeitfenster-Felder gesetzt
  R05: Entscheidungsfelder leer bei Auto-Vorschlaegen
  R06: Bestaetigte Gruppe erscheint korrekt im Report
  R07: Abgelehnte Gruppe erscheint korrekt im Report
  R08: Enthaltene und entfernte Belege werden gezaehlt
  R09: Mehrere Konten bleiben getrennt
  R10: Zusammenfassung-Metriken stimmen
"""
from datetime import date
from uuid import uuid4

import pytest


TENANT_A = "00000000-0000-4000-a000-000000000001"


async def _login(client, username: str = "admin_a", password: str = "testpassword123") -> str:
    resp = await client.post(
        "/api/v1/auth/login",
        data={"username": username, "password": password},
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    assert resp.status_code == 200
    return resp.json()["access_token"]


def _auth(t: str) -> dict:
    return {"Authorization": f"Bearer {t}"}


async def _konto(client, token: str, name: str) -> str:
    r = await client.post("/api/v1/bankkonten", json={"anzeigename": name}, headers=_auth(token))
    assert r.status_code == 201
    return r.json()["id"]


async def _buchungen(client, token: str, konto: str, rows: list[dict]) -> None:
    r = await client.post(
        "/api/v1/bankbuchungen/importe",
        json={"bankkonto_id": konto, "quell_referenz": "synthetic-test.mt940", "buchungen": rows},
        headers=_auth(token),
    )
    assert r.status_code == 201, r.text


async def _belege(client, token: str, konto: str, rows: list[dict]) -> None:
    r = await client.post(
        "/api/v1/ec/belege/importe",
        json={"bankkonto_id": konto, "quell_referenz": "synthetic-belege.csv", "belege": rows},
        headers=_auth(token),
    )
    assert r.status_code == 201, r.text


async def _rematch(client, token: str, konto: str, max_tage: int = 2) -> dict:
    r = await client.post(
        "/api/v1/ec/sammelzuordnungen/rematch",
        json={"bankkonto_id": konto, "max_verzoegerung_tage": max_tage},
        headers=_auth(token),
    )
    assert r.status_code == 200, r.text
    return r.json()


async def _zuordnungen(client, token: str, konto: str) -> list[dict]:
    r = await client.get(f"/api/v1/ec/sammelzuordnungen?bankkonto_id={konto}", headers=_auth(token))
    assert r.status_code == 200
    return r.json()


async def _detail(client, token: str, zid: str) -> dict:
    r = await client.get(f"/api/v1/ec/sammelzuordnungen/{zid}", headers=_auth(token))
    assert r.status_code == 200
    return r.json()


async def _bestaetigen(client, token: str, zid: str, notiz: str | None = None) -> dict:
    body: dict = {}
    if notiz:
        body["notiz"] = notiz
    r = await client.post(f"/api/v1/ec/sammelzuordnungen/{zid}/bestaetigen", json=body, headers=_auth(token))
    assert r.status_code == 200, r.text
    return r.json()


async def _ablehnen(client, token: str, zid: str, notiz: str | None = None) -> dict:
    body: dict = {}
    if notiz:
        body["notiz"] = notiz
    r = await client.post(f"/api/v1/ec/sammelzuordnungen/{zid}/ablehnen", json=body, headers=_auth(token))
    assert r.status_code == 200, r.text
    return r.json()


@pytest.fixture
async def report_konto(http_client):
    """Synthetisches Testkonto mit 4 EC_EINZAHLUNGen und deterministischen Belegen.

    Einzahlungen (k1):
      E1: 10000 Cent (2024-03-10) — UNSICHER (ba aktiv, bb+bc entfernt)
      E2:  8000 Cent (2024-03-20) — UNSICHER (bb aktiv 3000<8000, bc entfernt)
      E3:  6000 Cent (2024-03-30) — STARK    (bc allein im Pool, exakt 6000)
      E4:  5000 Cent (2024-04-10) — OFFENE_PERIODE (letzte, keine Belege mehr)

    Beleg-Design (deterministisch, kein UUID-Tie-Breaker noetig):
      ba (10000, 0309): wird von E1 als einziger aktiv konsumiert (bb+bc werden entfernt)
      bb  (3000, 0319): entfernt von E1; E2 konsumiert ihn als aktiv; bc entfernt bei E2
      bc  (6000, 0329): entfernt von E1 und E2; E3 konsumiert ihn → STARK

    Zweites Konto (k2):
      K2-E1: 4000 Cent (2024-03-15), Beleg k2ba (4000, 0314) → STARK
      K2-E2: 2000 Cent (2024-03-25), OFFENE_PERIODE
    """
    tok = await _login(http_client)

    # Konto 1
    k1 = await _konto(http_client, tok, "Report-Konto-1-Synthetic")
    await _buchungen(http_client, tok, k1, [
        {"buchungsdatum": "2024-03-10", "betrag_cent": 10000, "waehrung": "EUR",
         "verwendungszweck": "EC-Karte Abrechnung", "quell_position": 0},
        {"buchungsdatum": "2024-03-20", "betrag_cent": 8000, "waehrung": "EUR",
         "verwendungszweck": "EC-Karte Abrechnung", "quell_position": 1},
        {"buchungsdatum": "2024-03-30", "betrag_cent": 6000, "waehrung": "EUR",
         "verwendungszweck": "EC-Karte Abrechnung", "quell_position": 2},
        {"buchungsdatum": "2024-04-10", "betrag_cent": 5000, "waehrung": "EUR",
         "verwendungszweck": "EC-Karte Abrechnung", "quell_position": 3},
    ])
    await _belege(http_client, tok, k1, [
        # ba: E1 konsumiert ihn (exakt); bb und bc werden entfernt bei E1
        {"buchungsdatum": "2024-03-09", "betrag_cent": 10000, "waehrung": "EUR", "quell_position": "ba"},
        # bb: entfernt bei E1, E2 konsumiert ihn (unterdeckung 3000 < 8000)
        {"buchungsdatum": "2024-03-19", "betrag_cent": 3000, "waehrung": "EUR", "quell_position": "bb"},
        # bc: entfernt bei E1 und E2; E3 konsumiert ihn → STARK (6000=6000)
        {"buchungsdatum": "2024-03-29", "betrag_cent": 6000, "waehrung": "EUR", "quell_position": "bc"},
    ])

    # Konto 2 (anderes Konto)
    k2 = await _konto(http_client, tok, "Report-Konto-2-Synthetic")
    await _buchungen(http_client, tok, k2, [
        {"buchungsdatum": "2024-03-15", "betrag_cent": 4000, "waehrung": "EUR",
         "verwendungszweck": "EC-Karte Abrechnung", "quell_position": 0},
        {"buchungsdatum": "2024-03-25", "betrag_cent": 2000, "waehrung": "EUR",
         "verwendungszweck": "EC-Karte Abrechnung", "quell_position": 1},
    ])
    await _belege(http_client, tok, k2, [
        {"buchungsdatum": "2024-03-14", "betrag_cent": 4000, "waehrung": "EUR", "quell_position": "k2b1"},
    ])

    metriken1 = await _rematch(http_client, tok, k1)
    metriken2 = await _rematch(http_client, tok, k2)

    return {
        "tok": tok,
        "k1": k1,
        "k2": k2,
        "metriken1": metriken1,
        "metriken2": metriken2,
    }


@pytest.mark.asyncio
async def test_r01_jede_einzahlung_genau_einmal(http_client, report_konto):
    """R01: Jede EC_EINZAHLUNG erscheint genau einmal in der Zuordnungsliste."""
    tok = report_konto["tok"]
    k1 = report_konto["k1"]
    zlist = await _zuordnungen(http_client, tok, k1)
    # 4 Einzahlungen → 4 Zuordnungen
    assert len(zlist) == 4, f"Erwartet 4 Zuordnungen, bekam {len(zlist)}: {[z['status'] for z in zlist]}"
    # Jede bankbuchung_id genau einmal
    buch_ids = [z["bankbuchung_id"] for z in zlist]
    assert len(buch_ids) == len(set(buch_ids)), "Bankbuchung-ID mehrfach vorhanden"


@pytest.mark.asyncio
async def test_r02_status_verteilung(http_client, report_konto):
    """R02: Status-Verteilung korrekt — mindestens ein STARK, ein UNSICHER, ein OFFENE_PERIODE."""
    tok = report_konto["tok"]
    k1 = report_konto["k1"]
    zlist = await _zuordnungen(http_client, tok, k1)
    stati = [z["status"] for z in zlist]
    assert "STARK" in stati, f"Kein STARK: {stati}"
    assert "OFFENE_PERIODE" in stati, f"Kein OFFENE_PERIODE: {stati}"
    # UNSICHER oder STARK (Unterdeckung-Einzahlung koennte UNSICHER sein)
    assert any(s in ("UNSICHER", "STARK") for s in stati)


@pytest.mark.asyncio
async def test_r03_score_summe_differenz(http_client, report_konto):
    """R03: STARK-Einzahlungen haben differenz_cent=0 und score>=90."""
    tok = report_konto["tok"]
    k1 = report_konto["k1"]
    zlist = await _zuordnungen(http_client, tok, k1)
    stark_list = [z for z in zlist if z["status"] == "STARK"]
    assert len(stark_list) >= 1
    for z in stark_list:
        assert z["differenz_cent"] == 0, f"STARK mit differenz_cent={z['differenz_cent']}"
        assert z["score"] >= 90, f"STARK mit score={z['score']}"
        assert z["summe_cent"] == z["einzahlung_cent"]


@pytest.mark.asyncio
async def test_r04_zeitfenster_gesetzt(http_client, report_konto):
    """R04: fenster_von und fenster_bis sind bei allen Zuordnungen ausser OFFENE_PERIODE gesetzt."""
    tok = report_konto["tok"]
    k1 = report_konto["k1"]
    zlist = await _zuordnungen(http_client, tok, k1)
    for z in zlist:
        if z["status"] != "OFFENE_PERIODE":
            detail = await _detail(http_client, tok, z["id"])
            assert detail["fenster_von"] is not None, f"fenster_von fehlt fuer {z['status']}"
            assert detail["fenster_bis"] is not None, f"fenster_bis fehlt fuer {z['status']}"


@pytest.mark.asyncio
async def test_r05_entscheidungsfelder_leer_bei_vorschlag(http_client, report_konto):
    """R05: Auto-Vorschlaege haben keine Entscheidungsfelder gesetzt."""
    tok = report_konto["tok"]
    k1 = report_konto["k1"]
    zlist = await _zuordnungen(http_client, tok, k1)
    for z in zlist:
        detail = await _detail(http_client, tok, z["id"])
        assert detail["entschieden_at"] is None
        assert detail["entschieden_von_benutzer_id"] is None
        assert detail["entscheidungsnotiz"] is None


@pytest.mark.asyncio
async def test_r06_bestaetigte_gruppe_im_report(http_client, report_konto):
    """R06: Bestaetigte Gruppe hat korrekte Felder und Entscheidungszeitpunkt."""
    tok = report_konto["tok"]
    k1 = report_konto["k1"]
    zlist = await _zuordnungen(http_client, tok, k1)
    stark = next((z for z in zlist if z["status"] == "STARK"), None)
    assert stark is not None

    ergebnis = await http_client.post(
        f"/api/v1/ec/sammelzuordnungen/{stark['id']}/bestaetigen",
        json={"notiz": "Synthetischer Reporttest"},
        headers=_auth(tok),
    )
    assert ergebnis.status_code == 200
    detail = ergebnis.json()

    assert detail["status"] == "MANUELL_BESTAETIGT"
    assert detail["entschieden_at"] is not None
    assert detail["entschieden_von_benutzer_id"] is not None
    assert detail["entscheidungsnotiz"] == "Synthetischer Reporttest"
    assert detail["differenz_cent"] == 0


@pytest.mark.asyncio
async def test_r07_abgelehnte_gruppe_im_report(http_client, report_konto):
    """R07: Abgelehnte Gruppe hat MANUELL_ABGELEHNT und Entscheidungsnotiz."""
    tok = report_konto["tok"]
    k1 = report_konto["k1"]
    zlist = await _zuordnungen(http_client, tok, k1)
    # Unsichere oder offene Periode ablehnen
    nicht_stark = next(
        (z for z in zlist if z["status"] in ("UNSICHER", "OFFENE_PERIODE")),
        None,
    )
    assert nicht_stark is not None

    ergebnis = await http_client.post(
        f"/api/v1/ec/sammelzuordnungen/{nicht_stark['id']}/ablehnen",
        json={"notiz": "Synthetische Ablehnung"},
        headers=_auth(tok),
    )
    assert ergebnis.status_code == 200
    detail = ergebnis.json()

    assert detail["status"] == "MANUELL_ABGELEHNT"
    assert detail["entschieden_at"] is not None
    assert detail["entscheidungsnotiz"] == "Synthetische Ablehnung"


@pytest.mark.asyncio
async def test_r08_enthaltene_und_entfernte_belege(http_client, report_konto):
    """R08: Detail-Endpoint liefert enthaltene und entfernte Belege korrekt."""
    tok = report_konto["tok"]
    k1 = report_konto["k1"]
    zlist = await _zuordnungen(http_client, tok, k1)

    for z in zlist:
        detail = await _detail(http_client, tok, z["id"])
        # Enthaltene + entfernte Belege sind Listen
        assert isinstance(detail["enthaltene_belege"], list)
        assert isinstance(detail["entfernte_belege"], list)

        if z["status"] in ("STARK", "UNSICHER"):
            # Mindestens ein enthaltener Beleg
            assert len(detail["enthaltene_belege"]) >= 1, \
                f"Zuordnung {z['status']} hat keine enthaltenen Belege"

        # Summe der enthaltenen Belege = summe_cent
        summe = sum(b["betrag_cent"] for b in detail["enthaltene_belege"])
        assert summe == z["summe_cent"], \
            f"Belegsumme {summe} != summe_cent {z['summe_cent']}"


@pytest.mark.asyncio
async def test_r09_mehrere_konten_getrennt(http_client, report_konto):
    """R09: Zuordnungen von Konto 1 und Konto 2 bleiben getrennt."""
    tok = report_konto["tok"]
    k1 = report_konto["k1"]
    k2 = report_konto["k2"]
    z1 = await _zuordnungen(http_client, tok, k1)
    z2 = await _zuordnungen(http_client, tok, k2)

    ids1 = {z["id"] for z in z1}
    ids2 = {z["id"] for z in z2}
    assert ids1.isdisjoint(ids2), "Zuordnungen von Konto 1 und 2 ueberlappen"
    assert len(z1) == 4
    assert len(z2) >= 1


@pytest.mark.asyncio
async def test_r10_zusammenfassung_metriken(http_client, report_konto):
    """R10: Rematch-Metriken sind konsistent mit tatsaechlichen Zuordnungen."""
    tok = report_konto["tok"]
    k1 = report_konto["k1"]
    metriken = report_konto["metriken1"]

    assert metriken["ec_einzahlungen_geprueft"] == 4
    assert metriken["vorschlaege_gesamt"] == 4
    assert metriken["matcher_version"] == "1.0"
    assert metriken["vorschlaege_gesamt"] == metriken["stark"] + metriken["unsicher"]

    zlist = await _zuordnungen(http_client, tok, k1)
    stark_count = sum(1 for z in zlist if z["status"] == "STARK")
    assert stark_count == metriken["stark"]
