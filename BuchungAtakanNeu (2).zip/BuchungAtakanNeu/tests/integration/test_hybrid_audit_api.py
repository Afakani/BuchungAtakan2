"""Integrationstests Hybrid-Audit-API — POST/GET Auditbewertungen, GET Statistik (07-03A).
"""
import uuid

import pytest

from apps.server.models.dokument import Dokument
from apps.server.models.hybrid_extraktion import HybridStatusentscheidung
from apps.server.models.installationen import Installation
from apps.server.models.rechnung import Erkennungslauf

TENANT_A = uuid.UUID("00000000-0000-4000-a000-000000000001")
TENANT_B = uuid.UUID("00000000-0000-4000-a000-000000000002")


async def _login(client, username: str, password: str = "testpassword123") -> str:
    resp = await client.post(
        "/api/v1/auth/login",
        data={"username": username, "password": password},
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    assert resp.status_code == 200, f"Login fehlgeschlagen: {resp.text}"
    return resp.json()["access_token"]


def _auth(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


def _bewertung_body(**overrides) -> dict:
    body = dict(
        rechnungsnummer_korrekt=True,
        rechnungsdatum_korrekt=True,
        gesamtbetrag_korrekt=True,
        lieferant_korrekt=True,
        steuerwerte_korrekt=True,
        empfaenger_korrekt=True,
    )
    body.update(overrides)
    return body


async def _seed_statusentscheidung(db_session, tenant_id: uuid.UUID) -> str:
    from sqlalchemy import text as sa_text

    await db_session.execute(
        sa_text("SELECT set_config('app.current_tenant', :tid, true)"), {"tid": str(tenant_id)}
    )
    installation = Installation(unternehmen_id=tenant_id)
    db_session.add(installation)
    await db_session.flush()

    dokument = Dokument(
        unternehmen_id=tenant_id,
        installation_id=installation.id,
        sha256=f"test-{uuid.uuid4().hex}",
        relative_path="test/rechnung.pdf",
        dateiname="rechnung.pdf",
        dateigroesse=1,
        mime_type="application/pdf",
    )
    db_session.add(dokument)
    await db_session.flush()

    erkennungslauf = Erkennungslauf(
        unternehmen_id=tenant_id, dokument_id=dokument.id, extraktion_status="OK"
    )
    db_session.add(erkennungslauf)
    await db_session.flush()

    entscheidung = HybridStatusentscheidung(
        unternehmen_id=tenant_id,
        erkennungslauf_id=erkennungslauf.id,
        hybrid_status="OK",
        pflichtfelder_ok=True,
        konflikt_frei=True,
        dokument_klasse="TEXT_PDF",
    )
    db_session.add(entscheidung)
    await db_session.flush()
    await db_session.commit()
    return str(entscheidung.id)


@pytest.mark.asyncio
async def test_post_auditbewertung_erstellt_ressource(http_client, db_session):
    statusentscheidung_id = await _seed_statusentscheidung(db_session, TENANT_A)
    tok = await _login(http_client, "admin_a")

    resp = await http_client.post(
        f"/api/v1/hybrid/statusentscheidungen/{statusentscheidung_id}/auditbewertungen",
        json=_bewertung_body(),
        headers=_auth(tok),
    )
    assert resp.status_code == 201, resp.text
    body = resp.json()
    assert body["hybrid_statusentscheidung_id"] == statusentscheidung_id
    assert body["gesamtergebnis_korrekt"] is True


@pytest.mark.asyncio
async def test_post_zwei_bewertungen_liefern_unterschiedliche_ids(http_client, db_session):
    statusentscheidung_id = await _seed_statusentscheidung(db_session, TENANT_A)
    tok = await _login(http_client, "admin_a")

    resp1 = await http_client.post(
        f"/api/v1/hybrid/statusentscheidungen/{statusentscheidung_id}/auditbewertungen",
        json=_bewertung_body(),
        headers=_auth(tok),
    )
    resp2 = await http_client.post(
        f"/api/v1/hybrid/statusentscheidungen/{statusentscheidung_id}/auditbewertungen",
        json=_bewertung_body(steuerwerte_korrekt=False),
        headers=_auth(tok),
    )
    assert resp1.status_code == 201 and resp2.status_code == 201
    assert resp1.json()["id"] != resp2.json()["id"]


@pytest.mark.asyncio
async def test_get_latest_liefert_neueste_bewertung(http_client, db_session):
    statusentscheidung_id = await _seed_statusentscheidung(db_session, TENANT_A)
    tok = await _login(http_client, "admin_a")

    await http_client.post(
        f"/api/v1/hybrid/statusentscheidungen/{statusentscheidung_id}/auditbewertungen",
        json=_bewertung_body(),
        headers=_auth(tok),
    )
    zweite = await http_client.post(
        f"/api/v1/hybrid/statusentscheidungen/{statusentscheidung_id}/auditbewertungen",
        json=_bewertung_body(gesamtbetrag_korrekt=False),
        headers=_auth(tok),
    )

    resp = await http_client.get(
        f"/api/v1/hybrid/statusentscheidungen/{statusentscheidung_id}/auditbewertungen/latest",
        headers=_auth(tok),
    )
    assert resp.status_code == 200
    assert resp.json()["id"] == zweite.json()["id"]
    assert resp.json()["gesamtergebnis_korrekt"] is False


@pytest.mark.asyncio
async def test_get_latest_ohne_bewertung_404(http_client, db_session):
    statusentscheidung_id = await _seed_statusentscheidung(db_session, TENANT_A)
    tok = await _login(http_client, "admin_a")

    resp = await http_client.get(
        f"/api/v1/hybrid/statusentscheidungen/{statusentscheidung_id}/auditbewertungen/latest",
        headers=_auth(tok),
    )
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_tenant_b_kann_statusentscheidung_von_tenant_a_nicht_bewerten(http_client, db_session):
    statusentscheidung_id = await _seed_statusentscheidung(db_session, TENANT_A)
    tok_b = await _login(http_client, "admin_b")

    resp = await http_client.post(
        f"/api/v1/hybrid/statusentscheidungen/{statusentscheidung_id}/auditbewertungen",
        json=_bewertung_body(),
        headers=_auth(tok_b),
    )
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_tenant_b_sieht_auditbewertungen_von_tenant_a_nicht(http_client, db_session):
    statusentscheidung_id = await _seed_statusentscheidung(db_session, TENANT_A)
    tok_a = await _login(http_client, "admin_a")
    tok_b = await _login(http_client, "admin_b")

    await http_client.post(
        f"/api/v1/hybrid/statusentscheidungen/{statusentscheidung_id}/auditbewertungen",
        json=_bewertung_body(),
        headers=_auth(tok_a),
    )

    resp = await http_client.get(
        f"/api/v1/hybrid/statusentscheidungen/{statusentscheidung_id}/auditbewertungen/latest",
        headers=_auth(tok_b),
    )
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_request_body_kann_unternehmen_id_nicht_setzen(http_client, db_session):
    """extra='forbid' auf AuditBewertungRequest -- unternehmen_id ist kein deklariertes
    Feld und muss mit 422 abgelehnt werden (SRV-05: Tenant kommt ausschliesslich aus JWT)."""
    statusentscheidung_id = await _seed_statusentscheidung(db_session, TENANT_A)
    tok = await _login(http_client, "admin_a")

    body = _bewertung_body()
    body["unternehmen_id"] = str(TENANT_B)

    resp = await http_client.post(
        f"/api/v1/hybrid/statusentscheidungen/{statusentscheidung_id}/auditbewertungen",
        json=body,
        headers=_auth(tok),
    )
    assert resp.status_code == 422


@pytest.mark.asyncio
async def test_get_statistik_liefert_gruppen(http_client, db_session):
    statusentscheidung_id = await _seed_statusentscheidung(db_session, TENANT_A)
    tok = await _login(http_client, "admin_a")
    await http_client.post(
        f"/api/v1/hybrid/statusentscheidungen/{statusentscheidung_id}/auditbewertungen",
        json=_bewertung_body(),
        headers=_auth(tok),
    )

    resp = await http_client.get("/api/v1/hybrid/statistik", headers=_auth(tok))
    assert resp.status_code == 200
    gruppen = resp.json()
    assert isinstance(gruppen, list)
    assert len(gruppen) >= 1
    gruppe = gruppen[0]
    assert set(gruppe.keys()) >= {
        "dimensionen", "anzahl", "vollstaendigkeitsquote", "richtigkeitsquote",
        "automatisierungsquote", "pruefquote", "nichterkennungsquote",
    }


@pytest.mark.asyncio
async def test_get_statistik_unbekannte_dimension_400(http_client, db_session):
    tok = await _login(http_client, "admin_a")
    resp = await http_client.get(
        "/api/v1/hybrid/statistik?gruppieren_nach=nicht_existent", headers=_auth(tok)
    )
    assert resp.status_code == 400


@pytest.mark.asyncio
async def test_get_statistik_enthaelt_keine_originalinhalte(http_client, db_session):
    statusentscheidung_id = await _seed_statusentscheidung(db_session, TENANT_A)
    tok = await _login(http_client, "admin_a")
    await http_client.post(
        f"/api/v1/hybrid/statusentscheidungen/{statusentscheidung_id}/auditbewertungen",
        json=_bewertung_body(),
        headers=_auth(tok),
    )
    resp = await http_client.get("/api/v1/hybrid/statistik", headers=_auth(tok))
    text = resp.text.lower()
    for verboten in ("rechnung.pdf", "sha256", "test/rechnung.pdf", "dateiname", "hash"):
        assert verboten not in text
