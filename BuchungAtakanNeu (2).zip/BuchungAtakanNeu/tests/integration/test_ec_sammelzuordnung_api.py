"""Integrationstests EC-Sammelzuordnung-API — Phase 06, Paket 2.

Tests 10–17:
  T10: Rematch erstellt STARK-Vorschlag (exakte Summe, alle Belege im Fenster)
  T11: Rematch erstellt UNSICHER-Vorschlag (Belege nicht exakt)
  T12: Rematch fremdes Bankkonto → 404
  T13: Rematch ohne EC_EINZAHLUNG-Buchungen → leeres Ergebnis
  T14: GET Sammelzuordnungen mandantensicher
  T15: GET Sammelzuordnung Detail mit enthaltenen Belegen
  T16: GET Sammelzuordnung fremde ID → 404
  T17: Offene Periode — letzte EC_EINZAHLUNG bekommt OFFENE_PERIODE
"""
from datetime import date
from uuid import uuid4

import pytest

TENANT_A = "00000000-0000-4000-a000-000000000001"
TENANT_B = "00000000-0000-4000-a000-000000000002"


async def _login(client, username: str, password: str = "testpassword123") -> str:
    resp = await client.post(
        "/api/v1/auth/login",
        data={"username": username, "password": password},
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    assert resp.status_code == 200, f"Login fehlgeschlagen: {resp.text}"
    return resp.json()["access_token"]


def _auth(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


async def _konto_anlegen(client, token: str, anzeigename: str = "EC-Testkonto") -> str:
    resp = await client.post(
        "/api/v1/bankkonten",
        json={"anzeigename": anzeigename},
        headers=_auth(token),
    )
    assert resp.status_code == 201, f"Konto anlegen fehlgeschlagen: {resp.text}"
    return resp.json()["id"]


async def _bankbuchung_importieren(client, token: str, bankkonto_id: str, buchungen: list[dict]) -> None:
    resp = await client.post(
        "/api/v1/bankbuchungen/importe",
        json={"bankkonto_id": bankkonto_id, "quell_referenz": "test.mt940", "buchungen": buchungen},
        headers=_auth(token),
    )
    assert resp.status_code == 201, f"Buchungsimport fehlgeschlagen: {resp.text}"


async def _belege_importieren(client, token: str, bankkonto_id: str, belege: list[dict]) -> None:
    resp = await client.post(
        "/api/v1/ec/belege/importe",
        json={"bankkonto_id": bankkonto_id, "quell_referenz": "test-belege.csv", "belege": belege},
        headers=_auth(token),
    )
    assert resp.status_code == 201, f"Belegimport fehlgeschlagen: {resp.text}"


async def _rematch(client, token: str, bankkonto_id: str, max_verzoegerung_tage: int = 2) -> dict:
    resp = await client.post(
        "/api/v1/ec/sammelzuordnungen/rematch",
        json={"bankkonto_id": bankkonto_id, "max_verzoegerung_tage": max_verzoegerung_tage},
        headers=_auth(token),
    )
    assert resp.status_code == 200, f"Rematch fehlgeschlagen: {resp.text}"
    return resp.json()


@pytest.mark.asyncio
async def test_t10_rematch_stark_vorschlag(http_client):
    """T10: Exakte Summe, alle im Fenster → STARK.

    Zwei EC_EINZAHLUNGen: erste mit exakter Belegsumme (→ STARK),
    zweite ohne Belege (→ OFFENE_PERIODE als letzte Einzahlung).
    """
    tok = await _login(http_client, "admin_a")
    konto = await _konto_anlegen(http_client, tok, "EC-T10")

    # Zwei Einzahlungen: erste abschliessbar (STARK), zweite offen
    await _bankbuchung_importieren(http_client, tok, konto, [
        {
            "buchungsdatum": "2024-01-10",
            "betrag_cent": 15000,
            "waehrung": "EUR",
            "verwendungszweck": "EC-Karte Abrechnung",
            "quell_position": 0,
        },
        {
            "buchungsdatum": "2024-01-20",  # Spaetere Einzahlung (macht erste zu geschlossener Periode)
            "betrag_cent": 5000,
            "waehrung": "EUR",
            "verwendungszweck": "EC-Karte Abrechnung",
            "quell_position": 1,
        },
    ])

    await _belege_importieren(http_client, tok, konto, [
        {"buchungsdatum": "2024-01-09", "betrag_cent": 5000, "waehrung": "EUR", "quell_position": "0"},
        {"buchungsdatum": "2024-01-09", "betrag_cent": 10000, "waehrung": "EUR", "quell_position": "1"},
    ])

    metriken = await _rematch(http_client, tok, konto)
    assert metriken["ec_einzahlungen_geprueft"] == 2
    assert metriken["vorschlaege_gesamt"] == 2
    assert metriken["stark"] == 1
    assert metriken["matcher_version"] == "1.0"

    resp = await http_client.get(
        f"/api/v1/ec/sammelzuordnungen?bankkonto_id={konto}", headers=_auth(tok)
    )
    assert resp.status_code == 200
    zuordnungen = resp.json()
    stati = {z["status"] for z in zuordnungen}
    assert "STARK" in stati
    stark_z = next(z for z in zuordnungen if z["status"] == "STARK")
    assert stark_z["differenz_cent"] == 0


@pytest.mark.asyncio
async def test_t11_rematch_unsicher_vorschlag(http_client):
    """T11: Belege decken Einzahlung nicht exakt → UNSICHER."""
    tok = await _login(http_client, "admin_a")
    konto = await _konto_anlegen(http_client, tok, "EC-T11")

    await _bankbuchung_importieren(http_client, tok, konto, [{
        "buchungsdatum": "2024-02-10",
        "betrag_cent": 20000,
        "waehrung": "EUR",
        "verwendungszweck": "EC-Karte Abrechnung",
        "quell_position": 0,
    }])

    await _belege_importieren(http_client, tok, konto, [
        {"buchungsdatum": "2024-02-09", "betrag_cent": 8000, "waehrung": "EUR", "quell_position": "0"},
    ])

    metriken = await _rematch(http_client, tok, konto)
    assert metriken["vorschlaege_gesamt"] == 1
    # Differenz = 12000 → UNSICHER (score < 90)
    resp = await http_client.get(
        f"/api/v1/ec/sammelzuordnungen?bankkonto_id={konto}", headers=_auth(tok)
    )
    zuordnungen = resp.json()
    assert any(z["status"] in ("UNSICHER", "OFFENE_PERIODE") for z in zuordnungen)


@pytest.mark.asyncio
async def test_t12_rematch_fremdes_bankkonto(http_client):
    """T12: Rematch mit Bankkonto eines anderen Mandanten → 404."""
    tok_a = await _login(http_client, "admin_a")
    tok_b = await _login(http_client, "admin_b")
    konto_b = await _konto_anlegen(http_client, tok_b, "EC-T12-B")

    resp = await http_client.post(
        "/api/v1/ec/sammelzuordnungen/rematch",
        json={"bankkonto_id": konto_b},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_t13_rematch_ohne_buchungen(http_client):
    """T13: Rematch ohne EC_EINZAHLUNG-Buchungen → ohne_vorschlag=0, vorschlaege=0."""
    tok = await _login(http_client, "admin_a")
    konto = await _konto_anlegen(http_client, tok, "EC-T13")

    # Keine Buchungen importiert
    metriken = await _rematch(http_client, tok, konto)
    assert metriken["ec_einzahlungen_geprueft"] == 0
    assert metriken["vorschlaege_gesamt"] == 0
    assert metriken["ohne_vorschlag"] == 0


@pytest.mark.asyncio
async def test_t14_liste_mandantensicher(http_client):
    """T14: Tenant-A sieht keine Sammelzuordnungen von Tenant-B."""
    tok_a = await _login(http_client, "admin_a")
    tok_b = await _login(http_client, "admin_b")
    konto_a = await _konto_anlegen(http_client, tok_a, "EC-T14-A")
    konto_b = await _konto_anlegen(http_client, tok_b, "EC-T14-B")

    for tok, konto in [(tok_a, konto_a), (tok_b, konto_b)]:
        await _bankbuchung_importieren(http_client, tok, konto, [{
            "buchungsdatum": "2024-03-10",
            "betrag_cent": 5000,
            "waehrung": "EUR",
            "verwendungszweck": "EC-Karte Abrechnung",
            "quell_position": 0,
        }])
        await _belege_importieren(http_client, tok, konto, [
            {"buchungsdatum": "2024-03-09", "betrag_cent": 5000, "waehrung": "EUR", "quell_position": "0"},
        ])
        await _rematch(http_client, tok, konto)

    resp_a = await http_client.get(
        f"/api/v1/ec/sammelzuordnungen?bankkonto_id={konto_a}", headers=_auth(tok_a)
    )
    assert resp_a.status_code == 200
    ids_a = {z["id"] for z in resp_a.json()}

    resp_b = await http_client.get(
        f"/api/v1/ec/sammelzuordnungen?bankkonto_id={konto_b}", headers=_auth(tok_b)
    )
    assert resp_b.status_code == 200
    ids_b = {z["id"] for z in resp_b.json()}

    assert ids_a.isdisjoint(ids_b), "Tenant-A und Tenant-B teilen Sammelzuordnungs-IDs"


@pytest.mark.asyncio
async def test_t15_detail_mit_belegen(http_client):
    """T15: GET Detail enthält aktive Belege korrekt."""
    tok = await _login(http_client, "admin_a")
    konto = await _konto_anlegen(http_client, tok, "EC-T15")

    await _bankbuchung_importieren(http_client, tok, konto, [{
        "buchungsdatum": "2024-04-10",
        "betrag_cent": 3000,
        "waehrung": "EUR",
        "verwendungszweck": "EC-Karte Abrechnung",
        "quell_position": 0,
    }])
    await _belege_importieren(http_client, tok, konto, [
        {"buchungsdatum": "2024-04-09", "betrag_cent": 1000, "waehrung": "EUR", "quell_position": "0"},
        {"buchungsdatum": "2024-04-09", "betrag_cent": 2000, "waehrung": "EUR", "quell_position": "1"},
    ])
    await _rematch(http_client, tok, konto)

    resp_list = await http_client.get(
        f"/api/v1/ec/sammelzuordnungen?bankkonto_id={konto}", headers=_auth(tok)
    )
    assert resp_list.status_code == 200
    zuordnungen = resp_list.json()
    assert len(zuordnungen) >= 1
    zuordnung_id = zuordnungen[0]["id"]

    resp_detail = await http_client.get(
        f"/api/v1/ec/sammelzuordnungen/{zuordnung_id}", headers=_auth(tok)
    )
    assert resp_detail.status_code == 200
    detail = resp_detail.json()
    assert "enthaltene_belege" in detail
    assert "entfernte_belege" in detail
    assert len(detail["enthaltene_belege"]) == 2
    summe = sum(b["betrag_cent"] for b in detail["enthaltene_belege"])
    assert summe == 3000


@pytest.mark.asyncio
async def test_t16_detail_fremde_id(http_client):
    """T16: GET Detail mit fremder Zuordnungs-ID → 404."""
    tok = await _login(http_client, "admin_a")
    fremde_id = str(uuid4())
    resp = await http_client.get(
        f"/api/v1/ec/sammelzuordnungen/{fremde_id}", headers=_auth(tok)
    )
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_t17_offene_periode(http_client):
    """T17: Letzte EC_EINZAHLUNG (chronologisch) erhaelt OFFENE_PERIODE."""
    tok = await _login(http_client, "admin_a")
    konto = await _konto_anlegen(http_client, tok, "EC-T17")

    # Zwei EC_EINZAHLUNGEN: erste abschliessbar, zweite offen
    await _bankbuchung_importieren(http_client, tok, konto, [
        {
            "buchungsdatum": "2024-05-10",
            "betrag_cent": 3000,
            "waehrung": "EUR",
            "verwendungszweck": "EC-Karte Abrechnung",
            "quell_position": 0,
        },
        {
            "buchungsdatum": "2024-05-20",  # Spaetere Einzahlung (offen)
            "betrag_cent": 5000,
            "waehrung": "EUR",
            "verwendungszweck": "EC-Karte Abrechnung",
            "quell_position": 1,
        },
    ])
    await _belege_importieren(http_client, tok, konto, [
        {"buchungsdatum": "2024-05-09", "betrag_cent": 3000, "waehrung": "EUR", "quell_position": "0"},
        {"buchungsdatum": "2024-05-19", "betrag_cent": 5000, "waehrung": "EUR", "quell_position": "1"},
    ])
    await _rematch(http_client, tok, konto)

    resp = await http_client.get(
        f"/api/v1/ec/sammelzuordnungen?bankkonto_id={konto}", headers=_auth(tok)
    )
    assert resp.status_code == 200
    zuordnungen = resp.json()
    stati = {z["status"] for z in zuordnungen}
    # Erste Einzahlung → STARK (exakte Summe, im Fenster)
    assert "STARK" in stati or "UNSICHER" in stati
