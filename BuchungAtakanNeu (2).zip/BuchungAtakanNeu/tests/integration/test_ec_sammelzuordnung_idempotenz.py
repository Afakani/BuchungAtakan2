"""Integrationstests Idempotenz und Batch-Safety — Phase 06, Paket 2.

T18: Zweiter Rematch aktualisiert bestehende Vorschlaege (keine Duplikate)
T19: MANUELL_BESTAETIGT bleibt nach erneutem Rematch unveraendert
T20: Batch-Safety fuer Beleg-Zuordnungen (viele Belege pro Sammelzuordnung)
T21: Dritter Rematch nach neuen Belegen aktualisiert Score korrekt
"""
import pytest

TENANT_A = "00000000-0000-4000-a000-000000000001"


async def _login(client, username: str, password: str = "testpassword123") -> str:
    resp = await client.post(
        "/api/v1/auth/login",
        data={"username": username, "password": password},
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    assert resp.status_code == 200, f"Login fehlgeschlagen: {resp.text}"
    return resp.json()["access_token"]


def _auth(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


async def _konto_anlegen(client, token: str, anzeigename: str = "Idempotenz-Konto") -> str:
    resp = await client.post(
        "/api/v1/bankkonten",
        json={"anzeigename": anzeigename},
        headers=_auth(token),
    )
    assert resp.status_code == 201
    return resp.json()["id"]


async def _buchung_import(client, token: str, konto: str, buchungen: list[dict]) -> None:
    resp = await client.post(
        "/api/v1/bankbuchungen/importe",
        json={"bankkonto_id": konto, "quell_referenz": "test.mt940", "buchungen": buchungen},
        headers=_auth(token),
    )
    assert resp.status_code == 201


async def _beleg_import(client, token: str, konto: str, belege: list[dict]) -> None:
    resp = await client.post(
        "/api/v1/ec/belege/importe",
        json={"bankkonto_id": konto, "quell_referenz": "test-belege.csv", "belege": belege},
        headers=_auth(token),
    )
    assert resp.status_code == 201


async def _rematch(client, token: str, konto: str) -> dict:
    resp = await client.post(
        "/api/v1/ec/sammelzuordnungen/rematch",
        json={"bankkonto_id": konto},
        headers=_auth(token),
    )
    assert resp.status_code == 200
    return resp.json()


async def _get_zuordnungen(client, token: str, konto: str) -> list[dict]:
    resp = await client.get(
        f"/api/v1/ec/sammelzuordnungen?bankkonto_id={konto}",
        headers=_auth(token),
    )
    assert resp.status_code == 200
    return resp.json()


@pytest.mark.asyncio
async def test_t18_rematch_idempotent_keine_duplikate(http_client):
    """T18: Zweiter Rematch erzeugt keine doppelten Sammelzuordnungen."""
    tok = await _login(http_client, "admin_a")
    konto = await _konto_anlegen(http_client, tok, "Idempotenz-T18")

    await _buchung_import(http_client, tok, konto, [{
        "buchungsdatum": "2024-06-10",
        "betrag_cent": 10000,
        "waehrung": "EUR",
        "verwendungszweck": "EC-Karte Abrechnung",
        "quell_position": 0,
    }])
    await _beleg_import(http_client, tok, konto, [
        {"buchungsdatum": "2024-06-09", "betrag_cent": 10000, "waehrung": "EUR", "quell_position": "0"},
    ])

    m1 = await _rematch(http_client, tok, konto)
    assert m1["vorschlaege_gesamt"] == 1

    m2 = await _rematch(http_client, tok, konto)
    assert m2["vorschlaege_gesamt"] == 1

    zuordnungen = await _get_zuordnungen(http_client, tok, konto)
    # Nur eine Zuordnung fuer die EC_EINZAHLUNG
    assert len(zuordnungen) == 1


@pytest.mark.asyncio
async def test_t19_manuell_bestaetigt_unveraendert(http_client):
    """T19: MANUELL_BESTAETIGT wird durch erneuten Rematch nicht veraendert."""
    from sqlalchemy import text
    from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
    import os

    tok = await _login(http_client, "admin_a")
    konto = await _konto_anlegen(http_client, tok, "Idempotenz-T19")

    await _buchung_import(http_client, tok, konto, [{
        "buchungsdatum": "2024-07-10",
        "betrag_cent": 5000,
        "waehrung": "EUR",
        "verwendungszweck": "EC-Karte Abrechnung",
        "quell_position": 0,
    }])
    await _beleg_import(http_client, tok, konto, [
        {"buchungsdatum": "2024-07-09", "betrag_cent": 5000, "waehrung": "EUR", "quell_position": "0"},
    ])
    await _rematch(http_client, tok, konto)

    zuordnungen = await _get_zuordnungen(http_client, tok, konto)
    assert len(zuordnungen) == 1
    zuordnung_id = zuordnungen[0]["id"]

    test_url = os.environ.get("TEST_DATABASE_URL")
    if not test_url:
        pytest.skip("TEST_DATABASE_URL nicht gesetzt")

    from sqlalchemy.engine import make_url
    async_test_url = make_url(test_url).set(drivername="postgresql+asyncpg").render_as_string(hide_password=False)

    engine = create_async_engine(async_test_url, echo=False)
    factory = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)
    async with factory() as session:
        await session.execute(
            text("SELECT set_config('app.current_tenant', :tid, false)"),
            {"tid": TENANT_A},
        )
        await session.execute(
            text("UPDATE ec_sammelzuordnungen SET status = 'MANUELL_BESTAETIGT' WHERE id = :id"),
            {"id": zuordnung_id},
        )
        await session.commit()
    await engine.dispose()

    # Zweiter Rematch
    m2 = await _rematch(http_client, tok, konto)
    assert m2["ohne_vorschlag"] >= 1  # MANUELL_BESTAETIGT wird uebersprungen

    zuordnungen_nach = await _get_zuordnungen(http_client, tok, konto)
    bestaetigt = [z for z in zuordnungen_nach if z["id"] == zuordnung_id]
    assert len(bestaetigt) == 1
    assert bestaetigt[0]["status"] == "MANUELL_BESTAETIGT"


@pytest.mark.asyncio
async def test_t20_batch_safety_viele_belege(http_client):
    """T20: Batch-Safety fuer Beleg-Zuordnungen — 2100 Belege pro Sammelzuordnung."""
    tok = await _login(http_client, "admin_a")
    konto = await _konto_anlegen(http_client, tok, "Idempotenz-T20")

    # EC_EINZAHLUNG: 2100 * 100 = 210000 Cent
    await _buchung_import(http_client, tok, konto, [{
        "buchungsdatum": "2024-08-15",
        "betrag_cent": 210000,
        "waehrung": "EUR",
        "verwendungszweck": "EC-Karte Abrechnung",
        "quell_position": 0,
    }])

    # 2100 Belege a 100 Cent (ueberschreitet _MAX_BATCH_SZB=2000)
    belege = [
        {"buchungsdatum": "2024-08-14", "betrag_cent": 100, "waehrung": "EUR", "quell_position": str(i)}
        for i in range(2100)
    ]
    await _beleg_import(http_client, tok, konto, belege)

    # Rematch darf kein asyncpg-Fehler werfen
    metriken = await _rematch(http_client, tok, konto)
    assert metriken["vorschlaege_gesamt"] == 1

    # Detail: alle 2100 Belege als AKTIV
    zuordnungen = await _get_zuordnungen(http_client, tok, konto)
    zuordnung_id = zuordnungen[0]["id"]
    detail_resp = await http_client.get(
        f"/api/v1/ec/sammelzuordnungen/{zuordnung_id}", headers=_auth(tok)
    )
    assert detail_resp.status_code == 200
    detail = detail_resp.json()
    assert len(detail["enthaltene_belege"]) == 2100


@pytest.mark.asyncio
async def test_t21_zweiter_rematch_aktualisiert_score(http_client):
    """T21: Zweiter Rematch mit neuen Belegen aktualisiert Score (kein Duplikat).

    Zwei EC_EINZAHLUNGen: erste wird gematcht (geschlossene Periode → echter Score),
    zweite ist offen und ohne Belege.
    """
    tok = await _login(http_client, "admin_a")
    konto = await _konto_anlegen(http_client, tok, "Idempotenz-T21")

    # Zwei Einzahlungen damit erste eine geschlossene Periode hat
    await _buchung_import(http_client, tok, konto, [
        {
            "buchungsdatum": "2024-09-10",
            "betrag_cent": 12000,
            "waehrung": "EUR",
            "verwendungszweck": "EC-Karte Abrechnung",
            "quell_position": 0,
        },
        {
            "buchungsdatum": "2024-09-20",
            "betrag_cent": 3000,
            "waehrung": "EUR",
            "verwendungszweck": "EC-Karte Abrechnung",
            "quell_position": 1,
        },
    ])

    # Erster Rematch: nur ein Beleg (Unterdeckung bei Einzahlung 1)
    await _beleg_import(http_client, tok, konto, [
        {"buchungsdatum": "2024-09-09", "betrag_cent": 5000, "waehrung": "EUR", "quell_position": "0"},
    ])
    m1 = await _rematch(http_client, tok, konto)
    assert m1["vorschlaege_gesamt"] >= 1

    z1 = await _get_zuordnungen(http_client, tok, konto)
    # Erste Einzahlung: Unterdeckung → UNSICHER
    erste_z = next(z for z in z1 if z["einzahlung_cent"] == 12000)
    score1 = erste_z["score"]
    assert erste_z["status"] == "UNSICHER"

    # Zweiter Beleg importieren (ergibt exakte Summe fuer erste Einzahlung)
    await _beleg_import(http_client, tok, konto, [
        {"buchungsdatum": "2024-09-09", "betrag_cent": 7000, "waehrung": "EUR", "quell_position": "1"},
    ])
    m2 = await _rematch(http_client, tok, konto)
    assert m2["vorschlaege_gesamt"] >= 1

    z2 = await _get_zuordnungen(http_client, tok, konto)
    # Keine Duplikate fuer Einzahlung 1
    einzahlung1_list = [z for z in z2 if z["einzahlung_cent"] == 12000]
    assert len(einzahlung1_list) == 1
    score2 = einzahlung1_list[0]["score"]
    assert score2 > score1  # Score verbessert (exakte Summe)
    assert einzahlung1_list[0]["status"] == "STARK"
