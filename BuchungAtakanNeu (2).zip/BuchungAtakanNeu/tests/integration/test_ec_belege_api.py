"""Integrationstests EC-Beleg-Import-API — Phase 06, Paket 2.

Tests 1–8:
  T1: Import idempotent — zweiter Import selbe Belege → dedupliziert=N, neu=0
  T2: Import mit verschiedenen Belegen — alle werden gespeichert
  T3: Import fremdes Bankkonto → 404
  T4: Import ohne stabiles Signal → 422
  T5: Import mit Float betrag_cent → 422
  T6: Import mit betrag_cent=0 → 422
  T7: Import mit ungueltiger Waehrung → 422
  T8: Import Batch-Safety — viele Belege in einem Request
  T9: GET Belege mandantensicher — Tenant-A sieht keine Tenant-B-Belege
"""
from uuid import uuid4

import pytest

TENANT_A = "00000000-0000-4000-a000-000000000001"
TENANT_B = "00000000-0000-4000-a000-000000000002"


async def _login(client, username: str, password: str = "testpassword123") -> str:
    resp = await client.post(
        "/api/v1/auth/login",
        data={"username": username, "password": password},
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    assert resp.status_code == 200, f"Login fehlgeschlagen: {resp.text}"
    return resp.json()["access_token"]


def _auth(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


async def _konto_anlegen(client, token: str, anzeigename: str = "EC-Testkonto") -> str:
    resp = await client.post(
        "/api/v1/bankkonten",
        json={"anzeigename": anzeigename},
        headers=_auth(token),
    )
    assert resp.status_code == 201, f"Konto anlegen fehlgeschlagen: {resp.text}"
    return resp.json()["id"]


def _beleg(
    buchungsdatum: str = "2024-01-10",
    betrag_cent: int = 4500,
    quell_position: str | None = "0",
    waehrung: str = "EUR",
    zahlungskategorie_roh: str | None = "CardPayment",
    terminal_id: str | None = None,
    transaktionsreferenz: str | None = None,
) -> dict:
    b: dict = {
        "buchungsdatum": buchungsdatum,
        "betrag_cent": betrag_cent,
        "waehrung": waehrung,
    }
    if quell_position is not None:
        b["quell_position"] = quell_position
    if transaktionsreferenz is not None:
        b["transaktionsreferenz"] = transaktionsreferenz
    if zahlungskategorie_roh is not None:
        b["zahlungskategorie_roh"] = zahlungskategorie_roh
    if terminal_id is not None:
        b["terminal_id"] = terminal_id
    return b


async def _importiere(client, token: str, bankkonto_id: str, belege: list[dict]) -> dict:
    resp = await client.post(
        "/api/v1/ec/belege/importe",
        json={
            "bankkonto_id": bankkonto_id,
            "quell_referenz": "test-import.csv",
            "belege": belege,
        },
        headers=_auth(token),
    )
    return resp


@pytest.mark.asyncio
async def test_t1_import_idempotent(http_client):
    """T1: Zweiter Import derselben Belege → dedupliziert=N, neu=0."""
    tok = await _login(http_client, "admin_a")
    konto = await _konto_anlegen(http_client, tok)

    belege = [_beleg(quell_position="0"), _beleg(buchungsdatum="2024-01-11", quell_position="1")]

    resp1 = await _importiere(http_client, tok, konto, belege)
    assert resp1.status_code == 201
    d1 = resp1.json()
    assert d1["uebergeben"] == 2
    assert d1["neu"] == 2
    assert d1["dedupliziert"] == 0

    resp2 = await _importiere(http_client, tok, konto, belege)
    assert resp2.status_code == 201
    d2 = resp2.json()
    assert d2["uebergeben"] == 2
    assert d2["neu"] == 0
    assert d2["dedupliziert"] == 2


@pytest.mark.asyncio
async def test_t2_import_verschiedene_belege(http_client):
    """T2: Verschiedene Belege werden alle gespeichert."""
    tok = await _login(http_client, "admin_a")
    konto = await _konto_anlegen(http_client, tok, "EC-Konto-T2")

    belege = [
        _beleg(buchungsdatum="2024-02-01", betrag_cent=1000, quell_position="0"),
        _beleg(buchungsdatum="2024-02-02", betrag_cent=2000, quell_position="1"),
        _beleg(buchungsdatum="2024-02-03", betrag_cent=3000, quell_position="2"),
    ]
    resp = await _importiere(http_client, tok, konto, belege)
    assert resp.status_code == 201
    d = resp.json()
    assert d["neu"] == 3
    assert d["uebergeben"] == 3


@pytest.mark.asyncio
async def test_t3_import_fremdes_bankkonto(http_client):
    """T3: Import mit Bankkonto eines anderen Mandanten → 404."""
    tok_a = await _login(http_client, "admin_a")
    tok_b = await _login(http_client, "admin_b")
    konto_b = await _konto_anlegen(http_client, tok_b, "Konto-Tenant-B")

    resp = await _importiere(http_client, tok_a, konto_b, [_beleg(quell_position="0")])
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_t4_import_ohne_stabiles_signal(http_client):
    """T4: Import ohne quell_position und transaktionsreferenz → 422."""
    tok = await _login(http_client, "admin_a")
    konto = await _konto_anlegen(http_client, tok, "EC-Konto-T4")

    resp = await http_client.post(
        "/api/v1/ec/belege/importe",
        json={
            "bankkonto_id": konto,
            "quell_referenz": "test.csv",
            "belege": [{
                "buchungsdatum": "2024-01-10",
                "betrag_cent": 1000,
                "waehrung": "EUR",
            }],
        },
        headers=_auth(tok),
    )
    assert resp.status_code == 422


@pytest.mark.asyncio
async def test_t5_import_float_betrag(http_client):
    """T5: betrag_cent als float → 422."""
    tok = await _login(http_client, "admin_a")
    konto = await _konto_anlegen(http_client, tok, "EC-Konto-T5")

    resp = await http_client.post(
        "/api/v1/ec/belege/importe",
        json={
            "bankkonto_id": konto,
            "quell_referenz": "test.csv",
            "belege": [{
                "buchungsdatum": "2024-01-10",
                "betrag_cent": 45.00,
                "waehrung": "EUR",
                "quell_position": "0",
            }],
        },
        headers=_auth(tok),
    )
    assert resp.status_code == 422


@pytest.mark.asyncio
async def test_t6_import_betrag_null(http_client):
    """T6: betrag_cent=0 → 422."""
    tok = await _login(http_client, "admin_a")
    konto = await _konto_anlegen(http_client, tok, "EC-Konto-T6")

    resp = await http_client.post(
        "/api/v1/ec/belege/importe",
        json={
            "bankkonto_id": konto,
            "quell_referenz": "test.csv",
            "belege": [{
                "buchungsdatum": "2024-01-10",
                "betrag_cent": 0,
                "waehrung": "EUR",
                "quell_position": "0",
            }],
        },
        headers=_auth(tok),
    )
    assert resp.status_code == 422


@pytest.mark.asyncio
async def test_t7_import_ungueltige_waehrung(http_client):
    """T7: Ungueltige Waehrung → 422; Normalisierung klein→gross funktioniert."""
    tok = await _login(http_client, "admin_a")
    konto = await _konto_anlegen(http_client, tok, "EC-Konto-T7")

    # Ungueltig: zu kurz
    resp_kurz = await http_client.post(
        "/api/v1/ec/belege/importe",
        json={
            "bankkonto_id": konto,
            "quell_referenz": "test.csv",
            "belege": [{"buchungsdatum": "2024-01-10", "betrag_cent": 1000, "waehrung": "EU", "quell_position": "0"}],
        },
        headers=_auth(tok),
    )
    assert resp_kurz.status_code == 422

    # Klein-Schreibung wird normalisiert und akzeptiert
    resp_klein = await http_client.post(
        "/api/v1/ec/belege/importe",
        json={
            "bankkonto_id": konto,
            "quell_referenz": "test.csv",
            "belege": [{"buchungsdatum": "2024-01-10", "betrag_cent": 1000, "waehrung": "eur", "quell_position": "1"}],
        },
        headers=_auth(tok),
    )
    assert resp_klein.status_code == 201
    assert resp_klein.json()["neu"] == 1


@pytest.mark.asyncio
async def test_t8_import_batch_safety(http_client):
    """T8: Batch-Safety — viele Belege in einem Request ohne asyncpg-Limit."""
    tok = await _login(http_client, "admin_a")
    konto = await _konto_anlegen(http_client, tok, "EC-Konto-T8")

    # 600 Belege (ueberschreitet _MAX_BATCH_BELEGE=500 → zwei Batches)
    belege = [
        {"buchungsdatum": "2024-03-01", "betrag_cent": 100 + i, "waehrung": "EUR", "quell_position": str(i)}
        for i in range(600)
    ]
    resp = await http_client.post(
        "/api/v1/ec/belege/importe",
        json={"bankkonto_id": konto, "quell_referenz": "batch-test.csv", "belege": belege},
        headers=_auth(tok),
    )
    assert resp.status_code == 201
    d = resp.json()
    assert d["uebergeben"] == 600
    assert d["neu"] == 600


@pytest.mark.asyncio
async def test_t9_get_belege_mandantensicher(http_client):
    """T9: Tenant-A sieht keine Belege von Tenant-B."""
    tok_a = await _login(http_client, "admin_a")
    tok_b = await _login(http_client, "admin_b")
    konto_a = await _konto_anlegen(http_client, tok_a, "EC-Konto-T9-A")
    konto_b = await _konto_anlegen(http_client, tok_b, "EC-Konto-T9-B")

    await _importiere(http_client, tok_a, konto_a, [_beleg(quell_position="0", betrag_cent=9999)])
    await _importiere(http_client, tok_b, konto_b, [_beleg(quell_position="0", betrag_cent=8888)])

    resp_a = await http_client.get(
        f"/api/v1/ec/belege?bankkonto_id={konto_a}", headers=_auth(tok_a)
    )
    assert resp_a.status_code == 200
    belege_a = resp_a.json()
    betraege_a = {b["betrag_cent"] for b in belege_a}
    assert 9999 in betraege_a
    assert 8888 not in betraege_a

    resp_b = await http_client.get(
        f"/api/v1/ec/belege?bankkonto_id={konto_b}", headers=_auth(tok_b)
    )
    assert resp_b.status_code == 200
    belege_b = resp_b.json()
    betraege_b = {b["betrag_cent"] for b in belege_b}
    assert 8888 in betraege_b
    assert 9999 not in betraege_b
