"""Integrationstests Migration 012 — dokument_klasse + hybrid_audit_bewertungen (07-03A).

HAM01: hybrid_statusentscheidungen.dokument_klasse existiert, nullable
HAM02: Check-Constraint erlaubt nur bekannte DokumentKlasse-Werte oder NULL
HAM03: hybrid_audit_bewertungen existiert
HAM04: RLS aktiv auf hybrid_audit_bewertungen
HAM05: FORCE RLS aktiv auf hybrid_audit_bewertungen
HAM06: alembic check bleibt sauber nach Migration 012
HAM07: zweiter alembic upgrade head ist No-Op
"""
import pytest
from sqlalchemy import text as sa_text


@pytest.fixture(scope="module")
def sync_engine(apply_migrations):
    from sqlalchemy import create_engine
    from sqlalchemy.engine import make_url
    from tests.conftest import TEST_DB_URL

    url = make_url(TEST_DB_URL).set(drivername="postgresql+psycopg2").render_as_string(hide_password=False)
    engine = create_engine(url)
    yield engine
    engine.dispose()


def test_ham01_dokument_klasse_spalte_nullable(sync_engine):
    with sync_engine.connect() as conn:
        row = conn.execute(sa_text("""
            SELECT is_nullable FROM information_schema.columns
            WHERE table_schema = 'public'
              AND table_name = 'hybrid_statusentscheidungen'
              AND column_name = 'dokument_klasse'
        """)).fetchone()
        assert row is not None, "Spalte dokument_klasse fehlt"
        assert row[0] == "YES", "dokument_klasse muss nullable sein (Altzeilen bleiben NULL)"


@pytest.mark.parametrize("wert", ["TEXT_PDF", "SCAN_PDF", "SONDERFORMAT", "UNBEKANNT"])
def test_ham02_check_constraint_erlaubt_bekannte_werte(wert, sync_engine):
    with sync_engine.begin() as conn:
        conn.execute(sa_text("SELECT set_config('app.current_tenant', '00000000-0000-4000-a000-000000000001', true)"))
        conn.execute(sa_text(
            "INSERT INTO hybrid_statusentscheidungen "
            "(unternehmen_id, hybrid_status, pflichtfelder_ok, konflikt_frei, dokument_klasse) "
            "VALUES ('00000000-0000-4000-a000-000000000001', 'OK', true, true, :wert)"
        ), {"wert": wert})
        conn.execute(sa_text(
            "DELETE FROM hybrid_statusentscheidungen "
            "WHERE unternehmen_id = '00000000-0000-4000-a000-000000000001' AND dokument_klasse = :wert"
        ), {"wert": wert})


def test_ham02_check_constraint_lehnt_unbekannten_wert_ab(sync_engine):
    from sqlalchemy.exc import IntegrityError

    with sync_engine.connect() as conn:
        with conn.begin():
            conn.execute(sa_text("SELECT set_config('app.current_tenant', '00000000-0000-4000-a000-000000000001', true)"))
            with pytest.raises(IntegrityError):
                conn.execute(sa_text(
                    "INSERT INTO hybrid_statusentscheidungen "
                    "(unternehmen_id, hybrid_status, pflichtfelder_ok, konflikt_frei, dokument_klasse) "
                    "VALUES ('00000000-0000-4000-a000-000000000001', 'OK', true, true, 'ERFUNDENER_WERT')"
                ))


def test_ham03_hybrid_audit_bewertungen_tabelle_vorhanden(sync_engine):
    with sync_engine.connect() as conn:
        row = conn.execute(sa_text("""
            SELECT table_name FROM information_schema.tables
            WHERE table_schema = 'public' AND table_name = 'hybrid_audit_bewertungen'
        """)).fetchone()
        assert row is not None, "Tabelle hybrid_audit_bewertungen fehlt"


def test_ham04_rls_aktiv(sync_engine):
    with sync_engine.connect() as conn:
        row = conn.execute(sa_text("""
            SELECT relrowsecurity FROM pg_class
            WHERE relname = 'hybrid_audit_bewertungen' AND relkind = 'r'
        """)).fetchone()
        assert row is not None
        assert row[0] is True


def test_ham05_force_rls_aktiv(sync_engine):
    with sync_engine.connect() as conn:
        row = conn.execute(sa_text("""
            SELECT relforcerowsecurity FROM pg_class
            WHERE relname = 'hybrid_audit_bewertungen' AND relkind = 'r'
        """)).fetchone()
        assert row is not None
        assert row[0] is True


def test_ham06_alembic_check_nach_migration_012(apply_migrations):
    from alembic import command
    from alembic.config import Config
    from sqlalchemy.engine import make_url
    from tests.conftest import TEST_DB_URL

    sync_url = make_url(TEST_DB_URL).set(drivername="postgresql+psycopg2").render_as_string(hide_password=False)
    alembic_cfg = Config("alembic.ini")
    alembic_cfg.set_main_option("sqlalchemy.url", sync_url)
    command.check(alembic_cfg)


def test_ham07_migration_012_idempotent(apply_migrations):
    from alembic import command
    from alembic.config import Config
    from sqlalchemy.engine import make_url
    from tests.conftest import TEST_DB_URL

    sync_url = make_url(TEST_DB_URL).set(drivername="postgresql+psycopg2").render_as_string(hide_password=False)
    alembic_cfg = Config("alembic.ini")
    alembic_cfg.set_main_option("sqlalchemy.url", sync_url)
    command.upgrade(alembic_cfg, "head")
