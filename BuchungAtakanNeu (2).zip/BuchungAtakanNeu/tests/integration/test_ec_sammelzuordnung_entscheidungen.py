"""Integrationstests manuelle EC-Entscheidungen — Phase 06, Paket 3.

E01: Bestaetigen idempotent
E02: Bestaetigen setzt Benutzer-ID (aus JWT) und Zeitpunkt
E03: Nur enthaltene Belege werden auf ZUGEORDNET gesetzt (direkte DB-Verifikation)
E04: Entfernte Belege bleiben VERFUEGBAR nach Bestaetigung (direkte DB-Verifikation)
E05: Zweite bestaetigte Gruppe derselben Bankbuchung → 409 (via DB-Insert + bestaetigen)
E06: Bestaetigte Belege werden ZUGEORDNET und aus VERFUEGBAR entfernt
E07: Ablehnen idempotent
E08: Bestaetigte Gruppe ablehnen → 409
E09: Abgelehnte Gruppe bestaetigen → 409
E10: Rematch schuetzt bestaetigte Gruppe (MANUELL_BESTAETIGT unveraendert)
E11: Rematch laesst abgelehnte Gruppe unveraendert (Fingerprint nicht erneut vorgeschlagen)
E12: Fremde Tenant-Zuordnung → 404
E13: Benutzer-ID im Body wird abgelehnt (extra=forbid → 422)
E14: Parallele Bestaetigungsversuche bleiben durch Idempotenz sicher
"""
import pytest

TENANT_A = "00000000-0000-4000-a000-000000000001"
TENANT_B = "00000000-0000-4000-a000-000000000002"


async def _login(client, username: str, password: str = "testpassword123") -> str:
    resp = await client.post(
        "/api/v1/auth/login",
        data={"username": username, "password": password},
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    assert resp.status_code == 200, f"Login fehlgeschlagen: {resp.text}"
    return resp.json()["access_token"]


def _auth(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


async def _konto(client, token: str, name: str = "EC-Entscheid-Konto") -> str:
    resp = await client.post("/api/v1/bankkonten", json={"anzeigename": name}, headers=_auth(token))
    assert resp.status_code == 201
    return resp.json()["id"]


async def _buchungen(client, token: str, konto: str, rows: list[dict]) -> None:
    resp = await client.post(
        "/api/v1/bankbuchungen/importe",
        json={"bankkonto_id": konto, "quell_referenz": "test.mt940", "buchungen": rows},
        headers=_auth(token),
    )
    assert resp.status_code == 201, resp.text


async def _belege(client, token: str, konto: str, rows: list[dict]) -> None:
    resp = await client.post(
        "/api/v1/ec/belege/importe",
        json={"bankkonto_id": konto, "quell_referenz": "test.csv", "belege": rows},
        headers=_auth(token),
    )
    assert resp.status_code == 201, resp.text


async def _rematch(client, token: str, konto: str, max_tage: int = 2) -> dict:
    resp = await client.post(
        "/api/v1/ec/sammelzuordnungen/rematch",
        json={"bankkonto_id": konto, "max_verzoegerung_tage": max_tage},
        headers=_auth(token),
    )
    assert resp.status_code == 200, resp.text
    return resp.json()


async def _zuordnungen(client, token: str, konto: str) -> list[dict]:
    resp = await client.get(f"/api/v1/ec/sammelzuordnungen?bankkonto_id={konto}", headers=_auth(token))
    assert resp.status_code == 200
    return resp.json()


async def _detail(client, token: str, zuordnung_id: str) -> dict:
    resp = await client.get(f"/api/v1/ec/sammelzuordnungen/{zuordnung_id}", headers=_auth(token))
    assert resp.status_code == 200
    return resp.json()


async def _bestaetigen(client, token: str, zuordnung_id: str, notiz: str | None = None) -> tuple[int, dict]:
    body: dict = {}
    if notiz is not None:
        body["notiz"] = notiz
    resp = await client.post(
        f"/api/v1/ec/sammelzuordnungen/{zuordnung_id}/bestaetigen",
        json=body,
        headers=_auth(token),
    )
    return resp.status_code, resp.json() if resp.status_code < 500 else {}


async def _ablehnen(client, token: str, zuordnung_id: str, notiz: str | None = None) -> tuple[int, dict]:
    body: dict = {}
    if notiz is not None:
        body["notiz"] = notiz
    resp = await client.post(
        f"/api/v1/ec/sammelzuordnungen/{zuordnung_id}/ablehnen",
        json=body,
        headers=_auth(token),
    )
    return resp.status_code, resp.json() if resp.status_code < 500 else {}


async def _setup_einfach(client, token: str, konto_name: str, einzahlung_cent: int = 10000) -> tuple[str, str]:
    """Erstellt Konto, zwei EC_EINZAHLUNGen und einen Beleg, fuehrt Rematch aus.

    Erste Einzahlung (einzahlung_cent) bekommt den Beleg → geschlossene Periode → STARK.
    Zweite Einzahlung (3000) ist die letzte → OFFENE_PERIODE.
    Gibt (konto_id, zuordnung_id_der_ersten_einzahlung) zurueck.
    """
    konto = await _konto(client, token, konto_name)
    await _buchungen(client, token, konto, [
        {
            "buchungsdatum": "2024-11-10",
            "betrag_cent": einzahlung_cent,
            "waehrung": "EUR",
            "verwendungszweck": "EC-Karte Abrechnung",
            "quell_position": 0,
        },
        {
            "buchungsdatum": "2024-11-20",
            "betrag_cent": 3000,
            "waehrung": "EUR",
            "verwendungszweck": "EC-Karte Abrechnung",
            "quell_position": 1,
        },
    ])
    await _belege(client, token, konto, [
        {"buchungsdatum": "2024-11-09", "betrag_cent": einzahlung_cent, "waehrung": "EUR", "quell_position": "0"},
    ])
    await _rematch(client, token, konto)
    zlist = await _zuordnungen(client, token, konto)
    zid = next(z["id"] for z in zlist if z["einzahlung_cent"] == einzahlung_cent)
    return konto, zid


# ── E01-E06 ────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_e01_bestaetigen_idempotent(http_client):
    """E01: Doppeltes Bestaetigen gibt 200 und denselben Status zurueck."""
    tok = await _login(http_client, "admin_a")
    _, zid = await _setup_einfach(http_client, tok, "E01-Konto")

    sc1, r1 = await _bestaetigen(http_client, tok, zid)
    assert sc1 == 200
    assert r1["status"] == "MANUELL_BESTAETIGT"

    sc2, r2 = await _bestaetigen(http_client, tok, zid)
    assert sc2 == 200
    assert r2["status"] == "MANUELL_BESTAETIGT"
    assert r1["id"] == r2["id"]


@pytest.mark.asyncio
async def test_e02_bestaetigen_setzt_benutzer_und_zeitpunkt(http_client):
    """E02: entschieden_von_benutzer_id kommt aus JWT, entschieden_at wird gesetzt."""
    tok = await _login(http_client, "admin_a")
    _, zid = await _setup_einfach(http_client, tok, "E02-Konto")

    sc, r = await _bestaetigen(http_client, tok, zid, notiz="Test E02")
    assert sc == 200
    assert r["status"] == "MANUELL_BESTAETIGT"
    assert r["entschieden_at"] is not None
    assert r["entschieden_von_benutzer_id"] is not None
    assert r["entscheidungsnotiz"] == "Test E02"


@pytest.mark.asyncio
async def test_e03_enthaltene_belege_werden_zugeordnet(http_client):
    """E03: Aktive Belege wechseln nach Bestaetigung auf Status ZUGEORDNET (DB-Check)."""
    import os
    from sqlalchemy import text
    from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
    from sqlalchemy.engine import make_url

    test_url = os.environ.get("TEST_DATABASE_URL")
    if not test_url:
        pytest.skip("TEST_DATABASE_URL nicht gesetzt")

    tok = await _login(http_client, "admin_a")
    konto, zid = await _setup_einfach(http_client, tok, "E03-Konto", einzahlung_cent=5000)

    detail_vor = await _detail(http_client, tok, zid)
    beleg_ids = [b["beleg_id"] for b in detail_vor["enthaltene_belege"]]
    assert len(beleg_ids) > 0

    sc, _ = await _bestaetigen(http_client, tok, zid)
    assert sc == 200

    async_url = make_url(test_url).set(drivername="postgresql+asyncpg").render_as_string(hide_password=False)
    engine = create_async_engine(async_url, echo=False)
    from sqlalchemy.pool import NullPool
    engine = create_async_engine(async_url, echo=False, poolclass=NullPool)
    factory = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)
    try:
        async with factory() as session:
            await session.execute(
                text("SELECT set_config('app.current_tenant', :tid, false)"),
                {"tid": TENANT_A},
            )
            for bid in beleg_ids:
                result = await session.execute(
                    text("SELECT status FROM ec_belege WHERE id = :id AND unternehmen_id = :uid"),
                    {"id": bid, "uid": TENANT_A},
                )
                row = result.fetchone()
                assert row is not None
                assert row[0] == "ZUGEORDNET", f"Beleg {bid} hat Status {row[0]}, erwartet ZUGEORDNET"
    finally:
        await engine.dispose()


@pytest.mark.asyncio
async def test_e04_entfernte_belege_bleiben_verfuegbar(http_client):
    """E04: Entfernte Belege (ENTFERNT_VERSCHOBEN) bleiben VERFUEGBAR nach Bestaetigung."""
    import os
    from sqlalchemy import text
    from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
    from sqlalchemy.engine import make_url
    from sqlalchemy.pool import NullPool

    test_url = os.environ.get("TEST_DATABASE_URL")
    if not test_url:
        pytest.skip("TEST_DATABASE_URL nicht gesetzt")

    tok = await _login(http_client, "admin_a")
    konto = await _konto(http_client, tok, "E04-Konto")

    # Drei Buchungen, zwei Belege: erster (5000) passt in Einzahlung 1,
    # zweiter (9000) ist zu gross → ENTFERNT_VERSCHOBEN
    await _buchungen(http_client, tok, konto, [
        {"buchungsdatum": "2024-11-10", "betrag_cent": 5000, "waehrung": "EUR",
         "verwendungszweck": "EC-Karte Abrechnung", "quell_position": 0},
        {"buchungsdatum": "2024-11-20", "betrag_cent": 9000, "waehrung": "EUR",
         "verwendungszweck": "EC-Karte Abrechnung", "quell_position": 1},
        {"buchungsdatum": "2024-11-30", "betrag_cent": 3000, "waehrung": "EUR",
         "verwendungszweck": "EC-Karte Abrechnung", "quell_position": 2},
    ])
    await _belege(http_client, tok, konto, [
        {"buchungsdatum": "2024-11-09", "betrag_cent": 5000, "waehrung": "EUR", "quell_position": "0"},
        {"buchungsdatum": "2024-11-09", "betrag_cent": 9000, "waehrung": "EUR", "quell_position": "1"},
    ])
    await _rematch(http_client, tok, konto)

    zlist = await _zuordnungen(http_client, tok, konto)
    z5000 = next((z for z in zlist if z["einzahlung_cent"] == 5000), None)
    assert z5000 is not None, "Zuordnung fuer Einzahlung 5000 nicht gefunden"
    zid = z5000["id"]

    detail = await _detail(http_client, tok, zid)
    entfernte_ids = [b["beleg_id"] for b in detail["entfernte_belege"]]

    if not entfernte_ids:
        pytest.skip("Keine entfernten Belege — Testaufbau hat keine Verschiebung erzeugt")

    sc, _ = await _bestaetigen(http_client, tok, zid)
    assert sc == 200

    async_url = make_url(test_url).set(drivername="postgresql+asyncpg").render_as_string(hide_password=False)
    engine = create_async_engine(async_url, echo=False, poolclass=NullPool)
    factory = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)
    try:
        async with factory() as session:
            await session.execute(
                text("SELECT set_config('app.current_tenant', :tid, false)"),
                {"tid": TENANT_A},
            )
            for bid in entfernte_ids:
                result = await session.execute(
                    text("SELECT status FROM ec_belege WHERE id = :id AND unternehmen_id = :uid"),
                    {"id": bid, "uid": TENANT_A},
                )
                row = result.fetchone()
                assert row is not None
                assert row[0] == "VERFUEGBAR", f"Entfernter Beleg {bid} hat Status {row[0]}, erwartet VERFUEGBAR"
    finally:
        await engine.dispose()


@pytest.mark.asyncio
async def test_e05_zweite_bestaetigte_gruppe_selbe_buchung_409(http_client):
    """E05: Zwei MANUELL_BESTAETIGT fuer dieselbe Bankbuchung → 409 bei zweiter.

    Ablauf:
    1. Rematch → zid1=STARK fuer Buchung 8000
    2. bestaetigen(zid1) → MANUELL_BESTAETIGT (legt auto-Index-Slot frei)
    3. Zweite Zuordnung fuer dieselbe Buchung direkt per DB einsetzen (status=UNSICHER)
    4. bestaetigen(zid2) → uix_ec_sammelz_eine_bestaetigte_pro_buchung → IntegrityError → 409
    """
    import os
    from sqlalchemy import text
    from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
    from sqlalchemy.engine import make_url
    from sqlalchemy.pool import NullPool

    test_url = os.environ.get("TEST_DATABASE_URL")
    if not test_url:
        pytest.skip("TEST_DATABASE_URL nicht gesetzt")

    tok = await _login(http_client, "admin_a")
    konto = await _konto(http_client, tok, "E05-Konto")

    await _buchungen(http_client, tok, konto, [
        {"buchungsdatum": "2024-12-10", "betrag_cent": 8000, "waehrung": "EUR",
         "verwendungszweck": "EC-Karte Abrechnung", "quell_position": 0},
        {"buchungsdatum": "2024-12-20", "betrag_cent": 3000, "waehrung": "EUR",
         "verwendungszweck": "EC-Karte Abrechnung", "quell_position": 1},
    ])
    await _belege(http_client, tok, konto, [
        {"buchungsdatum": "2024-12-09", "betrag_cent": 8000, "waehrung": "EUR", "quell_position": "0"},
    ])
    await _rematch(http_client, tok, konto)
    zlist = await _zuordnungen(http_client, tok, konto)
    z8000 = next(z for z in zlist if z["einzahlung_cent"] == 8000)
    zid1 = z8000["id"]

    sc1, _ = await _bestaetigen(http_client, tok, zid1)
    assert sc1 == 200

    # Zweite Zuordnung fuer dieselbe Buchung direkt per DB einfuegen
    async_url = make_url(test_url).set(drivername="postgresql+asyncpg").render_as_string(hide_password=False)
    engine = create_async_engine(async_url, echo=False, poolclass=NullPool)
    factory = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)
    zid2: str | None = None
    try:
        async with factory() as session:
            await session.execute(
                text("SELECT set_config('app.current_tenant', :tid, false)"),
                {"tid": TENANT_A},
            )
            buchung_result = await session.execute(
                text(
                    "SELECT id FROM bankbuchungen "
                    "WHERE betrag_cent = 8000 AND unternehmen_id = :uid "
                    "ORDER BY created_at DESC LIMIT 1"
                ),
                {"uid": TENANT_A},
            )
            buchung_row = buchung_result.fetchone()
            assert buchung_row is not None, "Buchung 8000 nicht gefunden"
            buchung_id = buchung_row[0]

            sammellauf_result = await session.execute(
                text(
                    "SELECT id FROM ec_sammellaeufe "
                    "WHERE bankbuchung_id = :bid AND unternehmen_id = :uid LIMIT 1"
                ),
                {"bid": buchung_id, "uid": TENANT_A},
            )
            sammellauf_row = sammellauf_result.fetchone()
            assert sammellauf_row is not None, "Sammellauf nicht gefunden"
            sammellauf_id = sammellauf_row[0]

            await session.execute(text("""
                INSERT INTO ec_sammelzuordnungen
                    (unternehmen_id, sammellauf_id, bankbuchung_id, bankkonto_id,
                     gruppen_fingerprint, score, status, summe_cent, einzahlung_cent,
                     differenz_cent, matcher_version)
                VALUES
                    (:uid, :slid, :bid, :kid,
                     'test-fp-e05-second', 50, 'UNSICHER', 4000, 8000, 4000, '1.0')
            """), {
                "uid": TENANT_A,
                "slid": sammellauf_id,
                "bid": buchung_id,
                "kid": konto,
            })
            id_result = await session.execute(
                text(
                    "SELECT id FROM ec_sammelzuordnungen "
                    "WHERE gruppen_fingerprint = 'test-fp-e05-second' AND unternehmen_id = :uid"
                ),
                {"uid": TENANT_A},
            )
            id_row = id_result.fetchone()
            assert id_row is not None
            zid2 = str(id_row[0])
            await session.commit()
    finally:
        await engine.dispose()

    sc2, r2 = await _bestaetigen(http_client, tok, zid2)
    assert sc2 == 409, f"Erwartet 409, bekam {sc2}: {r2}"


@pytest.mark.asyncio
async def test_e06_bestaetigte_belege_gesperrt_und_nicht_verfuegbar(http_client):
    """E06: Nach Bestaetigung sind aktive Belege ZUGEORDNET und nicht mehr VERFUEGBAR.

    Application-seitige Schutzschicht: ec_belege.status='ZUGEORDNET' filtert den Beleg
    aus get_offene_ec_belege() heraus, sodass er bei Rematch nicht erneut zugewiesen wird.
    DB-seitig sichert uix_ec_szb_aktive_belegverwendung dasselbe auf Junction-Ebene ab.
    """
    tok = await _login(http_client, "admin_a")
    konto, zid = await _setup_einfach(http_client, tok, "E06-Konto", einzahlung_cent=8500)

    belege_vor = (await http_client.get(
        f"/api/v1/ec/belege?bankkonto_id={konto}", headers=_auth(tok)
    )).json()
    assert any(b["status"] == "VERFUEGBAR" for b in belege_vor), \
        "Kein VERFUEGBAR-Beleg vor Bestaetigung"

    sc, _ = await _bestaetigen(http_client, tok, zid)
    assert sc == 200

    belege_nach = (await http_client.get(
        f"/api/v1/ec/belege?bankkonto_id={konto}", headers=_auth(tok)
    )).json()
    detail = await _detail(http_client, tok, zid)
    aktive_beleg_ids = {b["beleg_id"] for b in detail["enthaltene_belege"]}
    assert len(aktive_beleg_ids) > 0

    zugeordnet_ids = {b["id"] for b in belege_nach if b["status"] == "ZUGEORDNET"}
    assert aktive_beleg_ids.issubset(zugeordnet_ids), \
        f"Nicht alle aktiven Belege ZUGEORDNET: {aktive_beleg_ids - zugeordnet_ids}"

    verfuegbar_ids = {b["id"] for b in belege_nach if b["status"] == "VERFUEGBAR"}
    assert aktive_beleg_ids.isdisjoint(verfuegbar_ids), \
        "Bestaetigte Belege erscheinen noch als VERFUEGBAR"

    # Zweiter Rematch: MANUELL_BESTAETIGT wird nicht ueberschrieben
    await _rematch(http_client, tok, konto)
    r_nach = await _detail(http_client, tok, zid)
    assert r_nach["status"] == "MANUELL_BESTAETIGT"


# ── E07-E11 ────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_e07_ablehnen_idempotent(http_client):
    """E07: Doppeltes Ablehnen gibt 200 und denselben Status zurueck."""
    tok = await _login(http_client, "admin_a")
    _, zid = await _setup_einfach(http_client, tok, "E07-Konto")

    sc1, r1 = await _ablehnen(http_client, tok, zid, notiz="Test E07")
    assert sc1 == 200
    assert r1["status"] == "MANUELL_ABGELEHNT"

    sc2, r2 = await _ablehnen(http_client, tok, zid)
    assert sc2 == 200
    assert r2["status"] == "MANUELL_ABGELEHNT"


@pytest.mark.asyncio
async def test_e08_bestaetigte_gruppe_ablehnen_409(http_client):
    """E08: Bereits bestaetigte Gruppe ablehnen → 409."""
    tok = await _login(http_client, "admin_a")
    _, zid = await _setup_einfach(http_client, tok, "E08-Konto")

    sc_b, _ = await _bestaetigen(http_client, tok, zid)
    assert sc_b == 200

    sc_a, _ = await _ablehnen(http_client, tok, zid)
    assert sc_a == 409


@pytest.mark.asyncio
async def test_e09_abgelehnte_gruppe_bestaetigen_409(http_client):
    """E09: Bereits abgelehnte Gruppe bestaetigen → 409."""
    tok = await _login(http_client, "admin_a")
    _, zid = await _setup_einfach(http_client, tok, "E09-Konto")

    sc_a, _ = await _ablehnen(http_client, tok, zid)
    assert sc_a == 200

    sc_b, _ = await _bestaetigen(http_client, tok, zid)
    assert sc_b == 409


@pytest.mark.asyncio
async def test_e10_rematch_schuetzt_bestaetigte_gruppe(http_client):
    """E10: Rematch veraendert MANUELL_BESTAETIGT weder Status noch Entscheidungsfelder."""
    tok = await _login(http_client, "admin_a")
    konto, zid = await _setup_einfach(http_client, tok, "E10-Konto", einzahlung_cent=7000)

    sc, r_vor = await _bestaetigen(http_client, tok, zid)
    assert sc == 200

    await _rematch(http_client, tok, konto)

    r_nach = await _detail(http_client, tok, zid)
    assert r_nach["status"] == "MANUELL_BESTAETIGT"
    assert r_nach["entschieden_at"] == r_vor["entschieden_at"]
    assert r_nach["entschieden_von_benutzer_id"] == r_vor["entschieden_von_benutzer_id"]


@pytest.mark.asyncio
async def test_e11_rematch_laesst_abgelehnte_gruppe_unveraendert(http_client):
    """E11: Rematch laesst MANUELL_ABGELEHNT unveraendert; abgelehnte Gruppe bleibt erhalten."""
    tok = await _login(http_client, "admin_a")
    konto, zid = await _setup_einfach(http_client, tok, "E11-Konto", einzahlung_cent=9000)

    sc, _ = await _ablehnen(http_client, tok, zid)
    assert sc == 200

    await _rematch(http_client, tok, konto)

    r_nach = await _detail(http_client, tok, zid)
    assert r_nach["status"] == "MANUELL_ABGELEHNT"
    assert r_nach["id"] == zid


# ── E12-E14 ────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_e12_fremde_tenant_zuordnung_404(http_client):
    """E12: Zuordnung aus anderem Mandanten → 404 bei Bestaetigen."""
    tok_a = await _login(http_client, "admin_a")
    tok_b = await _login(http_client, "admin_b")
    _, zid_b = await _setup_einfach(http_client, tok_b, "E12-Konto-B")

    sc, _ = await _bestaetigen(http_client, tok_a, zid_b)
    assert sc == 404


@pytest.mark.asyncio
async def test_e13_benutzer_id_in_body_abgelehnt(http_client):
    """E13: extra=forbid — benutzer_id im Body → 422 (Schema verbietet unbekannte Felder)."""
    from uuid import uuid4

    tok = await _login(http_client, "admin_a")
    _, zid = await _setup_einfach(http_client, tok, "E13-Konto")

    resp = await http_client.post(
        f"/api/v1/ec/sammelzuordnungen/{zid}/bestaetigen",
        json={"benutzer_id": str(uuid4())},
        headers=_auth(tok),
    )
    assert resp.status_code == 422


@pytest.mark.asyncio
async def test_e14_parallele_bestaetigungen_idempotent(http_client):
    """E14: Parallele Bestaetigungen derselben Zuordnung sind alle idempotent (keine 5xx)."""
    import asyncio

    tok = await _login(http_client, "admin_a")
    _, zid = await _setup_einfach(http_client, tok, "E14-Konto")

    async def versuche_bestaetigen() -> int:
        sc, _ = await _bestaetigen(http_client, tok, zid)
        return sc

    ergebnisse = await asyncio.gather(*[versuche_bestaetigen() for _ in range(5)])
    # Alle muessen 200 oder 409 zurueckgeben (kein 5xx)
    assert all(sc in (200, 409) for sc in ergebnisse), f"Unerwartete Status-Codes: {ergebnisse}"
    # Mindestens eine erfolgreiche Bestaetigung
    assert any(sc == 200 for sc in ergebnisse), "Keine einzige Bestaetigung erfolgreich"
