"""Integrationstests Bankbuchungen-API — PostgreSQL + RLS (BANK-01..03/BANK-10/BANK-11).

Abgedeckte Anforderungen:
  I1:  Migration 006/009 und Tabellen/Constraints pruefen.
  I2:  POST-Import — vollstaendiger Import speichert alle Buchungen (BANK-01).
  I3:  GET-Liste — mandantengefiltert.
  I4:  Re-Import desselben Datensatzes → keine Duplikate (BANK-02).
  I5:  Gleicher Betrag+Datum, anderer Verwendungszweck → getrennte Buchungen (BANK-03).
  I6:  Tenant-A sieht keine Daten von Tenant-B (vollstaendig, ohne or-True-Tautologie).
  I7:  Fremde Bankkonto-IDs → 404.
  I8:  RLS/Repository-Sicht konsistent.
  I9:  betrag_cent exakt als Integer gespeichert (BANK-10).
  I10: Klassifikation korrekt persistiert (BANK-11).
  I11: Identische echte Doppelbuchungen werden beide gespeichert (Befund-2).
  I12: Re-Import derselben Quelldatei ist idempotent (Befund-2).
  I13: Gleiche Buchungsdaten aus zwei Quellen → zwei Eintraege (Befund-2).
  I14: Fehlendes stabiles Quellsignal → 422 (Befund-2).
  I15: IBAN vollstaendig maskiert in Speicherung und Antwort (Befund-4).
  I16: Ungueltige Waehrung → 422; Normalisierung klein→gross (Befund-6).
  I17: Cross-Tenant Composite-FK DB-seitig abgelehnt (Migration 009).

Keine echten Kontoauszuege. Nur synthetische Fixtures.
"""
import pytest
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError
from uuid import uuid4

TENANT_A = "00000000-0000-4000-a000-000000000001"
TENANT_B = "00000000-0000-4000-a000-000000000002"


# ── Hilfs-Funktionen ─────────────────────────────────────────────────────────

async def _login(client, username: str, password: str) -> str:
    resp = await client.post(
        "/api/v1/auth/login",
        data={"username": username, "password": password},
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    assert resp.status_code == 200, f"Login fehlgeschlagen: {resp.text}"
    return resp.json()["access_token"]


def _auth(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


def _buchung(
    buchungsdatum="2024-01-15",
    betrag_cent=11900,
    verwendungszweck="Rechnung 001",
    gegenpartei_name="Lieferant GmbH",
    externe_buchungs_id=None,
    waehrung="EUR",
    quell_position: int | None = 0,
):
    b = {
        "buchungsdatum": buchungsdatum,
        "betrag_cent": betrag_cent,
        "waehrung": waehrung,
        "verwendungszweck": verwendungszweck,
        "gegenpartei_name": gegenpartei_name,
    }
    if externe_buchungs_id is not None:
        b["externe_buchungs_id"] = externe_buchungs_id
    elif quell_position is not None:
        b["quell_position"] = quell_position
    return b


async def _konto_anlegen(client, token: str, anzeigename: str = "Testkonto") -> str:
    resp = await client.post(
        "/api/v1/bankkonten",
        json={"anzeigename": anzeigename},
        headers=_auth(token),
    )
    assert resp.status_code == 201, f"Bankkonto anlegen fehlgeschlagen: {resp.text}"
    return resp.json()["id"]


async def _importieren(client, token: str, bankkonto_id: str, buchungen: list, quell_referenz: str | None = None) -> dict:
    body = {
        "bankkonto_id": bankkonto_id,
        "buchungen": buchungen,
    }
    if quell_referenz is not None:
        body["quell_referenz"] = quell_referenz
    resp = await client.post(
        "/api/v1/bankbuchungen/importe",
        json=body,
        headers=_auth(token),
    )
    return resp


# ── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture
async def tok_a(http_client):
    return await _login(http_client, "admin_a", "testpassword123")


@pytest.fixture
async def tok_b(http_client):
    return await _login(http_client, "admin_b", "testpassword123")


@pytest.fixture
async def konto_a(http_client, tok_a):
    return await _konto_anlegen(http_client, tok_a, "Hauptkonto A")


@pytest.fixture
async def konto_b(http_client, tok_b):
    return await _konto_anlegen(http_client, tok_b, "Hauptkonto B")


# ── Tests I1: Migrationen ────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_migration_006_tabellen_existieren(db_session):
    """I1: Migration 006 — bankkonten, kontoauszugsimporte, bankbuchungen vorhanden."""
    await db_session.execute(text("SELECT set_config('app.current_tenant', :t, true)"), {"t": TENANT_A})
    for tabelle in ("bankkonten", "kontoauszugsimporte", "bankbuchungen"):
        result = await db_session.execute(
            text(
                "SELECT COUNT(*) FROM information_schema.tables "
                "WHERE table_schema = 'public' AND table_name = :t"
            ),
            {"t": tabelle},
        )
        assert result.scalar() == 1, f"Tabelle '{tabelle}' fehlt"
    await db_session.rollback()


@pytest.mark.asyncio
async def test_migration_006_constraint_vorhanden(db_session):
    """I1: UNIQUE-Constraint uq_bankbuchung_fingerprint vorhanden."""
    await db_session.execute(text("SELECT set_config('app.current_tenant', :t, true)"), {"t": TENANT_A})
    result = await db_session.execute(
        text(
            "SELECT COUNT(*) FROM information_schema.table_constraints "
            "WHERE constraint_name = 'uq_bankbuchung_fingerprint'"
        )
    )
    assert result.scalar() == 1, "UNIQUE-Constraint uq_bankbuchung_fingerprint fehlt"
    await db_session.rollback()


@pytest.mark.asyncio
async def test_migration_006_betrag_cent_typ_integer(db_session):
    """I9: betrag_cent ist INTEGER, kein REAL/FLOAT."""
    await db_session.execute(text("SELECT set_config('app.current_tenant', :t, true)"), {"t": TENANT_A})
    result = await db_session.execute(
        text(
            "SELECT data_type FROM information_schema.columns "
            "WHERE table_name = 'bankbuchungen' AND column_name = 'betrag_cent'"
        )
    )
    typ = result.scalar()
    assert typ == "integer", f"betrag_cent sollte integer sein, ist: {typ}"
    await db_session.rollback()


@pytest.mark.asyncio
async def test_migration_009_composite_unique_bankkonten(db_session):
    """I17: Migration 009 — UNIQUE (id, unternehmen_id) auf bankkonten vorhanden."""
    await db_session.execute(text("SELECT set_config('app.current_tenant', :t, true)"), {"t": TENANT_A})
    result = await db_session.execute(
        text(
            "SELECT COUNT(*) FROM information_schema.table_constraints "
            "WHERE constraint_name = 'uq_bankkonten_id_unternehmen'"
        )
    )
    assert result.scalar() == 1, "UNIQUE uq_bankkonten_id_unternehmen fehlt (Migration 009)"
    await db_session.rollback()


@pytest.mark.asyncio
async def test_migration_009_composite_fk_vorhanden(db_session):
    """I17: Migration 009 — Composite FKs in pg_constraint vorhanden."""
    await db_session.execute(text("SELECT set_config('app.current_tenant', :t, true)"), {"t": TENANT_A})
    for constraint in (
        "fk_kontoauszugsimporte_bankkonto_tenant",
        "fk_bankbuchungen_bankkonto_tenant",
        "fk_bankbuchungen_import_tenant",
    ):
        result = await db_session.execute(
            text("SELECT COUNT(*) FROM pg_constraint WHERE conname = :c"),
            {"c": constraint},
        )
        assert result.scalar() == 1, f"Composite FK '{constraint}' fehlt (Migration 009)"
    await db_session.rollback()


# ── Tests I2/I4/I5: Basis-Import ─────────────────────────────────────────────

@pytest.mark.asyncio
async def test_bankkonto_anlegen(http_client, tok_a):
    """Bankkonto fuer Mandanten anlegen."""
    resp = await http_client.post(
        "/api/v1/bankkonten",
        json={"anzeigename": "Test GmbH Konto", "iban_masked": "DE**...**0000"},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 201, resp.text
    data = resp.json()
    assert data["anzeigename"] == "Test GmbH Konto"
    assert data["ist_aktiv"] is True
    assert "unternehmen_id" not in data


@pytest.mark.asyncio
async def test_post_import_alle_buchungen_gespeichert(http_client, tok_a, konto_a):
    """I2: BANK-01 — alle uebergebenen gueltigen Buchungen gespeichert."""
    buchungen = [
        _buchung("2024-01-10", 5000, "Rech-001", "Lieferant A", quell_position=0),
        _buchung("2024-01-11", 7500, "Rech-002", "Lieferant B", quell_position=1),
        _buchung("2024-01-12", 9999, "Rech-003", "Lieferant C", quell_position=2),
    ]
    resp = await _importieren(http_client, tok_a, konto_a, buchungen)
    assert resp.status_code == 201, resp.text
    data = resp.json()
    assert data["buchungen_uebergeben"] == 3
    assert data["buchungen_neu"] == 3
    assert data["buchungen_dedupliziert"] == 0
    assert data["import_id"] is not None

    resp = await http_client.get(
        "/api/v1/bankbuchungen",
        params={"bankkonto_id": konto_a},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 200
    ids_in_liste = {b["betrag_cent"] for b in resp.json()}
    assert {5000, 7500, 9999}.issubset(ids_in_liste)


@pytest.mark.asyncio
async def test_reimport_keine_duplikate(http_client, tok_a, konto_a):
    """I4: BANK-02 — Re-Import derselben Buchungen erzeugt keine Duplikate."""
    buchungen = [_buchung("2024-02-01", 1234, "Reimport-Test", "Firma X", externe_buchungs_id="TX-REIMPORT-01")]

    resp1 = await _importieren(http_client, tok_a, konto_a, buchungen)
    assert resp1.status_code == 201
    assert resp1.json()["buchungen_neu"] == 1

    resp2 = await _importieren(http_client, tok_a, konto_a, buchungen)
    assert resp2.status_code == 201
    data2 = resp2.json()
    assert data2["buchungen_neu"] == 0
    assert data2["buchungen_dedupliziert"] == 1


@pytest.mark.asyncio
async def test_gleicher_betrag_datum_anderer_text_getrennte_buchungen(
    http_client, tok_a, konto_a
):
    """I5: BANK-03 — gleicher Betrag+Datum, anderer Verwendungszweck → getrennte Buchungen."""
    buchungen = [
        _buchung("2024-03-01", 5000, "Rechnung Lieferant A", "Lieferant A", quell_position=0),
        _buchung("2024-03-01", 5000, "Rechnung Lieferant B", "Lieferant B", quell_position=1),
    ]
    resp = await _importieren(http_client, tok_a, konto_a, buchungen)
    assert resp.status_code == 201, resp.text
    data = resp.json()
    assert data["buchungen_neu"] == 2, "Beide Buchungen muessen gespeichert werden (BANK-03)"
    assert data["buchungen_dedupliziert"] == 0


# ── Tests I6: Tenant-Isolation (vollständig, kein or True) ───────────────────

@pytest.mark.asyncio
async def test_tenant_isolation_a_sieht_nicht_b(
    http_client, tok_a, tok_b, konto_a, konto_b
):
    """I6: Tenant A sieht weder Buchungen noch Konten von Tenant B."""
    # Buchung in Konto B importieren
    buchungen_b = [_buchung("2024-04-01", 9876, "Tenant-B-Buchung", "B-Firma", quell_position=0)]
    resp = await _importieren(http_client, tok_b, konto_b, buchungen_b)
    assert resp.status_code == 201

    # Tenant A: Buchungsliste darf kein fremdes Konto enthalten
    resp = await http_client.get("/api/v1/bankbuchungen", headers=_auth(tok_a))
    assert resp.status_code == 200
    betraege_a = {b["betrag_cent"] for b in resp.json()}
    assert 9876 not in betraege_a, "Tenant A sieht Buchung von Tenant B (Datenleck!)"

    # Tenant A: Konto-B-IDs duerfen in Buchungsliste nicht auftauchen
    konto_ids_a = {b["bankkonto_id"] for b in resp.json()}
    assert konto_b not in konto_ids_a, "Tenant A sieht konto_b in Buchungsliste (Datenleck!)"

    # Tenant A: Import auf fremdes Konto → 404
    resp = await _importieren(
        http_client, tok_a, konto_b,
        [_buchung("2024-04-02", 111, "Versuch fremd", "X", quell_position=0)]
    )
    assert resp.status_code == 404, "Fremdkonto-Import muss 404 liefern"

    # Tenant B: Buchungsliste darf keine Daten von Tenant A enthalten
    resp = await http_client.get("/api/v1/bankbuchungen", headers=_auth(tok_b))
    assert resp.status_code == 200
    betraege_b = {b["betrag_cent"] for b in resp.json()}
    konto_ids_b = {b["bankkonto_id"] for b in resp.json()}
    assert konto_a not in konto_ids_b, "Tenant B sieht konto_a (Datenleck!)"


@pytest.mark.asyncio
async def test_fremdes_bankkonto_404(http_client, tok_a, konto_b):
    """I7: Fremde Bankkonto-ID liefert 404."""
    resp = await _importieren(
        http_client, tok_a, konto_b,
        [_buchung("2024-05-01", 1000, "Test", "Firma", quell_position=0)]
    )
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_nicht_existierendes_konto_uuid_404(http_client, tok_a):
    """I7: Nicht-existierende Bankkonto-UUID → 404."""
    fake_id = str(uuid4())
    resp = await _importieren(
        http_client, tok_a, fake_id,
        [_buchung("2024-05-01", 1000, "Test", "Firma", quell_position=0)]
    )
    assert resp.status_code == 404


# ── Tests I9/I10/I3: Datentypen, Klassifikation, Filter ──────────────────────

@pytest.mark.asyncio
async def test_betrag_cent_exakt_gespeichert(http_client, tok_a, konto_a, db_session):
    """I9: BANK-10 — betrag_cent exakt als Integer in DB."""
    betrag = 999_999_99
    resp = await _importieren(
        http_client, tok_a, konto_a,
        [_buchung("2024-06-01", betrag, "Grossbetrag", "Grossfirma", quell_position=0)]
    )
    assert resp.status_code == 201, resp.text

    await db_session.execute(
        text("SELECT set_config('app.current_tenant', :t, true)"), {"t": TENANT_A}
    )
    result = await db_session.execute(
        text("SELECT betrag_cent FROM bankbuchungen WHERE betrag_cent = :b"),
        {"b": betrag},
    )
    row = result.scalar()
    await db_session.rollback()
    assert row == betrag, f"Betrag {betrag} nicht exakt gespeichert, gefunden: {row}"


@pytest.mark.asyncio
async def test_klassifikation_persistiert(http_client, tok_a, konto_a):
    """I10: BANK-11 — Klassifikation korrekt gespeichert und in Liste sichtbar."""
    buchungen = [
        _buchung("2024-07-01", 100, "Rechnung Normal", "Lieferant", quell_position=0),
        _buchung("2024-07-02", 200, "Kontoführungsgebühr Q2", "Bank AG", quell_position=1),
        _buchung("2024-07-03", 300, "EC-Karte Abrechnung", "Terminal", quell_position=2),
    ]
    resp = await _importieren(http_client, tok_a, konto_a, buchungen)
    assert resp.status_code == 201, resp.text

    resp = await http_client.get(
        "/api/v1/bankbuchungen",
        params={"bankkonto_id": konto_a},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 200
    klassen = {b["betrag_cent"]: b["klassifikation"] for b in resp.json()}

    assert klassen.get(100) == "MATCHBAR"
    assert klassen.get(200) == "NICHT_ZU_MATCHEN"
    assert klassen.get(300) == "EC_EINZAHLUNG"


@pytest.mark.asyncio
async def test_get_liste_filter_klassifikation(http_client, tok_a, konto_a):
    """I3: GET-Filter klassifikation."""
    buchungen = [
        _buchung("2024-08-01", 111, "Rechnung Filter", "Firma A", quell_position=0),
        _buchung("2024-08-02", 222, "Gebühr Filter", None, quell_position=1),
    ]
    await _importieren(http_client, tok_a, konto_a, buchungen)

    resp = await http_client.get(
        "/api/v1/bankbuchungen",
        params={"klassifikation": "MATCHBAR", "bankkonto_id": konto_a},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 200
    for b in resp.json():
        assert b["klassifikation"] == "MATCHBAR"


@pytest.mark.asyncio
async def test_get_liste_filter_datum(http_client, tok_a, konto_a):
    """I3: GET-Filter datum_von/datum_bis."""
    buchungen = [
        _buchung("2024-09-01", 333, "Sept Buchung", "Firma", quell_position=0),
        _buchung("2024-10-01", 444, "Okt Buchung", "Firma", quell_position=1),
    ]
    await _importieren(http_client, tok_a, konto_a, buchungen)

    resp = await http_client.get(
        "/api/v1/bankbuchungen",
        params={"datum_von": "2024-09-01", "datum_bis": "2024-09-30", "bankkonto_id": konto_a},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 200
    buchungen_result = resp.json()
    betraege = {b["betrag_cent"] for b in buchungen_result}
    assert 333 in betraege
    assert 444 not in betraege


@pytest.mark.asyncio
async def test_import_atomizitaet_ungueltige_buchung_abgelehnt(http_client, tok_a, konto_a):
    """I2: Atomarer Import — ungueltige Buchung → ganzer Request 422."""
    buchungen = [
        _buchung("2024-11-01", 500, "Gueltig", "Firma", quell_position=0),
        {
            "buchungsdatum": "2024-11-02",
            "betrag_cent": 1.5,  # float → abgelehnt
            "verwendungszweck": "Float-Fehler",
            "quell_position": 1,
        },
    ]
    resp = await http_client.post(
        "/api/v1/bankbuchungen/importe",
        json={"bankkonto_id": konto_a, "buchungen": buchungen},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 422


@pytest.mark.asyncio
async def test_rls_konsistenz_db_und_api(http_client, tok_a, konto_a, db_session):
    """I8: RLS-Sicht und API-Sicht konsistent."""
    buchungen = [_buchung("2024-12-01", 7777, "RLS-Test", "Firma", quell_position=0)]
    resp = await _importieren(http_client, tok_a, konto_a, buchungen)
    assert resp.status_code == 201

    resp = await http_client.get(
        "/api/v1/bankbuchungen",
        params={"bankkonto_id": konto_a},
        headers=_auth(tok_a),
    )
    api_betraege = {b["betrag_cent"] for b in resp.json()}

    await db_session.execute(
        text("SELECT set_config('app.current_tenant', :t, true)"), {"t": TENANT_A}
    )
    result = await db_session.execute(
        text("SELECT betrag_cent FROM bankbuchungen WHERE betrag_cent = 7777")
    )
    db_betraege = {row[0] for row in result.fetchall()}
    await db_session.rollback()

    assert 7777 in api_betraege
    assert 7777 in db_betraege


# ── Tests I11-I14: Dedup-Haertung (Befund 2) ─────────────────────────────────

@pytest.mark.asyncio
async def test_identische_echte_doppelbuchungen_beide_gespeichert(http_client, tok_a, konto_a):
    """I11: Zwei identische echte Buchungen in derselben Datei werden beide gespeichert.

    Szenario: Gleiches Datum, gleicher Betrag, gleicher Zweck, gleiche Gegenpartei,
    keine externe ID — aber verschiedene Quellpositionen (0 und 1).
    """
    buchungen = [
        _buchung("2024-05-15", 5000, "Miete Mai", "Vermieter GmbH", quell_position=0),
        _buchung("2024-05-15", 5000, "Miete Mai", "Vermieter GmbH", quell_position=1),
    ]
    resp = await _importieren(http_client, tok_a, konto_a, buchungen, quell_referenz="kontoauszug-mai.mta")
    assert resp.status_code == 201, resp.text
    data = resp.json()
    assert data["buchungen_neu"] == 2, (
        "Beide identischen Buchungen muessen gespeichert werden (unterschiedliche quell_position)"
    )
    assert data["buchungen_dedupliziert"] == 0


@pytest.mark.asyncio
async def test_reimport_identische_quelldatei_idempotent(http_client, tok_a, konto_a):
    """I12: Re-Import derselben Quelldatei erzeugt keine Duplikate."""
    buchungen = [
        _buchung("2024-06-01", 3000, "Gehalt", "Arbeitgeber AG", quell_position=0),
        _buchung("2024-06-15", 1200, "Miete", "Vermieter KG", quell_position=1),
    ]
    resp1 = await _importieren(http_client, tok_a, konto_a, buchungen, quell_referenz="juni-auszug.mta")
    assert resp1.status_code == 201
    assert resp1.json()["buchungen_neu"] == 2

    # Exakt derselbe Import nochmals
    resp2 = await _importieren(http_client, tok_a, konto_a, buchungen, quell_referenz="juni-auszug.mta")
    assert resp2.status_code == 201
    data2 = resp2.json()
    assert data2["buchungen_neu"] == 0, "Re-Import muss idempotent sein"
    assert data2["buchungen_dedupliziert"] == 2


@pytest.mark.asyncio
async def test_gleiche_daten_verschiedene_quellen_beide_gespeichert(http_client, tok_a, konto_a):
    """I13: Gleiche Buchungsdaten aus zwei verschiedenen Quellen → zwei Eintraege.

    Szenario: Dieselbe Transaktion erscheint im Oktober- und November-Auszug.
    quell_referenz unterscheidet die Quellen.
    """
    buchung = _buchung("2024-10-31", 9000, "Monatsabschluss", "Bank AG", quell_position=0)

    resp1 = await _importieren(http_client, tok_a, konto_a, [buchung], quell_referenz="oktober.mta")
    assert resp1.status_code == 201
    assert resp1.json()["buchungen_neu"] == 1

    resp2 = await _importieren(http_client, tok_a, konto_a, [buchung], quell_referenz="november.mta")
    assert resp2.status_code == 201
    assert resp2.json()["buchungen_neu"] == 1, (
        "Gleiche Buchung aus anderer Quelle muss als neue Buchung gespeichert werden"
    )


@pytest.mark.asyncio
async def test_externe_id_als_stabiles_signal(http_client, tok_a, konto_a):
    """I14a: Externe ID ist stabiles Primärsignal — Re-Import idempotent."""
    buchung = _buchung("2024-07-10", 4500, "Zahlung", "Kunde X", externe_buchungs_id="EXT-TX-9999")

    resp1 = await _importieren(http_client, tok_a, konto_a, [buchung])
    assert resp1.status_code == 201
    assert resp1.json()["buchungen_neu"] == 1

    resp2 = await _importieren(http_client, tok_a, konto_a, [buchung])
    assert resp2.status_code == 201
    assert resp2.json()["buchungen_dedupliziert"] == 1
    assert resp2.json()["buchungen_neu"] == 0


@pytest.mark.asyncio
async def test_fehlendes_quellsignal_422(http_client, tok_a, konto_a):
    """I14b: Buchung ohne externe_buchungs_id und ohne quell_position → 422."""
    buchung = {
        "buchungsdatum": "2024-08-01",
        "betrag_cent": 1000,
        "verwendungszweck": "Test",
        "gegenpartei_name": "Firma",
        "waehrung": "EUR",
        # weder externe_buchungs_id noch quell_position
    }
    resp = await http_client.post(
        "/api/v1/bankbuchungen/importe",
        json={"bankkonto_id": konto_a, "buchungen": [buchung]},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 422, "Fehlendes Quellsignal muss mit 422 abgelehnt werden"


# ── Tests I15: IBAN-Maskierung (Befund 4) ────────────────────────────────────

@pytest.mark.asyncio
async def test_bankkonto_volle_iban_wird_maskiert(http_client, tok_a):
    """I15a: Vollstaendige IBAN in iban_masked → serverseitig maskiert gespeichert."""
    resp = await http_client.post(
        "/api/v1/bankkonten",
        json={"anzeigename": "IBAN-Test Konto", "iban_masked": "DE89370400440532013000"},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 201, resp.text
    data = resp.json()
    returned_iban = data.get("iban_masked", "")
    assert "*" in returned_iban, "Volle IBAN muss im Response maskiert sein"
    assert returned_iban.startswith("DE"), "Laenderpräfix DE muss sichtbar bleiben"
    assert returned_iban.endswith("3000"), "Letzte 4 Zeichen muessen sichtbar bleiben"
    assert "370400440532" not in returned_iban, "Mittelteil darf nicht unmaskiert sein"


@pytest.mark.asyncio
async def test_bankkonto_maskierte_iban_bleibt_unveraendert(http_client, tok_a):
    """I15b: Bereits maskierte IBAN wird akzeptiert und unveraendert gespeichert."""
    iban = "DE********************3000"
    resp = await http_client.post(
        "/api/v1/bankkonten",
        json={"anzeigename": "Maskiert-Test", "iban_masked": iban},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 201, resp.text
    assert resp.json()["iban_masked"] == iban


@pytest.mark.asyncio
async def test_buchung_gegenpartei_iban_wird_maskiert(http_client, tok_a, konto_a):
    """I15c: Vollstaendige gegenpartei_iban wird maskiert gespeichert und nie unmaskiert zurueckgegeben."""
    buchung = {
        "buchungsdatum": "2024-09-01",
        "betrag_cent": 2500,
        "verwendungszweck": "IBAN-Test-Buchung",
        "gegenpartei_name": "Gegenseite GmbH",
        "gegenpartei_iban": "DE89370400440532013000",
        "waehrung": "EUR",
        "quell_position": 0,
    }
    resp = await _importieren(http_client, tok_a, konto_a, [buchung])
    assert resp.status_code == 201, resp.text

    resp = await http_client.get(
        "/api/v1/bankbuchungen",
        params={"bankkonto_id": konto_a},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 200
    buchungen_result = [b for b in resp.json() if b["betrag_cent"] == 2500]
    assert len(buchungen_result) >= 1
    returned_iban = buchungen_result[0].get("gegenpartei_iban", "")
    assert returned_iban is not None, "gegenpartei_iban sollte vorhanden sein"
    if returned_iban:
        assert "*" in returned_iban, f"gegenpartei_iban muss maskiert sein, ist: {returned_iban}"
        assert "370400440532" not in returned_iban, "Mittelteil unmaskiert (Datenleck!)"


# ── Tests I16: Währungsvalidierung (Befund 6) ─────────────────────────────────

@pytest.mark.asyncio
async def test_waehrung_kleinbuchstaben_normalisiert(http_client, tok_a, konto_a):
    """I16a: Kleinbuchstaben-Waehrung wird zu Grossbuchstaben normalisiert."""
    buchung = _buchung("2024-10-01", 100, "EUR-Test", "Firma", quell_position=0)
    buchung["waehrung"] = "eur"
    resp = await _importieren(http_client, tok_a, konto_a, [buchung])
    assert resp.status_code == 201, resp.text

    resp = await http_client.get(
        "/api/v1/bankbuchungen",
        params={"bankkonto_id": konto_a},
        headers=_auth(tok_a),
    )
    waehrungen = [b["waehrung"] for b in resp.json() if b["betrag_cent"] == 100]
    assert any(w == "EUR" for w in waehrungen), "Waehrung 'eur' muss zu 'EUR' normalisiert werden"


@pytest.mark.asyncio
async def test_waehrung_leer_422(http_client, tok_a, konto_a):
    """I16b: Leere Waehrung → 422."""
    buchung = {
        "buchungsdatum": "2024-10-02",
        "betrag_cent": 100,
        "waehrung": "",
        "quell_position": 0,
    }
    resp = await http_client.post(
        "/api/v1/bankbuchungen/importe",
        json={"bankkonto_id": konto_a, "buchungen": [buchung]},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 422


@pytest.mark.asyncio
async def test_waehrung_zwei_buchstaben_422(http_client, tok_a, konto_a):
    """I16c: Waehrung mit 2 Buchstaben → 422."""
    buchung = {
        "buchungsdatum": "2024-10-03",
        "betrag_cent": 100,
        "waehrung": "EU",
        "quell_position": 0,
    }
    resp = await http_client.post(
        "/api/v1/bankbuchungen/importe",
        json={"bankkonto_id": konto_a, "buchungen": [buchung]},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 422


@pytest.mark.asyncio
async def test_waehrung_vier_buchstaben_422(http_client, tok_a, konto_a):
    """I16d: Waehrung mit 4 Buchstaben → 422."""
    buchung = {
        "buchungsdatum": "2024-10-04",
        "betrag_cent": 100,
        "waehrung": "EURO",
        "quell_position": 0,
    }
    resp = await http_client.post(
        "/api/v1/bankbuchungen/importe",
        json={"bankkonto_id": konto_a, "buchungen": [buchung]},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 422


@pytest.mark.asyncio
async def test_waehrung_ziffer_422(http_client, tok_a, konto_a):
    """I16e: Waehrung mit Ziffer → 422."""
    buchung = {
        "buchungsdatum": "2024-10-05",
        "betrag_cent": 100,
        "waehrung": "12E",
        "quell_position": 0,
    }
    resp = await http_client.post(
        "/api/v1/bankbuchungen/importe",
        json={"bankkonto_id": konto_a, "buchungen": [buchung]},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 422


# ── Tests I17: Cross-Tenant Composite-FK (Befund 3, Migration 009) ───────────

@pytest.mark.asyncio
async def test_cross_tenant_bankkonto_referenz_db_abgelehnt(db_session):
    """I17a: Composite FK: kontoauszugsimporte darf kein Bankkonto eines anderen Mandanten referenzieren."""
    # Bankkonto fuer Tenant A anlegen
    await db_session.execute(
        text("SELECT set_config('app.current_tenant', :t, true)"), {"t": TENANT_A}
    )
    result = await db_session.execute(
        text(
            "INSERT INTO bankkonten (unternehmen_id, anzeigename) "
            "VALUES (:tid, 'Konto A FK-Test') RETURNING id"
        ),
        {"tid": TENANT_A},
    )
    konto_a_id = result.scalar()
    await db_session.flush()

    # Tenant B versucht, kontoauszugsimport mit Tenant-A-Konto anzulegen
    await db_session.execute(
        text("SELECT set_config('app.current_tenant', :t, true)"), {"t": TENANT_B}
    )
    try:
        await db_session.execute(
            text(
                "INSERT INTO kontoauszugsimporte "
                "(unternehmen_id, bankkonto_id, buchungen_uebergeben, buchungen_uebernommen) "
                "VALUES (:tid, :kid, 0, 0)"
            ),
            {"tid": TENANT_B, "kid": konto_a_id},
        )
        await db_session.flush()
        await db_session.rollback()
        pytest.fail(
            "Cross-Tenant-Referenz muss durch Composite FK abgelehnt werden, wurde aber akzeptiert"
        )
    except (IntegrityError, Exception) as e:
        await db_session.rollback()
        err = str(e).lower()
        assert any(kw in err for kw in ("foreign key", "integrity", "fk_kontoauszugsimporte")), (
            f"Erwarteter FK-Fehler, bekommen: {e}"
        )


@pytest.mark.asyncio
async def test_cross_tenant_import_referenz_db_abgelehnt(db_session):
    """I17b: Composite FK: bankbuchungen darf keinen Import eines anderen Mandanten referenzieren."""
    # Tenant A: Bankkonto + Import anlegen
    await db_session.execute(
        text("SELECT set_config('app.current_tenant', :t, true)"), {"t": TENANT_A}
    )
    result = await db_session.execute(
        text(
            "INSERT INTO bankkonten (unternehmen_id, anzeigename) "
            "VALUES (:tid, 'Konto A Import-FK-Test') RETURNING id"
        ),
        {"tid": TENANT_A},
    )
    konto_a_id = result.scalar()
    await db_session.flush()

    result = await db_session.execute(
        text(
            "INSERT INTO kontoauszugsimporte "
            "(unternehmen_id, bankkonto_id, buchungen_uebergeben, buchungen_uebernommen) "
            "VALUES (:tid, :kid, 0, 0) RETURNING id"
        ),
        {"tid": TENANT_A, "kid": konto_a_id},
    )
    import_a_id = result.scalar()
    await db_session.flush()

    # Tenant B: Konto anlegen
    await db_session.execute(
        text("SELECT set_config('app.current_tenant', :t, true)"), {"t": TENANT_B}
    )
    result = await db_session.execute(
        text(
            "INSERT INTO bankkonten (unternehmen_id, anzeigename) "
            "VALUES (:tid, 'Konto B Import-FK-Test') RETURNING id"
        ),
        {"tid": TENANT_B},
    )
    konto_b_id = result.scalar()
    await db_session.flush()

    # Tenant B versucht Buchung mit Tenant-A-Import
    try:
        fp = f"test-fp-cross-tenant-{uuid4().hex[:8]}"
        await db_session.execute(
            text(
                "INSERT INTO bankbuchungen "
                "(unternehmen_id, bankkonto_id, import_id, buchungsdatum, betrag_cent, "
                "waehrung, dedup_fingerprint, klassifikation) "
                "VALUES (:tid, :kid, :iid, '2024-01-01', 100, 'EUR', :fp, 'MATCHBAR')"
            ),
            {"tid": TENANT_B, "kid": konto_b_id, "iid": import_a_id, "fp": fp},
        )
        await db_session.flush()
        await db_session.rollback()
        pytest.fail(
            "Cross-Tenant import_id-Referenz muss durch Composite FK abgelehnt werden"
        )
    except (IntegrityError, Exception) as e:
        await db_session.rollback()
        err = str(e).lower()
        assert any(kw in err for kw in ("foreign key", "integrity", "fk_bankbuchungen")), (
            f"Erwarteter FK-Fehler, bekommen: {e}"
        )
