"""Integrationstests Migration 010 — EC-Sammelzuordnung (Phase 06, Paket 1).

Anforderungen:
  T14: Migration 010 nach 001–009 in Datenbankrevision vorhanden
  T15: Migration 010 mit bestehenden Phase-5-Testdaten kompatibel
  T16: RLS enabled und forced auf allen neuen Tabellen
  T17: Composite-FKs blockieren Cross-Tenant-Verknuepfungen
  T18: Keine Phase-5-Tabellen oder Daten veraendert

Alle Tests skippen ohne TEST_DATABASE_URL.
"""
import os

import pytest
from sqlalchemy import text


def test_migration_010_revision_vorhanden():
    """T14: Migration 010 existiert und ist Teil der Abstammung des aktuellen Head.

    Prueft die Alembic-Skripthistorie statt einer konkreten DB-Version, damit
    additive Nachfolgerevisionen (z. B. 011) den Test nicht brechen.
    """
    from alembic.config import Config
    from alembic.script import ScriptDirectory

    alembic_cfg = Config("alembic.ini")
    script = ScriptDirectory.from_config(alembic_cfg)

    revision_010 = script.get_revision("010")
    assert revision_010 is not None, "Revision 010 fehlt in der Alembic-Historie"

    heads = script.get_heads()
    assert heads, "Keine Head-Revision gefunden"

    for head in heads:
        lineage = {rev.revision for rev in script.iterate_revisions(head, "base")}
        assert "010" in lineage, f"Revision 010 nicht in Abstammung von Head '{head}'"


@pytest.mark.asyncio
async def test_ec_belege_tabelle_existiert(db_session):
    """T14: Tabelle ec_belege wurde durch Migration 010 angelegt."""
    result = await db_session.execute(text("""
        SELECT table_name FROM information_schema.tables
        WHERE table_schema = 'public' AND table_name = 'ec_belege'
    """))
    assert result.fetchone() is not None, "Tabelle ec_belege fehlt"


@pytest.mark.asyncio
async def test_ec_sammellaeufe_tabelle_existiert(db_session):
    """T14: Tabelle ec_sammellaeufe existiert."""
    result = await db_session.execute(text("""
        SELECT table_name FROM information_schema.tables
        WHERE table_schema = 'public' AND table_name = 'ec_sammellaeufe'
    """))
    assert result.fetchone() is not None, "Tabelle ec_sammellaeufe fehlt"


@pytest.mark.asyncio
async def test_ec_sammelzuordnungen_tabelle_existiert(db_session):
    """T14: Tabelle ec_sammelzuordnungen existiert."""
    result = await db_session.execute(text("""
        SELECT table_name FROM information_schema.tables
        WHERE table_schema = 'public' AND table_name = 'ec_sammelzuordnungen'
    """))
    assert result.fetchone() is not None, "Tabelle ec_sammelzuordnungen fehlt"


@pytest.mark.asyncio
async def test_ec_sammelzuordnung_belege_tabelle_existiert(db_session):
    """T14: Tabelle ec_sammelzuordnung_belege existiert."""
    result = await db_session.execute(text("""
        SELECT table_name FROM information_schema.tables
        WHERE table_schema = 'public' AND table_name = 'ec_sammelzuordnung_belege'
    """))
    assert result.fetchone() is not None, "Tabelle ec_sammelzuordnung_belege fehlt"


@pytest.mark.asyncio
async def test_phase5_tabellen_unveraendert(db_session):
    """T15/T18: Phase-5-Tabellen existieren weiterhin und haben unver Struktur."""
    phase5_tabellen = [
        "bankkonten",
        "kontoauszugsimporte",
        "bankbuchungen",
        "zuordnungsvorschlaege",
    ]
    for tbl in phase5_tabellen:
        result = await db_session.execute(text(f"""
            SELECT table_name FROM information_schema.tables
            WHERE table_schema = 'public' AND table_name = :tbl
        """), {"tbl": tbl})
        assert result.fetchone() is not None, f"Phase-5-Tabelle '{tbl}' fehlt nach Migration 010"


@pytest.mark.asyncio
async def test_rls_enabled_ec_belege(db_session):
    """T16: RLS enabled auf ec_belege."""
    result = await db_session.execute(text("""
        SELECT relrowsecurity, relforcerowsecurity
        FROM pg_class WHERE relname = 'ec_belege'
    """))
    row = result.fetchone()
    assert row is not None, "Tabelle ec_belege nicht in pg_class"
    assert row[0] is True, "RLS nicht enabled auf ec_belege"
    assert row[1] is True, "RLS nicht forced auf ec_belege"


@pytest.mark.asyncio
async def test_rls_enabled_ec_sammellaeufe(db_session):
    """T16: RLS enabled auf ec_sammellaeufe."""
    result = await db_session.execute(text("""
        SELECT relrowsecurity, relforcerowsecurity
        FROM pg_class WHERE relname = 'ec_sammellaeufe'
    """))
    row = result.fetchone()
    assert row is not None
    assert row[0] is True, "RLS nicht enabled auf ec_sammellaeufe"
    assert row[1] is True, "RLS nicht forced auf ec_sammellaeufe"


@pytest.mark.asyncio
async def test_rls_enabled_ec_sammelzuordnungen(db_session):
    """T16: RLS enabled auf ec_sammelzuordnungen."""
    result = await db_session.execute(text("""
        SELECT relrowsecurity, relforcerowsecurity
        FROM pg_class WHERE relname = 'ec_sammelzuordnungen'
    """))
    row = result.fetchone()
    assert row is not None
    assert row[0] is True, "RLS nicht enabled auf ec_sammelzuordnungen"
    assert row[1] is True, "RLS nicht forced auf ec_sammelzuordnungen"


@pytest.mark.asyncio
async def test_rls_enabled_ec_sammelzuordnung_belege(db_session):
    """T16: RLS enabled auf ec_sammelzuordnung_belege."""
    result = await db_session.execute(text("""
        SELECT relrowsecurity, relforcerowsecurity
        FROM pg_class WHERE relname = 'ec_sammelzuordnung_belege'
    """))
    row = result.fetchone()
    assert row is not None
    assert row[0] is True, "RLS nicht enabled auf ec_sammelzuordnung_belege"
    assert row[1] is True, "RLS nicht forced auf ec_sammelzuordnung_belege"


@pytest.mark.asyncio
async def test_rls_tenant_policy_ec_belege(db_session):
    """T16: tenant_isolation Policy existiert auf ec_belege."""
    result = await db_session.execute(text("""
        SELECT policyname FROM pg_policies
        WHERE tablename = 'ec_belege' AND policyname = 'tenant_isolation'
    """))
    assert result.fetchone() is not None, "Policy tenant_isolation fehlt auf ec_belege"


@pytest.mark.asyncio
async def test_composite_unique_ec_belege(db_session):
    """T17: UNIQUE (id, unternehmen_id) auf ec_belege als FK-Ziel vorhanden."""
    result = await db_session.execute(text("""
        SELECT conname FROM pg_constraint
        WHERE conrelid = 'ec_belege'::regclass
          AND contype = 'u'
          AND conname = 'uq_ec_belege_id_unternehmen'
    """))
    assert result.fetchone() is not None, "uq_ec_belege_id_unternehmen fehlt"


@pytest.mark.asyncio
async def test_composite_fk_ec_sammellaeufe_bankbuchung(db_session):
    """T17: Composite FK ec_sammellaeufe → bankbuchungen(id, unternehmen_id) vorhanden."""
    result = await db_session.execute(text("""
        SELECT conname FROM pg_constraint
        WHERE conrelid = 'ec_sammellaeufe'::regclass
          AND contype = 'f'
          AND conname = 'fk_ec_sammellaeufe_bankbuchung_tenant'
    """))
    assert result.fetchone() is not None, "fk_ec_sammellaeufe_bankbuchung_tenant fehlt"


@pytest.mark.asyncio
async def test_composite_fk_ec_sammelzuordnungen_sammellauf(db_session):
    """T17: Composite FK ec_sammelzuordnungen → ec_sammellaeufe(id, unternehmen_id) vorhanden."""
    result = await db_session.execute(text("""
        SELECT conname FROM pg_constraint
        WHERE conrelid = 'ec_sammelzuordnungen'::regclass
          AND contype = 'f'
          AND conname = 'fk_ec_sammelzuordnungen_sammellauf_tenant'
    """))
    assert result.fetchone() is not None, "fk_ec_sammelzuordnungen_sammellauf_tenant fehlt"


@pytest.mark.asyncio
async def test_composite_fk_ec_szb_zuordnung(db_session):
    """T17: Composite FK ec_sammelzuordnung_belege → ec_sammelzuordnungen(id, unternehmen_id)."""
    result = await db_session.execute(text("""
        SELECT conname FROM pg_constraint
        WHERE conrelid = 'ec_sammelzuordnung_belege'::regclass
          AND contype = 'f'
          AND conname = 'fk_ec_szb_zuordnung_tenant'
    """))
    assert result.fetchone() is not None, "fk_ec_szb_zuordnung_tenant fehlt"


@pytest.mark.asyncio
async def test_composite_fk_ec_szb_beleg(db_session):
    """T17: Composite FK ec_sammelzuordnung_belege → ec_belege(id, unternehmen_id)."""
    result = await db_session.execute(text("""
        SELECT conname FROM pg_constraint
        WHERE conrelid = 'ec_sammelzuordnung_belege'::regclass
          AND contype = 'f'
          AND conname = 'fk_ec_szb_beleg_tenant'
    """))
    assert result.fetchone() is not None, "fk_ec_szb_beleg_tenant fehlt"


@pytest.mark.asyncio
async def test_partial_index_aktive_belegverwendung(db_session):
    """T17: Partial Index verhindert doppelte aktive Belegverwendung."""
    result = await db_session.execute(text("""
        SELECT indexname FROM pg_indexes
        WHERE tablename = 'ec_sammelzuordnung_belege'
          AND indexname = 'uix_ec_szb_aktive_belegverwendung'
    """))
    assert result.fetchone() is not None, "uix_ec_szb_aktive_belegverwendung fehlt"


@pytest.mark.asyncio
async def test_partial_index_eine_bestaetigte_pro_buchung(db_session):
    """T17: Partial Index verhindert zwei MANUELL_BESTAETIGT pro Bankbuchung."""
    result = await db_session.execute(text("""
        SELECT indexname FROM pg_indexes
        WHERE tablename = 'ec_sammelzuordnungen'
          AND indexname = 'uix_ec_sammelz_eine_bestaetigte_pro_buchung'
    """))
    assert result.fetchone() is not None, "uix_ec_sammelz_eine_bestaetigte_pro_buchung fehlt"


@pytest.mark.asyncio
async def test_betrag_cent_ist_integer(db_session):
    """T15: betrag_cent in ec_belege ist INTEGER, kein Float."""
    result = await db_session.execute(text("""
        SELECT data_type FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = 'ec_belege'
          AND column_name = 'betrag_cent'
    """))
    row = result.fetchone()
    assert row is not None, "Spalte ec_belege.betrag_cent fehlt"
    assert row[0] == "integer", f"betrag_cent ist '{row[0]}', erwartet 'integer'"


@pytest.mark.asyncio
async def test_phase5_seed_data_unveraendert(db_session):
    """T18: Phase-5-Seed-Daten in unternehmen/benutzer unveraendert."""
    await db_session.execute(
        text("SELECT set_config('app.current_tenant', :tid, false)"),
        {"tid": "00000000-0000-4000-a000-000000000001"},
    )
    result = await db_session.execute(text("""
        SELECT COUNT(*) FROM unternehmen
        WHERE id = '00000000-0000-4000-a000-000000000001'
    """))
    count = result.scalar()
    assert count == 1, "Phase-5-Seed-Tenant fehlt nach Migration 010"
