"""Integrationstests Persistenz der Mehrprovider-Auswertung (07-03, HYB-14..16).

Nutzt bestehende Migration-011-Tabellen. Keine neue Migration.
"""
import uuid

import pytest
from sqlalchemy import text as sa_text

from apps.server.models.dokument import Dokument
from apps.server.models.hybrid_extraktion import (
    HybridErkennungslauf,
    HybridKandidatOrm,
    HybridKonflikt,
    HybridStatusentscheidung,
)
from apps.server.models.installationen import Installation
from apps.server.models.rechnung import Erkennungslauf
from apps.server.services.hybrid_auswertung_service import persistiere_hybrid_auswertung
from packages.core.invoice_extraction.hybrid_auswertung import HybridAuswertungsErgebnis
from packages.core.invoice_extraction.hybrid_ergebnis import HybridStatus
from packages.core.invoice_extraction.hybrid_kandidat import AuswahlStatus, HybridKandidat
from packages.core.invoice_extraction.hybrid_konflikt import KonfliktBefund
from packages.core.invoice_extraction.provider_ports import InvoiceProviderResult

TENANT_A = uuid.UUID("00000000-0000-4000-a000-000000000001")
TENANT_B = uuid.UUID("00000000-0000-4000-a000-000000000002")


async def _tenant(session, tenant_id: uuid.UUID) -> None:
    """Setzt den RLS-Tenant-Kontext fuer die aktuelle Transaktion.

    set_config(..., true) ist transaktionslokal -- ein commit() (auch innerhalb von
    persistiere_hybrid_auswertung) beendet die Transaktion und damit den Kontext.
    Nach jedem commit() muss _tenant() vor der naechsten Abfrage erneut aufgerufen
    werden, sonst blockt RLS die Sicht auf bereits committete Zeilen (leeres Ergebnis,
    kein Fehler).
    """
    await session.execute(sa_text("SELECT set_config('app.current_tenant', :tid, true)"), {"tid": str(tenant_id)})


async def _erstelle_erkennungslauf(session, tenant_id: uuid.UUID) -> uuid.UUID:
    """Legt eine echte Installation/Dokument/Erkennungslauf-Kette an.

    hybrid_erkennungslaeufe.erkennungslauf_id ist ein FK auf erkennungslaeufe.id --
    eine frei erfundene UUID ohne Elterndatensatz verletzt den Constraint. Nur
    geflusht (nicht committet), damit der Tenant-Kontext der aufrufenden Transaktion
    erhalten bleibt.
    """
    installation = Installation(unternehmen_id=tenant_id)
    session.add(installation)
    await session.flush()

    dokument = Dokument(
        unternehmen_id=tenant_id,
        installation_id=installation.id,
        sha256=f"test-{uuid.uuid4().hex}",
        relative_path="test/rechnung.pdf",
        dateiname="rechnung.pdf",
        dateigroesse=1,
        mime_type="application/pdf",
    )
    session.add(dokument)
    await session.flush()

    erkennungslauf = Erkennungslauf(
        unternehmen_id=tenant_id,
        dokument_id=dokument.id,
        extraktion_status="OK",
    )
    session.add(erkennungslauf)
    await session.flush()
    return erkennungslauf.id


def _auswertung(status: HybridStatus = HybridStatus.OK) -> HybridAuswertungsErgebnis:
    kandidat = HybridKandidat(
        feld="invoice_number", rohwert="RE-001", normwert="re-001", methode="regex_label",
        provider_name="pdfplumber", provider_version="1.0", confidence=0.9,
        validierungsbefund="NORMALISIERT_OK", auswahl_status=AuswahlStatus.AUSGEWAEHLT,
        auswahl_grund="Einziger Kandidat fuer dieses Feld",
    )
    konflikt = KonfliktBefund(
        feld="total_amount", kandidaten=(kandidat,), werte=("100.00", "200.00"),
        provider=("pdfplumber", "invoice2data"), konfliktart="PROVIDER_WERTABWEICHUNG",
        begruendung="abweichend", schweregrad="HOCH", aufloesungsstatus="AUFGELOEST_MEHRHEIT",
    )
    provider_ergebnis = InvoiceProviderResult(
        provider_name="pdfplumber", provider_version="1.0", laufstatus="success",
        kandidaten=[kandidat], fehlercode=None,
    )
    return HybridAuswertungsErgebnis(
        kandidaten=[kandidat], konflikte=[konflikt], plausibilitaet=[],
        status=status, gruende=["Testgrund"], provider_ergebnisse=[provider_ergebnis],
    )


@pytest.mark.asyncio
async def test_kandidaten_persistieren(db_session):
    await _tenant(db_session, TENANT_A)
    erkennungslauf_id = None
    geschrieben = await persistiere_hybrid_auswertung(db_session, TENANT_A, erkennungslauf_id, _auswertung())
    assert geschrieben is True

    await _tenant(db_session, TENANT_A)  # commit() in persistiere_hybrid_auswertung beendete den Kontext
    row = (await db_session.execute(sa_text(
        "SELECT feld, auswahl_status FROM hybrid_kandidaten WHERE unternehmen_id = :uid AND feld = 'invoice_number'"
    ), {"uid": str(TENANT_A)})).fetchone()
    assert row is not None
    assert row[1] == "AUSGEWAEHLT"


@pytest.mark.asyncio
async def test_konflikte_persistieren(db_session):
    await _tenant(db_session, TENANT_A)
    await persistiere_hybrid_auswertung(db_session, TENANT_A, None, _auswertung())

    await _tenant(db_session, TENANT_A)  # commit() in persistiere_hybrid_auswertung beendete den Kontext
    row = (await db_session.execute(sa_text(
        "SELECT feld, kandidaten_ids_json FROM hybrid_konflikte "
        "WHERE unternehmen_id = :uid AND feld = 'total_amount' ORDER BY created_at DESC LIMIT 1"
    ), {"uid": str(TENANT_A)})).fetchone()
    assert row is not None
    assert "PROVIDER_WERTABWEICHUNG" in row[1]


@pytest.mark.asyncio
async def test_statusentscheidung_persistieren(db_session):
    await _tenant(db_session, TENANT_A)
    erkennungslauf_id = None
    await persistiere_hybrid_auswertung(db_session, TENANT_A, erkennungslauf_id, _auswertung(HybridStatus.OK))

    await _tenant(db_session, TENANT_A)  # commit() in persistiere_hybrid_auswertung beendete den Kontext
    row = (await db_session.execute(sa_text(
        "SELECT hybrid_status FROM hybrid_statusentscheidungen "
        "WHERE unternehmen_id = :uid AND erkennungslauf_id IS NULL"
    ), {"uid": str(TENANT_A)})).fetchone()
    assert row is not None
    assert row[0] == "OK"


@pytest.mark.asyncio
async def test_tenant_isolation(app_role_session):
    """Laeuft ueber die App-Rolle (buchungatakan_app, kein Superuser/BYPASSRLS) --
    P-10-Skip ohne APP_DATABASE_URL. Ueber db_session (TEST_DATABASE_URL, moeglicherweise
    privilegiert) waere diese scharfe Assertion nicht aussagekraeftig."""
    await _tenant(app_role_session, TENANT_A)
    await persistiere_hybrid_auswertung(app_role_session, TENANT_A, None, _auswertung())

    await _tenant(app_role_session, TENANT_B)
    row = (await app_role_session.execute(sa_text(
        "SELECT id FROM hybrid_kandidaten WHERE unternehmen_id = :uid_a"
    ), {"uid_a": str(TENANT_A)})).fetchone()
    assert row is None, "Tenant B darf Kandidaten von Tenant A nicht sehen (RLS)"


@pytest.mark.asyncio
async def test_idempotenz_kein_doppelter_lauf(db_session):
    await _tenant(db_session, TENANT_A)
    erkennungslauf_id = await _erstelle_erkennungslauf(db_session, TENANT_A)

    erster = await persistiere_hybrid_auswertung(db_session, TENANT_A, erkennungslauf_id, _auswertung())

    await _tenant(db_session, TENANT_A)  # commit() in persistiere_hybrid_auswertung beendete den Kontext
    zweiter = await persistiere_hybrid_auswertung(db_session, TENANT_A, erkennungslauf_id, _auswertung())

    assert erster is True
    assert zweiter is False

    await _tenant(db_session, TENANT_A)
    rows = (await db_session.execute(sa_text(
        "SELECT id FROM hybrid_statusentscheidungen WHERE unternehmen_id = :uid AND erkennungslauf_id = :eid"
    ), {"uid": str(TENANT_A), "eid": str(erkennungslauf_id)})).fetchall()
    assert len(rows) == 1


@pytest.mark.asyncio
async def test_manuelle_entscheidung_bleibt_geschuetzt(db_session):
    """Eine bestehende Statusentscheidung wird durch einen erneuten Auswertungslauf
    nicht ungefragt ueberschrieben -- unabhaengig davon, ob sie automatisch oder
    manuell entstand.
    """
    await _tenant(db_session, TENANT_A)
    erkennungslauf_id = await _erstelle_erkennungslauf(db_session, TENANT_A)
    await persistiere_hybrid_auswertung(db_session, TENANT_A, erkennungslauf_id, _auswertung(HybridStatus.OK))

    # commit() in persistiere_hybrid_auswertung beendete den Kontext -- vor jeder
    # weiteren Operation erneut setzen.
    await _tenant(db_session, TENANT_A)
    # Simuliert eine spaetere manuelle Korrektur direkt in der Statusentscheidung.
    await db_session.execute(sa_text(
        "UPDATE hybrid_statusentscheidungen SET hybrid_status = 'MUSS_GEPRUEFT_WERDEN' "
        "WHERE unternehmen_id = :uid AND erkennungslauf_id = :eid"
    ), {"uid": str(TENANT_A), "eid": str(erkennungslauf_id)})
    await db_session.commit()

    await _tenant(db_session, TENANT_A)
    erneut_geschrieben = await persistiere_hybrid_auswertung(
        db_session, TENANT_A, erkennungslauf_id, _auswertung(HybridStatus.OK)
    )
    assert erneut_geschrieben is False

    await _tenant(db_session, TENANT_A)
    row = (await db_session.execute(sa_text(
        "SELECT hybrid_status FROM hybrid_statusentscheidungen "
        "WHERE unternehmen_id = :uid AND erkennungslauf_id = :eid"
    ), {"uid": str(TENANT_A), "eid": str(erkennungslauf_id)})).fetchone()
    assert row[0] == "MUSS_GEPRUEFT_WERDEN"
