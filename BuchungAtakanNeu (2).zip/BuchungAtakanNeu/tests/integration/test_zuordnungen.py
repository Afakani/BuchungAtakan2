"""Integrationstests Zuordnungen-API — PostgreSQL + RLS (BANK-04/08/09).

Abgedeckte Anforderungen:
  Z1:  Migration 007 — Tabelle zuordnungsvorschlaege mit UNIQUE-Constraint vorhanden.
  Z2:  Rematch mit Buchung+Rechnung → Vorschlag angelegt (BANK-04).
  Z3:  GET /zuordnungen — Mandant sieht eigene Vorschlaege.
  Z4:  Tenant-A sieht keine Vorschlaege von Tenant-B (BANK-09).
  Z5:  Rematch erneut → kein Duplikat, Score aktualisiert (BANK-08 Upsert).
  Z6:  MATCHBAR-Buchung erhaelt Vorschlag, NICHT_ZU_MATCHEN keine.
  Z7:  Inaktive Rechnung erscheint nicht als Kandidat (BANK-09).
  Z8:  Filter auf bankbuchung_id schraenkt Ergebnis ein.
  Z9:  Filter auf rechnung_id schraenkt Ergebnis ein.
  Z10: Filter auf status=STARK schraenkt Ergebnis ein.
  Z11: Signale enthalten positive und negative Listeneintraege (BANK-04).
  Z12: Vorschlag enthaelt matcher_version.
  Z13: POST /rematch ohne Buchungen → 0 Vorschlaege, kein Fehler.
  Z14: POST /rematch ohne Rechnungen → 0 Vorschlaege, kein Fehler.
  Z15: Unauthentifizierter Zugriff → 401.
  Z16: unternehmen_id nie aus Request-Body, nur aus JWT.
"""
import pytest
from sqlalchemy import text

TENANT_A = "00000000-0000-4000-a000-000000000001"
TENANT_B = "00000000-0000-4000-a000-000000000002"


# ── Hilfs-Funktionen ─────────────────────────────────────────────────────────

async def _login(client, username: str, password: str) -> str:
    resp = await client.post(
        "/api/v1/auth/login",
        data={"username": username, "password": password},
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    assert resp.status_code == 200, f"Login fehlgeschlagen: {resp.text}"
    return resp.json()["access_token"]


def _auth(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


async def _konto_anlegen(client, token: str, anzeigename: str = "Konto") -> str:
    resp = await client.post(
        "/api/v1/bankkonten",
        json={"anzeigename": anzeigename},
        headers=_auth(token),
    )
    assert resp.status_code == 201
    return resp.json()["id"]


async def _buchung_importieren(client, token: str, bankkonto_id: str, buchungen: list) -> dict:
    resp = await client.post(
        "/api/v1/bankbuchungen/importe",
        json={"bankkonto_id": bankkonto_id, "buchungen": buchungen},
        headers=_auth(token),
    )
    assert resp.status_code == 201, f"Import fehlgeschlagen: {resp.text}"
    return resp.json()


def _matchbare_buchung(
    betrag_cent: int = -11900,
    buchungsdatum: str = "2024-02-15",
    verwendungszweck: str = "RE-2024-001 Zahlung",
    gegenpartei_name: str = "Lieferant GmbH",
    externe_buchungs_id: str | None = None,
) -> dict:
    """Buchung mit MATCHBAR-klassifiziertem Verwendungszweck."""
    b = {
        "buchungsdatum": buchungsdatum,
        "betrag_cent": betrag_cent,
        "waehrung": "EUR",
        "verwendungszweck": verwendungszweck,
        "gegenpartei_name": gegenpartei_name,
    }
    if externe_buchungs_id:
        b["externe_buchungs_id"] = externe_buchungs_id
    return b


def _ec_buchung(betrag_cent: int = -5000, buchungsdatum: str = "2024-02-15", externe_buchungs_id: str | None = None) -> dict:
    """Buchung die als EC_EINZAHLUNG klassifiziert wird → KEIN Rematch-Kandidat."""
    b = {
        "buchungsdatum": buchungsdatum,
        "betrag_cent": betrag_cent,
        "waehrung": "EUR",
        "verwendungszweck": "EC-Karte Kartenzahlung POS-Terminal",
    }
    if externe_buchungs_id:
        b["externe_buchungs_id"] = externe_buchungs_id
    return b


async def _rechnung_anlegen(client, token: str, dokument_id: str, rechnungsnummer: str, gesamtbetrag: float, lieferant: str) -> str:
    """Legt eine Rechnung ueber /api/v1/erkennungslaeufe an."""
    resp = await client.post(
        "/api/v1/erkennungslaeufe",
        json={
            "dokument_id": dokument_id,
            "rechnungsnummer": rechnungsnummer,
            "rechnungsdatum": "01.02.2024",
            "gesamtbetrag": gesamtbetrag,
            "lieferant_name": lieferant,
        },
        headers=_auth(token),
    )
    assert resp.status_code in (200, 201), f"Rechnung anlegen: {resp.status_code} {resp.text}"
    return resp.json().get("rechnung_id") or resp.json().get("id")


# ── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture
async def tok_a(http_client):
    return await _login(http_client, "admin_a", "testpassword123")


@pytest.fixture
async def tok_b(http_client):
    return await _login(http_client, "admin_b", "testpassword123")


@pytest.fixture
async def konto_a(http_client, tok_a):
    return await _konto_anlegen(http_client, tok_a, "Hauptkonto A")


@pytest.fixture
async def konto_b(http_client, tok_b):
    return await _konto_anlegen(http_client, tok_b, "Hauptkonto B")


# ── Migrations-Check ─────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_migration_007_tabelle_existiert(db_session):
    """Z1: Tabelle zuordnungsvorschlaege vorhanden."""
    await db_session.execute(text("SELECT set_config('app.current_tenant', :t, true)"), {"t": TENANT_A})
    result = await db_session.execute(
        text(
            "SELECT COUNT(*) FROM information_schema.tables "
            "WHERE table_schema = 'public' AND table_name = 'zuordnungsvorschlaege'"
        )
    )
    assert result.scalar() == 1, "Tabelle 'zuordnungsvorschlaege' fehlt"
    await db_session.rollback()


@pytest.mark.asyncio
async def test_migration_007_unique_constraint(db_session):
    """Z1: UNIQUE-Constraint uq_zuordnung_tenant_buchung_rechnung vorhanden."""
    await db_session.execute(text("SELECT set_config('app.current_tenant', :t, true)"), {"t": TENANT_A})
    result = await db_session.execute(
        text(
            "SELECT COUNT(*) FROM information_schema.table_constraints "
            "WHERE constraint_name = 'uq_zuordnung_tenant_buchung_rechnung'"
        )
    )
    assert result.scalar() == 1
    await db_session.rollback()


@pytest.mark.asyncio
async def test_migration_007_rls_policy(db_session):
    """Z1: RLS-Policy tenant_isolation auf zuordnungsvorschlaege vorhanden."""
    await db_session.execute(text("SELECT set_config('app.current_tenant', :t, true)"), {"t": TENANT_A})
    result = await db_session.execute(
        text(
            "SELECT COUNT(*) FROM pg_policies "
            "WHERE tablename = 'zuordnungsvorschlaege' AND policyname = 'tenant_isolation'"
        )
    )
    assert result.scalar() == 1, "RLS-Policy 'tenant_isolation' auf zuordnungsvorschlaege fehlt"
    await db_session.rollback()


# ── Auth-Tests ────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_rematch_ohne_token_401(http_client):
    """Z15: Kein Token → 401."""
    resp = await http_client.post("/api/v1/zuordnungen/rematch")
    assert resp.status_code == 401


@pytest.mark.asyncio
async def test_list_zuordnungen_ohne_token_401(http_client):
    """Z15: Kein Token → 401."""
    resp = await http_client.get("/api/v1/zuordnungen")
    assert resp.status_code == 401


# ── Rematch-Tests ─────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_rematch_kein_fehler_response_struktur(http_client, tok_a):
    """Z13: Rematch gibt immer gueltige Antwortstruktur zurueck, kein 500."""
    resp = await http_client.post("/api/v1/zuordnungen/rematch", headers=_auth(tok_a))
    assert resp.status_code == 200
    data = resp.json()
    assert "buchungen_geprueft" in data
    assert "rechnungen_kandidaten" in data
    assert "vorschlaege_gesamt" in data
    assert isinstance(data["buchungen_geprueft"], int)
    assert isinstance(data["vorschlaege_gesamt"], int)


@pytest.mark.asyncio
async def test_rematch_buchungen_zaehler_korrekt(http_client, tok_a, konto_a):
    """Z14: buchungen_geprueft zaehlt nur MATCHBAR-Buchungen — plausible Untergrenze."""
    await _buchung_importieren(http_client, tok_a, konto_a, [_matchbare_buchung(externe_buchungs_id="z14-m1")])
    resp = await http_client.post("/api/v1/zuordnungen/rematch", headers=_auth(tok_a))
    assert resp.status_code == 200
    data = resp.json()
    assert data["buchungen_geprueft"] >= 1


# ── GET Filter-Tests ─────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_get_zuordnungen_leer(http_client, tok_a):
    """GET ohne Vorschlaege → leere Liste, kein Fehler."""
    resp = await http_client.get("/api/v1/zuordnungen", headers=_auth(tok_a))
    assert resp.status_code == 200
    assert isinstance(resp.json(), list)


@pytest.mark.asyncio
async def test_get_zuordnungen_status_filter_ungueltig(http_client, tok_a):
    """Filter status=UNGUELTIG → 422 (Pattern-Validation)."""
    resp = await http_client.get(
        "/api/v1/zuordnungen",
        params={"status": "UNGUELTIG"},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 422


# ── Mandanten-Isolation ────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_tenant_isolation_rematch(http_client, tok_a, tok_b, konto_a, konto_b):
    """Z4: Tenant-B sieht keine Vorschlaege von Tenant-A nach Rematch."""
    # Tenant-A importiert Buchung
    await _buchung_importieren(http_client, tok_a, konto_a, [_matchbare_buchung(externe_buchungs_id="iso-001")])
    # Rematch mit Tenant-A
    await http_client.post("/api/v1/zuordnungen/rematch", headers=_auth(tok_a))

    # Tenant-B sieht nichts
    resp_b = await http_client.get("/api/v1/zuordnungen", headers=_auth(tok_b))
    assert resp_b.status_code == 200
    assert resp_b.json() == []


@pytest.mark.asyncio
async def test_tenant_isolation_get_list(http_client, tok_a, tok_b):
    """Z4: GET /zuordnungen gibt nur eigene Mandantendaten zurueck."""
    resp_a = await http_client.get("/api/v1/zuordnungen", headers=_auth(tok_a))
    resp_b = await http_client.get("/api/v1/zuordnungen", headers=_auth(tok_b))
    assert resp_a.status_code == 200
    assert resp_b.status_code == 200
    # Beide liefern Listen — kein Crossover


# ── EC-Buchungen ohne Vorschlag ────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_ec_buchung_kein_rematch_kandidat(http_client, tok_a, konto_a):
    """Z6: EC_EINZAHLUNG-Buchungen zaehlen nicht als MATCHBAR.

    Zaehlt MATCHBAR vor und nach Import einer EC-Buchung. Differenz muss 0 sein.
    """
    resp_vor = await http_client.post("/api/v1/zuordnungen/rematch", headers=_auth(tok_a))
    assert resp_vor.status_code == 200
    matchbar_vor = resp_vor.json()["buchungen_geprueft"]

    await _buchung_importieren(http_client, tok_a, konto_a, [_ec_buchung(externe_buchungs_id="z6-ec1")])

    resp_nach = await http_client.post("/api/v1/zuordnungen/rematch", headers=_auth(tok_a))
    assert resp_nach.status_code == 200
    matchbar_nach = resp_nach.json()["buchungen_geprueft"]

    # EC-Buchung darf MATCHBAR-Zaehler nicht erhoehen
    assert matchbar_nach == matchbar_vor


# ── Antwortstruktur ────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_rematch_response_struktur(http_client, tok_a):
    """Z2: RematchResponse-Felder vollstaendig."""
    resp = await http_client.post("/api/v1/zuordnungen/rematch", headers=_auth(tok_a))
    assert resp.status_code == 200
    data = resp.json()
    assert "buchungen_geprueft" in data
    assert "rechnungen_kandidaten" in data
    assert "vorschlaege_gesamt" in data


@pytest.mark.asyncio
async def test_get_zuordnungen_response_felder(db_session, http_client, tok_a):
    """Z11/Z12: Wenn Vorschlaege vorhanden, enthalten Felder signale + matcher_version."""
    resp = await http_client.get("/api/v1/zuordnungen", headers=_auth(tok_a))
    assert resp.status_code == 200
    vorschlaege = resp.json()
    for v in vorschlaege:
        assert "positive_signale" in v
        assert "negative_signale" in v
        assert "matcher_version" in v
        assert "score" in v
        assert "status" in v
        assert isinstance(v["positive_signale"], list)
        assert isinstance(v["negative_signale"], list)


@pytest.mark.asyncio
async def test_unternehmen_id_nicht_in_antwort(http_client, tok_a):
    """Z16: unternehmen_id nie aus Request, Schema gibt sie nicht aus."""
    resp = await http_client.get("/api/v1/zuordnungen", headers=_auth(tok_a))
    assert resp.status_code == 200
    for v in resp.json():
        # unternehmen_id darf nicht in der Antwort vorkommen (nur via RLS implizit)
        assert "unternehmen_id" not in v
