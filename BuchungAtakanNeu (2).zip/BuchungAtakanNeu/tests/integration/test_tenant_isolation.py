"""Integrationstests Mandanten-Isolation (SRV-03, SRV-04, SRV-05).
Alle Tests skippen ohne TEST_DATABASE_URL.
"""
import pytest

TENANT_A = "00000000-0000-4000-a000-000000000001"
TENANT_B = "00000000-0000-4000-a000-000000000002"


async def _login(client, username: str, password: str) -> str:
    resp = await client.post(
        "/api/v1/auth/login",
        data={"username": username, "password": password},
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    assert resp.status_code == 200
    return resp.json()["access_token"]


@pytest.mark.asyncio
async def test_fremde_unternehmen_id_liefert_404(http_client):
    """SRV-04: /api/v1/unternehmen/me gibt immer das eigene Unternehmen -- niemals fremdes."""
    token_a = await _login(http_client, "admin_a", "testpassword123")
    resp = await http_client.get(
        "/api/v1/unternehmen/me",
        headers={"Authorization": f"Bearer {token_a}"},
    )
    assert resp.status_code == 200
    data = resp.json()
    # Mandant A erhaelt nie Daten von B
    assert data["id"] != TENANT_B
    assert data["id"] == TENANT_A


@pytest.mark.asyncio
async def test_client_unternehmen_id_im_body_abgelehnt(http_client):
    """SRV-05: unternehmen_id im Request-Body -> 422."""
    resp = await http_client.post(
        "/api/v1/auth/login",
        data={
            "username": "admin_a",
            "password": "testpassword123",
            "unternehmen_id": TENANT_B,
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    # OAuth2PasswordRequestForm ignoriert unbekannte Felder (form-data), aber
    # der Token wird fuer Mandant A ausgestellt, nicht B
    if resp.status_code == 200:
        import jwt as pyjwt
        payload = pyjwt.decode(
            resp.json()["access_token"], options={"verify_signature": False}
        )
        # unternehmen_id muss aus DB stammen (Mandant A), nicht vom Client (Mandant B)
        assert payload["unternehmen_id"] == TENANT_A
        assert payload["unternehmen_id"] != TENANT_B


@pytest.mark.asyncio
async def test_jwt_tenant_a_ergibt_keine_b_daten(http_client):
    """SRV-03: Token von Mandant A liefert keine Daten von Mandant B."""
    token_a = await _login(http_client, "admin_a", "testpassword123")
    resp = await http_client.get(
        "/api/v1/unternehmen/me",
        headers={"Authorization": f"Bearer {token_a}"},
    )
    assert resp.status_code == 200
    data = resp.json()
    # Sicherstellen: keine B-Daten im Response
    assert TENANT_B not in str(data)
    assert "Test GmbH B" not in str(data)


@pytest.mark.asyncio
async def test_tenant_a_und_b_sehen_getrennte_unternehmen(http_client):
    """SRV-03: Beide Mandanten sehen ausschliesslich ihr eigenes Unternehmen."""
    token_a = await _login(http_client, "admin_a", "testpassword123")
    token_b = await _login(http_client, "admin_b", "testpassword123")

    resp_a = await http_client.get(
        "/api/v1/unternehmen/me",
        headers={"Authorization": f"Bearer {token_a}"},
    )
    resp_b = await http_client.get(
        "/api/v1/unternehmen/me",
        headers={"Authorization": f"Bearer {token_b}"},
    )

    assert resp_a.status_code == 200
    assert resp_b.status_code == 200
    assert resp_a.json()["id"] == TENANT_A
    assert resp_b.json()["id"] == TENANT_B
    assert resp_a.json()["name"] == "Test GmbH A"
    assert resp_b.json()["name"] == "Test GmbH B"
