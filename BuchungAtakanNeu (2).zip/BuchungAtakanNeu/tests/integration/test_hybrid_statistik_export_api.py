"""Integrationstests Excel-Export-Endpoint (07-03B, HYB-19).

GET /api/v1/hybrid/statistik/export.xlsx
"""
import uuid
from io import BytesIO

import pytest
from openpyxl import load_workbook

from apps.server.models.dokument import Dokument
from apps.server.models.hybrid_extraktion import HybridStatusentscheidung
from apps.server.models.installationen import Installation
from apps.server.models.rechnung import Erkennungslauf

TENANT_A = uuid.UUID("00000000-0000-4000-a000-000000000001")
TENANT_B = uuid.UUID("00000000-0000-4000-a000-000000000002")

_XLSX_MEDIA_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


async def _login(client, username: str, password: str = "testpassword123") -> str:
    resp = await client.post(
        "/api/v1/auth/login",
        data={"username": username, "password": password},
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    assert resp.status_code == 200, f"Login fehlgeschlagen: {resp.text}"
    return resp.json()["access_token"]


def _auth(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


async def _seed_statusentscheidung(
    db_session, tenant_id: uuid.UUID, dokument_klasse: str | None = "TEXT_PDF"
) -> str:
    from sqlalchemy import text as sa_text

    await db_session.execute(
        sa_text("SELECT set_config('app.current_tenant', :tid, true)"), {"tid": str(tenant_id)}
    )
    installation = Installation(unternehmen_id=tenant_id)
    db_session.add(installation)
    await db_session.flush()

    dokument = Dokument(
        unternehmen_id=tenant_id,
        installation_id=installation.id,
        sha256=f"test-{uuid.uuid4().hex}",
        relative_path="test/rechnung.pdf",
        dateiname="rechnung.pdf",
        dateigroesse=1,
        mime_type="application/pdf",
    )
    db_session.add(dokument)
    await db_session.flush()

    erkennungslauf = Erkennungslauf(
        unternehmen_id=tenant_id, dokument_id=dokument.id, extraktion_status="OK"
    )
    db_session.add(erkennungslauf)
    await db_session.flush()

    entscheidung = HybridStatusentscheidung(
        unternehmen_id=tenant_id,
        erkennungslauf_id=erkennungslauf.id,
        hybrid_status="OK",
        pflichtfelder_ok=True,
        konflikt_frei=True,
        dokument_klasse=dokument_klasse,
    )
    db_session.add(entscheidung)
    await db_session.flush()
    await db_session.commit()
    return str(entscheidung.id)


@pytest.mark.asyncio
async def test_export_liefert_200_und_korrekten_mime_type(http_client, db_session):
    await _seed_statusentscheidung(db_session, TENANT_A, dokument_klasse="SONDERFORMAT")
    tok = await _login(http_client, "admin_a")

    resp = await http_client.get("/api/v1/hybrid/statistik/export.xlsx", headers=_auth(tok))
    assert resp.status_code == 200
    assert resp.headers["content-type"] == _XLSX_MEDIA_TYPE


@pytest.mark.asyncio
async def test_export_content_disposition_und_cache_control(http_client, db_session):
    tok = await _login(http_client, "admin_a")
    resp = await http_client.get("/api/v1/hybrid/statistik/export.xlsx", headers=_auth(tok))
    assert resp.status_code == 200
    assert 'attachment; filename="hybrid_statistik.xlsx"' == resp.headers["content-disposition"]
    assert resp.headers["cache-control"] == "no-store"


@pytest.mark.asyncio
async def test_export_bytes_oeffnen_mit_openpyxl(http_client, db_session):
    await _seed_statusentscheidung(db_session, TENANT_A, dokument_klasse="SCAN_PDF")
    tok = await _login(http_client, "admin_a")
    resp = await http_client.get("/api/v1/hybrid/statistik/export.xlsx", headers=_auth(tok))
    assert resp.status_code == 200
    wb = load_workbook(BytesIO(resp.content))
    assert wb.sheetnames == ["Uebersicht", "Statistik", "Metriken"]


@pytest.mark.asyncio
async def test_gruppieren_nach_verhaelt_sich_wie_json_endpoint(http_client, db_session):
    await _seed_statusentscheidung(db_session, TENANT_A, dokument_klasse="TEXT_PDF")
    tok = await _login(http_client, "admin_a")

    resp_json = await http_client.get(
        "/api/v1/hybrid/statistik?gruppieren_nach=dokument_klasse", headers=_auth(tok)
    )
    resp_xlsx = await http_client.get(
        "/api/v1/hybrid/statistik/export.xlsx?gruppieren_nach=dokument_klasse", headers=_auth(tok)
    )
    assert resp_json.status_code == 200
    assert resp_xlsx.status_code == 200

    json_gruppen = resp_json.json()
    wb = load_workbook(BytesIO(resp_xlsx.content))
    xlsx_zeilen = list(wb["Statistik"].iter_rows(values_only=True))[1:]

    assert len(xlsx_zeilen) == len(json_gruppen)
    json_dokumenttypen = {g["dimensionen"]["dokument_klasse"] for g in json_gruppen}
    xlsx_dokumenttypen = {row[0] for row in xlsx_zeilen}
    assert json_dokumenttypen == xlsx_dokumenttypen


@pytest.mark.asyncio
async def test_ungueltige_dimension_400(http_client, db_session):
    tok = await _login(http_client, "admin_a")
    resp = await http_client.get(
        "/api/v1/hybrid/statistik/export.xlsx?gruppieren_nach=nicht_existent", headers=_auth(tok)
    )
    assert resp.status_code == 400


@pytest.mark.asyncio
async def test_tenant_b_erhaelt_keine_gruppen_von_tenant_a(http_client, db_session):
    await _seed_statusentscheidung(db_session, TENANT_A, dokument_klasse="SONDERFORMAT")
    tok_b = await _login(http_client, "admin_b")

    resp = await http_client.get(
        "/api/v1/hybrid/statistik/export.xlsx?gruppieren_nach=dokument_klasse", headers=_auth(tok_b)
    )
    assert resp.status_code == 200
    wb = load_workbook(BytesIO(resp.content))
    xlsx_zeilen = list(wb["Statistik"].iter_rows(values_only=True))[1:]
    dokumenttypen = {row[0] for row in xlsx_zeilen}
    assert "SONDERFORMAT" not in dokumenttypen


async def _login_frischer_mandant(client, db_session) -> str:
    """Erzeugt einen brandneuen, garantiert leeren Mandanten fuer diesen Test --
    nicht TENANT_A/TENANT_B verwenden, da diese in der geteilten Testdatenbank durch
    andere Testdateien bereits Statusentscheidungen angesammelt haben koennten
    (siehe Regressionsfund 07-03A: 'Ein Test darf nicht von vorherigen Tests abhaengen').
    """
    from sqlalchemy import text as sa_text
    from pwdlib import PasswordHash

    tenant_id = uuid.uuid4()
    benutzername = f"leertest_{uuid.uuid4().hex[:12]}"
    pw_hash = PasswordHash.recommended().hash("testpassword123")

    await db_session.execute(
        sa_text("SELECT set_config('app.current_tenant', :tid, true)"), {"tid": str(tenant_id)}
    )
    await db_session.execute(
        sa_text("INSERT INTO unternehmen (id, name) VALUES (:id, :name)"),
        {"id": str(tenant_id), "name": "Leertest GmbH"},
    )
    await db_session.execute(
        sa_text(
            "INSERT INTO benutzer (id, unternehmen_id, benutzername, hashed_password, rolle) "
            "VALUES (gen_random_uuid(), :tid, :bn, :pw, 'UNTERNEHMEN_ADMIN')"
        ),
        {"tid": str(tenant_id), "bn": benutzername, "pw": pw_hash},
    )
    await db_session.commit()

    return await _login(client, benutzername)


@pytest.mark.asyncio
async def test_leere_statistik_liefert_gueltiges_workbook(http_client, db_session):
    tok = await _login_frischer_mandant(http_client, db_session)
    resp = await http_client.get(
        "/api/v1/hybrid/statistik/export.xlsx?gruppieren_nach=anbieter", headers=_auth(tok)
    )
    assert resp.status_code == 200
    wb = load_workbook(BytesIO(resp.content))
    uebersicht_rows = list(wb["Uebersicht"].iter_rows(values_only=True))
    status_zeile = next(r for r in uebersicht_rows if r[0] == "Status")
    assert status_zeile[1] == "LEER"
