"""Integrationstests manuelle Zuordnungsentscheidungen — PostgreSQL + RLS (BANK-05/06/07).

Abgedeckte Anforderungen:
  E1:  Migration 008 und Partial Unique Index vorhanden.
  E2:  Bestaetigungsendpunkt funktioniert.
  E3:  Ablehnungsendpunkt funktioniert.
  E4:  Zweite aktive bestaetigte Zuordnung fuer dieselbe Buchung scheitert 409 (BANK-05).
  E5:  Bestaetigte Zuordnung ueberlebt Rematch unberuehrt (BANK-07).
  E6:  Abgelehnte Paarung erscheint nach Rematch nicht erneut (BANK-06).
  E7:  Anderer Kandidat kann nach Ablehnung entstehen.
  E8:  Tenant-B kann Tenant-A-Zuordnung nicht bestaetigen oder ablehnen.
  E9:  Fremde ID liefert 404.
  E10: API- und DB-Sicht stimmen ueberein.
  E11: entschieden_at und Benutzer-ID werden gespeichert.
  E12: Wiederholte Requests sind stabil/idempotent.

Nur synthetische Daten. unternehmen_id ausschliesslich aus JWT.
"""
import pytest
from uuid import uuid4

from sqlalchemy import text

TENANT_A = "00000000-0000-4000-a000-000000000001"
TENANT_B = "00000000-0000-4000-a000-000000000002"


# ── Hilfs-Funktionen ─────────────────────────────────────────────────────────

async def _login(client, username: str, password: str) -> str:
    resp = await client.post(
        "/api/v1/auth/login",
        data={"username": username, "password": password},
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    assert resp.status_code == 200, f"Login fehlgeschlagen: {resp.text}"
    return resp.json()["access_token"]


def _auth(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


async def _konto_anlegen(client, token: str, anzeigename: str = "Konto") -> str:
    resp = await client.post(
        "/api/v1/bankkonten",
        json={"anzeigename": anzeigename},
        headers=_auth(token),
    )
    assert resp.status_code == 201
    return resp.json()["id"]


async def _buchung_importieren(client, token: str, bankkonto_id: str, buchungen: list) -> dict:
    resp = await client.post(
        "/api/v1/bankbuchungen/importe",
        json={"bankkonto_id": bankkonto_id, "buchungen": buchungen},
        headers=_auth(token),
    )
    assert resp.status_code == 201, f"Import fehlgeschlagen: {resp.text}"
    return resp.json()


def _matchbare_buchung(
    betrag_cent: int = -11900,
    buchungsdatum: str = "2024-02-15",
    verwendungszweck: str = "RE-2024-001 Zahlung",
    gegenpartei_name: str | None = "Lieferant GmbH",
    externe_buchungs_id: str | None = None,
) -> dict:
    b = {
        "buchungsdatum": buchungsdatum,
        "betrag_cent": betrag_cent,
        "waehrung": "EUR",
        "verwendungszweck": verwendungszweck,
    }
    if gegenpartei_name:
        b["gegenpartei_name"] = gegenpartei_name
    if externe_buchungs_id:
        b["externe_buchungs_id"] = externe_buchungs_id
    return b


async def _create_dok_und_rechnung(db_session, client, token, tenant_id, rechnungsnummer, betrag, lieferant) -> tuple[str, str]:
    """Legt Dokument + Rechnung an. Gibt (dok_id, rechnung_id) zurueck."""
    sha = f"e2e-{uuid4().hex}"
    await db_session.execute(
        text("SELECT set_config('app.current_tenant', :tid, true)"), {"tid": tenant_id}
    )
    r = await db_session.execute(
        text("INSERT INTO installationen (id, unternehmen_id) VALUES (gen_random_uuid(), :uid) RETURNING id"),
        {"uid": tenant_id},
    )
    install_id = r.scalar()
    r = await db_session.execute(
        text(
            "INSERT INTO dokumente "
            "(id, unternehmen_id, installation_id, sha256, relative_path, dateiname, dateigroesse, mime_type) "
            "VALUES (gen_random_uuid(), :uid, :iid, :sha, 'test/dok.pdf', 'dok.pdf', 1024, 'application/pdf') "
            "RETURNING id"
        ),
        {"uid": tenant_id, "iid": install_id, "sha": sha},
    )
    dok_id = str(r.scalar())
    await db_session.commit()

    resp = await client.post(
        "/api/v1/rechnungen",
        json={
            "dokument_id": dok_id,
            "rechnungsnummer": rechnungsnummer,
            "rechnungsdatum": "01.02.2024",
            "gesamtbetrag": betrag,
            "lieferant_name": lieferant,
        },
        headers=_auth(token),
    )
    assert resp.status_code == 201, f"Rechnung anlegen: {resp.text}"
    return dok_id, resp.json()["id"]


async def _vorschlag_erzeugen(client, token, konto_id, buchungsnummer, rechnungsnummer, betrag, lieferant, db_session, tenant_id) -> dict:
    """Importiert Buchung + Rechnung, loest Rematch aus, gibt ersten Vorschlag zurueck."""
    await _buchung_importieren(
        client, token, konto_id,
        [_matchbare_buchung(
            betrag_cent=-int(betrag * 100),
            verwendungszweck=f"{rechnungsnummer} {lieferant}",
            gegenpartei_name=lieferant,
            externe_buchungs_id=buchungsnummer,
        )]
    )
    _, rechnung_id = await _create_dok_und_rechnung(
        db_session, client, token, tenant_id,
        rechnungsnummer, betrag, lieferant,
    )

    resp = await client.post("/api/v1/zuordnungen/rematch", headers=_auth(token))
    assert resp.status_code == 200

    resp_list = await client.get(
        "/api/v1/zuordnungen",
        params={"rechnung_id": rechnung_id},
        headers=_auth(token),
    )
    assert resp_list.status_code == 200
    vorschlaege = resp_list.json()
    assert len(vorschlaege) >= 1, "Kein Vorschlag nach Rematch erzeugt"
    return vorschlaege[0]


# ── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture
async def tok_a(http_client):
    return await _login(http_client, "admin_a", "testpassword123")


@pytest.fixture
async def tok_b(http_client):
    return await _login(http_client, "admin_b", "testpassword123")


@pytest.fixture
async def konto_a(http_client, tok_a):
    return await _konto_anlegen(http_client, tok_a, "Entscheid-Konto-A")


# ── Migration 008 Tests ───────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_migration_008_felder_vorhanden(db_session):
    """E1: Migration 008 — neue Felder vorhanden."""
    await db_session.execute(text("SELECT set_config('app.current_tenant', :t, true)"), {"t": TENANT_A})
    result = await db_session.execute(
        text(
            "SELECT column_name FROM information_schema.columns "
            "WHERE table_name = 'zuordnungsvorschlaege' "
            "AND column_name IN ('entschieden_at', 'entschieden_von_benutzer_id', 'entscheidungsnotiz')"
        )
    )
    gefunden = {row[0] for row in result.all()}
    assert "entschieden_at" in gefunden
    assert "entschieden_von_benutzer_id" in gefunden
    assert "entscheidungsnotiz" in gefunden
    await db_session.rollback()


@pytest.mark.asyncio
async def test_migration_008_partial_unique_index(db_session):
    """E1: Partial Unique Index uix_zuordnung_eine_bestaetigte_pro_buchung vorhanden."""
    await db_session.execute(text("SELECT set_config('app.current_tenant', :t, true)"), {"t": TENANT_A})
    result = await db_session.execute(
        text(
            "SELECT indexname FROM pg_indexes "
            "WHERE tablename = 'zuordnungsvorschlaege' "
            "AND indexname = 'uix_zuordnung_eine_bestaetigte_pro_buchung'"
        )
    )
    assert result.scalar() is not None, "Partial Unique Index fehlt"
    await db_session.rollback()


@pytest.mark.asyncio
async def test_migration_008_rls_unveraendert(db_session):
    """E1: RLS-Policy tenant_isolation weiterhin vorhanden nach Migration 008."""
    await db_session.execute(text("SELECT set_config('app.current_tenant', :t, true)"), {"t": TENANT_A})
    result = await db_session.execute(
        text(
            "SELECT COUNT(*) FROM pg_policies "
            "WHERE tablename = 'zuordnungsvorschlaege' AND policyname = 'tenant_isolation'"
        )
    )
    assert result.scalar() == 1
    await db_session.rollback()


# ── Auth-Guard ────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_bestaetigen_ohne_token_401(http_client):
    """E9 (Sicherheit): Kein Token → 401."""
    resp = await http_client.post(f"/api/v1/zuordnungen/{uuid4()}/bestaetigen", json={})
    assert resp.status_code == 401


@pytest.mark.asyncio
async def test_ablehnen_ohne_token_401(http_client):
    resp = await http_client.post(f"/api/v1/zuordnungen/{uuid4()}/ablehnen", json={})
    assert resp.status_code == 401


@pytest.mark.asyncio
async def test_bestaetigen_fremde_id_404(http_client, tok_a):
    """E9: Fremde UUID → 404."""
    resp = await http_client.post(
        f"/api/v1/zuordnungen/{uuid4()}/bestaetigen",
        json={},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_ablehnen_fremde_id_404(http_client, tok_a):
    """E9: Fremde UUID → 404."""
    resp = await http_client.post(
        f"/api/v1/zuordnungen/{uuid4()}/ablehnen",
        json={},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 404


# ── Grundfunktionen ────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_bestaetigen_funktioniert(http_client, tok_a, konto_a, db_session):
    """E2: Vorschlag bestaetigen → status MANUELL_BESTAETIGT."""
    vorschlag = await _vorschlag_erzeugen(
        http_client, tok_a, konto_a,
        f"e2-buch-{uuid4().hex[:8]}", f"E2-{uuid4().hex[:8]}", 119.00, "Lieferant GmbH",
        db_session, TENANT_A,
    )

    resp = await http_client.post(
        f"/api/v1/zuordnungen/{vorschlag['id']}/bestaetigen",
        json={"notiz": "Geprueft und korrekt"},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "MANUELL_BESTAETIGT"
    assert data["entscheidungsnotiz"] == "Geprueft und korrekt"
    assert data["entschieden_at"] is not None


@pytest.mark.asyncio
async def test_ablehnen_funktioniert(http_client, tok_a, konto_a, db_session):
    """E3: Vorschlag ablehnen → status MANUELL_ABGELEHNT."""
    vorschlag = await _vorschlag_erzeugen(
        http_client, tok_a, konto_a,
        f"e3-buch-{uuid4().hex[:8]}", f"E3-{uuid4().hex[:8]}", 99.00, "Anderer Lieferant",
        db_session, TENANT_A,
    )

    resp = await http_client.post(
        f"/api/v1/zuordnungen/{vorschlag['id']}/ablehnen",
        json={"notiz": "Falscher Betrag"},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "MANUELL_ABGELEHNT"
    assert data["entscheidungsnotiz"] == "Falscher Betrag"


@pytest.mark.asyncio
async def test_entschieden_at_und_benutzer_id_gesetzt(http_client, tok_a, konto_a, db_session):
    """E11: entschieden_at vorhanden; entschieden_von_benutzer_id in DB gespeichert."""
    vorschlag = await _vorschlag_erzeugen(
        http_client, tok_a, konto_a,
        f"e11-buch-{uuid4().hex[:8]}", f"E11-{uuid4().hex[:8]}", 59.00, "Lief E11",
        db_session, TENANT_A,
    )

    resp = await http_client.post(
        f"/api/v1/zuordnungen/{vorschlag['id']}/bestaetigen",
        json={},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 200
    assert resp.json()["entschieden_at"] is not None

    # DB-Sicht pruefen (E10)
    await db_session.execute(text("SELECT set_config('app.current_tenant', :t, true)"), {"t": TENANT_A})
    result = await db_session.execute(
        text(
            "SELECT entschieden_at, entschieden_von_benutzer_id "
            "FROM zuordnungsvorschlaege WHERE id = :id"
        ),
        {"id": vorschlag["id"]},
    )
    row = result.one()
    assert row[0] is not None
    assert row[1] is not None
    await db_session.rollback()


# ── BANK-05 Constraint ────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_zweite_bestaetigung_selbe_buchung_scheitert(http_client, tok_a, konto_a, db_session):
    """E4: BANK-05 — zweite bestaetigte Zuordnung fuer dieselbe Buchung → 409."""
    externe_id = f"bank05-{uuid4().hex[:8]}"

    # Eine Buchung, zwei Rechnungen → zwei Vorschlaege
    await _buchung_importieren(
        http_client, tok_a, konto_a,
        [_matchbare_buchung(
            betrag_cent=-11900,
            verwendungszweck="RE-BANK05-A RE-BANK05-B Lieferant",
            gegenpartei_name="Lieferant GmbH",
            externe_buchungs_id=externe_id,
        )]
    )

    rn_a = f"RE-BANK05-A-{uuid4().hex[:6]}"
    rn_b = f"RE-BANK05-B-{uuid4().hex[:6]}"
    _, rid_a = await _create_dok_und_rechnung(
        db_session, http_client, tok_a, TENANT_A, rn_a, 119.00, "Lieferant GmbH"
    )
    _, rid_b = await _create_dok_und_rechnung(
        db_session, http_client, tok_a, TENANT_A, rn_b, 119.00, "Lieferant GmbH"
    )

    # Rematch → beide sollen als Vorschlaege entstehen
    await http_client.post("/api/v1/zuordnungen/rematch", headers=_auth(tok_a))

    vp_a_resp = await http_client.get(
        "/api/v1/zuordnungen", params={"rechnung_id": rid_a}, headers=_auth(tok_a)
    )
    vp_b_resp = await http_client.get(
        "/api/v1/zuordnungen", params={"rechnung_id": rid_b}, headers=_auth(tok_a)
    )

    assert len(vp_a_resp.json()) >= 1, f"Kein Vorschlag fuer Rechnung A (rn={rn_a})"
    assert len(vp_b_resp.json()) >= 1, f"Kein Vorschlag fuer Rechnung B (rn={rn_b})"

    vid_a = vp_a_resp.json()[0]["id"]
    vid_b = vp_b_resp.json()[0]["id"]

    # Ersten Vorschlag bestaetigen
    resp1 = await http_client.post(
        f"/api/v1/zuordnungen/{vid_a}/bestaetigen", json={}, headers=_auth(tok_a)
    )
    assert resp1.status_code == 200

    # Zweiten bestaetigen → 409 (selbe Buchung, BANK-05)
    resp2 = await http_client.post(
        f"/api/v1/zuordnungen/{vid_b}/bestaetigen", json={}, headers=_auth(tok_a)
    )
    assert resp2.status_code == 409, f"Erwartet 409 (BANK-05), bekam {resp2.status_code}: {resp2.text}"


# ── Rematch-Schutz ────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_bestaetigte_zuordnung_ueberlebt_rematch(http_client, tok_a, konto_a, db_session):
    """E5: BANK-07 — bestaetigte Zuordnung unveraendert nach Rematch."""
    vorschlag = await _vorschlag_erzeugen(
        http_client, tok_a, konto_a,
        f"e5-buch-{uuid4().hex[:8]}", f"E5-{uuid4().hex[:8]}", 79.00, "Lief E5",
        db_session, TENANT_A,
    )
    vid = vorschlag["id"]

    # Bestaetigen
    resp = await http_client.post(
        f"/api/v1/zuordnungen/{vid}/bestaetigen",
        json={"notiz": "Korrekt"},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 200

    # Rematch
    await http_client.post("/api/v1/zuordnungen/rematch", headers=_auth(tok_a))

    # Vorschlag prufen — muss noch MANUELL_BESTAETIGT sein
    resp_nach = await http_client.get("/api/v1/zuordnungen", headers=_auth(tok_a))
    vorschlaege_nach = resp_nach.json()
    bestaetigter = next((v for v in vorschlaege_nach if v["id"] == vid), None)
    assert bestaetigter is not None
    assert bestaetigter["status"] == "MANUELL_BESTAETIGT"
    assert bestaetigter["entscheidungsnotiz"] == "Korrekt"


@pytest.mark.asyncio
async def test_abgelehnte_paarung_nach_rematch_nicht_erneut(http_client, tok_a, konto_a, db_session):
    """E6: BANK-06 — abgelehnte Paarung erscheint nach Rematch nicht erneut als aktiver Vorschlag."""
    rn = f"E6-{uuid4().hex[:8]}"
    extern = f"e6-buch-{uuid4().hex[:8]}"

    vorschlag = await _vorschlag_erzeugen(
        http_client, tok_a, konto_a,
        extern, rn, 89.00, "Lief E6",
        db_session, TENANT_A,
    )
    vid = vorschlag["id"]
    bid = vorschlag["bankbuchung_id"]
    rid = vorschlag["rechnung_id"]

    # Ablehnen
    resp_abl = await http_client.post(
        f"/api/v1/zuordnungen/{vid}/ablehnen",
        json={"notiz": "Nicht zugehoerig"},
        headers=_auth(tok_a),
    )
    assert resp_abl.status_code == 200

    # Rematch
    await http_client.post("/api/v1/zuordnungen/rematch", headers=_auth(tok_a))

    # Paarung pruefen: status bleibt MANUELL_ABGELEHNT (nicht STARK/UNSICHER)
    resp_check = await http_client.get(
        "/api/v1/zuordnungen",
        params={"bankbuchung_id": bid, "rechnung_id": rid},
        headers=_auth(tok_a),
    )
    eintrag = next((v for v in resp_check.json() if v["id"] == vid), None)
    assert eintrag is not None
    assert eintrag["status"] == "MANUELL_ABGELEHNT"


# ── Idempotenz ────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_bestaetigung_idempotent(http_client, tok_a, konto_a, db_session):
    """E12: Wiederholte Bestaetigung → stabil, kein Fehler."""
    vorschlag = await _vorschlag_erzeugen(
        http_client, tok_a, konto_a,
        f"e12a-buch-{uuid4().hex[:8]}", f"E12A-{uuid4().hex[:8]}", 49.00, "Lief E12A",
        db_session, TENANT_A,
    )
    vid = vorschlag["id"]

    r1 = await http_client.post(f"/api/v1/zuordnungen/{vid}/bestaetigen", json={}, headers=_auth(tok_a))
    r2 = await http_client.post(f"/api/v1/zuordnungen/{vid}/bestaetigen", json={}, headers=_auth(tok_a))

    assert r1.status_code == 200
    assert r2.status_code == 200
    assert r2.json()["status"] == "MANUELL_BESTAETIGT"


@pytest.mark.asyncio
async def test_ablehnung_idempotent(http_client, tok_a, konto_a, db_session):
    """E12: Wiederholte Ablehnung → stabil, kein Fehler."""
    vorschlag = await _vorschlag_erzeugen(
        http_client, tok_a, konto_a,
        f"e12b-buch-{uuid4().hex[:8]}", f"E12B-{uuid4().hex[:8]}", 39.00, "Lief E12B",
        db_session, TENANT_A,
    )
    vid = vorschlag["id"]

    r1 = await http_client.post(f"/api/v1/zuordnungen/{vid}/ablehnen", json={}, headers=_auth(tok_a))
    r2 = await http_client.post(f"/api/v1/zuordnungen/{vid}/ablehnen", json={}, headers=_auth(tok_a))

    assert r1.status_code == 200
    assert r2.status_code == 200
    assert r2.json()["status"] == "MANUELL_ABGELEHNT"


# ── Mandanten-Isolation ────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_tenant_b_kann_tenant_a_nicht_bestaetigen(http_client, tok_a, tok_b, konto_a, db_session):
    """E8: Tenant-B kann Tenant-A-Vorschlag nicht bestaetigen."""
    vorschlag = await _vorschlag_erzeugen(
        http_client, tok_a, konto_a,
        f"e8a-buch-{uuid4().hex[:8]}", f"E8A-{uuid4().hex[:8]}", 69.00, "Lief E8",
        db_session, TENANT_A,
    )
    vid = vorschlag["id"]

    # Tenant-B versucht Bestaetigung von Tenant-A-Vorschlag
    resp = await http_client.post(
        f"/api/v1/zuordnungen/{vid}/bestaetigen",
        json={},
        headers=_auth(tok_b),
    )
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_tenant_b_kann_tenant_a_nicht_ablehnen(http_client, tok_a, tok_b, konto_a, db_session):
    """E8: Tenant-B kann Tenant-A-Vorschlag nicht ablehnen."""
    vorschlag = await _vorschlag_erzeugen(
        http_client, tok_a, konto_a,
        f"e8b-buch-{uuid4().hex[:8]}", f"E8B-{uuid4().hex[:8]}", 29.00, "Lief E8B",
        db_session, TENANT_A,
    )
    vid = vorschlag["id"]

    resp = await http_client.post(
        f"/api/v1/zuordnungen/{vid}/ablehnen",
        json={},
        headers=_auth(tok_b),
    )
    assert resp.status_code == 404
