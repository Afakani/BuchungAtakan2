"""Unit-Tests fuer Invoice2DataProvider (HYB-10).

Nutzt ausschliesslich das synthetische Test-Template unter
config/invoice2data_templates/synthetisch_muster_ag_v1.yml -- keine echten
Rechnungsinhalte, keine echten Kundendaten.
"""
from pathlib import Path
from unittest.mock import patch

import pytest

from packages.core.invoice_extraction.invoice2data_provider import (
    Invoice2DataProvider,
    ist_aktiviert,
)
from packages.core.invoice_extraction.pdfplumber_provider import PdfplumberProvider

pytest.importorskip("invoice2data", reason="invoice2data optional -- Skip statt Fail wenn fehlt")

_SYNTHETISCHER_TEXT_TREFFER = (
    "Synthetisch Muster AG\n"
    "Rechnungsnummer: RE-2026-SYNTH-01\n"
    "Rechnungsdatum: 01.07.2026\n"
    "Nettobetrag: 100.00\n"
    "Steuerbetrag: 19.00\n"
    "Gesamtbetrag: 119.00\n"
)
_SYNTHETISCHER_TEXT_UNBEKANNT = "Voellig unbekannter Anbieter ohne Keyword-Match\n"


def _mit_gemocktem_text(text: str):
    return patch(
        "packages.core.invoice_extraction.invoice2data_provider._READER.extract_text",
        return_value=text,
    )


class TestBekanntesLayout:
    def test_treffer_liefert_kandidaten(self):
        with _mit_gemocktem_text(_SYNTHETISCHER_TEXT_TREFFER):
            ergebnis = Invoice2DataProvider().extract(Path("dummy_synth.pdf"))
        assert ergebnis.laufstatus == "success"
        felder = {k.feld for k in ergebnis.kandidaten}
        assert "vendor_name" in felder
        assert "invoice_number" in felder
        assert "invoice_date" in felder
        assert "total_amount" in felder

    def test_provider_name_gesetzt(self):
        with _mit_gemocktem_text(_SYNTHETISCHER_TEXT_TREFFER):
            ergebnis = Invoice2DataProvider().extract(Path("dummy_synth.pdf"))
        assert all(k.provider_name == "invoice2data" for k in ergebnis.kandidaten)

    def test_template_version_nachvollziehbar(self):
        with _mit_gemocktem_text(_SYNTHETISCHER_TEXT_TREFFER):
            ergebnis = Invoice2DataProvider().extract(Path("dummy_synth.pdf"))
        k = next(k for k in ergebnis.kandidaten if k.feld == "invoice_number")
        assert k.provider_version == "synthetisch_muster_ag_v1.yml"

    def test_methode_ist_invoice2data_template(self):
        with _mit_gemocktem_text(_SYNTHETISCHER_TEXT_TREFFER):
            ergebnis = Invoice2DataProvider().extract(Path("dummy_synth.pdf"))
        assert all(k.methode == "invoice2data_template" for k in ergebnis.kandidaten)


class TestUnbekanntesLayout:
    def test_kein_match_liefert_leere_kandidatenliste(self):
        with _mit_gemocktem_text(_SYNTHETISCHER_TEXT_UNBEKANNT):
            ergebnis = Invoice2DataProvider().extract(Path("dummy_synth.pdf"))
        assert ergebnis.kandidaten == []

    def test_kein_match_ist_kein_fehler(self):
        """Unbekanntes Layout ist ein kontrolliertes Leerergebnis, kein Fehlerstatus."""
        with _mit_gemocktem_text(_SYNTHETISCHER_TEXT_UNBEKANNT):
            ergebnis = Invoice2DataProvider().extract(Path("dummy_synth.pdf"))
        assert ergebnis.laufstatus == "success"
        assert ergebnis.fehlercode is None


class TestDeaktiviertesFlag:
    def test_flag_default_false(self):
        settings = type("S", (), {"BUCHUNG_ATAKAN_FEATURE_INVOICE2DATA": False})()
        assert ist_aktiviert(settings) is False

    def test_flag_aktiviert(self):
        settings = type("S", (), {"BUCHUNG_ATAKAN_FEATURE_INVOICE2DATA": True})()
        assert ist_aktiviert(settings) is True

    def test_fehlendes_flag_attribut_ist_deaktiviert(self):
        settings = type("S", (), {})()
        assert ist_aktiviert(settings) is False


class TestTemplatefehlerIsoliert:
    def test_ausnahme_wird_sanitisiert_zurueckgegeben(self):
        with _mit_gemocktem_text(_SYNTHETISCHER_TEXT_TREFFER):
            with patch(
                "packages.core.invoice_extraction.invoice2data_provider._load_templates",
                side_effect=RuntimeError("interner Templatefehler mit /echtem/pfad"),
            ):
                ergebnis = Invoice2DataProvider().extract(Path("dummy_synth.pdf"))
        assert ergebnis.laufstatus == "error"
        assert ergebnis.fehlercode == "RuntimeError"
        assert ergebnis.kandidaten == []

    def test_kein_dateipfad_im_fehlercode(self):
        with _mit_gemocktem_text(_SYNTHETISCHER_TEXT_TREFFER):
            with patch(
                "packages.core.invoice_extraction.invoice2data_provider._load_templates",
                side_effect=RuntimeError("interner Templatefehler mit /echtem/pfad"),
            ):
                ergebnis = Invoice2DataProvider().extract(Path("dummy_synth.pdf"))
        assert "/" not in ergebnis.fehlercode
        assert "echtem" not in ergebnis.fehlercode


class TestKonkurrierendeKandidatenOhneStilleAuswahl:
    def test_zwei_provider_liefern_beide_kandidaten_ohne_auswahl(self):
        """invoice2data und pdfplumber liefern unabhaengige Kandidaten fuer dasselbe
        Feld mit abweichenden Werten -- keiner der Provider trifft eine Auswahl.
        """
        with _mit_gemocktem_text(_SYNTHETISCHER_TEXT_TREFFER):
            i2d_ergebnis = Invoice2DataProvider().extract(Path("dummy_synth.pdf"))

        pdfplumber_text = (
            "Synthetisch Muster AG\n"
            "Rechnungsnummer: RE-2026-SYNTH-01\n"
            "Rechnungsdatum: 01.07.2026\n"
            "Gesamtbetrag: 999.99 EUR\n"
        )
        with patch(
            "packages.core.invoice_extraction.invoice_parser_adapter._READER.extract_text",
            return_value=pdfplumber_text,
        ):
            pdfplumber_ergebnis = PdfplumberProvider().extract(Path("dummy_synth.pdf"))

        alle_kandidaten = i2d_ergebnis.kandidaten + pdfplumber_ergebnis.kandidaten
        total_amount_kandidaten = [k for k in alle_kandidaten if k.feld == "total_amount"]

        assert len(total_amount_kandidaten) == 2
        werte = {k.normwert for k in total_amount_kandidaten}
        assert werte == {"119.00", "999.99"}
        assert all(k.auswahl_status is None for k in total_amount_kandidaten)
