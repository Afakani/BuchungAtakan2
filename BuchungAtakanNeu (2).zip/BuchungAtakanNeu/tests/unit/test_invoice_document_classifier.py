"""Unit-Tests fuer die deterministische Dokumentklassifikation (07-02).

Arbeitet ausschliesslich auf synthetischen DokumentMerkmale-Werten -- kein Datei-IO,
keine echten PDFs noetig.
"""
from packages.core.invoice_extraction.document_classifier import (
    MIN_ZEICHEN_PRO_SEITE,
    DokumentKlasse,
    DokumentMerkmale,
    klassifiziere,
)


def _merkmale(**kwargs) -> DokumentMerkmale:
    defaults = dict(suffix=".pdf", seiten_anzahl=1, text_zeichen_gesamt=500)
    defaults.update(kwargs)
    return DokumentMerkmale(**defaults)


class TestTextPdf:
    def test_ausreichend_text_ist_text_pdf(self):
        m = _merkmale(seiten_anzahl=1, text_zeichen_gesamt=500)
        assert klassifiziere(m) == DokumentKlasse.TEXT_PDF

    def test_mehrseitig_ausreichend_text_pro_seite(self):
        m = _merkmale(seiten_anzahl=3, text_zeichen_gesamt=3 * MIN_ZEICHEN_PRO_SEITE)
        assert klassifiziere(m) == DokumentKlasse.TEXT_PDF


class TestScanPdf:
    def test_kein_text_ist_scan_pdf(self):
        m = _merkmale(seiten_anzahl=1, text_zeichen_gesamt=0)
        assert klassifiziere(m) == DokumentKlasse.SCAN_PDF

    def test_zu_wenig_text_ist_scan_pdf(self):
        m = _merkmale(seiten_anzahl=1, text_zeichen_gesamt=MIN_ZEICHEN_PRO_SEITE - 1)
        assert klassifiziere(m) == DokumentKlasse.SCAN_PDF

    def test_mehrseitig_zu_wenig_text_pro_seite(self):
        m = _merkmale(seiten_anzahl=5, text_zeichen_gesamt=MIN_ZEICHEN_PRO_SEITE * 5 - 1)
        assert klassifiziere(m) == DokumentKlasse.SCAN_PDF


class TestSonderformat:
    def test_bekanntes_bildformat(self):
        m = _merkmale(suffix=".png")
        assert klassifiziere(m) == DokumentKlasse.SONDERFORMAT

    def test_bekanntes_tiff_format(self):
        m = _merkmale(suffix=".tiff")
        assert klassifiziere(m) == DokumentKlasse.SONDERFORMAT

    def test_xml_format(self):
        m = _merkmale(suffix=".xml")
        assert klassifiziere(m) == DokumentKlasse.SONDERFORMAT


class TestUnbekannt:
    def test_unbekanntes_suffix(self):
        m = _merkmale(suffix=".docx")
        assert klassifiziere(m) == DokumentKlasse.UNBEKANNT

    def test_pdf_ohne_seiten(self):
        m = _merkmale(seiten_anzahl=0, text_zeichen_gesamt=0)
        assert klassifiziere(m) == DokumentKlasse.UNBEKANNT


class TestGrenzwerteDeterministisch:
    def test_genau_auf_schwelle_ist_text_pdf(self):
        m = _merkmale(seiten_anzahl=1, text_zeichen_gesamt=MIN_ZEICHEN_PRO_SEITE)
        assert klassifiziere(m) == DokumentKlasse.TEXT_PDF

    def test_knapp_unter_schwelle_ist_scan_pdf(self):
        m = _merkmale(seiten_anzahl=1, text_zeichen_gesamt=MIN_ZEICHEN_PRO_SEITE - 1)
        assert klassifiziere(m) == DokumentKlasse.SCAN_PDF

    def test_wiederholter_aufruf_liefert_gleiches_ergebnis(self):
        m = _merkmale(seiten_anzahl=2, text_zeichen_gesamt=40)
        ergebnisse = {klassifiziere(m) for _ in range(5)}
        assert len(ergebnisse) == 1
