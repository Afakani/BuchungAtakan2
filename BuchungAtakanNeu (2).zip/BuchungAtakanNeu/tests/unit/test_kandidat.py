"""Unit-Tests fuer Kandidat-Modell (RECH-01)."""
import pytest

from packages.core.invoice_extraction.kandidat import Kandidat, KandidatQuelle, RECHNUNGS_FELDER


def test_kandidat_erstellen():
    k = Kandidat(feld="total_amount", rohwert="119,00", normwert="119.00", methode="regex_label", quelle=KandidatQuelle.PDF_TEXT, confidence=0.85)
    assert k.feld == "total_amount"
    assert k.normwert == "119.00"
    assert k.confidence == 0.85


def test_kandidat_frozen():
    k = Kandidat(feld="vendor_name", rohwert="Test GmbH", normwert="Test GmbH", methode="label", quelle="pdf_text", confidence=0.9)
    with pytest.raises(Exception):
        k.feld = "other"  # type: ignore[misc]


def test_kandidat_confidence_invalid():
    with pytest.raises(ValueError, match="confidence"):
        Kandidat(feld="total_amount", rohwert="100", normwert="100.00", methode="x", quelle="pdf_text", confidence=1.5)


def test_kandidat_confidence_grenzwerte():
    Kandidat(feld="currency", rohwert="EUR", normwert="EUR", methode="x", quelle="pdf_text", confidence=0.0)
    Kandidat(feld="currency", rohwert="EUR", normwert="EUR", methode="x", quelle="pdf_text", confidence=1.0)


def test_kandidat_rohwert_pflicht():
    with pytest.raises((TypeError, ValueError)):
        Kandidat(feld="total_amount", rohwert=None, normwert=None, methode="x", quelle="pdf_text", confidence=0.5)  # type: ignore[arg-type]


def test_kandidat_feld_leer():
    with pytest.raises(ValueError, match="feld"):
        Kandidat(feld="", rohwert="100", normwert=None, methode="x", quelle="pdf_text", confidence=0.5)


def test_kandidat_normwert_none_erlaubt():
    k = Kandidat(feld="vendor_name", rohwert="Unbekannt", normwert=None, methode="x", quelle="pdf_text", confidence=0.1)
    assert k.normwert is None


def test_rechnungs_felder_vollstaendig():
    assert "vendor_name" in RECHNUNGS_FELDER
    assert "invoice_number" in RECHNUNGS_FELDER
    assert "total_amount" in RECHNUNGS_FELDER
    assert "tax_amount" in RECHNUNGS_FELDER


def test_kandidat_quelle_enum():
    assert KandidatQuelle.PDF_TEXT == "pdf_text"
    assert KandidatQuelle.OCR == "ocr"
    assert KandidatQuelle.E_RECHNUNG == "e_rechnung"
