"""Unit-Tests EC-Scoring (Phase 06, Paket 1).

Anforderungen:
  STARK-Schwelle: score >= 90, alle Bedingungen (differenz==0, keine Entfernten, Zeitfenster OK)
  UNSICHER: score >= 40, nicht STARK
  Signalnamen korrekt
"""
import pytest

from packages.core.ec_sammlung.scorer import (
    EC_SCHWELLE_STARK,
    EC_SCHWELLE_UNSICHER,
    berechne_ec_score,
    bestimme_status,
)
from packages.core.ec_sammlung.typen import EcSammelStatus


class TestScoreBerechnung:
    def test_alle_bedingungen_erfuellt_score_100(self):
        score, pos, neg = berechne_ec_score(
            differenz_cent=0,
            entfernte_belege_cnt=0,
            zeitfenster_ueberschritten=False,
            aktive_belege_cnt=1,
        )
        assert score == 100
        assert len(neg) == 0

    def test_alle_positiven_signale_vorhanden_bei_perfekt(self):
        score, pos, neg = berechne_ec_score(0, 0, False, 1)
        pos_typen = {s.typ for s in pos}
        assert "SUMME_EXAKT" in pos_typen
        assert "KEINE_ENTFERNTEN" in pos_typen
        assert "ZEITFENSTER_OK" in pos_typen
        assert "MINDESTENS_EIN_BELEG" in pos_typen

    def test_entfernte_belege_reduzieren_score(self):
        score_ohne, _, _ = berechne_ec_score(0, 0, False, 1)
        score_mit, _, _ = berechne_ec_score(0, 2, False, 1)
        assert score_mit < score_ohne

    def test_zeitfenster_ueberschreitung_reduziert_score(self):
        score_ok, _, _ = berechne_ec_score(0, 0, False, 1)
        score_ue, _, _ = berechne_ec_score(0, 0, True, 1)
        assert score_ue < score_ok

    def test_unterdeckung_reduziert_score(self):
        score_exakt, _, _ = berechne_ec_score(0, 0, False, 1)
        score_unter, _, _ = berechne_ec_score(500, 0, False, 1)  # 5 EUR Unterdeckung
        assert score_unter < score_exakt

    def test_keine_belege_negative_signal(self):
        score, _, neg = berechne_ec_score(0, 0, False, 0)
        neg_typen = {s.typ for s in neg}
        assert "KEINE_BELEGE" in neg_typen

    def test_punkte_summe_konsistent(self):
        score, pos, neg = berechne_ec_score(100, 1, True, 2)
        erwartet = sum(s.punkte for s in pos) + sum(s.punkte for s in neg)
        assert score == erwartet


class TestStatusBestimmung:
    def test_perfekte_bedingungen_stark(self):
        status = bestimme_status(100, 0, 0, False, 1)
        assert status == EcSammelStatus.STARK

    def test_stark_schwelle_genau_90(self):
        status = bestimme_status(EC_SCHWELLE_STARK, 0, 0, False, 1)
        assert status == EcSammelStatus.STARK

    def test_unter_stark_schwelle_unsicher(self):
        status = bestimme_status(EC_SCHWELLE_STARK - 1, 0, 0, False, 1)
        assert status == EcSammelStatus.UNSICHER

    def test_differenz_nicht_null_verhindert_stark(self):
        status = bestimme_status(95, 1, 0, False, 1)  # score 95 aber differenz=1
        assert status == EcSammelStatus.UNSICHER

    def test_entfernte_belege_verhindert_stark(self):
        status = bestimme_status(95, 0, 1, False, 1)  # entfernte_belege_cnt=1
        assert status == EcSammelStatus.UNSICHER

    def test_zeitfenster_ueberschritten_verhindert_stark(self):
        status = bestimme_status(95, 0, 0, True, 1)  # zeitfenster_ueberschritten
        assert status == EcSammelStatus.UNSICHER

    def test_keine_belege_verhindert_stark(self):
        status = bestimme_status(95, 0, 0, False, 0)  # aktive_belege_cnt=0
        assert status == EcSammelStatus.UNSICHER

    def test_schwellen_korrekt_definiert(self):
        assert EC_SCHWELLE_STARK == 90
        assert EC_SCHWELLE_UNSICHER == 40
        assert EC_SCHWELLE_STARK > EC_SCHWELLE_UNSICHER
