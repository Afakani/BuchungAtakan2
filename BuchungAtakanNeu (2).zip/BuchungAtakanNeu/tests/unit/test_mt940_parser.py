"""Unit-Tests fuer MT940-Parser (packages/core/bank_import/mt940_parser.py).

Alle Testdaten sind vollstaendig synthetisch und anonym.
Keine echten Kontonummern, IBANs, Namen oder Betraege.

Abgedeckte Anforderungen:
  P01: Einzelne Haben-Buchung (Credit, CR)
  P02: Einzelne Soll-Buchung (Debit, DR)
  P03: Mehrere Buchungen in einer Datei
  P04: Zwei identische Buchungen an verschiedenen Quellpositionen
  P05: Wiederholtes Parsen → identische Positionen und Fingerprints
  P06: Verwendungszweck ueber mehrere Zeilen (:86: Fortsetzungszeilen)
  P07: Gegenpartei und IBAN aus strukturiertem :86:
  P08: Fehlende optionale Gegenpartei — kein Datenverlust
  P09: Dezimalkomma in Betrag
  P10: CRLF- und LF-Zeilenenden
  P11: UTF-8 und CP1252 Encoding
  P12: Ungültiges Datum in :61: → MT940DatumFehler im Fehlerbericht
  P13: Ungueltiger Betrag in :61: → MT940BetragFehler im Fehlerbericht
  P14: Leere Datei → MT940FormatFehler
  P15: Unbekanntes Format → MT940FormatFehler
"""
import pytest

from packages.core.bank_import.mt940_parser import (
    MT940FormatFehler,
    parse_mt940,
)


# ── Hilfsfunktionen ───────────────────────────────────────────────────────────

def _mt940(buchungen_block: str = "", waehrung: str = "EUR") -> bytes:
    """Erzeugt minimalen validen MT940-Inhalt mit einem Statement."""
    kopf = (
        ":20:TESTREF\n"
        ":25:1234567890/12345678\n"
        ":28C:0\n"
        f":60F:C240101{waehrung}1000,00\n"
    )
    abschluss = f":62F:C240101{waehrung}1000,00\n-\n"
    return (kopf + buchungen_block + abschluss).encode("utf-8")


def _cr_buchung(
    datum: str = "240115",
    betrag: str = "100,00",
    waehrung_kz: str = "",
    swift: str = "NTRF",
    verwendungszweck: str = "Zahlung RE-2024-001",
    gegenpartei_name: str = "Muster GmbH",
    gegenpartei_iban: str = "DE89370400440532013000",
    gegenpartei_bic: str = "COBADEFFXXX",
    position_suffix: str = "",
) -> str:
    return (
        f":61:{datum}CR{waehrung_kz}{betrag}{swift}KREF+\n"
        f":86:166?00Ueberweisung Eingang?20SVWZ+{verwendungszweck}"
        f"{position_suffix}?30{gegenpartei_bic}?31{gegenpartei_iban}?32{gegenpartei_name}\n"
    )


def _dr_buchung(
    datum: str = "240115",
    betrag: str = "200,00",
    swift: str = "NTRF",
    verwendungszweck: str = "Miete Januar 2024",
    gegenpartei_name: str = "Vermieter AG",
    gegenpartei_iban: str = "DE12500105170648489890",
    gegenpartei_bic: str = "BELADEBEXXX",
) -> str:
    return (
        f":61:{datum}DR{betrag}{swift}KREF+\n"
        f":86:177?00Ueberweisung?20SVWZ+{verwendungszweck}"
        f"?30{gegenpartei_bic}?31{gegenpartei_iban}?32{gegenpartei_name}\n"
    )


# ── P01: Haben-Buchung ────────────────────────────────────────────────────────

class TestHabenBuchung:
    def test_betrag_positiv(self):
        """P01: CR-Buchung → positiver Cent-Betrag."""
        datei = _mt940(_cr_buchung(betrag="100,00"))
        ergebnis = parse_mt940(datei)
        assert len(ergebnis.buchungen) == 1
        assert ergebnis.buchungen[0].betrag_cent == 10000

    def test_quell_position_eins(self):
        """P01: Erste Buchung hat quell_position=1."""
        ergebnis = parse_mt940(_mt940(_cr_buchung()))
        assert ergebnis.buchungen[0].quell_position == 1

    def test_buchungsdatum_korrekt(self):
        """P01: Datum wird korrekt geparst."""
        from datetime import date
        ergebnis = parse_mt940(_mt940(_cr_buchung(datum="240315")))
        assert ergebnis.buchungen[0].buchungsdatum == date(2024, 3, 15)

    def test_keine_fehler(self):
        """P01: Keine Parse-Fehler bei gueltiger Buchung."""
        ergebnis = parse_mt940(_mt940(_cr_buchung()))
        assert ergebnis.fehler == []


# ── P02: Soll-Buchung ─────────────────────────────────────────────────────────

class TestSollBuchung:
    def test_betrag_negativ(self):
        """P02: DR-Buchung → negativer Cent-Betrag."""
        datei = _mt940(_dr_buchung(betrag="200,00"))
        ergebnis = parse_mt940(datei)
        assert len(ergebnis.buchungen) == 1
        assert ergebnis.buchungen[0].betrag_cent == -20000

    def test_waehrung_eur(self):
        """P02: Waehrung aus :60F: gelesen."""
        ergebnis = parse_mt940(_mt940(_dr_buchung()))
        assert ergebnis.buchungen[0].waehrung == "EUR"


# ── P03: Mehrere Buchungen ────────────────────────────────────────────────────

class TestMehrereBuchungen:
    def test_anzahl_korrekt(self):
        """P03: Mehrere :61:-Tags → entsprechende Buchungsanzahl."""
        block = _cr_buchung(datum="240101") + _dr_buchung(datum="240102") + _cr_buchung(datum="240103")
        ergebnis = parse_mt940(_mt940(block))
        assert len(ergebnis.buchungen) == 3

    def test_positionen_aufsteigend(self):
        """P03: Quellpositionen sind 1, 2, 3 in Dateireihenfolge."""
        block = _cr_buchung() + _dr_buchung() + _cr_buchung()
        ergebnis = parse_mt940(_mt940(block))
        positionen = [b.quell_position for b in ergebnis.buchungen]
        assert positionen == [1, 2, 3]

    def test_vorzeichen_korrekt(self):
        """P03: CR positiv, DR negativ."""
        block = _cr_buchung(betrag="300,00") + _dr_buchung(betrag="150,00")
        ergebnis = parse_mt940(_mt940(block))
        assert ergebnis.buchungen[0].betrag_cent == 30000
        assert ergebnis.buchungen[1].betrag_cent == -15000


# ── P04: Identische Buchungen verschiedene Positionen ────────────────────────

class TestIdentischeBuchungenVerschiedenePositionen:
    def test_beide_erhalten(self):
        """P04: Zwei identische Buchungen werden beide importiert."""
        buchung = _cr_buchung(datum="240101", betrag="100,00")
        ergebnis = parse_mt940(_mt940(buchung + buchung))
        assert len(ergebnis.buchungen) == 2

    def test_verschiedene_positionen(self):
        """P04: Identische Buchungen erhalten verschiedene quell_position."""
        buchung = _cr_buchung()
        ergebnis = parse_mt940(_mt940(buchung + buchung))
        pos = [b.quell_position for b in ergebnis.buchungen]
        assert pos[0] != pos[1]
        assert pos == [1, 2]


# ── P05: Wiederholtes Parsen ──────────────────────────────────────────────────

class TestWiederholtesParsing:
    def test_positionen_stabil(self):
        """P05: Wiederholtes Parsen → gleiche quell_position."""
        datei = _mt940(_cr_buchung() + _dr_buchung())
        r1 = parse_mt940(datei)
        r2 = parse_mt940(datei)
        assert [b.quell_position for b in r1.buchungen] == [b.quell_position for b in r2.buchungen]

    def test_fingerprint_stabil(self):
        """P05: Wiederholtes Parsen → identischer quell_fingerprint."""
        datei = _mt940(_cr_buchung())
        r1 = parse_mt940(datei)
        r2 = parse_mt940(datei)
        assert r1.quell_fingerprint == r2.quell_fingerprint

    def test_fingerprint_sha256_format(self):
        """P05: Fingerprint ist 64-stelliger Hex-String (SHA-256)."""
        ergebnis = parse_mt940(_mt940(_cr_buchung()))
        assert len(ergebnis.quell_fingerprint) == 64
        assert all(c in "0123456789abcdef" for c in ergebnis.quell_fingerprint)


# ── P06: Mehrzeiliger Verwendungszweck ────────────────────────────────────────

class TestMehrzeiliger86:
    def test_verwendungszweck_aus_fortsetzungszeilen(self):
        """P06: :86: ueber mehrere Zeilen wird korrekt zusammengefuehrt."""
        block = (
            ":61:240101CR500,00NTRFKREF+\n"
            ":86:166?00Gutschrift?20SVWZ+Rechnung RE-2024-042 Teilzahlung\n"
            "?21 Auftrag 2024-999\n"
            "?30COBADEFFXXX?31DE89370400440532013000?32Test GmbH\n"
        )
        ergebnis = parse_mt940(_mt940(block))
        assert len(ergebnis.buchungen) == 1
        zweck = ergebnis.buchungen[0].verwendungszweck
        assert zweck is not None
        # Mindestens der erste Teil muss enthalten sein
        assert "Rechnung RE-2024-042" in zweck or "Teilzahlung" in zweck

    def test_gegenpartei_name_aus_86(self):
        """P06: Gegenparteiname aus ?32 extrahiert."""
        block = (
            ":61:240101CR100,00NTRFKREF+\n"
            ":86:166?00Gutschrift?20SVWZ+Test?30COBADEFFXXX"
            "?31DE89370400440532013000?32Testfirma Beispiel GmbH\n"
        )
        ergebnis = parse_mt940(_mt940(block))
        assert ergebnis.buchungen[0].gegenpartei_name == "Testfirma Beispiel GmbH"


# ── P07: Gegenpartei und IBAN ─────────────────────────────────────────────────

class TestGegenparteiUndIBAN:
    def test_iban_aus_86_feld_31(self):
        """P07: IBAN aus :86: ?31 extrahiert."""
        ergebnis = parse_mt940(_mt940(_cr_buchung(gegenpartei_iban="DE89370400440532013000")))
        assert ergebnis.buchungen[0].gegenpartei_iban == "DE89370400440532013000"

    def test_bic_aus_86_feld_30(self):
        """P07: BIC aus :86: ?30 extrahiert."""
        ergebnis = parse_mt940(_mt940(_cr_buchung(gegenpartei_bic="COBADEFFXXX")))
        assert ergebnis.buchungen[0].gegenpartei_bic == "COBADEFFXXX"

    def test_name_aus_86_feld_32(self):
        """P07: Gegenparteiname aus ?32."""
        ergebnis = parse_mt940(_mt940(_cr_buchung(gegenpartei_name="Muster GmbH")))
        assert ergebnis.buchungen[0].gegenpartei_name == "Muster GmbH"


# ── P08: Fehlende Gegenpartei ─────────────────────────────────────────────────

class TestFehlenderGegenpartei:
    def test_ohne_86_keine_gegenpartei(self):
        """P08: Buchung ohne :86: → Gegenpartei None, Buchung trotzdem valide."""
        block = ":61:240101CR100,00NTRFKREF+\n"
        ergebnis = parse_mt940(_mt940(block))
        assert len(ergebnis.buchungen) == 1
        b = ergebnis.buchungen[0]
        assert b.gegenpartei_name is None
        assert b.gegenpartei_iban is None
        assert b.betrag_cent == 10000  # trotzdem korrekt

    def test_ohne_iban_in_86(self):
        """P08: :86: ohne ?31 → gegenpartei_iban None."""
        block = (
            ":61:240101CR100,00NTRFKREF+\n"
            ":86:166?00Gutschrift?20SVWZ+Zahlung?32Test AG\n"
        )
        ergebnis = parse_mt940(_mt940(block))
        assert ergebnis.buchungen[0].gegenpartei_iban is None
        assert ergebnis.buchungen[0].gegenpartei_name == "Test AG"


# ── P09: Dezimalkomma ─────────────────────────────────────────────────────────

class TestDezimalkomma:
    def test_komma_als_dezimaltrennzeichen(self):
        """P09: MT940 nutzt Komma als Dezimaltrennzeichen."""
        ergebnis = parse_mt940(_mt940(_cr_buchung(betrag="1217,46")))
        assert ergebnis.buchungen[0].betrag_cent == 121746

    def test_ganzzahl_betrag(self):
        """P09: Betrag ohne Nachkommastellen (z.B. 500,00 oder 500)."""
        ergebnis = parse_mt940(_mt940(_cr_buchung(betrag="500,00")))
        assert ergebnis.buchungen[0].betrag_cent == 50000

    def test_grosser_betrag(self):
        """P09: Groessere Betraege werden korrekt konvertiert."""
        ergebnis = parse_mt940(_mt940(_cr_buchung(betrag="9999,99")))
        assert ergebnis.buchungen[0].betrag_cent == 999999


# ── P10: Zeilenenden ─────────────────────────────────────────────────────────

class TestZeilenenden:
    def test_lf_zeilenende(self):
        """P10: LF-Zeilenenden (Unix) werden korrekt verarbeitet."""
        inhalt = (
            ":20:TESTREF\n:25:1234567890/12345678\n:28C:0\n"
            ":60F:C240101EUR1000,00\n"
            ":61:240101CR100,00NTRFKREF+\n"
            ":86:166?00Gutschrift?20SVWZ+Test\n"
            ":62F:C240101EUR1100,00\n-\n"
        )
        ergebnis = parse_mt940(inhalt.encode("utf-8"))
        assert len(ergebnis.buchungen) == 1

    def test_crlf_zeilenende(self):
        """P10: CRLF-Zeilenenden (Windows) werden korrekt verarbeitet."""
        inhalt = (
            ":20:TESTREF\r\n:25:1234567890/12345678\r\n:28C:0\r\n"
            ":60F:C240101EUR1000,00\r\n"
            ":61:240101CR100,00NTRFKREF+\r\n"
            ":86:166?00Gutschrift?20SVWZ+Test\r\n"
            ":62F:C240101EUR1100,00\r\n-\r\n"
        )
        ergebnis = parse_mt940(inhalt.encode("utf-8"))
        assert len(ergebnis.buchungen) == 1
        assert ergebnis.buchungen[0].betrag_cent == 10000


# ── P11: Encoding ─────────────────────────────────────────────────────────────

class TestEncoding:
    def test_utf8_encoding(self):
        """P11: UTF-8 kodierte Datei wird korrekt geparst."""
        block = (
            ":61:240101CR100,00NTRFKREF+\n"
            ":86:166?00Gutschrift?20SVWZ+Zahlung Büro München?32Müller GmbH\n"
        )
        datei = (_mt940.__doc__ and None) or _mt940(block).replace(
            b":86:166?00Gutschrift?20SVWZ+Zahlung B",
            ":86:166?00Gutschrift?20SVWZ+Zahlung B".encode("utf-8"),
        )
        ergebnis = parse_mt940(_mt940(block))
        assert len(ergebnis.buchungen) == 1

    def test_cp1252_encoding(self):
        """P11: CP1252-kodierte Datei (typisch Windows/Volksbank) wird korrekt geparst."""
        inhalt = (
            ":20:TESTREF\n:25:1234567890/12345678\n:28C:0\n"
            ":60F:C240101EUR1000,00\n"
            ":61:240101CR100,00NTRFKREF+\n"
            ":86:166?00Überweisung?20SVWZ+Zahlung für Büroausstattung?32Müller AG\n"
            ":62F:C240101EUR1100,00\n-\n"
        )
        datei_cp1252 = inhalt.encode("cp1252")
        ergebnis = parse_mt940(datei_cp1252)
        assert len(ergebnis.buchungen) == 1
        # Gegenparteiname muss lesbar sein
        gp = ergebnis.buchungen[0].gegenpartei_name
        assert gp is not None
        assert "AG" in gp


# ── P12: Ungültiges Datum ─────────────────────────────────────────────────────

class TestUngueltigesDatum:
    def test_ungueltiges_datum_in_61_ergibt_fehler(self):
        """P12: Ungueltiges Datum → Fehler-Eintrag, kein Absturz."""
        block = ":61:991399CR100,00NTRFKREF+\n"  # Monat 13 = ungueltig
        ergebnis = parse_mt940(_mt940(block))
        assert len(ergebnis.buchungen) == 0
        assert len(ergebnis.fehler) == 1
        assert "991399" in ergebnis.fehler[0].meldung or "Datum" in ergebnis.fehler[0].meldung

    def test_andere_buchungen_weiterhin_valide(self):
        """P12: Fehler in einer Buchung stoppt nicht den Rest."""
        block = (
            ":61:240101CR100,00NTRFKREF+\n"
            ":86:166?00Gutschrift?20SVWZ+Erste\n"
            ":61:991399CR200,00NTRFKREF+\n"  # ungueltig
            ":61:240103CR300,00NTRFKREF+\n"
            ":86:166?00Gutschrift?20SVWZ+Dritte\n"
        )
        ergebnis = parse_mt940(_mt940(block))
        assert len(ergebnis.buchungen) == 2
        assert len(ergebnis.fehler) == 1


# ── P13: Ungültiger Betrag ────────────────────────────────────────────────────

class TestUngueltigerBetrag:
    def test_kein_betrag_in_61_ergibt_fehler(self):
        """P13: Fehlender Betrag in :61: → Fehler-Eintrag."""
        # Keine Ziffern nach D/C-Marker
        block = ":61:240101CRNTRFKREF+\n"
        ergebnis = parse_mt940(_mt940(block))
        # Kein valider Betrag → Fehler erwartet
        assert len(ergebnis.fehler) >= 1 or len(ergebnis.buchungen) == 0


# ── P14: Leere Datei ─────────────────────────────────────────────────────────

class TestLeereDate:
    def test_leere_datei_wirft_format_fehler(self):
        """P14: Leere Bytes → MT940FormatFehler."""
        with pytest.raises(MT940FormatFehler, match="Leere Datei"):
            parse_mt940(b"")

    def test_nur_leerzeichen_wirft_format_fehler(self):
        """P14: Nur Whitespace → MT940FormatFehler (kein Tag erkannt)."""
        with pytest.raises(MT940FormatFehler):
            parse_mt940(b"   \n   \n")


# ── P15: Unbekanntes Format ───────────────────────────────────────────────────

class TestUnbekanntesFormat:
    def test_xml_content_wirft_format_fehler(self):
        """P15: XML-Inhalt → MT940FormatFehler."""
        with pytest.raises(MT940FormatFehler):
            parse_mt940(b"<?xml version='1.0'?><root><data>123</data></root>")

    def test_csv_content_wirft_format_fehler(self):
        """P15: CSV-Inhalt → MT940FormatFehler."""
        with pytest.raises(MT940FormatFehler):
            parse_mt940(b"Datum;Betrag;Buchungstext\n2024-01-15;100,00;Testbuchung\n")

    def test_zufaelliger_text_wirft_format_fehler(self):
        """P15: Beliebiger Text ohne MT940-Tags → MT940FormatFehler."""
        with pytest.raises(MT940FormatFehler):
            parse_mt940(b"Dies ist kein MT940-Format.")
