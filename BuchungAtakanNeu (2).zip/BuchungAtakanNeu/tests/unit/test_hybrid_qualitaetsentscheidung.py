"""Unit-Tests fuer die finale Statusentscheidung nach Mehrprovider-Auswertung (HYB-14/15/16).

OK entsteht nie allein aus Vollstaendigkeit -- Konflikte, Plausibilitaet und
kritische Providerfehler fliessen mit ein.
"""
from packages.core.invoice_extraction.hybrid_ergebnis import HybridStatus
from packages.core.invoice_extraction.hybrid_kandidat import AuswahlStatus, HybridKandidat
from packages.core.invoice_extraction.hybrid_konflikt import KonfliktBefund
from packages.core.invoice_extraction.hybrid_plausibilitaet import PlausibilitaetsBefund
from packages.core.invoice_extraction.hybrid_qualitaetsentscheidung import berechne_finalen_status
from packages.core.invoice_extraction.provider_ports import InvoiceProviderResult


def _k(feld: str, confidence: float = 0.9, status=AuswahlStatus.AUSGEWAEHLT) -> HybridKandidat:
    return HybridKandidat(
        feld=feld, rohwert="wert", normwert="wert", methode="regex_label",
        provider_name="pdfplumber", provider_version="1.0", confidence=confidence,
        auswahl_status=status,
    )


def _k_azure(feld: str, confidence: float = 0.9, status=AuswahlStatus.AUSGEWAEHLT) -> HybridKandidat:
    return HybridKandidat(
        feld=feld, rohwert="wert", normwert="wert", methode="azure_document_intelligence",
        provider_name="azure_document_intelligence", provider_version="1.0", confidence=confidence,
        auswahl_status=status,
    )


_PFLICHT = ["vendor_name", "invoice_number", "invoice_date", "total_amount"]


def _alle_pflicht_ausgewaehlt(confidence: float = 0.9) -> list[HybridKandidat]:
    return [_k(f, confidence=confidence) for f in _PFLICHT]


def _bestandene_plausibilitaet() -> list[PlausibilitaetsBefund]:
    return [PlausibilitaetsBefund(regel=r, bestanden=True, begruendung="ok") for r in [
        "betragsrelation", "steuer_nicht_negativ", "waehrung_konsistent",
        "rechnungsdatum_plausibel", "rechnungsnummer_plausibel", "anbieter_bestimmbar",
    ]]


def _provider_erfolg() -> list[InvoiceProviderResult]:
    return [InvoiceProviderResult(
        provider_name="pdfplumber", provider_version="1.0", laufstatus="success",
        kandidaten=[], fehlercode=None,
    )]


class TestEindeutigOk:
    def test_alle_kriterien_erfuellt_ergibt_ok(self):
        status, gruende = berechne_finalen_status(
            _alle_pflicht_ausgewaehlt(), [], _bestandene_plausibilitaet(), _provider_erfolg(),
        )
        assert status == HybridStatus.OK
        assert any("OK" in g for g in gruende)


class TestKonfliktbedingtMussGeprueft:
    def test_offener_pflichtfeld_konflikt_verhindert_ok(self):
        konflikt = KonfliktBefund(
            feld="total_amount", kandidaten=(), werte=("100.00", "200.00"),
            provider=("pdfplumber", "invoice2data"), konfliktart="PROVIDER_WERTABWEICHUNG",
            begruendung="abweichend", schweregrad="HOCH", aufloesungsstatus="AUFGELOEST_MEHRHEIT",
        )
        status, gruende = berechne_finalen_status(
            _alle_pflicht_ausgewaehlt(), [konflikt], _bestandene_plausibilitaet(), _provider_erfolg(),
        )
        assert status == HybridStatus.MUSS_GEPRUEFT_WERDEN
        assert any("Konflikt" in g for g in gruende)

    def test_optionalfeld_konflikt_blockiert_ok_nicht(self):
        konflikt = KonfliktBefund(
            feld="payment_method", kandidaten=(), werte=("CASH", "BANK_TRANSFER"),
            provider=("pdfplumber", "invoice2data"), konfliktart="PROVIDER_WERTABWEICHUNG",
            begruendung="abweichend", schweregrad="MITTEL", aufloesungsstatus="AUFGELOEST_MEHRHEIT",
        )
        status, _ = berechne_finalen_status(
            _alle_pflicht_ausgewaehlt(), [konflikt], _bestandene_plausibilitaet(), _provider_erfolg(),
        )
        assert status == HybridStatus.OK


class TestUnvollstaendigMussGeprueft:
    def test_ein_pflichtfeld_fehlt(self):
        kandidaten = _alle_pflicht_ausgewaehlt()[:-1]  # total_amount fehlt
        status, gruende = berechne_finalen_status(
            kandidaten, [], _bestandene_plausibilitaet(), _provider_erfolg(),
        )
        assert status == HybridStatus.MUSS_GEPRUEFT_WERDEN
        assert any("total_amount" in g for g in gruende)


class TestKeineKandidatenNichtGefunden:
    def test_leere_kandidatenliste(self):
        status, gruende = berechne_finalen_status([], [], [], [])
        assert status == HybridStatus.NICHT_GEFUNDEN

    def test_alle_provider_fehlgeschlagen(self):
        fehlgeschlagen = [InvoiceProviderResult(
            provider_name="pdfplumber", provider_version="1.0", laufstatus="error",
            kandidaten=[], fehlercode="ValueError",
        )]
        status, _ = berechne_finalen_status(
            _alle_pflicht_ausgewaehlt(), [], _bestandene_plausibilitaet(), fehlgeschlagen,
        )
        assert status == HybridStatus.NICHT_GEFUNDEN


class TestUngueltigeBetragsrelation:
    def test_gescheiterte_betragsrelation_verhindert_ok(self):
        plausibilitaet = _bestandene_plausibilitaet()
        plausibilitaet[0] = PlausibilitaetsBefund(
            regel="betragsrelation", bestanden=False, begruendung="Netto+Steuer != Brutto",
        )
        status, gruende = berechne_finalen_status(
            _alle_pflicht_ausgewaehlt(), [], plausibilitaet, _provider_erfolg(),
        )
        assert status == HybridStatus.MUSS_GEPRUEFT_WERDEN
        assert any("betragsrelation" in g for g in gruende)


class TestNiedrigeConfidence:
    def test_niedrige_confidence_bei_pflichtfeld_verhindert_ok(self):
        status, gruende = berechne_finalen_status(
            _alle_pflicht_ausgewaehlt(confidence=0.2), [], _bestandene_plausibilitaet(), _provider_erfolg(),
        )
        assert status == HybridStatus.MUSS_GEPRUEFT_WERDEN
        assert any("Confidence" in g for g in gruende)


class TestKritischerProviderfehler:
    def test_ein_providerfehler_neben_erfolgreichem_lauf_verhindert_ok(self):
        provider_ergebnisse = _provider_erfolg() + [InvoiceProviderResult(
            provider_name="invoice2data", provider_version="1.0", laufstatus="error",
            kandidaten=[], fehlercode="RuntimeError",
        )]
        status, gruende = berechne_finalen_status(
            _alle_pflicht_ausgewaehlt(), [], _bestandene_plausibilitaet(), provider_ergebnisse,
        )
        assert status == HybridStatus.MUSS_GEPRUEFT_WERDEN
        assert any("Providerfehler" in g for g in gruende)


class TestAzureOnlyGuard:
    """Paket 07-04 Akzeptanzkriterium: Azure-Kandidaten duerfen Pflichtfelder nie
    allein bestaetigen -- Azure-Ergebnisse sind nur zusaetzliche Kandidaten."""

    def test_azure_only_pflichtfelder_verhindert_ok(self):
        kandidaten = [_k_azure(f) for f in _PFLICHT]
        status, gruende = berechne_finalen_status(
            kandidaten, [], _bestandene_plausibilitaet(),
            [InvoiceProviderResult(
                provider_name="azure_document_intelligence", provider_version="1.0",
                laufstatus="success", kandidaten=[], fehlercode=None,
            )],
        )
        assert status == HybridStatus.MUSS_GEPRUEFT_WERDEN
        assert any("Azure" in g for g in gruende)

    def test_mindestens_ein_lokaler_pflichtkandidat_erlaubt_ok(self):
        """Mischfall: ein lokaler Provider bestaetigt mindestens ein Pflichtfeld ->
        Azure-only-Guard greift nicht, bestehende Kriterien entscheiden weiter."""
        kandidaten = [_k_azure(f) for f in _PFLICHT[1:]] + [_k(_PFLICHT[0])]
        status, gruende = berechne_finalen_status(
            kandidaten, [], _bestandene_plausibilitaet(), _provider_erfolg(),
        )
        assert status == HybridStatus.OK
        assert not any("Azure" in g for g in gruende)

    def test_azure_only_bleibt_bei_zusaetzlichen_fehlern_maximal_muss_gepr(self):
        """Azure-only UND ein weiteres Kriterium verletzt -- bleibt MUSS_GEPRUEFT_WERDEN,
        eskaliert nicht zu NICHT_GEFUNDEN."""
        kandidaten = [_k_azure(f, confidence=0.9) for f in _PFLICHT]
        plausibilitaet = _bestandene_plausibilitaet()
        plausibilitaet[0] = PlausibilitaetsBefund(
            regel="betragsrelation", bestanden=False, begruendung="Netto+Steuer != Brutto",
        )
        status, gruende = berechne_finalen_status(
            kandidaten, [], plausibilitaet,
            [InvoiceProviderResult(
                provider_name="azure_document_intelligence", provider_version="1.0",
                laufstatus="success", kandidaten=[], fehlercode=None,
            )],
        )
        assert status == HybridStatus.MUSS_GEPRUEFT_WERDEN
        assert any("Azure" in g for g in gruende)
        assert any("betragsrelation" in g for g in gruende)


class TestDeterminismus:
    def test_gleiche_eingabe_liefert_gleichen_status(self):
        ergebnisse = [
            berechne_finalen_status(
                _alle_pflicht_ausgewaehlt(), [], _bestandene_plausibilitaet(), _provider_erfolg(),
            )
            for _ in range(5)
        ]
        assert all(e == ergebnisse[0] for e in ergebnisse)
