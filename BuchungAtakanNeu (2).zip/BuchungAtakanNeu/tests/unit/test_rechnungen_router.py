"""Unit-Tests fuer Rechnungs-Router — HTTP-Schicht mit gepatchtem Repository."""
from decimal import Decimal
from unittest.mock import AsyncMock, patch
from uuid import uuid4, UUID

from fastapi import HTTPException
from fastapi.testclient import TestClient

from apps.server.auth.dependencies import get_current_unternehmen_id, get_rls_session
from apps.server.main import create_app
from apps.server.models.rechnung import Erkennungslauf, Rechnung, RechnungsKandidat, RechnungsStatus
from apps.server.repositories.rechnung import RechnungRepository
from apps.server.routers.rechnungen import (
    RechnungCreateRequest,
    _hat_starke_partnersignale,
    _rech06_prueffall,
)

FIXED_TENANT = uuid4()
FIXED_DOK = uuid4()
FIXED_RECH_ID = uuid4()


# ── Test-App mit Dependency-Overrides ────────────────────────────────────────

def _make_client() -> TestClient:
    """Frische App-Instanz mit überschriebenen Auth/Session-Dependencies."""
    _app = create_app()

    def _tenant():
        return FIXED_TENANT

    async def _rls_session():
        yield AsyncMock()

    _app.dependency_overrides[get_current_unternehmen_id] = _tenant
    _app.dependency_overrides[get_rls_session] = _rls_session
    return TestClient(_app)


def _rechnung(
    rechnungsnummer: str | None = "2024-001",
    rechnungsdatum: str | None = "01.01.2024",
    version_lfd_nr: int = 1,
    ist_aktiv: bool = True,
    status: str = "NEU",
    lieferant_name: str | None = "Test GmbH",
) -> Rechnung:
    r = Rechnung(
        unternehmen_id=FIXED_TENANT,
        dokument_id=FIXED_DOK,
        rechnungsnummer=rechnungsnummer,
        rechnungsdatum=rechnungsdatum,
        gesamtbetrag=Decimal("119.00"),
        nettobetrag=Decimal("100.00"),
        steuerbetrag=Decimal("19.00"),
        waehrung="EUR",
        zahlungsart=None,
        lieferant_name=lieferant_name,
        version_lfd_nr=version_lfd_nr,
        ist_aktiv=ist_aktiv,
        status=status,
    )
    r.id = FIXED_RECH_ID  # type: ignore[assignment]
    return r


def _erkennungslauf() -> Erkennungslauf:
    e = Erkennungslauf(
        unternehmen_id=FIXED_TENANT,
        dokument_id=FIXED_DOK,
        extraktion_status="OK",
        fehler=None,
    )
    e.id = uuid4()  # type: ignore[assignment]
    e.rechnung_id = None  # type: ignore[assignment]
    e.extraktion_confidence = None  # type: ignore[assignment]
    return e


# ── RECH-06 Guard — reine Logik ───────────────────────────────────────────────

def test_rech06_guard_rechnungsnummer_verhindert_prueffall():
    req = RechnungCreateRequest(
        dokument_id=FIXED_DOK, rechnungsnummer="2024-001", lieferant_name="Muster GmbH"
    )
    assert _rech06_prueffall(req) is False


def test_rech06_guard_nur_lieferant_name_kein_starkes_signal():
    req = RechnungCreateRequest(dokument_id=FIXED_DOK, lieferant_name="Muster GmbH")
    assert _rech06_prueffall(req) is True


def test_rech06_guard_gesamtbetrag_ist_kein_starkes_signal():
    """RECH-06: gesamtbetrag ist kein Identifikationsmerkmal — PRUEFFALL bleibt."""
    req = RechnungCreateRequest(
        dokument_id=FIXED_DOK,
        lieferant_name="Muster GmbH",
        gesamtbetrag=Decimal("100.00"),
    )
    assert _rech06_prueffall(req) is True


def test_rech06_guard_betrag_ohne_lieferant_kein_prueffall():
    """Kein lieferant_name → Guard feuert nicht, auch ohne starkes Signal."""
    req = RechnungCreateRequest(dokument_id=FIXED_DOK, gesamtbetrag=Decimal("100.00"))
    assert _rech06_prueffall(req) is False


def test_rech06_guard_kein_lieferant_kein_prueffall():
    req = RechnungCreateRequest(dokument_id=FIXED_DOK)
    assert _rech06_prueffall(req) is False


def test_hat_starke_partnersignale_rechnungsnummer():
    req = RechnungCreateRequest(dokument_id=FIXED_DOK, rechnungsnummer="2024-001")
    assert _hat_starke_partnersignale(req) is True


def test_hat_starke_partnersignale_gesamtbetrag_kein_starkes_signal():
    """gesamtbetrag ist kein Identifikationssignal."""
    req = RechnungCreateRequest(dokument_id=FIXED_DOK, gesamtbetrag=Decimal("100.00"))
    assert _hat_starke_partnersignale(req) is False


def test_hat_starke_partnersignale_lieferant_allein_kein_starkes_signal():
    req = RechnungCreateRequest(dokument_id=FIXED_DOK, lieferant_name="Muster GmbH")
    assert _hat_starke_partnersignale(req) is False


# ── Schema-Validierung ────────────────────────────────────────────────────────

def test_post_extra_forbid_unternehmen_id_im_body_wird_abgelehnt():
    """SRV-05: extra='forbid' — unternehmen_id im Body → 422."""
    client = _make_client()
    response = client.post(
        "/api/v1/rechnungen",
        json={"dokument_id": str(FIXED_DOK), "unternehmen_id": str(FIXED_TENANT)},
    )
    assert response.status_code == 422


def test_post_extra_forbid_unbekanntes_feld_abgelehnt():
    client = _make_client()
    response = client.post(
        "/api/v1/rechnungen",
        json={"dokument_id": str(FIXED_DOK), "unbekanntes_feld": "wert"},
    )
    assert response.status_code == 422


# ── Response: unternehmen_id darf nicht ausgegeben werden ────────────────────

def test_response_enthaelt_keine_unternehmen_id():
    """unternehmen_id darf nicht in der API-Response erscheinen."""
    client = _make_client()
    with patch.object(RechnungRepository, "create_version", new_callable=AsyncMock) as mock_cv:
        mock_cv.return_value = _rechnung()
        response = client.post(
            "/api/v1/rechnungen",
            json={"dokument_id": str(FIXED_DOK), "rechnungsnummer": "2024-001"},
        )
    assert response.status_code == 201
    data = response.json()
    assert "unternehmen_id" not in data


def test_get_liste_response_enthaelt_keine_unternehmen_id():
    client = _make_client()
    with patch.object(RechnungRepository, "list_aktive", new_callable=AsyncMock) as mock_la:
        mock_la.return_value = [_rechnung()]
        response = client.get("/api/v1/rechnungen")
    assert response.status_code == 200
    assert "unternehmen_id" not in response.json()[0]


def test_erkennungslauf_response_enthaelt_keine_unternehmen_id():
    client = _make_client()
    lauf = _erkennungslauf()
    with patch.object(RechnungRepository, "get_by_id", new_callable=AsyncMock) as mock_gbi:
        mock_gbi.return_value = _rechnung()
        with patch.object(RechnungRepository, "list_erkennungslaeufe", new_callable=AsyncMock) as mock_le:
            mock_le.return_value = [lauf]
            response = client.get(f"/api/v1/rechnungen/{FIXED_RECH_ID}/erkennungslaeufe")
    assert response.status_code == 200
    assert "unternehmen_id" not in response.json()[0]


# ── Response-Serialisierung ───────────────────────────────────────────────────

def test_response_uuid_serialisierung():
    """id und dokument_id müssen als UUID-Strings ausgegeben werden."""
    client = _make_client()
    with patch.object(RechnungRepository, "create_version", new_callable=AsyncMock) as mock_cv:
        mock_cv.return_value = _rechnung()
        response = client.post(
            "/api/v1/rechnungen",
            json={"dokument_id": str(FIXED_DOK)},
        )
    data = response.json()
    assert UUID(data["id"]) == FIXED_RECH_ID
    assert UUID(data["dokument_id"]) == FIXED_DOK


def test_response_decimal_serialisierung():
    """Decimal-Felder werden als String serialisiert (Pydantic v2, Präzision erhalten)."""
    client = _make_client()
    with patch.object(RechnungRepository, "create_version", new_callable=AsyncMock) as mock_cv:
        mock_cv.return_value = _rechnung()
        response = client.post(
            "/api/v1/rechnungen",
            json={"dokument_id": str(FIXED_DOK), "rechnungsnummer": "2024-001"},
        )
    data = response.json()
    assert Decimal(data["gesamtbetrag"]) == Decimal("119.00")
    assert Decimal(data["nettobetrag"]) == Decimal("100.00")
    assert Decimal(data["steuerbetrag"]) == Decimal("19.00")


def test_response_status_serialisierung():
    """status muss als String-Wert des StrEnum ausgegeben werden."""
    client = _make_client()
    with patch.object(RechnungRepository, "create_version", new_callable=AsyncMock) as mock_cv:
        mock_cv.return_value = _rechnung(status="PRUEFFALL")
        response = client.post(
            "/api/v1/rechnungen",
            json={"dokument_id": str(FIXED_DOK), "lieferant_name": "Muster GmbH"},
        )
    assert response.json()["status"] == "PRUEFFALL"


# ── POST /api/v1/rechnungen ───────────────────────────────────────────────────

def test_post_rechnung_erstimport_201():
    client = _make_client()
    with patch.object(RechnungRepository, "create_version", new_callable=AsyncMock) as mock_cv:
        mock_cv.return_value = _rechnung()
        response = client.post(
            "/api/v1/rechnungen",
            json={"dokument_id": str(FIXED_DOK), "rechnungsnummer": "2024-001", "rechnungsdatum": "01.01.2024"},
        )
    assert response.status_code == 201
    data = response.json()
    assert data["rechnungsnummer"] == "2024-001"
    assert data["version_lfd_nr"] == 1
    assert data["ist_aktiv"] is True
    assert data["status"] == "NEU"


def test_post_rechnung_tenant_aus_jwt_second_arg():
    """unternehmen_id kommt aus JWT-Override (zweites Arg an create_version)."""
    client = _make_client()
    with patch.object(RechnungRepository, "create_version", new_callable=AsyncMock) as mock_cv:
        mock_cv.return_value = _rechnung()
        client.post("/api/v1/rechnungen", json={"dokument_id": str(FIXED_DOK)})
    call_args = mock_cv.call_args
    assert call_args.args[1] == FIXED_TENANT


def test_post_rechnung_rech06_guard_lieferant_ohne_nummer_prueffall():
    """RECH-06: nur lieferant_name ohne rechnungsnummer → initial_status=PRUEFFALL."""
    client = _make_client()
    with patch.object(RechnungRepository, "create_version", new_callable=AsyncMock) as mock_cv:
        mock_cv.return_value = _rechnung(rechnungsnummer=None, status="PRUEFFALL")
        client.post(
            "/api/v1/rechnungen",
            json={"dokument_id": str(FIXED_DOK), "lieferant_name": "Muster GmbH"},
        )
    call_args = mock_cv.call_args
    initial_status = call_args.args[4]
    assert str(initial_status) == "PRUEFFALL"


def test_post_rechnung_rech06_gesamtbetrag_kein_starkes_signal_prueffall():
    """gesamtbetrag verhindert RECH-06 NICHT — ohne rechnungsnummer bleibt PRUEFFALL."""
    client = _make_client()
    with patch.object(RechnungRepository, "create_version", new_callable=AsyncMock) as mock_cv:
        mock_cv.return_value = _rechnung(rechnungsnummer=None, status="PRUEFFALL")
        client.post(
            "/api/v1/rechnungen",
            json={
                "dokument_id": str(FIXED_DOK),
                "lieferant_name": "Muster GmbH",
                "gesamtbetrag": "100.00",
            },
        )
    call_args = mock_cv.call_args
    initial_status = call_args.args[4]
    assert str(initial_status) == "PRUEFFALL"


def test_post_rechnung_rechnungsnummer_verhindert_prueffall():
    """rechnungsnummer als starkes Signal → initial_status=NEU."""
    client = _make_client()
    with patch.object(RechnungRepository, "create_version", new_callable=AsyncMock) as mock_cv:
        mock_cv.return_value = _rechnung(status="NEU")
        client.post(
            "/api/v1/rechnungen",
            json={"dokument_id": str(FIXED_DOK), "rechnungsnummer": "2024-001", "lieferant_name": "Muster"},
        )
    call_args = mock_cv.call_args
    initial_status = call_args.args[4]
    assert str(initial_status) == "NEU"


def test_post_rechnung_erkennungslauf_id_wird_uebergeben():
    """erkennungslauf_id aus Body wird als Keyword-Arg an create_version weitergegeben."""
    client = _make_client()
    eid = uuid4()
    with patch.object(RechnungRepository, "create_version", new_callable=AsyncMock) as mock_cv:
        mock_cv.return_value = _rechnung()
        client.post(
            "/api/v1/rechnungen",
            json={"dokument_id": str(FIXED_DOK), "erkennungslauf_id": str(eid)},
        )
    call_kwargs = mock_cv.call_args.kwargs
    assert call_kwargs.get("erkennungslauf_id") == eid


def test_post_rechnung_erkennungslauf_nicht_gefunden_404():
    """Repository wirft 404 für fremden/nicht vorhandenen Erkennungslauf → 404 HTTP."""
    client = _make_client()
    with patch.object(RechnungRepository, "create_version", new_callable=AsyncMock) as mock_cv:
        mock_cv.side_effect = HTTPException(status_code=404, detail="Erkennungslauf nicht gefunden")
        response = client.post(
            "/api/v1/rechnungen",
            json={"dokument_id": str(FIXED_DOK), "erkennungslauf_id": str(uuid4())},
        )
    assert response.status_code == 404


# ── GET /api/v1/rechnungen ───────────────────────────────────────────────────

def test_get_liste_nur_aktive():
    client = _make_client()
    with patch.object(RechnungRepository, "list_aktive", new_callable=AsyncMock) as mock_la:
        mock_la.return_value = [_rechnung(ist_aktiv=True)]
        response = client.get("/api/v1/rechnungen")
    assert response.status_code == 200
    assert response.json()[0]["ist_aktiv"] is True


def test_get_liste_leer_wenn_keine_aktive():
    client = _make_client()
    with patch.object(RechnungRepository, "list_aktive", new_callable=AsyncMock) as mock_la:
        mock_la.return_value = []
        response = client.get("/api/v1/rechnungen")
    assert response.status_code == 200
    assert response.json() == []


# ── GET /api/v1/rechnungen/{id} ──────────────────────────────────────────────

def test_get_detail_eigene_rechnung():
    client = _make_client()
    with patch.object(RechnungRepository, "get_by_id", new_callable=AsyncMock) as mock_gbi:
        mock_gbi.return_value = _rechnung()
        response = client.get(f"/api/v1/rechnungen/{FIXED_RECH_ID}")
    assert response.status_code == 200
    assert UUID(response.json()["id"]) == FIXED_RECH_ID


def test_get_detail_fremde_rechnung_id_404():
    """Fremde rechnung_id → get_by_id → 404 ohne Mandantendaten in Antwort."""
    client = _make_client()
    with patch.object(RechnungRepository, "get_by_id", new_callable=AsyncMock) as mock_gbi:
        mock_gbi.side_effect = HTTPException(status_code=404, detail="Nicht gefunden")
        response = client.get(f"/api/v1/rechnungen/{uuid4()}")
    assert response.status_code == 404
    body = response.text
    assert str(FIXED_TENANT) not in body
    assert "sql" not in body.lower()
    assert "traceback" not in body.lower()


# ── GET /{id}/erkennungslaeufe ────────────────────────────────────────────────

def test_get_erkennungslaeufe_erst_rechnung_dann_laeufe():
    """Router muss Rechnung zuerst laden (tenant-check), dann Läufe."""
    client = _make_client()
    lauf = _erkennungslauf()
    with patch.object(RechnungRepository, "get_by_id", new_callable=AsyncMock) as mock_gbi:
        mock_gbi.return_value = _rechnung()
        with patch.object(RechnungRepository, "list_erkennungslaeufe", new_callable=AsyncMock) as mock_le:
            mock_le.return_value = [lauf]
            response = client.get(f"/api/v1/rechnungen/{FIXED_RECH_ID}/erkennungslaeufe")
    assert response.status_code == 200
    mock_gbi.assert_awaited_once()
    mock_le.assert_awaited_once()


def test_get_erkennungslaeufe_fremde_rechnung_404():
    client = _make_client()
    with patch.object(RechnungRepository, "get_by_id", new_callable=AsyncMock) as mock_gbi:
        mock_gbi.side_effect = HTTPException(status_code=404, detail="Nicht gefunden")
        response = client.get(f"/api/v1/rechnungen/{uuid4()}/erkennungslaeufe")
    assert response.status_code == 404


# ── GET /{id}/kandidaten ──────────────────────────────────────────────────────

def test_get_kandidaten_mandantengefiltert():
    client = _make_client()
    kandidat = RechnungsKandidat(
        unternehmen_id=FIXED_TENANT,
        erkennungslauf_id=uuid4(),
        feld="vendor_name",
        rohwert="Muster GmbH",
        normwert="Muster GmbH",
        methode="regex_label",
        quelle="pdf_text",
        confidence=Decimal("0.85"),
    )
    kandidat.id = uuid4()  # type: ignore[assignment]
    with patch.object(RechnungRepository, "get_by_id", new_callable=AsyncMock) as mock_gbi:
        mock_gbi.return_value = _rechnung()
        with patch.object(RechnungRepository, "list_kandidaten_fuer_rechnung", new_callable=AsyncMock) as mock_lk:
            mock_lk.return_value = [kandidat]
            response = client.get(f"/api/v1/rechnungen/{FIXED_RECH_ID}/kandidaten")
    assert response.status_code == 200
    data = response.json()
    assert len(data) == 1
    assert data[0]["feld"] == "vendor_name"
    assert "unternehmen_id" not in data[0]


def test_get_kandidaten_fremde_rechnung_404():
    client = _make_client()
    with patch.object(RechnungRepository, "get_by_id", new_callable=AsyncMock) as mock_gbi:
        mock_gbi.side_effect = HTTPException(status_code=404, detail="Nicht gefunden")
        response = client.get(f"/api/v1/rechnungen/{uuid4()}/kandidaten")
    assert response.status_code == 404
