"""Unit-Tests fuer auth/service.py -- kein DB-Zugriff."""
from datetime import timedelta

import jwt
import pytest

from apps.server.auth.service import (
    create_access_token,
    decode_access_token,
    hash_password,
    verify_password,
)

_SUB = "00000000-0000-4000-a000-000000000099"
_UID = "00000000-0000-4000-a000-000000000001"


def test_hash_password_returns_argon2_hash():
    h = hash_password("geheimnis")
    assert h.startswith("$argon2")


def test_verify_password_correct():
    h = hash_password("korrekt")
    assert verify_password("korrekt", h) is True


def test_verify_password_incorrect():
    h = hash_password("korrekt")
    assert verify_password("falsch", h) is False


def test_verify_password_none_hashed_returns_false():
    # Kein Exception erwartet -- Dummy-Verify fuer Timing-Schutz
    result = verify_password("beliebig", None)
    assert result is False


def test_create_access_token_returns_string():
    token = create_access_token(sub=_SUB, unternehmen_id=_UID, rolle="LESER")
    assert isinstance(token, str)
    assert len(token) > 20


def test_decode_access_token_contains_claims():
    token = create_access_token(sub=_SUB, unternehmen_id=_UID, rolle="BEARBEITER")
    payload = decode_access_token(token)
    assert payload["sub"] == _SUB
    assert payload["unternehmen_id"] == _UID
    assert payload["rolle"] == "BEARBEITER"
    assert "exp" in payload


def test_token_has_no_db_credentials():
    """SRV-10: JWT enthaelt keine DB-Zugangsdaten."""
    token = create_access_token(sub=_SUB, unternehmen_id=_UID, rolle="LESER")
    payload = decode_access_token(token)
    payload_str = str(payload).lower()
    assert "database_url" not in payload_str
    assert "db_" not in payload_str
    forbidden_keys = {"password", "hashed_password", "secret_key", "database_url"}
    assert not forbidden_keys.intersection(payload.keys())


def test_decode_expired_token_raises():
    token = create_access_token(
        sub=_SUB, unternehmen_id=_UID, rolle="LESER",
        expires_delta=timedelta(seconds=-1),
    )
    with pytest.raises(jwt.ExpiredSignatureError):
        decode_access_token(token)


def test_decode_invalid_token_raises():
    with pytest.raises(jwt.InvalidTokenError):
        decode_access_token("nicht.ein.gueltiger.token")
