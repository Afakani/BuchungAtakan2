"""Unit-Tests fuer Phase-04-Server-Modelle (Rechnung, Erkennungslauf, RechnungsKandidat)."""
import pytest

from apps.server.models.rechnung import Erkennungslauf, Rechnung, RechnungsKandidat, RechnungsStatus


def test_rechnungs_status_enum():
    assert RechnungsStatus.NEU == "NEU"
    assert RechnungsStatus.FREIGEGEBEN == "FREIGEGEBEN"
    assert RechnungsStatus.PRUEFFALL == "PRUEFFALL"
    assert RechnungsStatus.ABGELEHNT == "ABGELEHNT"


def test_rechnung_tablename():
    assert Rechnung.__tablename__ == "rechnungen"


def test_erkennungslauf_tablename():
    assert Erkennungslauf.__tablename__ == "erkennungslaeufe"


def test_rechnungs_kandidat_tablename():
    assert RechnungsKandidat.__tablename__ == "rechnungs_kandidaten"


def test_rechnung_hat_ist_aktiv_spalte():
    col_names = {col.name for col in Rechnung.__table__.columns}
    assert "ist_aktiv" in col_names


def test_rechnung_hat_version_lfd_nr():
    col_names = {col.name for col in Rechnung.__table__.columns}
    assert "version_lfd_nr" in col_names


def test_rechnung_hat_unternehmen_id():
    col_names = {col.name for col in Rechnung.__table__.columns}
    assert "unternehmen_id" in col_names


def test_erkennungslauf_hat_rechnung_id():
    col_names = {col.name for col in Erkennungslauf.__table__.columns}
    assert "rechnung_id" in col_names


def test_rechnungs_kandidat_hat_confidence():
    col_names = {col.name for col in RechnungsKandidat.__table__.columns}
    assert "confidence" in col_names
    assert "rohwert" in col_names
    assert "normwert" in col_names
    assert "feld" in col_names


def test_rechnung_unique_constraint_vorhanden():
    constraint_names = {c.name for c in Rechnung.__table__.constraints}
    assert "uq_rechnung_tenant_nr_version" in constraint_names


def test_models_in_init_importierbar():
    from apps.server.models import Erkennungslauf, Rechnung, RechnungsKandidat, RechnungsStatus
    assert Rechnung is not None


def test_timestamp_konvention_nur_created_at():
    """TimestampMixin liefert nur created_at — kein updated_at (Projektkonvention)."""
    for model in (Rechnung, Erkennungslauf, RechnungsKandidat):
        cols = {col.name for col in model.__table__.columns}
        assert "created_at" in cols, f"{model.__name__} fehlt created_at"
        assert "updated_at" not in cols, f"{model.__name__} hat unexpected updated_at"
