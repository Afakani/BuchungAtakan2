"""Unit-Tests manuelle Zuordnungsentscheidungen (BANK-05/06/07).

Testet Repository-Logik ohne DB (Mock-Session) und MatchingService-Filterlogik.

Abgedeckte Anforderungen:
  U1:  Vorschlag kann bestaetigt werden.
  U2:  Vorschlag kann abgelehnt werden.
  U3:  Wiederholte Bestaetigung desselben Vorschlags ist idempotent.
  U4:  Wiederholte Ablehnung desselben Vorschlags ist idempotent.
  U5:  Zweite Bestaetigung fuer dieselbe Buchung → HTTP 409 (BANK-05).
  U6:  Bestaetigte Zuordnung bleibt bei Rematch unberuehrt (BANK-07).
  U7:  Abgelehnte Paarung beim Rematch nicht erneut vorgeschlagen (BANK-06).
  U8:  Andere Rechnung darf nach Ablehnung weiterhin Kandidat werden.
  U9:  Offene automatische Vorschlaege duerfen weiter aktualisiert werden.
  U10: Benutzer-ID stammt aus Auth-Kontext, nicht aus Request.
  U11: Fremde Tenant-ID → 404 (wird in Repository-Ebene erzwungen).
  U12: Entscheidungsnotiz wird gespeichert.
"""
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID, uuid4

import pytest
from fastapi import HTTPException

from apps.server.repositories.zuordnung import (
    STATUS_MANUELL_ABGELEHNT,
    STATUS_MANUELL_BESTAETIGT,
    STATUS_STARK,
    STATUS_UNSICHER,
    ZuordnungRepository,
)

# Test-UUIDs
_UID = UUID("00000000-0000-4000-a000-000000000001")
_BID = UUID("00000000-0000-4000-b000-000000000001")
_RID = UUID("00000000-0000-4000-c000-000000000001")
_USER_ID = UUID("00000000-0000-4000-d000-000000000001")
_VORSCHLAG_ID = UUID("00000000-0000-4000-e000-000000000001")


def _make_vorschlag(status: str = STATUS_STARK, vid: UUID | None = None):
    """Synthetischer ZuordnungsVorschlag als MagicMock — kein DB-Zugriff."""
    v = MagicMock()
    v.id = vid or _VORSCHLAG_ID
    v.unternehmen_id = _UID
    v.bankbuchung_id = _BID
    v.rechnung_id = _RID
    v.score = 100
    v.status = status
    v.positive_signale = []
    v.negative_signale = []
    v.matcher_version = "1.0"
    v.entschieden_at = None
    v.entschieden_von_benutzer_id = None
    v.entscheidungsnotiz = None
    v.created_at = datetime.now(tz=timezone.utc)
    v.updated_at = datetime.now(tz=timezone.utc)
    return v


def _mock_session(vorschlag):
    """Mock-Session die get_by_id per Monkey-Patch unterstuetzt."""
    session = AsyncMock()
    session.flush = AsyncMock()
    session.rollback = AsyncMock()
    return session


class TestBestaetigen:
    @pytest.mark.asyncio
    async def test_vorschlag_kann_bestaetigt_werden(self):
        """U1: STARK-Vorschlag → MANUELL_BESTAETIGT."""
        repo = ZuordnungRepository()
        v = _make_vorschlag(STATUS_STARK)
        session = _mock_session(v)

        with patch.object(repo, "get_by_id", AsyncMock(return_value=v)):
            result = await repo.bestaetigen(session, _VORSCHLAG_ID, _UID, _USER_ID, "Bestaetigt")

        assert result.status == STATUS_MANUELL_BESTAETIGT
        assert result.entschieden_von_benutzer_id == _USER_ID
        assert result.entscheidungsnotiz == "Bestaetigt"
        session.flush.assert_called_once()

    @pytest.mark.asyncio
    async def test_vorschlag_kann_abgelehnt_werden(self):
        """U2: STARK-Vorschlag → MANUELL_ABGELEHNT."""
        repo = ZuordnungRepository()
        v = _make_vorschlag(STATUS_STARK)
        session = _mock_session(v)

        with patch.object(repo, "get_by_id", AsyncMock(return_value=v)):
            result = await repo.ablehnen(session, _VORSCHLAG_ID, _UID, _USER_ID, None)

        assert result.status == STATUS_MANUELL_ABGELEHNT
        assert result.entschieden_von_benutzer_id == _USER_ID
        assert result.entscheidungsnotiz is None
        session.flush.assert_called_once()

    @pytest.mark.asyncio
    async def test_bestaetigung_idempotent(self):
        """U3: Bereits bestaetigter Vorschlag → unveraendert, kein zweites flush."""
        repo = ZuordnungRepository()
        v = _make_vorschlag(STATUS_MANUELL_BESTAETIGT)
        session = _mock_session(v)

        with patch.object(repo, "get_by_id", AsyncMock(return_value=v)):
            result = await repo.bestaetigen(session, _VORSCHLAG_ID, _UID, _USER_ID, "Nochmal")

        assert result.status == STATUS_MANUELL_BESTAETIGT
        session.flush.assert_not_called()

    @pytest.mark.asyncio
    async def test_ablehnung_idempotent(self):
        """U4: Bereits abgelehnter Vorschlag → unveraendert, kein zweites flush."""
        repo = ZuordnungRepository()
        v = _make_vorschlag(STATUS_MANUELL_ABGELEHNT)
        session = _mock_session(v)

        with patch.object(repo, "get_by_id", AsyncMock(return_value=v)):
            result = await repo.ablehnen(session, _VORSCHLAG_ID, _UID, _USER_ID, None)

        assert result.status == STATUS_MANUELL_ABGELEHNT
        session.flush.assert_not_called()

    @pytest.mark.asyncio
    async def test_abgelehnter_kann_nicht_bestaetigt_werden(self):
        """MANUELL_ABGELEHNT → Bestaetigung liefert HTTP 409."""
        repo = ZuordnungRepository()
        v = _make_vorschlag(STATUS_MANUELL_ABGELEHNT)
        session = _mock_session(v)

        with patch.object(repo, "get_by_id", AsyncMock(return_value=v)):
            with pytest.raises(HTTPException) as exc_info:
                await repo.bestaetigen(session, _VORSCHLAG_ID, _UID, _USER_ID, None)

        assert exc_info.value.status_code == 409

    @pytest.mark.asyncio
    async def test_entscheidungsnotiz_wird_gespeichert(self):
        """U12: Notiz wird in entscheidungsnotiz gespeichert."""
        repo = ZuordnungRepository()
        v = _make_vorschlag(STATUS_UNSICHER)
        session = _mock_session(v)

        with patch.object(repo, "get_by_id", AsyncMock(return_value=v)):
            result = await repo.ablehnen(session, _VORSCHLAG_ID, _UID, _USER_ID, "Falscher Betrag")

        assert result.entscheidungsnotiz == "Falscher Betrag"

    @pytest.mark.asyncio
    async def test_benutzer_id_aus_parameter(self):
        """U10: Benutzer-ID aus Auth-Kontext (Parameter), nicht aus Vorschlag-Daten."""
        repo = ZuordnungRepository()
        v = _make_vorschlag(STATUS_STARK)
        anderer_user = uuid4()
        session = _mock_session(v)

        with patch.object(repo, "get_by_id", AsyncMock(return_value=v)):
            result = await repo.bestaetigen(session, _VORSCHLAG_ID, _UID, anderer_user, None)

        assert result.entschieden_von_benutzer_id == anderer_user

    @pytest.mark.asyncio
    async def test_fremde_id_404(self):
        """U11: Fremde Vorschlags-ID → 404."""
        repo = ZuordnungRepository()
        session = _mock_session(None)

        fremde_id = uuid4()
        with patch.object(
            repo, "get_by_id",
            AsyncMock(side_effect=HTTPException(status_code=404, detail="nicht gefunden"))
        ):
            with pytest.raises(HTTPException) as exc_info:
                await repo.bestaetigen(session, fremde_id, _UID, _USER_ID, None)

        assert exc_info.value.status_code == 404

    @pytest.mark.asyncio
    async def test_entschieden_at_gesetzt(self):
        """entschieden_at wird bei Bestaetigung gesetzt."""
        repo = ZuordnungRepository()
        v = _make_vorschlag(STATUS_STARK)
        session = _mock_session(v)

        vorher = datetime.now(tz=timezone.utc)
        with patch.object(repo, "get_by_id", AsyncMock(return_value=v)):
            result = await repo.bestaetigen(session, _VORSCHLAG_ID, _UID, _USER_ID, None)

        assert result.entschieden_at is not None
        assert result.entschieden_at >= vorher


class TestRematchSchutz:
    """U6/U7/U8/U9 — Filterlogik des MatchingService."""

    @pytest.mark.asyncio
    async def test_bestaetigte_buchung_aus_rematch_ausgeschlossen(self):
        """U6: Buchung mit MANUELL_BESTAETIGT wird nicht erneut bewertet."""
        from apps.server.services.matching_service import MatchingService

        service = MatchingService()
        session = AsyncMock()
        uid = uuid4()
        bid = uuid4()

        buchung = MagicMock()
        buchung.id = bid
        buchung.klassifikation = "MATCHBAR"

        with (
            patch.object(service._zuordnung_repo, "get_bestaetigte_buchung_ids", AsyncMock(return_value={bid})),
            patch.object(service._zuordnung_repo, "get_abgelehnte_paare", AsyncMock(return_value=set())),
            patch.object(service, "_get_matchbare_buchungen", AsyncMock(return_value=[])),
            patch.object(service, "_get_aktive_rechnungen", AsyncMock(return_value=[])),
            patch.object(service._zuordnung_repo, "upsert_vorschlaege", AsyncMock(return_value=(0, 0))),
        ):
            ergebnis = await service.rematch(session, uid)

        assert ergebnis["buchungen_geprueft"] == 0

    @pytest.mark.asyncio
    async def test_abgelehnte_paarung_uebersprungen(self):
        """U7: (buchung_id, rechnung_id) in abgelehnte_paare → Score wird nicht berechnet."""
        from packages.core.matching.scorer import berechne_match
        from apps.server.services.matching_service import MatchingService
        from datetime import date
        from decimal import Decimal

        service = MatchingService()
        session = AsyncMock()
        uid = uuid4()
        bid = uuid4()
        rid = uuid4()

        buchung = MagicMock()
        buchung.id = bid
        buchung.betrag_cent = -11900
        buchung.buchungsdatum = date(2024, 1, 1)
        buchung.verwendungszweck = "Test"
        buchung.gegenpartei_name = None

        rechnung = MagicMock()
        rechnung.id = rid
        rechnung.gesamtbetrag = Decimal("119.00")
        rechnung.rechnungsdatum = "01.01.2024"
        rechnung.rechnungsnummer = "RE-001"
        rechnung.lieferant_name = None

        abgelehnte = {(bid, rid)}

        with (
            patch.object(service._zuordnung_repo, "get_bestaetigte_buchung_ids", AsyncMock(return_value=set())),
            patch.object(service._zuordnung_repo, "get_abgelehnte_paare", AsyncMock(return_value=abgelehnte)),
            patch.object(service, "_get_matchbare_buchungen", AsyncMock(return_value=[buchung])),
            patch.object(service, "_get_aktive_rechnungen", AsyncMock(return_value=[rechnung])),
            patch.object(service._zuordnung_repo, "upsert_vorschlaege", AsyncMock(return_value=(0, 0))) as mock_upsert,
        ):
            await service.rematch(session, uid)

        # upsert_vorschlaege wird mit leerer Liste aufgerufen → Paar ausgeschlossen
        call_args = mock_upsert.call_args
        ergebnisse_arg = call_args[0][2]  # positional: session, uid, ergebnisse
        assert all(e.rechnung_id != rid or e.bankbuchung_id != bid for e in ergebnisse_arg)

    @pytest.mark.asyncio
    async def test_andere_rechnung_nach_ablehnung_erlaubt(self):
        """U8: Abgelehnte Paarung (bid, rid1) blockiert nicht (bid, rid2)."""
        from apps.server.services.matching_service import MatchingService
        from datetime import date
        from decimal import Decimal

        service = MatchingService()
        session = AsyncMock()
        uid = uuid4()
        bid = uuid4()
        rid1 = uuid4()
        rid2 = uuid4()

        buchung = MagicMock()
        buchung.id = bid
        buchung.betrag_cent = -11900
        buchung.buchungsdatum = date(2024, 1, 1)
        buchung.verwendungszweck = "RE-001 Test Lieferant"
        buchung.gegenpartei_name = "Lieferant GmbH"

        rechnung2 = MagicMock()
        rechnung2.id = rid2
        rechnung2.gesamtbetrag = Decimal("119.00")
        rechnung2.rechnungsdatum = "01.01.2024"
        rechnung2.rechnungsnummer = "RE-001"
        rechnung2.lieferant_name = "Lieferant GmbH"

        abgelehnte = {(bid, rid1)}

        with (
            patch.object(service._zuordnung_repo, "get_bestaetigte_buchung_ids", AsyncMock(return_value=set())),
            patch.object(service._zuordnung_repo, "get_abgelehnte_paare", AsyncMock(return_value=abgelehnte)),
            patch.object(service, "_get_matchbare_buchungen", AsyncMock(return_value=[buchung])),
            patch.object(service, "_get_aktive_rechnungen", AsyncMock(return_value=[rechnung2])),
            patch.object(service._zuordnung_repo, "upsert_vorschlaege", AsyncMock(return_value=(1, 0))) as mock_upsert,
        ):
            ergebnis = await service.rematch(session, uid)

        call_args = mock_upsert.call_args
        ergebnisse_arg = call_args[0][2]
        # rid2 darf als Kandidat erscheinen
        assert any(e.rechnung_id == rid2 for e in ergebnisse_arg)

    @pytest.mark.asyncio
    async def test_offene_vorschlaege_koennen_aktualisiert_werden(self):
        """U9: STARK-/UNSICHER-Vorschlaege werden beim Rematch neu bewertet."""
        from apps.server.services.matching_service import MatchingService
        from datetime import date
        from decimal import Decimal

        service = MatchingService()
        session = AsyncMock()
        uid = uuid4()
        bid = uuid4()
        rid = uuid4()

        buchung = MagicMock()
        buchung.id = bid
        buchung.betrag_cent = -11900
        buchung.buchungsdatum = date(2024, 2, 15)
        buchung.verwendungszweck = "RE-2024-001 Lieferant"
        buchung.gegenpartei_name = "Lieferant GmbH"

        rechnung = MagicMock()
        rechnung.id = rid
        rechnung.gesamtbetrag = Decimal("119.00")
        rechnung.rechnungsdatum = "01.02.2024"
        rechnung.rechnungsnummer = "RE-2024-001"
        rechnung.lieferant_name = "Lieferant GmbH"

        with (
            patch.object(service._zuordnung_repo, "get_bestaetigte_buchung_ids", AsyncMock(return_value=set())),
            patch.object(service._zuordnung_repo, "get_abgelehnte_paare", AsyncMock(return_value=set())),
            patch.object(service, "_get_matchbare_buchungen", AsyncMock(return_value=[buchung])),
            patch.object(service, "_get_aktive_rechnungen", AsyncMock(return_value=[rechnung])),
            patch.object(service._zuordnung_repo, "upsert_vorschlaege", AsyncMock(return_value=(1, 0))) as mock_upsert,
        ):
            await service.rematch(session, uid)

        call_args = mock_upsert.call_args
        ergebnisse_arg = call_args[0][2]
        assert len(ergebnisse_arg) >= 1
        assert ergebnisse_arg[0].bankbuchung_id == bid
