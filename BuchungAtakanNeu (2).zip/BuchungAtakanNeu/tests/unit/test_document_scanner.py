from pathlib import Path

import pytest

from apps.client.document_scanner import SUPPORTED_EXTENSIONS, scan_for_documents, to_relative_posix


def test_scan_empty_dir(tmp_path):
    (tmp_path / "dump").mkdir()
    result = scan_for_documents(tmp_path)
    assert result == []


def test_scan_nonexistent_dir(tmp_path):
    result = scan_for_documents(tmp_path)
    assert result == []


def test_scan_finds_pdf(tmp_path):
    dump = tmp_path / "dump"
    dump.mkdir()
    pdf = dump / "rechnung.pdf"
    pdf.write_bytes(b"%PDF content")
    result = scan_for_documents(tmp_path)
    assert pdf in result


def test_scan_filters_unsupported(tmp_path):
    dump = tmp_path / "dump"
    dump.mkdir()
    (dump / "dokument.docx").write_bytes(b"Word-Datei")
    (dump / "skript.py").write_bytes(b"python")
    result = scan_for_documents(tmp_path)
    assert result == []


def test_scan_recursive(tmp_path):
    dump = tmp_path / "dump"
    subdir = dump / "2026" / "januar"
    subdir.mkdir(parents=True)
    pdf = subdir / "eingangsrechnung.pdf"
    pdf.write_bytes(b"%PDF")
    result = scan_for_documents(tmp_path)
    assert pdf in result


def test_scan_case_insensitive_extension(tmp_path):
    dump = tmp_path / "dump"
    dump.mkdir()
    f = dump / "BILD.PDF"
    f.write_bytes(b"%PDF")
    result = scan_for_documents(tmp_path)
    assert f in result


def test_scan_all_supported_extensions(tmp_path):
    dump = tmp_path / "dump"
    dump.mkdir()
    for ext in SUPPORTED_EXTENSIONS:
        (dump / f"datei{ext}").write_bytes(b"inhalt")
    result = scan_for_documents(tmp_path)
    assert len(result) == len(SUPPORTED_EXTENSIONS)


def test_to_relative_posix(tmp_path):
    path = tmp_path / "dump" / "2026" / "rechnung.pdf"
    path.parent.mkdir(parents=True)
    path.write_bytes(b"")
    rel = to_relative_posix(path, tmp_path)
    assert "/" in rel
    assert "\\" not in rel
    assert rel == "dump/2026/rechnung.pdf"


def test_scan_sorted_order(tmp_path):
    dump = tmp_path / "dump"
    dump.mkdir()
    for name in ["z.pdf", "a.pdf", "m.pdf"]:
        (dump / name).write_bytes(b"%PDF")
    result = scan_for_documents(tmp_path)
    names = [p.name for p in result]
    assert names == sorted(names)
