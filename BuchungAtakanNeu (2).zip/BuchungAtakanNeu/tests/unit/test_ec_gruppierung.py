"""Unit-Tests deterministischer EC-Gruppierungsalgorithmus (Phase 06, Paket 1).

Anforderungen:
  T3:  Float-Betraege abgelehnt (betrag_cent muss int sein)
  T4:  Betrag 0 abgelehnt
  T5:  Stabile chronologische Sortierung
  T6:  Exakte Summe ohne Entfernung → STARK
  T7:  Ueberdeckung entfernt neuesten Beleg zuerst
  T8:  Mehrere neueste Belege bei Bedarf nacheinander entfernt
  T9:  Entfernte Belege bleiben fuer Folgegruppe verfuegbar (unveraendert zurueckgegeben)
  T10: Exakte Summe nach Entfernung bleibt UNSICHER
  T11: Unterdeckung niemals STARK
  T12: Verzug ueber max_verzoegerung_tage niemals STARK
  T13: Offene Periode loescht oder sperrt keine Belege
"""
import uuid
from datetime import date
from uuid import UUID

import pytest

from packages.core.ec_sammlung.gruppierung import gruppiere_belege
from packages.core.ec_sammlung.typen import EcBeleg, EcBelegStatus, EcSammelStatus


def _beleg(betrag_cent: int, buchungsdatum: date, uid: str | None = None) -> EcBeleg:
    return EcBeleg(
        id=UUID(uid) if uid else uuid.uuid4(),
        betrag_cent=betrag_cent,
        buchungsdatum=buchungsdatum,
    )


_TAG_0 = date(2024, 3, 10)  # Einzahlungsdatum
_TAG_1 = date(2024, 3, 9)   # 1 Tag vorher
_TAG_2 = date(2024, 3, 8)   # 2 Tage vorher
_TAG_3 = date(2024, 3, 7)   # 3 Tage vorher (Verzug bei max=2)


class TestEcBelegValidierung:
    """T3/T4: Ungueltige Betraege werden abgelehnt."""

    def test_float_betrag_wird_abgelehnt(self):
        with pytest.raises(TypeError, match="betrag_cent muss int sein"):
            EcBeleg(id=uuid.uuid4(), betrag_cent=100.0, buchungsdatum=_TAG_1)  # type: ignore

    def test_betrag_null_wird_abgelehnt(self):
        with pytest.raises(ValueError, match="betrag_cent muss > 0 sein"):
            EcBeleg(id=uuid.uuid4(), betrag_cent=0, buchungsdatum=_TAG_1)

    def test_negativer_betrag_wird_abgelehnt(self):
        with pytest.raises(ValueError, match="betrag_cent muss > 0 sein"):
            EcBeleg(id=uuid.uuid4(), betrag_cent=-100, buchungsdatum=_TAG_1)

    def test_ganzzahl_betrag_valide(self):
        b = EcBeleg(id=uuid.uuid4(), betrag_cent=500, buchungsdatum=_TAG_1)
        assert b.betrag_cent == 500


class TestChronologischeSortierung:
    """T5: Stabile chronologische Sortierung (aelteste zuerst)."""

    def test_aelteste_belege_zuerst_nach_gruppierung(self):
        b_alt = _beleg(100, _TAG_2)
        b_neu = _beleg(100, _TAG_1)
        ergebnis = gruppiere_belege(300, [b_neu, b_alt], _TAG_0)
        assert ergebnis.aktive_belege[0] == b_alt
        assert ergebnis.aktive_belege[1] == b_neu

    def test_gleicher_tag_stabile_sortierung_via_uuid(self):
        uid_a = "00000000-0000-4000-a000-000000000001"
        uid_b = "00000000-0000-4000-b000-000000000002"
        b1 = _beleg(100, _TAG_1, uid_a)
        b2 = _beleg(100, _TAG_1, uid_b)
        ergebnis1 = gruppiere_belege(300, [b1, b2], _TAG_0)
        ergebnis2 = gruppiere_belege(300, [b2, b1], _TAG_0)
        assert ergebnis1.aktive_belege == ergebnis2.aktive_belege


class TestExakteSumme:
    """T6: Exakte Summe ohne Entfernung → STARK."""

    def test_exakte_summe_ein_beleg_ist_stark(self):
        b = _beleg(1000, _TAG_1)
        ergebnis = gruppiere_belege(1000, [b], _TAG_0)
        assert ergebnis.differenz_cent == 0
        assert len(ergebnis.entfernte_belege) == 0
        assert ergebnis.status == EcSammelStatus.STARK

    def test_exakte_summe_mehrere_belege_ist_stark(self):
        b1 = _beleg(400, _TAG_2)
        b2 = _beleg(600, _TAG_1)
        ergebnis = gruppiere_belege(1000, [b1, b2], _TAG_0)
        assert ergebnis.differenz_cent == 0
        assert ergebnis.status == EcSammelStatus.STARK

    def test_exakte_summe_score_mindestens_90(self):
        b = _beleg(500, _TAG_1)
        ergebnis = gruppiere_belege(500, [b], _TAG_0)
        assert ergebnis.score >= 90

    def test_stark_enthaelt_summe_exakt_signal(self):
        b = _beleg(500, _TAG_1)
        ergebnis = gruppiere_belege(500, [b], _TAG_0)
        typen = {s.typ for s in ergebnis.positive_signale}
        assert "SUMME_EXAKT" in typen


class TestUeberdeckung:
    """T7/T8: Ueberdeckung entfernt neueste Belege zuerst."""

    def test_neuester_beleg_wird_bei_ueberdeckung_entfernt(self):
        b_alt = _beleg(500, _TAG_2)
        b_neu = _beleg(600, _TAG_1)  # neuester; Summe 1100 > 1000
        ergebnis = gruppiere_belege(1000, [b_alt, b_neu], _TAG_0)
        assert b_neu in ergebnis.entfernte_belege
        assert b_alt in ergebnis.aktive_belege

    def test_mehrere_neueste_werden_nacheinander_entfernt(self):
        b1 = _beleg(400, _TAG_2)   # aeltester, bleibt
        b2 = _beleg(400, _TAG_1)   # nach b1, wird entfernt
        b3 = _beleg(400, _TAG_0)   # neuester, wird zuerst entfernt
        # Summe 1200, Einzahlung 500; beide neuesten muessen entfernt werden
        ergebnis = gruppiere_belege(500, [b1, b2, b3], _TAG_0)
        assert b1 in ergebnis.aktive_belege
        assert b2 in ergebnis.entfernte_belege
        assert b3 in ergebnis.entfernte_belege
        assert ergebnis.summe_cent == 400
        assert ergebnis.differenz_cent == 100

    def test_entfernung_stoppt_bei_unterdeckung(self):
        b1 = _beleg(300, _TAG_2)
        b2 = _beleg(300, _TAG_1)
        # Summe 600, Einzahlung 400 → b2 wird entfernt, b1 bleibt (300 <= 400)
        ergebnis = gruppiere_belege(400, [b1, b2], _TAG_0)
        assert len(ergebnis.aktive_belege) == 1
        assert ergebnis.aktive_belege[0] == b1
        assert len(ergebnis.entfernte_belege) == 1
        assert ergebnis.entfernte_belege[0] == b2


class TestEntfernteBelegeVerfuegbar:
    """T9: Entfernte Belege bleiben unveraendert zurueckgegeben."""

    def test_entfernte_belege_werden_unveraendert_zurueckgegeben(self):
        b_alt = _beleg(500, _TAG_2)
        b_neu = _beleg(700, _TAG_1)
        ergebnis = gruppiere_belege(600, [b_alt, b_neu], _TAG_0)
        # b_neu wird entfernt (Summe 1200 > 600)
        assert b_neu in ergebnis.entfernte_belege
        # Entfernter Beleg ist dasselbe Objekt, unveraendert
        assert ergebnis.entfernte_belege[0] is b_neu

    def test_entfernte_belege_nicht_final_gesperrt(self):
        b_alt = _beleg(300, _TAG_2)
        b_neu = _beleg(800, _TAG_1)
        ergebnis = gruppiere_belege(400, [b_alt, b_neu], _TAG_0)
        # Entfernter Beleg hat keinen geaenderten Status im EcBeleg-Objekt
        # (Status wird von der Service-Schicht gesteuert, nicht vom Algo)
        assert b_neu in ergebnis.entfernte_belege
        # EcBeleg ist immutabel (frozen dataclass) — kein status-Feld im Core-Typ
        assert hasattr(b_neu, "betrag_cent")  # Objekt unver


class TestExaktNachEntfernung:
    """T10: Exakte Summe nach Entfernung ist UNSICHER, nicht STARK."""

    def test_exakte_summe_mit_entfernten_belegen_ist_unsicher(self):
        b1 = _beleg(500, _TAG_2)
        b2 = _beleg(300, _TAG_1)   # neuester, wird entfernt → b1-Summe = 500 exakt
        ergebnis = gruppiere_belege(500, [b1, b2], _TAG_0)
        assert ergebnis.differenz_cent == 0
        assert len(ergebnis.entfernte_belege) == 1
        assert ergebnis.status == EcSammelStatus.UNSICHER

    def test_exakte_summe_mit_entfernung_score_unter_90(self):
        b1 = _beleg(1000, _TAG_2)
        b2 = _beleg(500, _TAG_1)
        ergebnis = gruppiere_belege(1000, [b1, b2], _TAG_0)
        assert ergebnis.differenz_cent == 0
        assert len(ergebnis.entfernte_belege) == 1
        assert ergebnis.score < 90


class TestUnterdeckung:
    """T11: Unterdeckung ist niemals STARK."""

    def test_unterdeckung_ist_niemals_stark(self):
        b = _beleg(900, _TAG_1)
        ergebnis = gruppiere_belege(1000, [b], _TAG_0)
        assert ergebnis.differenz_cent > 0
        assert ergebnis.status != EcSammelStatus.STARK

    def test_geringe_unterdeckung_1_cent_ist_unsicher(self):
        b = _beleg(999, _TAG_1)
        ergebnis = gruppiere_belege(1000, [b], _TAG_0)
        assert ergebnis.differenz_cent == 1
        assert ergebnis.status == EcSammelStatus.UNSICHER


class TestVerzug:
    """T12: Verzug ueber max_verzoegerung_tage verhindert STARK."""

    def test_beleg_an_verzug_grenze_erlaubt_stark(self):
        b = _beleg(500, _TAG_2)  # 2 Tage Verzug bei max=2 → OK
        ergebnis = gruppiere_belege(500, [b], _TAG_0, max_verzoegerung_tage=2)
        assert ergebnis.status == EcSammelStatus.STARK

    def test_beleg_ueber_verzug_grenze_verhindert_stark(self):
        b = _beleg(500, _TAG_3)  # 3 Tage Verzug bei max=2 → NICHT STARK
        ergebnis = gruppiere_belege(500, [b], _TAG_0, max_verzoegerung_tage=2)
        assert ergebnis.status != EcSammelStatus.STARK

    def test_ein_beleg_mit_verzug_macht_gruppe_unsicher(self):
        b_ok = _beleg(300, _TAG_1)    # 1 Tag Verzug OK
        b_versp = _beleg(200, _TAG_3)  # 3 Tage Verzug → Gruppe UNSICHER
        ergebnis = gruppiere_belege(500, [b_ok, b_versp], _TAG_0, max_verzoegerung_tage=2)
        assert ergebnis.status != EcSammelStatus.STARK


class TestOffenePeriode:
    """T13: Offene Periode loescht und sperrt keine Belege."""

    def test_offene_periode_entfernt_keine_belege(self):
        b1 = _beleg(600, _TAG_2)
        b2 = _beleg(700, _TAG_1)  # Summe 1300 > Einzahlung 1000
        ergebnis = gruppiere_belege(1000, [b1, b2], _TAG_0, offene_periode=True)
        assert len(ergebnis.entfernte_belege) == 0
        assert len(ergebnis.aktive_belege) == 2

    def test_offene_periode_status_ist_offene_periode(self):
        b = _beleg(500, _TAG_1)
        ergebnis = gruppiere_belege(1000, [b], _TAG_0, offene_periode=True)
        assert ergebnis.status == EcSammelStatus.OFFENE_PERIODE

    def test_offene_periode_ist_nicht_stark(self):
        b = _beleg(1000, _TAG_1)  # exakte Summe, aber offene Periode
        ergebnis = gruppiere_belege(1000, [b], _TAG_0, offene_periode=True)
        assert ergebnis.status != EcSammelStatus.STARK

    def test_offene_periode_belege_unveraendert(self):
        belege = [_beleg(300, _TAG_2), _beleg(400, _TAG_1)]
        ergebnis = gruppiere_belege(500, belege, _TAG_0, offene_periode=True)
        assert set(ergebnis.aktive_belege) == set(belege)

    def test_offene_periode_hat_offene_periode_signal(self):
        b = _beleg(100, _TAG_1)
        ergebnis = gruppiere_belege(200, [b], _TAG_0, offene_periode=True)
        neg_typen = {s.typ for s in ergebnis.negative_signale}
        assert "OFFENE_PERIODE" in neg_typen
