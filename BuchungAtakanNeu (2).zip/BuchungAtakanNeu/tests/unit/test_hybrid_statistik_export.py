"""Unit-Tests fuer Excel-Export der Hybrid-Qualitaetsstatistik (07-03B, HYB-19).

Reine Domainlogik -- kein Datenbankzugriff. Dateisystemzugriff wird explizit geprueft.
"""
import os

from io import BytesIO

from openpyxl import load_workbook

from packages.core.invoice_extraction.hybrid_statistik import (
    ALLE_DIMENSIONEN,
    Quote,
    StatistikGruppe,
)
from packages.core.invoice_extraction.hybrid_statistik_export import (
    erstelle_hybrid_statistik_workbook_bytes,
)


def _quote(zaehler: int, nenner: int, quote: float | None) -> Quote:
    return Quote(zaehler=zaehler, nenner=nenner, quote=quote)


def _gruppe(
    dimensionen=("anbieter", "status"),
    dimensionswerte=("Muster GmbH", "OK"),
    anzahl=3,
    vollstaendigkeitsquote=None,
    richtigkeitsquote=None,
    automatisierungsquote=None,
    pruefquote=None,
    nichterkennungsquote=None,
) -> StatistikGruppe:
    return StatistikGruppe(
        dimensionen=dimensionen,
        dimensionswerte=dimensionswerte,
        anzahl=anzahl,
        vollstaendigkeitsquote=vollstaendigkeitsquote or _quote(3, 3, 1.0),
        richtigkeitsquote=richtigkeitsquote or _quote(0, 0, None),
        automatisierungsquote=automatisierungsquote or _quote(3, 3, 1.0),
        pruefquote=pruefquote or _quote(0, 3, 0.0),
        nichterkennungsquote=nichterkennungsquote or _quote(0, 3, 0.0),
    )


def _load(data: bytes):
    return load_workbook(BytesIO(data))


class TestSheetStruktur:
    def test_exakt_drei_sheets(self):
        wb = _load(erstelle_hybrid_statistik_workbook_bytes([_gruppe()], ("anbieter", "status")))
        assert wb.sheetnames == ["Uebersicht", "Statistik", "Metriken"]

    def test_leere_statistik_hat_trotzdem_drei_sheets(self):
        wb = _load(erstelle_hybrid_statistik_workbook_bytes([], ALLE_DIMENSIONEN))
        assert wb.sheetnames == ["Uebersicht", "Statistik", "Metriken"]


class TestStatistikSpalten:
    def test_spaltenreihenfolge_exakt(self):
        wb = _load(erstelle_hybrid_statistik_workbook_bytes([_gruppe()], ("anbieter", "status")))
        header = next(wb["Statistik"].iter_rows(values_only=True))
        assert header == (
            "Anbieter", "Status", "Anzahl",
            "Vollstaendigkeitsquote Zaehler", "Vollstaendigkeitsquote Nenner", "Vollstaendigkeitsquote Quote",
            "Richtigkeitsquote Zaehler", "Richtigkeitsquote Nenner", "Richtigkeitsquote Quote",
            "Automatisierungsquote Zaehler", "Automatisierungsquote Nenner", "Automatisierungsquote Quote",
            "Pruefquote Zaehler", "Pruefquote Nenner", "Pruefquote Quote",
            "Nichterkennungsquote Zaehler", "Nichterkennungsquote Nenner", "Nichterkennungsquote Quote",
        )

    def test_dimensionsspalten_folgen_angeforderter_reihenfolge(self):
        wb = _load(erstelle_hybrid_statistik_workbook_bytes(
            [_gruppe(dimensionen=("status", "dokument_klasse"), dimensionswerte=("OK", "TEXT_PDF"))],
            ("status", "dokument_klasse"),
        ))
        header = next(wb["Statistik"].iter_rows(values_only=True))
        assert header[:2] == ("Status", "Dokumenttyp")

    def test_korrekte_zaehler_nenner_quoten(self):
        gruppe = _gruppe(
            vollstaendigkeitsquote=_quote(2, 3, 2 / 3),
            richtigkeitsquote=_quote(1, 2, 0.5),
        )
        wb = _load(erstelle_hybrid_statistik_workbook_bytes([gruppe], ("anbieter", "status")))
        row = list(wb["Statistik"].iter_rows(values_only=True))[1]
        # Anbieter, Status, Anzahl, Vollst.Z, Vollst.N, Vollst.Q, Richt.Z, Richt.N, Richt.Q, ...
        assert row[2] == 3  # Anzahl
        assert row[3:6] == (2, 3, 2 / 3)
        assert row[6:9] == (1, 2, 0.5)

    def test_none_quote_ergibt_leere_zelle(self):
        gruppe = _gruppe(richtigkeitsquote=_quote(0, 0, None))
        wb = _load(erstelle_hybrid_statistik_workbook_bytes([gruppe], ("anbieter", "status")))
        row = list(wb["Statistik"].iter_rows(values_only=True))[1]
        assert row[8] is None  # Richtigkeitsquote Quote
        assert row[6] == 0 and row[7] == 0  # Zaehler/Nenner bleiben sichtbar

    def test_prozentformat_auf_quote_spalten(self):
        wb = _load(erstelle_hybrid_statistik_workbook_bytes([_gruppe()], ("anbieter", "status")))
        ws = wb["Statistik"]
        # Quote-Spalten: F(6), I(9), L(12), O(15), R(18) bei 2 Dimensionsspalten
        for spalte in (6, 9, 12, 15, 18):
            zelle = ws.cell(row=2, column=spalte)
            assert zelle.number_format == "0.00%", f"Spalte {spalte} hat falsches Format"

    def test_zaehler_nenner_spalten_kein_prozentformat(self):
        wb = _load(erstelle_hybrid_statistik_workbook_bytes([_gruppe()], ("anbieter", "status")))
        ws = wb["Statistik"]
        for spalte in (4, 5, 7, 8):  # Zaehler/Nenner-Spalten
            zelle = ws.cell(row=2, column=spalte)
            assert zelle.number_format != "0.00%"

    def test_leere_statistik_hat_nur_header(self):
        wb = _load(erstelle_hybrid_statistik_workbook_bytes([], ("anbieter",)))
        rows = list(wb["Statistik"].iter_rows(values_only=True))
        assert len(rows) == 1  # nur Header, keine Datenzeile


class TestUebersichtSheet:
    def test_status_ok_bei_gruppen(self):
        wb = _load(erstelle_hybrid_statistik_workbook_bytes([_gruppe()], ("anbieter",)))
        rows = list(wb["Uebersicht"].iter_rows(values_only=True))
        status_zeile = next(r for r in rows if r[0] == "Status")
        assert status_zeile[1] == "OK"

    def test_status_leer_ohne_gruppen(self):
        wb = _load(erstelle_hybrid_statistik_workbook_bytes([], ("anbieter",)))
        rows = list(wb["Uebersicht"].iter_rows(values_only=True))
        status_zeile = next(r for r in rows if r[0] == "Status")
        assert status_zeile[1] == "LEER"

    def test_anzahl_gruppen_korrekt(self):
        wb = _load(erstelle_hybrid_statistik_workbook_bytes([_gruppe(), _gruppe(dimensionswerte=("Andere GmbH", "OK"))], ("anbieter", "status")))
        rows = list(wb["Uebersicht"].iter_rows(values_only=True))
        anzahl_zeile = next(r for r in rows if r[0] == "Anzahl Gruppen")
        assert anzahl_zeile[1] == 2


class TestMetrikenSheet:
    def test_enthaelt_alle_fuenf_quoten_definitionen(self):
        wb = _load(erstelle_hybrid_statistik_workbook_bytes([], ALLE_DIMENSIONEN))
        namen = {row[0] for row in wb["Metriken"].iter_rows(values_only=True, min_row=2)}
        for quote_name in (
            "Vollstaendigkeitsquote", "Richtigkeitsquote", "Automatisierungsquote",
            "Pruefquote", "Nichterkennungsquote",
        ):
            assert quote_name in namen


class TestDeterminismus:
    def test_gleiche_eingabe_ergibt_gleiche_bytes_struktur(self):
        gruppen = [_gruppe(), _gruppe(dimensionswerte=("Andere GmbH", "OK"))]
        a = erstelle_hybrid_statistik_workbook_bytes(gruppen, ("anbieter", "status"))
        b = erstelle_hybrid_statistik_workbook_bytes(gruppen, ("anbieter", "status"))
        wb_a, wb_b = _load(a), _load(b)
        for sheet in wb_a.sheetnames:
            rows_a = list(wb_a[sheet].iter_rows(values_only=True))
            rows_b = list(wb_b[sheet].iter_rows(values_only=True))
            assert rows_a == rows_b

    def test_reihenfolge_der_eingabe_beeinflusst_sortierung_nicht(self):
        g1 = _gruppe(dimensionswerte=("Zeta GmbH", "OK"))
        g2 = _gruppe(dimensionswerte=("Alpha GmbH", "OK"))
        wb_a = _load(erstelle_hybrid_statistik_workbook_bytes([g1, g2], ("anbieter", "status")))
        wb_b = _load(erstelle_hybrid_statistik_workbook_bytes([g2, g1], ("anbieter", "status")))
        rows_a = list(wb_a["Statistik"].iter_rows(values_only=True))
        rows_b = list(wb_b["Statistik"].iter_rows(values_only=True))
        assert rows_a == rows_b
        assert rows_a[1][0] == "Alpha GmbH"
        assert rows_a[2][0] == "Zeta GmbH"


class TestKeinDateisystemzugriff:
    def test_erzeugt_keine_dateien(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        vorher = set(os.listdir(tmp_path))
        erstelle_hybrid_statistik_workbook_bytes([_gruppe()], ("anbieter", "status"))
        nachher = set(os.listdir(tmp_path))
        assert vorher == nachher, "Exportfunktion darf nicht auf das Dateisystem schreiben"
