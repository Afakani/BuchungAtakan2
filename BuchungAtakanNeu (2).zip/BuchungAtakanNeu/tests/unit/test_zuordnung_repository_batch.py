"""Unit-Tests fuer ZuordnungRepository.upsert_vorschlaege Batch-Logik.

Kein Datenbankzugriff. session.execute und session.flush werden gemockt.

Abgedeckte Anforderungen:
  B1: Leere Eingabe → (0, 0), kein execute.
  B2: Nur Nicht-Kandidaten (score < Schwelle) → (0, 0), kein execute.
  B3: N > _MAX_BATCH Kandidaten → ceil(N / _MAX_BATCH) execute-Aufrufe.
  B4: Jede Batch-Groesse <= _MAX_BATCH.
  B5: _MAX_BATCH * 8 <= 32767 (asyncpg-Parametergrenze nie ueberschritten).
  B6: Einzelner Kandidat → genau 1 execute-Aufruf.
  B7: Genau _MAX_BATCH Kandidaten → genau 1 execute-Aufruf (Grenzwert).
"""
import math
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest

from apps.server.repositories.zuordnung import ZuordnungRepository, _MAX_BATCH
from packages.core.matching.signale import MatchErgebnis, Signal, SCHWELLE_UNSICHER


# ── Hilfsfunktionen ──────────────────────────────────────────────────────────

def _ergebnis(score: int = 90) -> MatchErgebnis:
    return MatchErgebnis(
        bankbuchung_id=uuid4(),
        rechnung_id=uuid4(),
        score=score,
        status="STARK" if score >= 80 else "UNSICHER",
        positive_signale=(Signal("BETRAG_EXAKT", "Betrag stimmt", 50),),
        negative_signale=(),
        matcher_version="1.0",
    )


def _mock_session() -> AsyncMock:
    session = AsyncMock()
    result = MagicMock()
    result.scalars.return_value.all.return_value = []
    session.execute.return_value = result
    return session


# ── Tests ─────────────────────────────────────────────────────────────────────

class TestParametergrenze:
    def test_max_batch_sicher_unter_asyncpg_limit(self):
        """B5: _MAX_BATCH * 8 Spalten bleibt unter asyncpg-Grenze 32767."""
        assert _MAX_BATCH * 8 <= 32767


class TestUpsertLeereEingabe:
    @pytest.mark.asyncio
    async def test_leere_liste_gibt_null_zurueck(self):
        """B1: Keine Ergebnisse → (0, 0), kein DB-Zugriff."""
        repo = ZuordnungRepository()
        session = _mock_session()
        total, _ = await repo.upsert_vorschlaege(session, uuid4(), [])
        assert total == 0
        session.execute.assert_not_called()

    @pytest.mark.asyncio
    async def test_nur_nicht_kandidaten_gibt_null_zurueck(self):
        """B2: Alle Ergebnisse unter Schwelle → (0, 0), kein execute."""
        repo = ZuordnungRepository()
        session = _mock_session()
        ergebnisse = [_ergebnis(score=SCHWELLE_UNSICHER - 1) for _ in range(10)]
        total, _ = await repo.upsert_vorschlaege(session, uuid4(), ergebnisse)
        assert total == 0
        session.execute.assert_not_called()


class TestUpsertBatchSplitting:
    @pytest.mark.asyncio
    async def test_einzelner_kandidat_genau_ein_execute(self):
        """B6: 1 Kandidat → 1 execute."""
        repo = ZuordnungRepository()
        session = _mock_session()
        await repo.upsert_vorschlaege(session, uuid4(), [_ergebnis()])
        assert session.execute.call_count == 1

    @pytest.mark.asyncio
    async def test_max_batch_kandidaten_genau_ein_execute(self):
        """B7: Genau _MAX_BATCH Kandidaten → 1 execute (Grenzwert, kein Split)."""
        repo = ZuordnungRepository()
        session = _mock_session()
        ergebnisse = [_ergebnis() for _ in range(_MAX_BATCH)]
        await repo.upsert_vorschlaege(session, uuid4(), ergebnisse)
        assert session.execute.call_count == 1

    @pytest.mark.asyncio
    async def test_max_batch_plus_eins_ergibt_zwei_batches(self):
        """B3: _MAX_BATCH + 1 Kandidaten → 2 execute-Aufrufe."""
        repo = ZuordnungRepository()
        session = _mock_session()
        ergebnisse = [_ergebnis() for _ in range(_MAX_BATCH + 1)]
        await repo.upsert_vorschlaege(session, uuid4(), ergebnisse)
        assert session.execute.call_count == 2

    @pytest.mark.asyncio
    async def test_grosse_liste_wird_korrekt_aufgeteilt(self):
        """B3/B4: 2.5 * _MAX_BATCH Kandidaten → 3 Batches."""
        n = int(_MAX_BATCH * 2.5)
        ergebnisse = [_ergebnis() for _ in range(n)]
        repo = ZuordnungRepository()
        session = _mock_session()
        await repo.upsert_vorschlaege(session, uuid4(), ergebnisse)
        erwartete_batches = math.ceil(n / _MAX_BATCH)
        assert session.execute.call_count == erwartete_batches

    @pytest.mark.asyncio
    async def test_flush_je_batch_aufgerufen(self):
        """Pro Batch wird session.flush() genau einmal aufgerufen."""
        n = _MAX_BATCH + 1  # 2 Batches
        ergebnisse = [_ergebnis() for _ in range(n)]
        repo = ZuordnungRepository()
        session = _mock_session()
        await repo.upsert_vorschlaege(session, uuid4(), ergebnisse)
        assert session.flush.call_count == 2
