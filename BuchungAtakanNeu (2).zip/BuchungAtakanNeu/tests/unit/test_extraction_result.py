"""Unit-Tests fuer ExtractionResult und ExtraktionsStatus."""
import pytest

from packages.core.invoice_extraction.extraction_result import ExtractionResult, ExtraktionsStatus
from packages.core.invoice_extraction.kandidat import Kandidat


def _k(feld: str, normwert: str | None = "x", confidence: float = 0.8) -> Kandidat:
    return Kandidat(feld=feld, rohwert=normwert or "x", normwert=normwert, methode="m", quelle="pdf_text", confidence=confidence)


def test_kandidaten_fuer_feld():
    r = ExtractionResult(
        kandidaten=[_k("total_amount", "100.00"), _k("net_amount", "84.03")],
        status=ExtraktionsStatus.OK, fehler=[], roher_text="", confidence=0.7,
    )
    treffer = r.kandidaten_fuer_feld("total_amount")
    assert len(treffer) == 1
    assert treffer[0].normwert == "100.00"


def test_bestes_fuer_feld_hoechste_confidence():
    k1 = _k("total_amount", "100.00", 0.6)
    k2 = _k("total_amount", "100.00", 0.9)
    r = ExtractionResult(kandidaten=[k1, k2], status=ExtraktionsStatus.OK, fehler=[], roher_text="", confidence=0.8)
    assert r.bestes_fuer_feld("total_amount") == k2


def test_bestes_fuer_feld_nicht_vorhanden():
    r = ExtractionResult(kandidaten=[], status=ExtraktionsStatus.OK, fehler=[], roher_text="", confidence=0.0)
    assert r.bestes_fuer_feld("total_amount") is None


def test_fehlende_pflichtfelder_leer():
    kandidaten = [_k("vendor_name"), _k("invoice_number"), _k("invoice_date"), _k("total_amount")]
    r = ExtractionResult(kandidaten=kandidaten, status=ExtraktionsStatus.OK, fehler=[], roher_text="", confidence=0.9)
    assert r.fehlende_pflichtfelder == frozenset()


def test_fehlende_pflichtfelder_teilweise():
    r = ExtractionResult(
        kandidaten=[_k("vendor_name"), _k("total_amount")],
        status=ExtraktionsStatus.OK, fehler=[], roher_text="", confidence=0.5,
    )
    missing = r.fehlende_pflichtfelder
    assert "invoice_number" in missing
    assert "invoice_date" in missing
    assert "vendor_name" not in missing


def test_status_enum_werte():
    assert ExtraktionsStatus.OK == "OK"
    assert ExtraktionsStatus.PRUEFFALL == "PRUEFFALL"
    assert ExtraktionsStatus.MATH_FEHLER == "MATH_FEHLER"
    assert ExtraktionsStatus.UNVOLLSTAENDIG == "UNVOLLSTAENDIG"
