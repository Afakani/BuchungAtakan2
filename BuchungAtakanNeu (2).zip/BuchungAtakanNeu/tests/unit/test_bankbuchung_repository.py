"""Unit-Tests BankbuchungRepository — Logik ohne echte DB (Mocks).

Repository-Service-Tests (mandantenbezogene Logik, Deduplizierung, Atomizitaet)
werden durch echte PostgreSQL-Integrationstests abgedeckt (tests/integration/).
Diese Datei prueft die Hilfslogik und die Cent-Integritaet auf Repository-Ebene.
"""
import pytest

from packages.core.bank_import.cent_konvertierung import parse_betrag_cent
from packages.core.bank_import.fingerprint import berechne_fingerprint
from packages.core.bank_import.klassifikation import BuchungsKlassifikation, klassifiziere_buchung
from uuid import UUID

_T = UUID("00000000-0000-4000-a000-000000000001")
_K = UUID("00000000-0000-4000-b000-000000000001")


def _make_buchung_data(
    buchungsdatum="2024-01-15",
    betrag_cent=11900,
    verwendungszweck="Rechnung 001",
    gegenpartei_name="Lieferant",
    externe_buchungs_id=None,
):
    fp = berechne_fingerprint(
        unternehmen_id=_T,
        bankkonto_id=_K,
        buchungsdatum=buchungsdatum,
        betrag_cent=betrag_cent,
        waehrung="EUR",
        verwendungszweck=verwendungszweck,
        gegenpartei_name=gegenpartei_name,
        externe_buchungs_id=externe_buchungs_id,
    )
    klasse = klassifiziere_buchung(verwendungszweck, gegenpartei_name)
    return {
        "buchungsdatum": buchungsdatum,
        "betrag_cent": betrag_cent,
        "waehrung": "EUR",
        "verwendungszweck": verwendungszweck,
        "gegenpartei_name": gegenpartei_name,
        "externe_buchungs_id": externe_buchungs_id,
        "dedup_fingerprint": fp,
        "klassifikation": str(klasse),
    }


class TestFingerprintDeduplication:
    def test_identische_buchung_gleicher_fingerprint(self):
        """Idempotenz: gleiche Buchung → gleicher Fingerprint → Duplikat im DB-Constraint."""
        d1 = _make_buchung_data()
        d2 = _make_buchung_data()
        assert d1["dedup_fingerprint"] == d2["dedup_fingerprint"]

    def test_gleicher_betrag_datum_anderer_text_anderer_fingerprint(self):
        """BANK-03: Betrag+Datum allein keine Deduplizierung."""
        d1 = _make_buchung_data(verwendungszweck="Rechnung A")
        d2 = _make_buchung_data(verwendungszweck="Rechnung B")
        assert d1["dedup_fingerprint"] != d2["dedup_fingerprint"]

    def test_externe_id_unterscheidet_buchungen(self):
        d1 = _make_buchung_data(externe_buchungs_id="TX-001")
        d2 = _make_buchung_data(externe_buchungs_id="TX-002")
        assert d1["dedup_fingerprint"] != d2["dedup_fingerprint"]


class TestCentIntegritaet:
    def test_betrag_cent_ist_integer_unveraendert(self):
        """BANK-10: betrag_cent ist direkt int, kein float."""
        bd = _make_buchung_data(betrag_cent=9999)
        assert bd["betrag_cent"] == 9999
        assert isinstance(bd["betrag_cent"], int)

    def test_dezimalstring_wird_korrekt_konvertiert(self):
        cent = parse_betrag_cent("99.99")
        bd = _make_buchung_data(betrag_cent=cent)
        assert bd["betrag_cent"] == 9999

    def test_negativer_betrag_korrekt(self):
        bd = _make_buchung_data(betrag_cent=-500)
        assert bd["betrag_cent"] == -500


class TestKlassifikationInDaten:
    def test_matchbar_in_buchungsdaten(self):
        bd = _make_buchung_data(verwendungszweck="Rechnung 2024-001")
        assert bd["klassifikation"] == BuchungsKlassifikation.MATCHBAR

    def test_nicht_zu_matchen_in_buchungsdaten(self):
        bd = _make_buchung_data(verwendungszweck="Kontoführungsgebühr")
        assert bd["klassifikation"] == BuchungsKlassifikation.NICHT_ZU_MATCHEN

    def test_ec_einzahlung_in_buchungsdaten(self):
        bd = _make_buchung_data(verwendungszweck="EC-Karte Abrechnung")
        assert bd["klassifikation"] == BuchungsKlassifikation.EC_EINZAHLUNG
