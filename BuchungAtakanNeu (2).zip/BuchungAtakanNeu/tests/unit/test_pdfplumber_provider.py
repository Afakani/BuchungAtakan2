"""Unit-Tests fuer PdfplumberProvider (HYB-01/07) -- bisher keine dedizierte Testdatei.

Regressionsschutz fuer den provider_name-Bug (Realtest-Gap-Paket): PdfplumberProvider
wrappt bestehende Kandidaten ueber from_kandidat() -- ohne explizites provider_name
landete dort die Phase-4-KandidatQuelle (z.B. "pdf_text") statt "pdfplumber". Das
erzeugte Phantom-Eintraege in hybrid_erkennungslaeufe (kein InvoiceProviderResult mit
diesem Namen) und verhinderte den dokumentierten pdfplumber-Tie-Break in hybrid_auswahl.py.
"""
from __future__ import annotations
from pathlib import Path
from unittest.mock import patch

from packages.core.invoice_extraction.extraction_result import ExtractionResult, ExtraktionsStatus
from packages.core.invoice_extraction.hybrid_auswahl import waehle_kandidaten
from packages.core.invoice_extraction.hybrid_kandidat import AuswahlStatus
from packages.core.invoice_extraction.hybrid_konflikt import erkenne_konflikte
from packages.core.invoice_extraction.hybrid_normalisierung import normalisiere_kandidat
from packages.core.invoice_extraction.kandidat import Kandidat, KandidatQuelle
from packages.core.invoice_extraction.pdfplumber_provider import PdfplumberProvider

_MODUL = "packages.core.invoice_extraction.pdfplumber_provider"


def _extraction_result(quelle: str = KandidatQuelle.PDF_TEXT) -> ExtractionResult:
    return ExtractionResult(
        kandidaten=[
            Kandidat(feld="invoice_number", rohwert="RE-1", normwert="RE-1", methode="regex_label", quelle=quelle, confidence=0.9),
            Kandidat(feld="total_amount", rohwert="119,00", normwert="119.00", methode="regex_label", quelle=quelle, confidence=0.85),
        ],
        status=ExtraktionsStatus.OK, fehler=[], roher_text="irrelevant", confidence=0.9,
    )


class TestProviderNameKonsistenz:
    def test_kandidaten_tragen_provider_name_pdfplumber_nicht_kandidatquelle(self):
        """Kernregression: quelle=pdf_text darf provider_name nicht ueberschreiben."""
        with patch(f"{_MODUL}.extract_from_pdf", return_value=_extraction_result(KandidatQuelle.PDF_TEXT)):
            ergebnis = PdfplumberProvider().extract(Path("irrelevant.pdf"))

        assert ergebnis.kandidaten, "Testaufbau muss Kandidaten liefern"
        for k in ergebnis.kandidaten:
            assert k.provider_name == "pdfplumber"
            assert k.provider_name != "pdf_text"

    def test_kandidaten_provider_name_stimmt_mit_ergebnis_provider_name_ueberein(self):
        """Invariante, die Phantom-hybrid_erkennungslaeufe verhindert: jeder Kandidat
        muss denselben provider_name tragen wie das umschliessende InvoiceProviderResult --
        sonst legt persistiere_hybrid_auswertung() einen zusaetzlichen, nicht
        zugeordneten Lauf-Eintrag an (ueber _lauf_id_fuer(kandidat.provider_name, ...))."""
        with patch(f"{_MODUL}.extract_from_pdf", return_value=_extraction_result(KandidatQuelle.OCR)):
            ergebnis = PdfplumberProvider().extract(Path("irrelevant.pdf"))

        for k in ergebnis.kandidaten:
            assert k.provider_name == ergebnis.provider_name

    def test_funktioniert_unabhaengig_von_kandidatquelle(self):
        for quelle in (KandidatQuelle.PDF_TEXT, KandidatQuelle.OCR, KandidatQuelle.E_RECHNUNG):
            with patch(f"{_MODUL}.extract_from_pdf", return_value=_extraction_result(quelle)):
                ergebnis = PdfplumberProvider().extract(Path("irrelevant.pdf"))
            assert all(k.provider_name == "pdfplumber" for k in ergebnis.kandidaten), quelle


class TestPdfplumberTieBreakFunktioniertMitEchtenKandidaten:
    def test_tie_break_greift_mit_echten_pdfplumber_kandidaten(self):
        """Vor dem Fix konnte dieser Tie-Break nie greifen, weil echte pdfplumber-
        Kandidaten provider_name="pdf_text" statt "pdfplumber" trugen -- Regel c in
        hybrid_auswahl._bestimme_gewinner() vergleicht explizit auf "pdfplumber"."""
        with patch(f"{_MODUL}.extract_from_pdf", return_value=_extraction_result(KandidatQuelle.PDF_TEXT)):
            pdfplumber_ergebnis = PdfplumberProvider().extract(Path("irrelevant.pdf"))

        from packages.core.invoice_extraction.hybrid_kandidat import HybridKandidat
        konkurrent = HybridKandidat(
            feld="invoice_number", rohwert="RE-9", normwert="RE-9", methode="template",
            provider_name="invoice2data", provider_version="1.0", confidence=0.9,
        )
        alle_kandidaten = [
            normalisiere_kandidat(k) for k in pdfplumber_ergebnis.kandidaten if k.feld == "invoice_number"
        ] + [normalisiere_kandidat(konkurrent)]

        konflikte = erkenne_konflikte(alle_kandidaten)
        assert len(konflikte) == 1
        finale_kandidaten, finale_konflikte = waehle_kandidaten(alle_kandidaten, konflikte)

        assert finale_konflikte[0].aufloesungsstatus == "AUFGELOEST_PARSER_TIEBREAK"
        gewinner = next(k for k in finale_kandidaten if k.auswahl_status == AuswahlStatus.AUSGEWAEHLT)
        assert gewinner.provider_name == "pdfplumber"
