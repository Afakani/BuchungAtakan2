"""Unit-Tests fuer automatische Konflikterkennung zwischen Providern (HYB-14).

Konflikte werden nie still aufgeloest -- Reihenfolge der Eingabe darf das
Ergebnis nicht veraendern.
"""
from packages.core.invoice_extraction.hybrid_kandidat import HybridKandidat
from packages.core.invoice_extraction.hybrid_konflikt import erkenne_konflikte
from packages.core.invoice_extraction.hybrid_normalisierung import normalisiere_kandidat


def _k(feld: str, rohwert: str, provider: str, confidence: float = 0.8) -> HybridKandidat:
    roh = HybridKandidat(
        feld=feld, rohwert=rohwert, normwert=None, methode="regex_label",
        provider_name=provider, provider_version="1.0", confidence=confidence,
    )
    return normalisiere_kandidat(roh)


class TestGleicheWerte:
    def test_gleiche_werte_verschiedener_provider_kein_konflikt(self):
        kandidaten = [
            _k("total_amount", "119,00", "pdfplumber"),
            _k("total_amount", "119.00", "invoice2data"),
        ]
        konflikte = erkenne_konflikte(kandidaten)
        assert konflikte == []


class TestUnterschiedlicheWerte:
    def test_abweichende_werte_ergeben_konflikt(self):
        kandidaten = [
            _k("total_amount", "119,00", "pdfplumber"),
            _k("total_amount", "199.00", "invoice2data"),
        ]
        konflikte = erkenne_konflikte(kandidaten)
        assert len(konflikte) == 1
        assert konflikte[0].feld == "total_amount"
        assert set(konflikte[0].werte) == {"119.00", "199.00"}

    def test_pflichtfeld_konflikt_hat_hohen_schweregrad(self):
        kandidaten = [
            _k("invoice_number", "RE-001", "pdfplumber"),
            _k("invoice_number", "RE-002", "invoice2data"),
        ]
        konflikte = erkenne_konflikte(kandidaten)
        assert konflikte[0].schweregrad == "HOCH"

    def test_optionalfeld_konflikt_hat_mittleren_schweregrad(self):
        kandidaten = [
            _k("payment_method", "BANK_TRANSFER", "pdfplumber"),
            _k("payment_method", "CASH", "invoice2data"),
        ]
        konflikte = erkenne_konflikte(kandidaten)
        assert konflikte[0].schweregrad == "MITTEL"


class TestDreiProviderZweiUebereinstimmend:
    def test_zwei_von_drei_stimmen_ueberein_bleibt_konflikt_sichtbar(self):
        kandidaten = [
            _k("total_amount", "119,00", "pdfplumber"),
            _k("total_amount", "119.00", "invoice2data"),
            _k("total_amount", "999.99", "paddleocr"),
        ]
        konflikte = erkenne_konflikte(kandidaten)
        assert len(konflikte) == 1
        assert set(konflikte[0].werte) == {"119.00", "999.99"}
        assert set(konflikte[0].provider) == {"pdfplumber", "invoice2data", "paddleocr"}


class TestGleichstand:
    def test_zwei_provider_zwei_unterschiedliche_werte_ist_konflikt(self):
        kandidaten = [
            _k("total_amount", "100,00", "pdfplumber"),
            _k("total_amount", "200,00", "invoice2data"),
        ]
        konflikte = erkenne_konflikte(kandidaten)
        assert len(konflikte) == 1


class TestNiedrigeOcrConfidence:
    def test_paddleocr_konflikt_wird_als_ocr_abweichung_klassifiziert(self):
        kandidaten = [
            _k("total_amount", "119,00", "pdfplumber", confidence=0.9),
            _k("total_amount", "719,00", "paddleocr", confidence=0.3),
        ]
        konflikte = erkenne_konflikte(kandidaten)
        assert konflikte[0].konfliktart == "OCR_VS_TEXT_ABWEICHUNG"


class TestTemplateGegenEigenenParser:
    def test_pdfplumber_vs_invoice2data_wird_klassifiziert(self):
        kandidaten = [
            _k("invoice_number", "RE-001", "pdfplumber"),
            _k("invoice_number", "RE-999", "invoice2data"),
        ]
        konflikte = erkenne_konflikte(kandidaten)
        assert konflikte[0].konfliktart == "PARSER_VS_TEMPLATE_ABWEICHUNG"


class TestReihenfolgeunabhaengigkeit:
    def test_umgekehrte_eingabereihenfolge_liefert_gleiches_ergebnis(self):
        a = _k("total_amount", "119,00", "pdfplumber")
        b = _k("total_amount", "199.00", "invoice2data")
        c = _k("total_amount", "119.00", "paddleocr")

        konflikte_1 = erkenne_konflikte([a, b, c])
        konflikte_2 = erkenne_konflikte([c, b, a])

        assert konflikte_1 == konflikte_2

    def test_mehrfache_ausfuehrung_liefert_identisches_ergebnis(self):
        kandidaten = [
            _k("total_amount", "119,00", "pdfplumber"),
            _k("total_amount", "199.00", "invoice2data"),
        ]
        laeufe = [erkenne_konflikte(kandidaten) for _ in range(5)]
        assert all(lauf == laeufe[0] for lauf in laeufe)
