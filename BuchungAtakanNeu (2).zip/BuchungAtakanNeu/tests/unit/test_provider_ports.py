"""Unit-Tests fuer Provider-Ports und InvoiceProviderResult (HYB-02)."""
from packages.core.invoice_extraction.hybrid_kandidat import HybridKandidat
from packages.core.invoice_extraction.provider_ports import InvoiceProviderResult


def _result(**kwargs) -> InvoiceProviderResult:
    defaults = dict(
        provider_name="test_provider",
        provider_version="1.0",
        laufstatus="success",
        kandidaten=[],
        fehlercode=None,
    )
    defaults.update(kwargs)
    return InvoiceProviderResult(**defaults)


class TestInvoiceProviderResult:
    def test_erfolg_ohne_fehlercode(self):
        r = _result()
        assert r.laufstatus == "success"
        assert r.fehlercode is None

    def test_fehler_nur_als_fehlercode(self):
        r = _result(laufstatus="error", fehlercode="FileNotFoundError", kandidaten=[])
        assert r.fehlercode == "FileNotFoundError"
        # Kein Volltext, kein Dateiname — nur Fehlertyp gespeichert
        assert "/" not in r.fehlercode
        assert "\\" not in r.fehlercode

    def test_kein_volltext_im_fehlercode(self):
        r = _result(laufstatus="error", fehlercode="ValueError")
        # fehlercode enthaelt keinen Stack-Trace-Inhalt
        assert "\n" not in r.fehlercode
        assert "Traceback" not in r.fehlercode

    def test_skipped_laufstatus(self):
        r = _result(laufstatus="skipped", fehlercode=None)
        assert r.laufstatus == "skipped"

    def test_seiten_anzahl_optional(self):
        r = _result(seiten_anzahl=3)
        assert r.seiten_anzahl == 3

    def test_lauf_dauer_optional(self):
        r = _result(lauf_dauer_ms=250)
        assert r.lauf_dauer_ms == 250

    def test_kandidaten_leer_bei_fehler(self):
        r = _result(laufstatus="error", fehlercode="OSError", kandidaten=[])
        assert r.kandidaten == []

    def test_provider_version_none_erlaubt(self):
        r = _result(provider_version=None)
        assert r.provider_version is None


class TestProtocolKompatibilitaet:
    """PdfplumberProvider implementiert InvoiceCandidateProvider-Protocol."""

    def test_pdfplumber_provider_hat_name_und_version(self):
        from packages.core.invoice_extraction.pdfplumber_provider import PdfplumberProvider
        p = PdfplumberProvider()
        assert isinstance(p.name, str) and p.name
        assert isinstance(p.version, str) and p.version

    def test_pdfplumber_provider_hat_extract_methode(self):
        from packages.core.invoice_extraction.pdfplumber_provider import PdfplumberProvider
        p = PdfplumberProvider()
        assert callable(p.extract)
