"""Unit-Tests fuer Pydantic-Schemata -- kein DB-Zugriff."""
import pytest
from pydantic import ConfigDict, ValidationError

from apps.server.auth.schemas import TokenResponse


def test_token_response_default_type():
    t = TokenResponse(access_token="eyJ...")
    assert t.token_type == "bearer"


def test_token_response_access_token_required():
    with pytest.raises(ValidationError):
        TokenResponse()  # type: ignore[call-arg]


def test_request_body_rejects_extra_fields():
    """SRV-05: Schemata mit extra=forbid lehnen unternehmen_id im Body ab."""
    from pydantic import BaseModel

    class TestRequestSchema(BaseModel):
        model_config = ConfigDict(extra="forbid")
        username: str

    with pytest.raises(ValidationError) as exc_info:
        TestRequestSchema(username="test", unternehmen_id="00000000-0000-4000-a000-000000000001")  # type: ignore[call-arg]
    errors = exc_info.value.errors()
    assert any("unternehmen_id" in str(e) for e in errors)


def test_token_response_extra_fields_rejected():
    """TokenResponse selbst lehnt Extra-Felder ab."""
    with pytest.raises(ValidationError):
        TokenResponse(access_token="x", unerwartetes_feld="y")  # type: ignore[call-arg]
