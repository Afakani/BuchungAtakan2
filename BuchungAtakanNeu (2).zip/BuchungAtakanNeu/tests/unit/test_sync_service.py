"""Unit-Tests fuer DokumentSyncService (Mock-Client, kein echter Server)."""
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock
from uuid import UUID

import pytest

from apps.client.outbox import DokumentOutbox, OutboxStatus
from apps.client.sync_service import DokumentSyncService

_INSTALL_ID = UUID("12345678-1234-4000-a000-000000000001")


@pytest.fixture
def data_root(tmp_path) -> Path:
    dump = tmp_path / "dump"
    dump.mkdir()
    (dump / "rechnung.pdf").write_bytes(b"%PDF-1.4 content")
    (dump / "kontoauszug.csv").write_bytes(b"datum,betrag\n2026-01-01,100")
    return tmp_path


@pytest.fixture
def outbox(tmp_path) -> DokumentOutbox:
    return DokumentOutbox(tmp_path / "outbox.db")


@pytest.fixture
def mock_client():
    client = MagicMock()
    client.dokument_sync = AsyncMock(return_value={"id": "abc", "sha256": "x" * 64})
    return client


@pytest.fixture
def sync_service(mock_client, data_root, outbox) -> DokumentSyncService:
    return DokumentSyncService(mock_client, data_root, _INSTALL_ID, outbox)


@pytest.mark.asyncio
async def test_sync_sendet_alle_dokumente(sync_service, mock_client, data_root):
    result = await sync_service.sync_alle_dokumente()
    assert result["gesendet"] == 2
    assert result["outbox"] == 0
    assert mock_client.dokument_sync.call_count == 2


@pytest.mark.asyncio
async def test_sync_legt_in_outbox_bei_fehler(sync_service, mock_client, outbox):
    mock_client.dokument_sync.side_effect = ConnectionError("Kein Netz")
    result = await sync_service.sync_alle_dokumente()
    assert result["outbox"] == 2
    assert result["gesendet"] == 0
    assert len(outbox.pending()) == 2


@pytest.mark.asyncio
async def test_sync_teilfehler(sync_service, mock_client, outbox):
    # Erster Aufruf OK, zweiter Aufruf Fehler
    mock_client.dokument_sync.side_effect = [
        {"id": "ok"},
        ConnectionError("Timeout"),
    ]
    result = await sync_service.sync_alle_dokumente()
    assert result["gesendet"] == 1
    assert result["outbox"] == 1


@pytest.mark.asyncio
async def test_outbox_verarbeiten_sendet_pending(sync_service, mock_client, outbox):
    outbox.enqueue("/api/v1/dokumente", {"sha256": "a" * 64, "dateiname": "x.pdf"})
    result = await sync_service.outbox_verarbeiten()
    assert result["gesendet"] == 1
    assert result["fehler"] == 0
    assert outbox.pending() == []


@pytest.mark.asyncio
async def test_outbox_verarbeiten_markiert_fehler(sync_service, mock_client, outbox):
    mock_client.dokument_sync.side_effect = ConnectionError("Netz weg")
    outbox.enqueue("/api/v1/dokumente", {"sha256": "a" * 64})
    result = await sync_service.outbox_verarbeiten()
    assert result["fehler"] == 1
    assert result["gesendet"] == 0
    import sqlite3
    with sqlite3.connect(outbox._db_path) as conn:
        row = conn.execute("SELECT status FROM outbox").fetchone()
    assert row[0] == "FAILED"


@pytest.mark.asyncio
async def test_sync_leerer_dump_ordner(mock_client, tmp_path, outbox):
    (tmp_path / "dump").mkdir()
    service = DokumentSyncService(mock_client, tmp_path, _INSTALL_ID, outbox)
    result = await service.sync_alle_dokumente()
    assert result == {"gesendet": 0, "outbox": 0}
    mock_client.dokument_sync.assert_not_called()


@pytest.mark.asyncio
async def test_payload_enthaelt_kein_bytes_feld(sync_service, mock_client):
    await sync_service.sync_alle_dokumente()
    for call in mock_client.dokument_sync.call_args_list:
        payload = call.args[0]
        assert "bytes" not in payload
        assert "content" not in payload
        assert "file" not in payload
        assert "data" not in payload
        # CLI-08: nur Metadaten
        assert "sha256" in payload
        assert "dateigroesse" in payload
        assert "mime_type" in payload
