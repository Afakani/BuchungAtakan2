"""Smoke-Tests: Server-Modelle Phase 3 importieren ohne DB-Verbindung."""
from apps.server.models.dokument import Dokument, DokumentVerfuegbarkeit


def test_dokument_model_importiert():
    assert Dokument.__tablename__ == "dokumente"


def test_verfuegbarkeit_enum_vollstaendig():
    values = {v.value for v in DokumentVerfuegbarkeit}
    assert values == {"LOCAL_AVAILABLE", "LOCAL_MISSING", "UNKNOWN"}


def test_unique_constraint_definiert():
    constraints = Dokument.__table_args__
    names = [c.name for c in constraints if hasattr(c, "name")]
    assert "uq_dokument_tenant_sha256" in names


def test_dokument_router_importiert():
    from apps.server.routers.dokumente import router
    assert router.prefix == "/api/v1/dokumente"


def test_installationen_router_importiert():
    from apps.server.routers.installationen import router
    assert router.prefix == "/api/v1/installationen"


def test_main_app_enthaelt_neue_router():
    from apps.server.main import create_app
    app = create_app()
    paths = list(app.openapi().get("paths", {}).keys())
    assert any("/api/v1/dokumente" in p for p in paths)
    assert any("/api/v1/installationen" in p for p in paths)
