import pytest

from packages.core.document_locator import DokumentLocator, DokumentQuelle, DokumentVerfuegbarkeit

_VALID_SHA256 = "a" * 64


def test_valid_locator():
    loc = DokumentLocator(
        relative_path="dump/rechnung.pdf",
        sha256=_VALID_SHA256,
        dateigroesse=1024,
        mime_type="application/pdf",
    )
    assert loc.relative_path == "dump/rechnung.pdf"
    assert loc.quelle == DokumentQuelle.DUMP


def test_frozen():
    loc = DokumentLocator(
        relative_path="dump/x.pdf",
        sha256=_VALID_SHA256,
        dateigroesse=1,
        mime_type="application/pdf",
    )
    with pytest.raises(Exception):
        loc.relative_path = "anderer/pfad.pdf"  # type: ignore[misc]


def test_absolute_unix_path_rejected():
    with pytest.raises(ValueError, match="relativ"):
        DokumentLocator(
            relative_path="/absolut/pfad.pdf",
            sha256=_VALID_SHA256,
            dateigroesse=1,
            mime_type="application/pdf",
        )


def test_absolute_windows_path_rejected():
    with pytest.raises(ValueError, match="relativ"):
        DokumentLocator(
            relative_path="C:\\Users\\test.pdf",
            sha256=_VALID_SHA256,
            dateigroesse=1,
            mime_type="application/pdf",
        )


def test_short_sha256_rejected():
    with pytest.raises(ValueError, match="sha256"):
        DokumentLocator(
            relative_path="dump/x.pdf",
            sha256="abc123",
            dateigroesse=1,
            mime_type="application/pdf",
        )


def test_negative_size_rejected():
    with pytest.raises(ValueError, match="dateigroesse"):
        DokumentLocator(
            relative_path="dump/x.pdf",
            sha256=_VALID_SHA256,
            dateigroesse=-1,
            mime_type="application/pdf",
        )


def test_verfuegbarkeit_enum_vollstaendig():
    values = set(DokumentVerfuegbarkeit)
    assert "LOCAL_AVAILABLE" in values
    assert "LOCAL_MISSING" in values
    assert "UNKNOWN" in values


def test_quelle_enum_vollstaendig():
    values = set(DokumentQuelle)
    assert "DUMP" in values
    assert "UPLOAD" in values
    assert "SCANNER" in values
