"""Direkte Unit-Tests fuer alle Plausibilitaetsregeln (HYB-15, Paket 07-06).

Bisher waren diese Regeln nur indirekt ueber die Statusentscheidung abgedeckt --
diese Datei testet jede Regel einzeln inkl. Toleranzgrenzen und Storno-Faellen.
"""
from packages.core.invoice_extraction.hybrid_plausibilitaet import (
    BETRAGS_TOLERANZ,
    pruefe_anbieter_bestimmbar,
    pruefe_betrag_nicht_negativ,
    pruefe_betragsrelation,
    pruefe_rechnungsdatum_plausibel,
    pruefe_rechnungsnummer_plausibel,
    pruefe_steuer_nicht_negativ,
    pruefe_waehrung_konsistent,
)


class TestBetragsrelation:
    def test_exakte_relation_besteht(self):
        assert pruefe_betragsrelation("119.00", "100.00", "19.00").bestanden is True

    def test_abweichung_genau_auf_toleranzgrenze_besteht(self):
        # diff == BETRAGS_TOLERANZ (0.02) ist noch zulaessig (> Toleranz faellt durch)
        assert pruefe_betragsrelation("119.02", "100.00", "19.00").bestanden is True

    def test_abweichung_knapp_ueber_toleranz_faellt_durch(self):
        befund = pruefe_betragsrelation("119.03", "100.00", "19.00")
        assert befund.bestanden is False
        assert "weicht" in befund.begruendung

    def test_fehlender_wert_faellt_durch(self):
        assert pruefe_betragsrelation(None, "100.00", "19.00").bestanden is False
        assert pruefe_betragsrelation("119.00", None, "19.00").bestanden is False
        assert pruefe_betragsrelation("119.00", "100.00", None).bestanden is False

    def test_unlesbarer_wert_faellt_durch(self):
        assert pruefe_betragsrelation("abc", "100.00", "19.00").bestanden is False

    def test_toleranzkonstante_unveraendert(self):
        # Schwellenwert ist Fachentscheidung -- Test schuetzt vor stiller Aenderung.
        assert str(BETRAGS_TOLERANZ) == "0.02"


class TestSteuerNichtNegativ:
    def test_positive_steuer_besteht(self):
        assert pruefe_steuer_nicht_negativ("19.00").bestanden is True

    def test_null_steuer_besteht(self):
        assert pruefe_steuer_nicht_negativ("0.00").bestanden is True

    def test_negative_steuer_faellt_durch(self):
        befund = pruefe_steuer_nicht_negativ("-19.00")
        assert befund.bestanden is False
        assert "negativ" in befund.begruendung

    def test_fehlende_steuer_faellt_durch(self):
        assert pruefe_steuer_nicht_negativ(None).bestanden is False


class TestBetragNichtNegativ:
    def test_positiver_brutto_besteht(self):
        assert pruefe_betrag_nicht_negativ("total_amount", "119.00").bestanden is True

    def test_negativer_brutto_ohne_storno_faellt_durch(self):
        befund = pruefe_betrag_nicht_negativ("total_amount", "-119.00")
        assert befund.bestanden is False
        assert "Storno" in befund.begruendung

    def test_negativer_brutto_mit_storno_freigabe_besteht(self):
        befund = pruefe_betrag_nicht_negativ("total_amount", "-119.00", storno_erlaubt=True)
        assert befund.bestanden is True

    def test_negatives_netto_ohne_storno_faellt_durch(self):
        assert pruefe_betrag_nicht_negativ("net_amount", "-100.00").bestanden is False

    def test_regelname_enthaelt_feld(self):
        assert pruefe_betrag_nicht_negativ("net_amount", "1.00").regel == "net_amount_nicht_negativ"

    def test_fehlender_betrag_faellt_durch(self):
        assert pruefe_betrag_nicht_negativ("total_amount", None).bestanden is False


class TestWaehrungKonsistent:
    def test_eine_waehrung_besteht(self):
        assert pruefe_waehrung_konsistent(["EUR"]).bestanden is True

    def test_mehrfach_gleiche_waehrung_besteht(self):
        assert pruefe_waehrung_konsistent(["EUR", "EUR", "EUR"]).bestanden is True

    def test_widerspruechliche_waehrungen_fallen_durch(self):
        befund = pruefe_waehrung_konsistent(["EUR", "USD"])
        assert befund.bestanden is False
        assert "EUR" in befund.begruendung and "USD" in befund.begruendung

    def test_none_werte_werden_ignoriert(self):
        assert pruefe_waehrung_konsistent([None, "EUR", None]).bestanden is True

    def test_leere_liste_besteht(self):
        # Keine Waehrungskandidaten = kein Widerspruch feststellbar.
        assert pruefe_waehrung_konsistent([]).bestanden is True


class TestRechnungsdatumPlausibel:
    def test_gueltiges_datum_besteht(self):
        assert pruefe_rechnungsdatum_plausibel("2026-06-12").bestanden is True

    def test_unmoegliches_kalenderdatum_faellt_durch(self):
        """Paket 07-06: 31. Februar existiert nicht -- vorher bestand dieses Datum."""
        befund = pruefe_rechnungsdatum_plausibel("2026-02-31")
        assert befund.bestanden is False
        assert "Kalenderdatum" in befund.begruendung

    def test_schalttag_in_schaltjahr_besteht(self):
        assert pruefe_rechnungsdatum_plausibel("2024-02-29").bestanden is True

    def test_schalttag_in_nicht_schaltjahr_faellt_durch(self):
        assert pruefe_rechnungsdatum_plausibel("2026-02-29").bestanden is False

    def test_jahr_unter_minimum_faellt_durch(self):
        assert pruefe_rechnungsdatum_plausibel("1999-06-12").bestanden is False

    def test_fehlendes_datum_faellt_durch(self):
        assert pruefe_rechnungsdatum_plausibel(None).bestanden is False

    def test_unlesbares_datum_faellt_durch(self):
        assert pruefe_rechnungsdatum_plausibel("nicht-ein-datum").bestanden is False


class TestRechnungsnummerPlausibel:
    def test_echte_rechnungsnummer_besteht(self):
        assert pruefe_rechnungsnummer_plausibel("re-2026-100").bestanden is True

    def test_generischer_text_faellt_durch(self):
        for generisch in ("rechnung", "invoice", "n/a", "unbekannt", "none", "-"):
            assert pruefe_rechnungsnummer_plausibel(generisch).bestanden is False, generisch

    def test_leere_nummer_faellt_durch(self):
        assert pruefe_rechnungsnummer_plausibel("").bestanden is False
        assert pruefe_rechnungsnummer_plausibel("   ").bestanden is False
        assert pruefe_rechnungsnummer_plausibel(None).bestanden is False


class TestAnbieterBestimmbar:
    def test_vorhandener_anbieter_besteht(self):
        assert pruefe_anbieter_bestimmbar("muster ag").bestanden is True

    def test_fehlender_anbieter_faellt_durch(self):
        assert pruefe_anbieter_bestimmbar(None).bestanden is False
        assert pruefe_anbieter_bestimmbar("  ").bestanden is False
