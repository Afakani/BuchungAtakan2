"""Unit-Tests fuer das strukturierte Audit-Booleanmodell (07-03A, HYB-17).

Reine Domainlogik -- kein Datenbankzugriff, kein Datei-IO.
"""
from dataclasses import fields
from datetime import datetime, timezone
from uuid import UUID, uuid4

import pytest

from packages.core.invoice_extraction.hybrid_audit import (
    AUDIT_FELDER,
    AuditBewertungFelder,
    BewertungEintrag,
    berechne_gesamtergebnis_korrekt,
    waehle_neueste_bewertung,
)


def _felder(**overrides) -> AuditBewertungFelder:
    defaults = dict(
        rechnungsnummer_korrekt=True,
        rechnungsdatum_korrekt=True,
        gesamtbetrag_korrekt=True,
        lieferant_korrekt=True,
        steuerwerte_korrekt=True,
        empfaenger_korrekt=True,
    )
    defaults.update(overrides)
    return AuditBewertungFelder(**defaults)


class TestAuditBewertungFelderNurBoolean:
    def test_akzeptiert_reine_booleanwerte(self):
        felder = _felder()
        assert felder.rechnungsnummer_korrekt is True

    def test_lehnt_string_statt_boolean_ab(self):
        with pytest.raises(TypeError):
            _felder(rechnungsnummer_korrekt="ja")

    def test_lehnt_int_statt_boolean_ab(self):
        """bool ist Unterklasse von int -- 1/0 sind trotzdem keine echten Booleans."""
        with pytest.raises(TypeError):
            _felder(gesamtbetrag_korrekt=1)

    def test_lehnt_none_statt_boolean_ab(self):
        with pytest.raises(TypeError):
            _felder(empfaenger_korrekt=None)

    def test_kein_freitextfeld_vorhanden(self):
        namen = {f.name for f in fields(AuditBewertungFelder)}
        assert namen == set(AUDIT_FELDER)
        for verboten in ("notiz", "kommentar", "freitext", "originalwert", "rechnungsnummer", "betrag"):
            assert verboten not in namen


class TestGesamtergebnisAbleitung:
    def test_alle_felder_korrekt_ergibt_gesamtergebnis_korrekt(self):
        assert berechne_gesamtergebnis_korrekt(_felder()) is True

    def test_ein_falsches_feld_ergibt_gesamtergebnis_fehlerhaft(self):
        assert berechne_gesamtergebnis_korrekt(_felder(steuerwerte_korrekt=False)) is False

    def test_alle_felder_falsch_ergibt_gesamtergebnis_fehlerhaft(self):
        alle_falsch = _felder(**{name: False for name in AUDIT_FELDER})
        assert berechne_gesamtergebnis_korrekt(alle_falsch) is False

    def test_deterministisch_bei_gleichen_eingaben(self):
        felder = _felder(lieferant_korrekt=False)
        assert berechne_gesamtergebnis_korrekt(felder) == berechne_gesamtergebnis_korrekt(felder)


def _eintrag(id_int: int, bewertet_am: datetime, **felder_overrides) -> BewertungEintrag:
    return BewertungEintrag(
        id=UUID(int=id_int),
        bewertet_am=bewertet_am,
        felder=_felder(**felder_overrides),
    )


class TestNeuesteBewertungGewinnt:
    def test_leere_liste_ergibt_none(self):
        assert waehle_neueste_bewertung([]) is None

    def test_neuester_zeitstempel_gewinnt(self):
        alt = _eintrag(1, datetime(2026, 1, 1, tzinfo=timezone.utc))
        neu = _eintrag(2, datetime(2026, 6, 1, tzinfo=timezone.utc))
        assert waehle_neueste_bewertung([alt, neu]) is neu
        assert waehle_neueste_bewertung([neu, alt]) is neu

    def test_gleichstand_bei_zeitstempel_hoechste_id_gewinnt(self):
        zeitpunkt = datetime(2026, 6, 1, tzinfo=timezone.utc)
        niedrige_id = _eintrag(1, zeitpunkt)
        hohe_id = _eintrag(2, zeitpunkt)
        assert waehle_neueste_bewertung([niedrige_id, hohe_id]) is hohe_id
        assert waehle_neueste_bewertung([hohe_id, niedrige_id]) is hohe_id

    def test_reihenfolge_der_eingabe_beeinflusst_ergebnis_nicht(self):
        e1 = _eintrag(1, datetime(2026, 1, 1, tzinfo=timezone.utc))
        e2 = _eintrag(2, datetime(2026, 2, 1, tzinfo=timezone.utc))
        e3 = _eintrag(3, datetime(2026, 3, 1, tzinfo=timezone.utc))
        assert waehle_neueste_bewertung([e1, e2, e3]) is e3
        assert waehle_neueste_bewertung([e3, e1, e2]) is e3
        assert waehle_neueste_bewertung([e2, e3, e1]) is e3

    def test_zufaellige_uuid_reihenfolge_wird_korrekt_verglichen(self):
        zeitpunkt = datetime(2026, 6, 1, tzinfo=timezone.utc)
        a = BewertungEintrag(id=uuid4(), bewertet_am=zeitpunkt, felder=_felder())
        b = BewertungEintrag(id=uuid4(), bewertet_am=zeitpunkt, felder=_felder())
        erwartet = a if a.id > b.id else b
        assert waehle_neueste_bewertung([a, b]) is erwartet
