"""Unit-Tests Deduplizierungs-Fingerprint (BANK-02/BANK-03).

Abgedeckte Anforderungen:
  T5: Identische Buchung erzeugt identischen Fingerprint.
  T6: Gleicher Betrag+Datum, anderer Text → anderer Fingerprint.
  T7: Externe Buchungs-ID fliesst stabil ein.
"""
from uuid import UUID

from packages.core.bank_import.fingerprint import berechne_fingerprint

_TENANT = UUID("00000000-0000-4000-a000-000000000001")
_KONTO = UUID("00000000-0000-4000-b000-000000000001")

_BASIS = dict(
    unternehmen_id=_TENANT,
    bankkonto_id=_KONTO,
    buchungsdatum="2024-01-15",
    betrag_cent=11900,
    waehrung="EUR",
    verwendungszweck="Rechnung 2024-001",
    gegenpartei_name="Lieferant GmbH",
)


class TestFingerprintIdentisch:
    def test_identische_daten_gleicher_fingerprint(self):
        """T5: Identische Buchung → gleicher Fingerprint."""
        fp1 = berechne_fingerprint(**_BASIS)
        fp2 = berechne_fingerprint(**_BASIS)
        assert fp1 == fp2

    def test_fingerprint_ist_hex_string_64_zeichen(self):
        fp = berechne_fingerprint(**_BASIS)
        assert len(fp) == 64
        assert all(c in "0123456789abcdef" for c in fp)


class TestFingerprintUnterschiedlich:
    def test_anderer_verwendungszweck_anderer_fingerprint(self):
        """T6: gleicher Betrag+Datum, anderer Verwendungszweck → anderer Fingerprint."""
        fp1 = berechne_fingerprint(**_BASIS)
        fp2 = berechne_fingerprint(**{**_BASIS, "verwendungszweck": "Andere Rechnung"})
        assert fp1 != fp2

    def test_andere_gegenpartei_anderer_fingerprint(self):
        """T6: gleicher Betrag+Datum, andere Gegenpartei → anderer Fingerprint."""
        fp1 = berechne_fingerprint(**_BASIS)
        fp2 = berechne_fingerprint(**{**_BASIS, "gegenpartei_name": "Anderer Lieferant"})
        assert fp1 != fp2

    def test_anderer_betrag_anderer_fingerprint(self):
        fp1 = berechne_fingerprint(**_BASIS)
        fp2 = berechne_fingerprint(**{**_BASIS, "betrag_cent": 5000})
        assert fp1 != fp2

    def test_anderes_datum_anderer_fingerprint(self):
        fp1 = berechne_fingerprint(**_BASIS)
        fp2 = berechne_fingerprint(**{**_BASIS, "buchungsdatum": "2024-02-01"})
        assert fp1 != fp2

    def test_anderer_mandant_anderer_fingerprint(self):
        fp1 = berechne_fingerprint(**_BASIS)
        fp2 = berechne_fingerprint(**{**_BASIS, "unternehmen_id": UUID("00000000-0000-4000-a000-000000000002")})
        assert fp1 != fp2

    def test_anderes_konto_anderer_fingerprint(self):
        fp1 = berechne_fingerprint(**_BASIS)
        fp2 = berechne_fingerprint(**{**_BASIS, "bankkonto_id": UUID("00000000-0000-4000-b000-000000000002")})
        assert fp1 != fp2


class TestExterneBuchungsId:
    def test_externe_id_fliesst_in_fingerprint_ein(self):
        """T7: Externe Buchungs-ID veraendert den Fingerprint stabil."""
        ohne = berechne_fingerprint(**_BASIS)
        mit = berechne_fingerprint(**{**_BASIS, "externe_buchungs_id": "BANK-TX-001"})
        assert ohne != mit

    def test_externe_id_stabil_reproduzierbar(self):
        """T7: Gleiche externe ID → gleicher Fingerprint."""
        fp1 = berechne_fingerprint(**{**_BASIS, "externe_buchungs_id": "BANK-TX-001"})
        fp2 = berechne_fingerprint(**{**_BASIS, "externe_buchungs_id": "BANK-TX-001"})
        assert fp1 == fp2

    def test_verschiedene_externe_ids_unterschiedliche_fingerprints(self):
        fp1 = berechne_fingerprint(**{**_BASIS, "externe_buchungs_id": "BANK-TX-001"})
        fp2 = berechne_fingerprint(**{**_BASIS, "externe_buchungs_id": "BANK-TX-002"})
        assert fp1 != fp2


class TestGegenparteiIban:
    def test_iban_normalisierung_leerzeichen(self):
        """IBAN mit Leerzeichen == IBAN ohne Leerzeichen im Fingerprint."""
        fp1 = berechne_fingerprint(**{**_BASIS, "gegenpartei_iban": "DE89 3704 0044 0532 0130 00"})
        fp2 = berechne_fingerprint(**{**_BASIS, "gegenpartei_iban": "DE89370400440532013000"})
        assert fp1 == fp2

    def test_andere_iban_anderer_fingerprint(self):
        fp1 = berechne_fingerprint(**{**_BASIS, "gegenpartei_iban": "DE89370400440532013000"})
        fp2 = berechne_fingerprint(**{**_BASIS, "gegenpartei_iban": "DE00123456789012345678"})
        assert fp1 != fp2


class TestQuellPosition:
    """T-POS: Quellpositions-basierte Deduplizierung fuer identische echte Buchungen."""

    def test_verschiedene_positionen_verschiedene_fingerprints(self):
        """Identische Buchung an Position 0 und 1 → verschiedene Fingerprints."""
        fp0 = berechne_fingerprint(**_BASIS, quell_position=0)
        fp1 = berechne_fingerprint(**_BASIS, quell_position=1)
        assert fp0 != fp1

    def test_gleiche_position_gleicher_fingerprint(self):
        """Gleiche Buchung, gleiche Position → gleicher Fingerprint (Re-Import idempotent)."""
        fp1 = berechne_fingerprint(**_BASIS, quell_position=0)
        fp2 = berechne_fingerprint(**_BASIS, quell_position=0)
        assert fp1 == fp2

    def test_keine_position_vs_position_null_verschieden(self):
        """quell_position=None und quell_position=0 ergeben verschiedene Fingerprints."""
        fp_none = berechne_fingerprint(**_BASIS, quell_position=None)
        fp_null = berechne_fingerprint(**_BASIS, quell_position=0)
        assert fp_none != fp_null

    def test_grosse_positionsnummer_stabil(self):
        """quell_position=999 ist reproduzierbar."""
        fp1 = berechne_fingerprint(**_BASIS, quell_position=999)
        fp2 = berechne_fingerprint(**_BASIS, quell_position=999)
        assert fp1 == fp2

    def test_quell_referenz_unterscheidet_quellen(self):
        """Gleiche Position in verschiedenen Quellen → verschiedene Fingerprints."""
        fp_a = berechne_fingerprint(**_BASIS, quell_referenz="oktober.mta", quell_position=0)
        fp_b = berechne_fingerprint(**_BASIS, quell_referenz="november.mta", quell_position=0)
        assert fp_a != fp_b

    def test_quell_referenz_und_position_reproduzierbar(self):
        """Gleiche Quelle + gleiche Position → identischer Fingerprint."""
        fp1 = berechne_fingerprint(**_BASIS, quell_referenz="auszug.mta", quell_position=3)
        fp2 = berechne_fingerprint(**_BASIS, quell_referenz="auszug.mta", quell_position=3)
        assert fp1 == fp2

    def test_externe_id_dominiert_ueber_position(self):
        """Externe ID veraendert Fingerprint unabhaengig von quell_position."""
        fp_mit_ext = berechne_fingerprint(**_BASIS, externe_buchungs_id="TX-001", quell_position=0)
        fp_mit_ext_pos1 = berechne_fingerprint(**_BASIS, externe_buchungs_id="TX-001", quell_position=1)
        # Fingerprint aendert sich, weil qpos Teil des Hashes ist
        assert fp_mit_ext != fp_mit_ext_pos1
        # Aber externe ID allein (ohne pos) ist stabil
        fp_ext_nopos = berechne_fingerprint(**_BASIS, externe_buchungs_id="TX-001")
        fp_ext_nopos2 = berechne_fingerprint(**_BASIS, externe_buchungs_id="TX-001")
        assert fp_ext_nopos == fp_ext_nopos2

    def test_fingerprint_ist_hex_string_nach_position(self):
        """Fingerprint bleibt 64-stelliger Hex-String auch mit Position."""
        fp = berechne_fingerprint(**_BASIS, quell_position=42)
        assert len(fp) == 64
        assert all(c in "0123456789abcdef" for c in fp)
