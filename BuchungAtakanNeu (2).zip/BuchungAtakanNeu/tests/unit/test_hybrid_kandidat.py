"""Unit-Tests fuer HybridKandidat (HYB-03/04)."""
import pytest

from packages.core.invoice_extraction.hybrid_kandidat import (
    AuswahlStatus,
    HybridKandidat,
    from_kandidat,
)
from packages.core.invoice_extraction.kandidat import Kandidat, KandidatQuelle


def _kandidat(**kwargs) -> HybridKandidat:
    defaults = dict(
        feld="invoice_number",
        rohwert="RE-001",
        normwert="RE-001",
        methode="regex_label",
        provider_name="pdfplumber",
        provider_version="1.0",
        confidence=0.9,
    )
    defaults.update(kwargs)
    return HybridKandidat(**defaults)


class TestHybridKandidatErstellen:
    def test_vollstaendig_ok(self):
        k = _kandidat()
        assert k.feld == "invoice_number"
        assert k.confidence == 0.9
        assert k.auswahl_status is None

    def test_frozen_unveraenderlich(self):
        k = _kandidat()
        with pytest.raises(AttributeError):
            k.feld = "anderes_feld"  # type: ignore[misc]

    def test_feld_leer_fehler(self):
        with pytest.raises(ValueError, match="feld"):
            _kandidat(feld="")

    def test_rohwert_none_fehler(self):
        with pytest.raises((ValueError, TypeError)):
            _kandidat(rohwert=None)  # type: ignore[arg-type]

    def test_confidence_zu_hoch_fehler(self):
        with pytest.raises(ValueError, match="confidence"):
            _kandidat(confidence=1.1)

    def test_confidence_negativ_fehler(self):
        with pytest.raises(ValueError, match="confidence"):
            _kandidat(confidence=-0.01)

    def test_methode_leer_fehler(self):
        with pytest.raises(ValueError, match="methode"):
            _kandidat(methode="")

    def test_provider_name_leer_fehler(self):
        with pytest.raises(ValueError, match="provider_name"):
            _kandidat(provider_name="")

    def test_confidence_grenzen_ok(self):
        assert _kandidat(confidence=0.0).confidence == 0.0
        assert _kandidat(confidence=1.0).confidence == 1.0


class TestAuswahlStatus:
    def test_alle_werte_vorhanden(self):
        assert AuswahlStatus.AUSGEWAEHLT == "AUSGEWAEHLT"
        assert AuswahlStatus.ABGELEHNT == "ABGELEHNT"
        assert AuswahlStatus.KONFLIKT == "KONFLIKT"
        assert AuswahlStatus.UNSICHER == "UNSICHER"

    def test_auswahl_status_setzen(self):
        k = _kandidat(auswahl_status=AuswahlStatus.KONFLIKT, auswahl_grund="Widerspruch Provider A/B")
        assert k.auswahl_status == AuswahlStatus.KONFLIKT
        assert k.auswahl_grund == "Widerspruch Provider A/B"

    def test_konflikt_gruppe(self):
        k = _kandidat(konflikt_gruppe="GRUPPE-1")
        assert k.konflikt_gruppe == "GRUPPE-1"


class TestHybridKandidatErweiterteFelder:
    def test_seite_optional(self):
        k = _kandidat(seite=2)
        assert k.seite == 2

    def test_bbox_optional(self):
        k = _kandidat(bbox={"x0": 10, "y0": 20, "x1": 100, "y1": 40})
        assert k.bbox is not None
        assert k.bbox["x0"] == 10

    def test_validierungsbefund_optional(self):
        k = _kandidat(validierungsbefund="PLAUSIBEL")
        assert k.validierungsbefund == "PLAUSIBEL"

    def test_provider_version_none_erlaubt(self):
        k = _kandidat(provider_version=None)
        assert k.provider_version is None


class TestFromKandidatAdapter:
    def _legacy(self, **kwargs) -> Kandidat:
        defaults = dict(
            feld="vendor_name",
            rohwert="Muster GmbH",
            normwert="Muster GmbH",
            methode="regex_label",
            quelle=KandidatQuelle.PDF_TEXT,
            confidence=0.8,
        )
        defaults.update(kwargs)
        return Kandidat(**defaults)

    def test_konvertierung_grundfelder(self):
        legacy = self._legacy()
        hybrid = from_kandidat(legacy)
        assert hybrid.feld == legacy.feld
        assert hybrid.rohwert == legacy.rohwert
        assert hybrid.normwert == legacy.normwert
        assert hybrid.methode == legacy.methode
        assert hybrid.confidence == legacy.confidence
        assert hybrid.provider_name == str(KandidatQuelle.PDF_TEXT)

    def test_konvertierung_mit_version(self):
        legacy = self._legacy()
        hybrid = from_kandidat(legacy, provider_version="2.0")
        assert hybrid.provider_version == "2.0"

    def test_explizites_provider_name_ueberschreibt_quelle(self):
        """Regressionsschutz: ein aufrufender Provider MUSS provider_name setzen
        koennen, damit nicht die Phase-4-KandidatQuelle (z.B. "pdf_text") statt des
        tatsaechlichen Providernamens (z.B. "pdfplumber") landet."""
        legacy = self._legacy(quelle=KandidatQuelle.PDF_TEXT)
        hybrid = from_kandidat(legacy, provider_name="pdfplumber")
        assert hybrid.provider_name == "pdfplumber"

    def test_ohne_explizites_provider_name_faellt_auf_quelle_zurueck(self):
        legacy = self._legacy(quelle=KandidatQuelle.OCR)
        hybrid = from_kandidat(legacy)
        assert hybrid.provider_name == str(KandidatQuelle.OCR)

    def test_konvertierung_mit_seite(self):
        legacy = self._legacy()
        hybrid = from_kandidat(legacy, seite=3)
        assert hybrid.seite == 3

    def test_auswahl_status_initial_none(self):
        legacy = self._legacy()
        hybrid = from_kandidat(legacy)
        assert hybrid.auswahl_status is None
        assert hybrid.auswahl_grund is None
