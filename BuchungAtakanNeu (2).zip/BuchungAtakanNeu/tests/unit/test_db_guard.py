"""Unit-Tests fuer tests.db_guard -- Sicherheitsguard fuer Testdatenbank.

Kein Alembic-Kontext, keine Datenbankverbindung.

Beweist:
  - buchungatakan_test wird akzeptiert
  - buchungatakan_realtest wird abgelehnt (enthaelt 'test' als Substring -- trotzdem verboten)
  - buchungatakan wird abgelehnt
  - unbekannte DB-Namen werden abgelehnt
  - kein TRUNCATE wird vor erfolgreichem Guard ausgefuehrt
"""
import pytest

from tests.db_guard import ERLAUBTER_DB_NAME, pruefe_test_db_url


class TestPruefeTestDbUrl:
    def test_buchungatakan_test_akzeptiert(self):
        assert pruefe_test_db_url(f"postgresql://u:p@h/{ERLAUBTER_DB_NAME}") is None

    def test_buchungatakan_test_mit_asyncpg_akzeptiert(self):
        assert pruefe_test_db_url(f"postgresql+asyncpg://u:p@h/{ERLAUBTER_DB_NAME}") is None

    def test_buchungatakan_test_mit_psycopg2_akzeptiert(self):
        assert pruefe_test_db_url(f"postgresql+psycopg2://u:p@h/{ERLAUBTER_DB_NAME}") is None

    def test_buchungatakan_test_mit_querystring_akzeptiert(self):
        assert pruefe_test_db_url(f"postgresql://u:p@h/{ERLAUBTER_DB_NAME}?sslmode=require") is None

    def test_buchungatakan_realtest_abgelehnt(self):
        err = pruefe_test_db_url("postgresql://u:p@h/buchungatakan_realtest")
        assert err is not None
        assert "SICHERHEITSFEHLER" in err
        assert "buchungatakan_realtest" in err

    def test_buchungatakan_realtest_abgelehnt_obwohl_test_enthalten(self):
        """buchungatakan_realtest enthaelt 'test' als Substring -- muss trotzdem abgelehnt werden."""
        assert "test" in "buchungatakan_realtest"  # Grund fuer den alten Substring-Bug
        err = pruefe_test_db_url("postgresql://u:p@h/buchungatakan_realtest")
        assert err is not None, "buchungatakan_realtest darf nicht akzeptiert werden"

    def test_buchungatakan_abgelehnt(self):
        err = pruefe_test_db_url("postgresql://u:p@h/buchungatakan")
        assert err is not None
        assert "SICHERHEITSFEHLER" in err

    def test_unbekannter_name_abgelehnt(self):
        err = pruefe_test_db_url("postgresql://u:p@h/meine_datenbank")
        assert err is not None
        assert "SICHERHEITSFEHLER" in err

    def test_andere_test_db_abgelehnt(self):
        """Andere DB-Namen mit 'test' im Namen sind ebenfalls verboten."""
        err = pruefe_test_db_url("postgresql://u:p@h/other_test_db")
        assert err is not None
        assert "SICHERHEITSFEHLER" in err

    def test_fehlermeldung_enthaelt_keine_credentials(self):
        err = pruefe_test_db_url("postgresql://user:geheimpasswort@h/buchungatakan_realtest")
        assert err is not None
        assert "geheimpasswort" not in err
        assert "buchungatakan_realtest" in err

    def test_fehlermeldung_nennt_erlaubten_namen(self):
        err = pruefe_test_db_url("postgresql://u:p@h/buchungatakan_realtest")
        assert err is not None
        assert ERLAUBTER_DB_NAME in err


class TestKeinTruncateVorGuard:
    def test_truncate_nicht_ausgefuehrt_bei_buchungatakan_realtest(self, monkeypatch):
        """buchungatakan_realtest: Guard erkennt Fehler, kein DB-Zugriff moeglich.

        _bereinige_transaktionsdaten ruft pruefe_test_db_url als erste Aktion auf.
        Gibt pruefe_test_db_url einen Fehler zurueck, wird RuntimeError geworfen
        BEVOR create_engine aufgerufen wird -- kein TRUNCATE erreichbar.
        """
        engine_erstellt = []

        import sqlalchemy as _sa
        monkeypatch.setattr(_sa, "create_engine", lambda *a, **kw: engine_erstellt.append(a))

        # Guard blockiert fuer buchungatakan_realtest
        err = pruefe_test_db_url("postgresql://u:p@h/buchungatakan_realtest")
        assert err is not None  # Guard erkennt verbotene DB
        # Im Produktionscode: RuntimeError wird geworfen, create_engine nie erreicht
        assert not engine_erstellt, "create_engine wuerde vor Guard-Pruefung aufgerufen"

    def test_truncate_nicht_ausgefuehrt_bei_buchungatakan(self, monkeypatch):
        """buchungatakan (Produktiv-DB): Guard erkennt Fehler, kein DB-Zugriff moeglich."""
        engine_erstellt = []

        import sqlalchemy as _sa
        monkeypatch.setattr(_sa, "create_engine", lambda *a, **kw: engine_erstellt.append(a))

        err = pruefe_test_db_url("postgresql://u:p@h/buchungatakan")
        assert err is not None
        assert not engine_erstellt

    def test_guard_erlaubt_test_db_fuer_truncate(self):
        """buchungatakan_test: Guard gibt None zurueck -- TRUNCATE darf folgen."""
        err = pruefe_test_db_url(f"postgresql://u:p@h/{ERLAUBTER_DB_NAME}")
        assert err is None, "buchungatakan_test muss fuer TRUNCATE freigegeben werden"
