"""Unit-Tests fuer auth/dependencies.py -- kein DB-Zugriff."""
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from fastapi import HTTPException

from apps.server.auth.dependencies import get_current_user
from apps.server.auth.service import create_access_token
from apps.server.models.benutzer import Benutzer, Rolle

TENANT = uuid4()
USER_ID = uuid4()


def _make_token(sub=None, unternehmen_id=None, rolle="LESER"):
    return create_access_token(
        sub=str(sub or USER_ID),
        unternehmen_id=str(unternehmen_id or TENANT),
        rolle=rolle,
    )


def _mock_benutzer(aktiv=True):
    return Benutzer(id=USER_ID, unternehmen_id=TENANT, rolle=Rolle.LESER, aktiv=aktiv)


def _mock_session():
    return AsyncMock()


# ── get_current_user: normaler Pfad ──────────────────────────────────────────

@pytest.mark.asyncio
async def test_get_current_user_gibt_benutzer_zurueck():
    token = _make_token()
    user = _mock_benutzer()
    session = _mock_session()

    with patch(
        "apps.server.repositories.benutzer.BenutzerRepository.get_by_id_raw",
        new=AsyncMock(return_value=user),
    ) as mock_repo:
        result = await get_current_user(token=token, session=session)

    assert result is user
    mock_repo.assert_called_once()
    _, call_kwargs = mock_repo.call_args
    # Positional args: (session, id, unternehmen_id)
    call_args_pos = mock_repo.call_args[0]
    assert str(call_args_pos[1]) == str(USER_ID)
    assert str(call_args_pos[2]) == str(TENANT)


@pytest.mark.asyncio
async def test_get_current_user_uebergibt_unternehmen_id_aus_jwt():
    """get_current_user muss unternehmen_id aus JWT an Repository weitergeben."""
    other_tenant = uuid4()
    token = _make_token(unternehmen_id=other_tenant)
    session = _mock_session()

    with patch(
        "apps.server.repositories.benutzer.BenutzerRepository.get_by_id_raw",
        new=AsyncMock(return_value=None),
    ) as mock_repo:
        with pytest.raises(HTTPException) as exc_info:
            await get_current_user(token=token, session=session)

    assert exc_info.value.status_code == 401
    call_args_pos = mock_repo.call_args[0]
    # unternehmen_id aus Token muss an Repo weitergereicht werden
    assert str(call_args_pos[2]) == str(other_tenant)


# ── get_current_user: Cross-Tenant-Schutz ───────────────────────────────────

@pytest.mark.asyncio
async def test_get_current_user_wirft_401_wenn_benutzer_nicht_gefunden():
    token = _make_token()
    session = _mock_session()

    with patch(
        "apps.server.repositories.benutzer.BenutzerRepository.get_by_id_raw",
        new=AsyncMock(return_value=None),
    ):
        with pytest.raises(HTTPException) as exc_info:
            await get_current_user(token=token, session=session)

    assert exc_info.value.status_code == 401


@pytest.mark.asyncio
async def test_get_current_user_cross_tenant_schlaegt_fehl():
    """Token mit fremder unternehmen_id darf keinen Benutzer liefern."""
    foreign_tenant = uuid4()
    # Token behauptet foreign_tenant -- Repo gibt None zurueck (unternehmen_id passt nicht)
    token = _make_token(unternehmen_id=foreign_tenant)
    session = _mock_session()

    with patch(
        "apps.server.repositories.benutzer.BenutzerRepository.get_by_id_raw",
        new=AsyncMock(return_value=None),
    ):
        with pytest.raises(HTTPException) as exc_info:
            await get_current_user(token=token, session=session)

    assert exc_info.value.status_code == 401


# ── get_current_user: Token-Fehler ───────────────────────────────────────────

@pytest.mark.asyncio
async def test_get_current_user_wirft_401_bei_fehlendem_sub():
    """Token ohne 'sub'-Claim → 401."""
    import jwt as pyjwt
    from apps.server.config import settings
    token = pyjwt.encode(
        {"unternehmen_id": str(TENANT), "rolle": "LESER"},
        settings.SECRET_KEY,
        algorithm=settings.ALGORITHM,
    )
    session = _mock_session()
    with pytest.raises(HTTPException) as exc_info:
        await get_current_user(token=token, session=session)
    assert exc_info.value.status_code == 401


@pytest.mark.asyncio
async def test_get_current_user_wirft_401_bei_fehlendem_unternehmen_id():
    """Token ohne 'unternehmen_id'-Claim → 401 (tenantloser Lookup verboten)."""
    import jwt as pyjwt
    from apps.server.config import settings
    token = pyjwt.encode(
        {"sub": str(USER_ID), "rolle": "LESER"},
        settings.SECRET_KEY,
        algorithm=settings.ALGORITHM,
    )
    session = _mock_session()
    with pytest.raises(HTTPException) as exc_info:
        await get_current_user(token=token, session=session)
    assert exc_info.value.status_code == 401


@pytest.mark.asyncio
async def test_get_current_user_wirft_401_bei_ungueltigem_token():
    session = _mock_session()
    with pytest.raises(HTTPException) as exc_info:
        await get_current_user(token="ungueltig.token.hier", session=session)
    assert exc_info.value.status_code == 401
