"""Unit-Tests fuer RechnungRepository — Versionierungslogik ohne echte DB (RECH-08/09)."""
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock, call
from uuid import uuid4, UUID

from fastapi import HTTPException
import pytest

from apps.server.models.rechnung import Erkennungslauf, Rechnung, RechnungsStatus
from apps.server.repositories.rechnung import (
    RechnungRepository,
    _neue_version_ist_aktiv,
    _parse_datum,
)

TENANT_A = uuid4()
TENANT_B = uuid4()
DOK_ID = uuid4()


# ── Hilfs-Fabriken ────────────────────────────────────────────────────────────

def _mock_session(*scalar_results) -> AsyncMock:
    """
    Erzeugt AsyncMock-Session mit vordefinierten execute()-Rückgabewerten.
    Für einen Wert: session.execute.return_value.
    Für mehrere: session.execute.side_effect (sequenziell).
    add() ist explizit MagicMock (synchron in SQLAlchemy).
    """
    session = AsyncMock()
    session.add = MagicMock()
    if len(scalar_results) == 1:
        mr = MagicMock()
        mr.scalar_one_or_none.return_value = scalar_results[0]
        session.execute.return_value = mr
    else:
        side = []
        for sr in scalar_results:
            mr = MagicMock()
            mr.scalar_one_or_none.return_value = sr
            side.append(mr)
        session.execute.side_effect = side
    return session


def _mock_session_scalars(items: list) -> AsyncMock:
    """Session-Mock für list_*-Methoden (scalars().all())."""
    session = AsyncMock()
    mr = MagicMock()
    mr.scalars.return_value.all.return_value = items
    session.execute.return_value = mr
    return session


def _vorhandene_rechnung(
    rechnungsdatum: str = "01.01.2024",
    version_lfd_nr: int = 1,
) -> Rechnung:
    return Rechnung(
        unternehmen_id=TENANT_A,
        dokument_id=DOK_ID,
        rechnungsnummer="2024-001",
        rechnungsdatum=rechnungsdatum,
        version_lfd_nr=version_lfd_nr,
        ist_aktiv=True,
        status="NEU",
    )


def _erkennungslauf(rechnung_id: UUID | None = None) -> Erkennungslauf:
    e = Erkennungslauf(
        unternehmen_id=TENANT_A,
        dokument_id=DOK_ID,
        extraktion_status="OK",
        fehler=None,
    )
    e.id = uuid4()  # type: ignore[assignment]
    e.rechnung_id = rechnung_id  # type: ignore[assignment]
    e.extraktion_confidence = None  # type: ignore[assignment]
    return e


# ── _parse_datum ──────────────────────────────────────────────────────────────

def test_parse_datum_gueltig():
    assert _parse_datum("15.01.2024") == datetime(2024, 1, 15)


def test_parse_datum_mit_leerzeichen():
    assert _parse_datum("  01.06.2024  ") == datetime(2024, 6, 1)


def test_parse_datum_ungueltig():
    assert _parse_datum("abc") is None
    assert _parse_datum("2024-01-15") is None
    assert _parse_datum("32.13.2024") is None


def test_parse_datum_leer():
    assert _parse_datum(None) is None
    assert _parse_datum("") is None


# ── _neue_version_ist_aktiv ───────────────────────────────────────────────────

def test_neueres_datum_gewinnt():
    assert _neue_version_ist_aktiv(datetime(2024, 1, 1), datetime(2024, 6, 1)) is True


def test_aelteres_datum_verliert():
    assert _neue_version_ist_aktiv(datetime(2024, 6, 1), datetime(2024, 1, 1)) is False


def test_gleiches_datum_last_write_wins():
    datum = datetime(2024, 3, 15)
    assert _neue_version_ist_aktiv(datum, datum) is True


def test_neues_datum_fehlt_vorhandenes_gueltig_schuetzt_aktive():
    """Fehlendes neues Datum darf gültige aktive Rechnung NICHT ersetzen."""
    assert _neue_version_ist_aktiv(datetime(2024, 1, 1), None) is False


def test_neues_datum_vorhanden_vorhandenes_fehlt_neue_gewinnt():
    """Neue Rechnung hat Datum, vorhandene nicht → neue gewinnt."""
    assert _neue_version_ist_aktiv(None, datetime(2024, 1, 1)) is True


def test_beide_none_last_write_wins():
    """Beide ohne Datum → last-write-wins (kein Vergleich möglich)."""
    assert _neue_version_ist_aktiv(None, None) is True


# ── _baue_neue_version — reine Logik ─────────────────────────────────────────

def test_baue_neue_version_erstimport():
    repo = RechnungRepository()
    felder = {"rechnungsnummer": "2024-001", "rechnungsdatum": "01.01.2024"}
    neue, alte_deaktivieren = repo._baue_neue_version(
        TENANT_A, DOK_ID, felder, RechnungsStatus.NEU, None
    )
    assert neue.version_lfd_nr == 1
    assert neue.ist_aktiv is True
    assert alte_deaktivieren is False
    assert neue.unternehmen_id == TENANT_A
    assert neue.rechnungsnummer == "2024-001"
    assert neue.status == "NEU"


def test_baue_neue_version_neueres_datum_gewinnt():
    repo = RechnungRepository()
    vorhandene = _vorhandene_rechnung("01.01.2024")
    felder = {"rechnungsnummer": "2024-001", "rechnungsdatum": "15.06.2024"}
    neue, alte_deaktivieren = repo._baue_neue_version(
        TENANT_A, DOK_ID, felder, RechnungsStatus.NEU, vorhandene
    )
    assert neue.version_lfd_nr == 2
    assert neue.ist_aktiv is True
    assert alte_deaktivieren is True


def test_baue_neue_version_aelteres_datum_inaktive_historienzeile():
    repo = RechnungRepository()
    vorhandene = _vorhandene_rechnung("15.06.2024")
    felder = {"rechnungsnummer": "2024-001", "rechnungsdatum": "01.01.2024"}
    neue, alte_deaktivieren = repo._baue_neue_version(
        TENANT_A, DOK_ID, felder, RechnungsStatus.NEU, vorhandene
    )
    assert neue.version_lfd_nr == 2
    assert neue.ist_aktiv is False
    assert alte_deaktivieren is False


def test_baue_neue_version_gleiches_datum_last_write_wins():
    repo = RechnungRepository()
    vorhandene = _vorhandene_rechnung("01.03.2024")
    felder = {"rechnungsnummer": "2024-001", "rechnungsdatum": "01.03.2024"}
    neue, alte_deaktivieren = repo._baue_neue_version(
        TENANT_A, DOK_ID, felder, RechnungsStatus.NEU, vorhandene
    )
    assert neue.version_lfd_nr == 2
    assert neue.ist_aktiv is True
    assert alte_deaktivieren is True


def test_baue_neue_version_fehlendes_datum_bei_vorhandenem_datum_inaktiv():
    """Neues Datum fehlt, vorhandene hat gültiges Datum → neue Version INAKTIV."""
    repo = RechnungRepository()
    vorhandene = _vorhandene_rechnung("15.06.2024")
    felder = {"rechnungsnummer": "2024-001"}  # kein rechnungsdatum
    neue, alte_deaktivieren = repo._baue_neue_version(
        TENANT_A, DOK_ID, felder, RechnungsStatus.NEU, vorhandene
    )
    assert neue.ist_aktiv is False
    assert alte_deaktivieren is False  # vorhandene bleibt aktiv


def test_baue_neue_version_ungueltige_datum_bei_vorhandenem_datum_inaktiv():
    """Ungültiges neues Datum (Parse→None) ersetzt keine gültige aktive Version."""
    repo = RechnungRepository()
    vorhandene = _vorhandene_rechnung("15.06.2024")
    felder = {"rechnungsnummer": "2024-001", "rechnungsdatum": "nicht-ein-datum"}
    neue, alte_deaktivieren = repo._baue_neue_version(
        TENANT_A, DOK_ID, felder, RechnungsStatus.NEU, vorhandene
    )
    assert neue.ist_aktiv is False
    assert alte_deaktivieren is False


def test_baue_neue_version_prueffall_status_weitergereicht():
    repo = RechnungRepository()
    felder = {"lieferant_name": "Muster GmbH"}
    neue, _ = repo._baue_neue_version(
        TENANT_A, DOK_ID, felder, RechnungsStatus.PRUEFFALL, None
    )
    assert neue.status == "PRUEFFALL"


def test_baue_neue_version_erhoeht_version_lfd_nr():
    repo = RechnungRepository()
    vorhandene = _vorhandene_rechnung("01.01.2024", version_lfd_nr=3)
    felder = {"rechnungsnummer": "2024-001", "rechnungsdatum": "01.06.2024"}
    neue, _ = repo._baue_neue_version(TENANT_A, DOK_ID, felder, RechnungsStatus.NEU, vorhandene)
    assert neue.version_lfd_nr == 4


# ── SQL-Filterprüfungen (Statement-Inspektion) ────────────────────────────────

async def test_list_aktive_query_enthaelt_tenant_und_ist_aktiv_filter():
    """list_aktive() muss unternehmen_id UND ist_aktiv=True im WHERE haben."""
    repo = RechnungRepository()
    session = _mock_session_scalars([])
    await repo.list_aktive(session, TENANT_A)
    stmt = session.execute.call_args.args[0]
    sql = str(stmt)
    assert "unternehmen_id" in sql
    assert "ist_aktiv" in sql


async def test_get_aktive_by_nummer_query_enthaelt_alle_filter():
    """get_aktive_by_nummer() muss unternehmen_id, rechnungsnummer, ist_aktiv filtern."""
    repo = RechnungRepository()
    session = _mock_session(None)
    await repo.get_aktive_by_nummer(session, "2024-001", TENANT_A)
    stmt = session.execute.call_args.args[0]
    sql = str(stmt)
    assert "unternehmen_id" in sql
    assert "rechnungsnummer" in sql
    assert "ist_aktiv" in sql


async def test_list_erkennungslaeufe_query_enthaelt_tenant_und_rechnung_filter():
    """list_erkennungslaeufe() muss unternehmen_id UND rechnung_id filtern."""
    repo = RechnungRepository()
    session = _mock_session_scalars([])
    rechnung_id = uuid4()
    await repo.list_erkennungslaeufe(session, rechnung_id, TENANT_A)
    stmt = session.execute.call_args.args[0]
    sql = str(stmt)
    assert "unternehmen_id" in sql
    assert "rechnung_id" in sql


async def test_get_erkennungslauf_by_id_query_enthaelt_tenant_filter():
    """_get_erkennungslauf_by_id() muss unternehmen_id im WHERE haben."""
    repo = RechnungRepository()
    elauf = _erkennungslauf()
    session = _mock_session(elauf)
    await repo._get_erkennungslauf_by_id(session, elauf.id, TENANT_A)
    stmt = session.execute.call_args.args[0]
    sql = str(stmt)
    assert "unternehmen_id" in sql


# ── create_version mit gemockter Session ──────────────────────────────────────

async def test_create_version_erstimport_keine_vorhandene():
    repo = RechnungRepository()
    session = _mock_session(None)
    felder = {"rechnungsnummer": "2024-001", "rechnungsdatum": "01.01.2024"}
    rechnung = await repo.create_version(session, TENANT_A, DOK_ID, felder)
    assert rechnung.version_lfd_nr == 1
    assert rechnung.ist_aktiv is True
    session.add.assert_called_once_with(rechnung)
    session.flush.assert_awaited_once()
    session.commit.assert_awaited_once()


async def test_create_version_neueres_datum_deaktiviert_alte():
    repo = RechnungRepository()
    vorhandene = _vorhandene_rechnung("01.01.2024")
    session = _mock_session(vorhandene)
    felder = {"rechnungsnummer": "2024-001", "rechnungsdatum": "15.06.2024"}
    neue = await repo.create_version(session, TENANT_A, DOK_ID, felder)
    assert neue.version_lfd_nr == 2
    assert neue.ist_aktiv is True
    assert vorhandene.ist_aktiv is False


async def test_create_version_aelteres_datum_bleibt_vorhandene_aktiv():
    repo = RechnungRepository()
    vorhandene = _vorhandene_rechnung("15.06.2024")
    session = _mock_session(vorhandene)
    felder = {"rechnungsnummer": "2024-001", "rechnungsdatum": "01.01.2024"}
    neue = await repo.create_version(session, TENANT_A, DOK_ID, felder)
    assert neue.ist_aktiv is False
    assert vorhandene.ist_aktiv is True


async def test_create_version_fehlendes_datum_schuetzt_aktive():
    """Fehlendes neues Datum darf aktive Rechnung mit gültigem Datum nicht ersetzen."""
    repo = RechnungRepository()
    vorhandene = _vorhandene_rechnung("15.06.2024")
    session = _mock_session(vorhandene)
    felder = {"rechnungsnummer": "2024-001"}  # kein rechnungsdatum
    neue = await repo.create_version(session, TENANT_A, DOK_ID, felder)
    assert neue.ist_aktiv is False
    assert vorhandene.ist_aktiv is True


async def test_create_version_gleiches_datum_last_write_wins():
    repo = RechnungRepository()
    vorhandene = _vorhandene_rechnung("01.03.2024")
    session = _mock_session(vorhandene)
    felder = {"rechnungsnummer": "2024-001", "rechnungsdatum": "01.03.2024"}
    neue = await repo.create_version(session, TENANT_A, DOK_ID, felder)
    assert neue.ist_aktiv is True
    assert vorhandene.ist_aktiv is False


async def test_create_version_ohne_rechnungsnummer_kein_duplikatcheck():
    """Ohne Rechnungsnummer wird kein get_aktive_by_nummer ausgeführt."""
    repo = RechnungRepository()
    session = AsyncMock()
    session.add = MagicMock()
    felder = {"lieferant_name": "Muster GmbH"}
    rechnung = await repo.create_version(
        session, TENANT_A, DOK_ID, felder, RechnungsStatus.PRUEFFALL
    )
    assert rechnung.version_lfd_nr == 1
    assert rechnung.ist_aktiv is True
    session.execute.assert_not_called()


# ── Erkennungslauf-Verknüpfung ────────────────────────────────────────────────

async def test_create_version_mit_erkennungslauf_verknuepft():
    """
    Mit erkennungslauf_id: Erkennungslauf mandantensicher laden,
    nach Flush mit Rechnung verknüpfen (rechnung_id setzen).
    """
    repo = RechnungRepository()
    elauf = _erkennungslauf(rechnung_id=None)
    # session.execute: erst Erkennungslauf-Lookup, dann kein vorhandener Aktiver
    session = _mock_session(elauf, None)
    felder = {"rechnungsnummer": "2024-001", "rechnungsdatum": "01.01.2024"}
    neue = await repo.create_version(
        session, TENANT_A, DOK_ID, felder, erkennungslauf_id=elauf.id
    )
    assert neue.ist_aktiv is True
    # Erkennungslauf.rechnung_id muss auf neue.id gesetzt sein
    assert elauf.rechnung_id == neue.id
    session.flush.assert_awaited_once()
    session.commit.assert_awaited_once()


async def test_create_version_erkennungslauf_fremder_mandant_404():
    """Fremder oder nicht vorhandener Erkennungslauf → HTTPException 404."""
    repo = RechnungRepository()
    # execute gibt None zurück → Erkennungslauf nicht gefunden
    session = _mock_session(None)
    felder = {"rechnungsnummer": "2024-001"}
    with pytest.raises(HTTPException) as exc_info:
        await repo.create_version(
            session, TENANT_A, DOK_ID, felder, erkennungslauf_id=uuid4()
        )
    assert exc_info.value.status_code == 404
    # Rechnung darf NICHT angelegt worden sein
    session.add.assert_not_called()


async def test_get_erkennungslauf_by_id_gefunden():
    repo = RechnungRepository()
    elauf = _erkennungslauf()
    session = _mock_session(elauf)
    result = await repo._get_erkennungslauf_by_id(session, elauf.id, TENANT_A)
    assert result is elauf


async def test_get_erkennungslauf_by_id_nicht_gefunden_404():
    repo = RechnungRepository()
    session = _mock_session(None)
    with pytest.raises(HTTPException) as exc_info:
        await repo._get_erkennungslauf_by_id(session, uuid4(), TENANT_A)
    assert exc_info.value.status_code == 404


# ── list_aktive — Ergebnis-Filterung ─────────────────────────────────────────

async def test_list_aktive_gibt_nur_aktive_zurueck():
    repo = RechnungRepository()
    aktive = _vorhandene_rechnung()
    session = _mock_session_scalars([aktive])
    result = await repo.list_aktive(session, TENANT_A)
    assert result == [aktive]
    session.execute.assert_awaited_once()
