"""Unit-Tests fuer Feature-Flags Phase 07 (HYB-01).

Azure-Flag muss default False sein — kein versehentlicher Cloud-Aufruf.
"""
import os


class TestFeatureFlags:
    def test_azure_flag_default_false(self, monkeypatch):
        """Azure-DI darf nie versehentlich aktiv sein (HYB-01/HYB-20)."""
        # Env bereinigen damit kein gesetztes AZURE_DI-Flag das Ergebnis verfaelscht
        monkeypatch.delenv("BUCHUNG_ATAKAN_FEATURE_AZURE_DI", raising=False)
        from importlib import reload
        import apps.server.config as cfg_mod
        reload(cfg_mod)
        settings = cfg_mod.Settings()
        assert settings.BUCHUNG_ATAKAN_FEATURE_AZURE_DI is False

    def test_hybrid_pipeline_default_false(self, monkeypatch):
        monkeypatch.delenv("BUCHUNG_ATAKAN_FEATURE_HYBRID_PIPELINE", raising=False)
        from importlib import reload
        import apps.server.config as cfg_mod
        reload(cfg_mod)
        settings = cfg_mod.Settings()
        assert settings.BUCHUNG_ATAKAN_FEATURE_HYBRID_PIPELINE is False

    def test_invoice2data_default_false(self, monkeypatch):
        monkeypatch.delenv("BUCHUNG_ATAKAN_FEATURE_INVOICE2DATA", raising=False)
        from importlib import reload
        import apps.server.config as cfg_mod
        reload(cfg_mod)
        settings = cfg_mod.Settings()
        assert settings.BUCHUNG_ATAKAN_FEATURE_INVOICE2DATA is False

    def test_paddle_ocr_default_false(self, monkeypatch):
        monkeypatch.delenv("BUCHUNG_ATAKAN_FEATURE_PADDLE_OCR", raising=False)
        from importlib import reload
        import apps.server.config as cfg_mod
        reload(cfg_mod)
        settings = cfg_mod.Settings()
        assert settings.BUCHUNG_ATAKAN_FEATURE_PADDLE_OCR is False

    def test_qualitaetsaudit_default_false(self, monkeypatch):
        monkeypatch.delenv("BUCHUNG_ATAKAN_FEATURE_QUALITAETSAUDIT", raising=False)
        from importlib import reload
        import apps.server.config as cfg_mod
        reload(cfg_mod)
        settings = cfg_mod.Settings()
        assert settings.BUCHUNG_ATAKAN_FEATURE_QUALITAETSAUDIT is False

    def test_azure_flag_aktivierbar(self, monkeypatch):
        monkeypatch.setenv("BUCHUNG_ATAKAN_FEATURE_AZURE_DI", "true")
        from importlib import reload
        import apps.server.config as cfg_mod
        reload(cfg_mod)
        settings = cfg_mod.Settings()
        assert settings.BUCHUNG_ATAKAN_FEATURE_AZURE_DI is True

    def test_azure_document_intelligence_flag_default_false(self, monkeypatch):
        """Kanonisches Azure-Flag Paket 07-04 (HYB-20) -- default False."""
        monkeypatch.delenv("BUCHUNG_ATAKAN_FEATURE_AZURE_DOCUMENT_INTELLIGENCE", raising=False)
        from importlib import reload
        import apps.server.config as cfg_mod
        reload(cfg_mod)
        settings = cfg_mod.Settings()
        assert settings.BUCHUNG_ATAKAN_FEATURE_AZURE_DOCUMENT_INTELLIGENCE is False

    def test_azure_document_intelligence_flag_aktivierbar(self, monkeypatch):
        monkeypatch.setenv("BUCHUNG_ATAKAN_FEATURE_AZURE_DOCUMENT_INTELLIGENCE", "true")
        from importlib import reload
        import apps.server.config as cfg_mod
        reload(cfg_mod)
        settings = cfg_mod.Settings()
        assert settings.BUCHUNG_ATAKAN_FEATURE_AZURE_DOCUMENT_INTELLIGENCE is True

    def test_legacy_azure_di_flag_aktiviert_kanonisches_flag_nicht(self, monkeypatch):
        """Legacy-Flag (07-01) und kanonisches Flag (07-04) sind vollstaendig entkoppelt --
        Setzen des Legacy-Flags darf das neue Flag nicht beeinflussen."""
        monkeypatch.setenv("BUCHUNG_ATAKAN_FEATURE_AZURE_DI", "true")
        monkeypatch.delenv("BUCHUNG_ATAKAN_FEATURE_AZURE_DOCUMENT_INTELLIGENCE", raising=False)
        from importlib import reload
        import apps.server.config as cfg_mod
        reload(cfg_mod)
        settings = cfg_mod.Settings()
        assert settings.BUCHUNG_ATAKAN_FEATURE_AZURE_DI is True
        assert settings.BUCHUNG_ATAKAN_FEATURE_AZURE_DOCUMENT_INTELLIGENCE is False
