import hashlib

import pytest

from packages.core.hash_utils import sha256_of_bytes, sha256_of_file


def test_sha256_of_bytes_known_value():
    data = b"hello world"
    expected = hashlib.sha256(data).hexdigest()
    assert sha256_of_bytes(data) == expected


def test_sha256_of_bytes_empty():
    result = sha256_of_bytes(b"")
    assert len(result) == 64
    assert result == "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"


def test_sha256_of_file(tmp_path):
    content = b"Test-Inhalt fuer SHA-256"
    f = tmp_path / "test.pdf"
    f.write_bytes(content)
    assert sha256_of_file(f) == sha256_of_bytes(content)


def test_sha256_of_file_large(tmp_path):
    # groesser als CHUNK_SIZE (65536), um chunked-Logik zu testen
    content = b"X" * (65536 * 3 + 1000)
    f = tmp_path / "gross.bin"
    f.write_bytes(content)
    expected = hashlib.sha256(content).hexdigest()
    assert sha256_of_file(f) == expected


def test_sha256_of_file_not_found(tmp_path):
    with pytest.raises(FileNotFoundError):
        sha256_of_file(tmp_path / "existiert_nicht.pdf")
