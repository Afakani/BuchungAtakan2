"""Unit-Tests ORM-Modelle Phase 06 (EC-Sammelzuordnung).

Prueft Tabellennamen, Spaltennamen, Constraints und Enum-Werte
ohne Datenbankverbindung.
"""
import pytest

from packages.core.ec_sammlung.typen import (
    EcBelegRolle,
    EcBelegStatus,
    EcSammelStatus,
    ZahlungsKategorie,
)
from apps.server.models.ec_sammlung import (
    EcBeleg,
    EcSammellauf,
    EcSammelzuordnung,
    EcSammelzuordnungBeleg,
)


class TestZahlungsKategorieEnum:
    def test_ec_karte_wert(self):
        assert ZahlungsKategorie.EC_KARTE == "EC_KARTE"

    def test_unbekannt_wert(self):
        assert ZahlungsKategorie.UNBEKANNT == "UNBEKANNT"

    def test_manuell_pruefen_wert(self):
        assert ZahlungsKategorie.MANUELL_PRUEFEN == "MANUELL_PRUEFEN"


class TestEcBelegStatusEnum:
    def test_verfuegbar_wert(self):
        assert EcBelegStatus.VERFUEGBAR == "VERFUEGBAR"

    def test_final_zugeordnet_wert(self):
        assert EcBelegStatus.FINAL_ZUGEORDNET == "FINAL_ZUGEORDNET"


class TestEcBelegRolleEnum:
    def test_aktiv_wert(self):
        assert EcBelegRolle.AKTIV == "AKTIV"

    def test_entfernt_verschoben_wert(self):
        assert EcBelegRolle.ENTFERNT_VERSCHOBEN == "ENTFERNT_VERSCHOBEN"


class TestEcSammelStatusEnum:
    def test_stark_wert(self):
        assert EcSammelStatus.STARK == "STARK"

    def test_unsicher_wert(self):
        assert EcSammelStatus.UNSICHER == "UNSICHER"

    def test_manuell_bestaetigt_wert(self):
        assert EcSammelStatus.MANUELL_BESTAETIGT == "MANUELL_BESTAETIGT"

    def test_manuell_abgelehnt_wert(self):
        assert EcSammelStatus.MANUELL_ABGELEHNT == "MANUELL_ABGELEHNT"

    def test_offene_periode_wert(self):
        assert EcSammelStatus.OFFENE_PERIODE == "OFFENE_PERIODE"


class TestEcBelegModel:
    def test_tablename(self):
        assert EcBeleg.__tablename__ == "ec_belege"

    def test_hat_betrag_cent_spalte(self):
        cols = {c.name for c in EcBeleg.__table__.columns}
        assert "betrag_cent" in cols

    def test_hat_buchungsdatum_spalte(self):
        cols = {c.name for c in EcBeleg.__table__.columns}
        assert "buchungsdatum" in cols

    def test_hat_zahlungskategorie_spalte(self):
        cols = {c.name for c in EcBeleg.__table__.columns}
        assert "zahlungskategorie" in cols

    def test_hat_status_spalte(self):
        cols = {c.name for c in EcBeleg.__table__.columns}
        assert "status" in cols

    def test_hat_unternehmen_id(self):
        cols = {c.name for c in EcBeleg.__table__.columns}
        assert "unternehmen_id" in cols

    def test_hat_created_at(self):
        cols = {c.name for c in EcBeleg.__table__.columns}
        assert "created_at" in cols

    def test_composite_unique_constraint_vorhanden(self):
        names = {c.name for c in EcBeleg.__table__.constraints}
        assert "uq_ec_belege_id_unternehmen" in names


class TestEcSammellaufModel:
    def test_tablename(self):
        assert EcSammellauf.__tablename__ == "ec_sammellaeufe"

    def test_hat_bankbuchung_id(self):
        cols = {c.name for c in EcSammellauf.__table__.columns}
        assert "bankbuchung_id" in cols

    def test_hat_matcher_version(self):
        cols = {c.name for c in EcSammellauf.__table__.columns}
        assert "matcher_version" in cols

    def test_composite_unique_constraint_vorhanden(self):
        names = {c.name for c in EcSammellauf.__table__.constraints}
        assert "uq_ec_sammellaeufe_id_unternehmen" in names


class TestEcSammelzuordnungModel:
    def test_tablename(self):
        assert EcSammelzuordnung.__tablename__ == "ec_sammelzuordnungen"

    def test_hat_score(self):
        cols = {c.name for c in EcSammelzuordnung.__table__.columns}
        assert "score" in cols

    def test_hat_status(self):
        cols = {c.name for c in EcSammelzuordnung.__table__.columns}
        assert "status" in cols

    def test_hat_summe_cent(self):
        cols = {c.name for c in EcSammelzuordnung.__table__.columns}
        assert "summe_cent" in cols

    def test_hat_differenz_cent(self):
        cols = {c.name for c in EcSammelzuordnung.__table__.columns}
        assert "differenz_cent" in cols

    def test_hat_kein_float_betrag(self):
        from sqlalchemy import Float
        col_types = {c.name: type(c.type) for c in EcSammelzuordnung.__table__.columns}
        assert col_types.get("summe_cent") is not Float
        assert col_types.get("differenz_cent") is not Float

    def test_partial_index_vorhanden(self):
        index_names = {i.name for i in EcSammelzuordnung.__table__.indexes}
        assert "uix_ec_sammelz_eine_bestaetigte_pro_buchung" in index_names

    def test_composite_unique_constraint_vorhanden(self):
        names = {c.name for c in EcSammelzuordnung.__table__.constraints}
        assert "uq_ec_sammelzuordnungen_id_unternehmen" in names


class TestEcSammelzuordnungBelegModel:
    def test_tablename(self):
        assert EcSammelzuordnungBeleg.__tablename__ == "ec_sammelzuordnung_belege"

    def test_hat_zuordnung_id(self):
        cols = {c.name for c in EcSammelzuordnungBeleg.__table__.columns}
        assert "zuordnung_id" in cols

    def test_hat_beleg_id(self):
        cols = {c.name for c in EcSammelzuordnungBeleg.__table__.columns}
        assert "beleg_id" in cols

    def test_hat_rolle(self):
        cols = {c.name for c in EcSammelzuordnungBeleg.__table__.columns}
        assert "rolle" in cols

    def test_unique_constraint_zuordnung_beleg(self):
        names = {c.name for c in EcSammelzuordnungBeleg.__table__.constraints}
        assert "uq_ec_szb_zuordnung_beleg" in names

    def test_partial_index_aktive_belegverwendung(self):
        index_names = {i.name for i in EcSammelzuordnungBeleg.__table__.indexes}
        assert "uix_ec_szb_aktive_belegverwendung" in index_names


class TestModelsImportierbar:
    def test_aus_models_init_importierbar(self):
        from apps.server.models import (
            EcBeleg,
            EcSammellauf,
            EcSammelzuordnung,
            EcSammelzuordnungBeleg,
        )
        assert EcBeleg.__tablename__ == "ec_belege"
        assert EcSammellauf.__tablename__ == "ec_sammellaeufe"
        assert EcSammelzuordnung.__tablename__ == "ec_sammelzuordnungen"
        assert EcSammelzuordnungBeleg.__tablename__ == "ec_sammelzuordnung_belege"

    def test_integer_cents_kein_float(self):
        from sqlalchemy import Float, Integer
        for col in EcBeleg.__table__.columns:
            if col.name in ("betrag_cent",):
                assert isinstance(col.type, Integer), f"{col.name} ist kein Integer"
                assert not isinstance(col.type, Float), f"{col.name} ist Float"
