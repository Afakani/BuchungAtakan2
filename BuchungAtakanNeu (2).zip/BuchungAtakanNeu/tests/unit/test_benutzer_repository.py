"""Unit-Tests fuer BenutzerRepository — SECURITY DEFINER Lookups ohne echte DB."""
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest

from apps.server.models.benutzer import Benutzer, Rolle
from apps.server.repositories.benutzer import BenutzerRepository

TENANT = uuid4()
OTHER_TENANT = uuid4()
USER_ID = uuid4()
REPO = BenutzerRepository()


def _mock_session_mapping(row: dict | None) -> AsyncMock:
    """Session-Mock fuer .mappings().one_or_none()-Ergebnis."""
    session = AsyncMock()
    result = MagicMock()
    result.mappings.return_value.one_or_none.return_value = row
    session.execute.return_value = result
    return session


# ── get_by_benutzername ───────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_get_by_benutzername_returns_benutzer():
    row = {
        "id": USER_ID,
        "hashed_password": "$argon2id$v=19$hash",
        "unternehmen_id": TENANT,
        "rolle": "BEARBEITER",
        "aktiv": True,
    }
    session = _mock_session_mapping(row)
    result = await REPO.get_by_benutzername(session, "hans")

    assert isinstance(result, Benutzer)
    assert result.id == USER_ID
    assert result.hashed_password == "$argon2id$v=19$hash"
    assert result.unternehmen_id == TENANT
    assert result.rolle == Rolle.BEARBEITER
    assert result.aktiv is True


@pytest.mark.asyncio
async def test_get_by_benutzername_none_when_not_found():
    session = _mock_session_mapping(None)
    result = await REPO.get_by_benutzername(session, "unbekannt")
    assert result is None


@pytest.mark.asyncio
async def test_get_by_benutzername_calls_security_definer_function():
    session = _mock_session_mapping(None)
    await REPO.get_by_benutzername(session, "hans")

    call_args = session.execute.call_args
    sql_str = str(call_args[0][0]).lower()
    assert "auth_benutzer_by_name" in sql_str
    assert call_args[0][1] == {"name": "hans"}


@pytest.mark.asyncio
async def test_get_by_benutzername_inaktiver_benutzer_wird_zurueckgegeben():
    """Login-Funktion gibt inaktiven Benutzer zurueck -- caller prueft aktiv-Flag."""
    row = {
        "id": USER_ID,
        "hashed_password": "$argon2id$x",
        "unternehmen_id": TENANT,
        "rolle": "LESER",
        "aktiv": False,
    }
    session = _mock_session_mapping(row)
    result = await REPO.get_by_benutzername(session, "inaktiv")

    assert result is not None
    assert result.aktiv is False


# ── get_by_id_raw ─────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_get_by_id_raw_returns_benutzer():
    row = {
        "id": USER_ID,
        "unternehmen_id": TENANT,
        "rolle": "UNTERNEHMEN_ADMIN",
        "aktiv": True,
    }
    session = _mock_session_mapping(row)
    result = await REPO.get_by_id_raw(session, USER_ID, TENANT)

    assert isinstance(result, Benutzer)
    assert result.id == USER_ID
    assert result.unternehmen_id == TENANT
    assert result.rolle == Rolle.UNTERNEHMEN_ADMIN
    assert result.aktiv is True


@pytest.mark.asyncio
async def test_get_by_id_raw_none_when_not_found():
    session = _mock_session_mapping(None)
    result = await REPO.get_by_id_raw(session, USER_ID, TENANT)
    assert result is None


@pytest.mark.asyncio
async def test_get_by_id_raw_cross_tenant_lookup_schlaegt_fehl():
    """Fremdes unternehmen_id liefert None -- SQL-Funktion filtert auf unternehmen_id."""
    # DB-Funktion gibt None zurueck wenn unternehmen_id nicht passt.
    session = _mock_session_mapping(None)
    result = await REPO.get_by_id_raw(session, USER_ID, OTHER_TENANT)
    assert result is None


@pytest.mark.asyncio
async def test_get_by_id_raw_uebergibt_beide_parameter_an_sql():
    """SQL-Aufruf muss id UND unternehmen_id enthalten."""
    session = _mock_session_mapping(None)
    await REPO.get_by_id_raw(session, USER_ID, TENANT)

    call_args = session.execute.call_args
    sql_str = str(call_args[0][0]).lower()
    assert "auth_benutzer_by_id" in sql_str
    params = call_args[0][1]
    assert params["id"] == USER_ID
    assert params["unternehmen_id"] == TENANT


@pytest.mark.asyncio
async def test_get_by_id_raw_alle_rollen_mapbar():
    for rolle in Rolle:
        row = {
            "id": USER_ID,
            "unternehmen_id": TENANT,
            "rolle": rolle.value,
            "aktiv": True,
        }
        session = _mock_session_mapping(row)
        result = await REPO.get_by_id_raw(session, USER_ID, TENANT)
        assert result.rolle == rolle


# ── Sicherheits-Invarianten ───────────────────────────────────────────────────

def test_get_by_benutzername_verwendet_kein_orm_select():
    """Repository darf kein select(Benutzer) verwenden -- wuerde benutzer-RLS unterliegen."""
    import inspect
    from apps.server.repositories import benutzer as mod
    source = inspect.getsource(mod.BenutzerRepository.get_by_benutzername)
    assert "select(Benutzer)" not in source
    assert "auth_benutzer_by_name" in source


def test_get_by_id_raw_verwendet_kein_orm_select():
    import inspect
    from apps.server.repositories import benutzer as mod
    source = inspect.getsource(mod.BenutzerRepository.get_by_id_raw)
    assert "select(Benutzer)" not in source
    assert "auth_benutzer_by_id" in source


def test_get_by_id_raw_hat_unternehmen_id_parameter():
    """Signatur muss unternehmen_id enthalten -- tenantloser Lookup verboten."""
    import inspect
    sig = inspect.signature(BenutzerRepository.get_by_id_raw)
    assert "unternehmen_id" in sig.parameters
