import pytest

from packages.core.mime_utils import detect_mime_type


def test_detect_pdf_magic(tmp_path):
    f = tmp_path / "rechnung.pdf"
    f.write_bytes(b"%PDF-1.4 content follows")
    assert detect_mime_type(f) == "application/pdf"


def test_detect_png_magic(tmp_path):
    f = tmp_path / "bild.png"
    f.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 100)
    assert detect_mime_type(f) == "image/png"


def test_detect_jpeg_magic(tmp_path):
    f = tmp_path / "foto.jpg"
    f.write_bytes(b"\xff\xd8\xff\xe0" + b"\x00" * 100)
    assert detect_mime_type(f) == "image/jpeg"


def test_detect_zip_magic(tmp_path):
    f = tmp_path / "archiv.zip"
    f.write_bytes(b"PK\x03\x04" + b"\x00" * 100)
    assert detect_mime_type(f) == "application/zip"


def test_extension_fallback_csv(tmp_path):
    f = tmp_path / "kontoauszug.csv"
    f.write_bytes(b"datum,betrag,verwendungszweck\n")
    result = detect_mime_type(f)
    # Windows: mimetypes kann "text/csv", "application/vnd.ms-excel" oder aehnlich liefern
    assert result is not None and len(result) > 0 and result != "application/octet-stream"


def test_extension_fallback_xlsx(tmp_path):
    f = tmp_path / "tabelle.xlsx"
    f.write_bytes(b"kein Magic hier, nur Dummy")
    result = detect_mime_type(f)
    assert result is not None and len(result) > 0


def test_unknown_type_returns_default(tmp_path):
    f = tmp_path / "datei.xyz_unbekannt_typ"
    f.write_bytes(b"\x00\x01\x02\x03")
    assert detect_mime_type(f) == "application/octet-stream"


def test_unreadable_file_uses_extension(tmp_path):
    f = tmp_path / "datei.csv"
    # Datei existiert nicht; OSError -> Extension-Fallback (nicht application/octet-stream)
    result = detect_mime_type(f)
    assert result is not None and result != "application/octet-stream"
