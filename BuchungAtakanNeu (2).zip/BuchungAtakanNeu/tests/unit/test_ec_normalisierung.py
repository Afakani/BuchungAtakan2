"""Unit-Tests Zahlungskategorie-Normalisierung (Phase 06, Paket 1).

Anforderungen:
  T1:  CardPayment → EC_KARTE (sicher, orthografische Variante)
  T2:  EC_Karte, EC-Karte, ec karte → EC_KARTE (sicher)
  T3:  Debit → UNBEKANNT (zu allgemein, kein Synonym konfiguriert)
  T4:  Maestro → UNBEKANNT (zu allgemein, kein Synonym konfiguriert)
  T5:  Visa Debit → UNBEKANNT (Fremdmarke, kein Synonym konfiguriert)
  T6:  Maestro in expliziter Synonymliste → EC_KARTE
  T7:  None/leerer String → UNBEKANNT
  T8:  Gross-/Kleinschreibung irrelevant bei sicheren Varianten
"""
import pytest

from packages.core.ec_sammlung.normalisierung import normalisiere_zahlungskategorie
from packages.core.ec_sammlung.typen import ZahlungsKategorie


class TestSichereEC_KARTE:
    """T1/T2: Orthografisch sichere EC-KARTE-Varianten."""

    @pytest.mark.parametrize("rohwert", [
        "CardPayment",
        "card payment",
        "cardpayment",
        "CARDPAYMENT",
        "EC_Karte",
        "EC-Karte",
        "ec karte",
        "EC KARTE",
        "eckarte",
        "ECKarte",
    ])
    def test_sichere_varianten_werden_ec_karte(self, rohwert: str):
        assert normalisiere_zahlungskategorie(rohwert) == ZahlungsKategorie.EC_KARTE

    def test_card_payment_mit_leerzeichen(self):
        assert normalisiere_zahlungskategorie("Card Payment") == ZahlungsKategorie.EC_KARTE

    def test_ec_karte_mit_unterstrich(self):
        assert normalisiere_zahlungskategorie("EC_Karte") == ZahlungsKategorie.EC_KARTE

    def test_ec_karte_mit_bindestrich(self):
        assert normalisiere_zahlungskategorie("EC-Karte") == ZahlungsKategorie.EC_KARTE


class TestNichtAutomatischEC:
    """T3/T4/T5: Allgemeine Kartenbegriffe werden NICHT still als EC_KARTE akzeptiert."""

    @pytest.mark.parametrize("rohwert", [
        "Debit",
        "debit",
        "DEBIT",
        "Maestro",
        "maestro",
        "Visa Debit",
        "visa debit",
        "VISA",
        "MasterCard",
        "Karte",
        "Kartenzahlung",  # in Bankklassifikation EC_EINZAHLUNG, hier aber UNBEKANNT
        "Girocard",
    ])
    def test_allgemeine_begriffe_bleiben_unbekannt(self, rohwert: str):
        """Ohne explizite Synonymliste → UNBEKANNT, keine stillen Fehlklassifikationen."""
        result = normalisiere_zahlungskategorie(rohwert)
        assert result == ZahlungsKategorie.UNBEKANNT, (
            f"'{rohwert}' wurde als {result} klassifiziert, erwartet UNBEKANNT"
        )


class TestSynonymliste:
    """T6: Explizit konfigurierte Synonymliste erlaubt Erweiterung."""

    def test_maestro_in_synonymliste_wird_ec_karte(self):
        synonyme = frozenset({"maestro"})
        assert normalisiere_zahlungskategorie("Maestro", synonyme=synonyme) == ZahlungsKategorie.EC_KARTE

    def test_maestro_ohne_synonymliste_bleibt_unbekannt(self):
        assert normalisiere_zahlungskategorie("Maestro") == ZahlungsKategorie.UNBEKANNT

    def test_visa_debit_in_synonymliste_wird_ec_karte(self):
        synonyme = frozenset({"visa debit"})
        assert normalisiere_zahlungskategorie("Visa Debit", synonyme=synonyme) == ZahlungsKategorie.EC_KARTE

    def test_synonymliste_ist_case_insensitive(self):
        synonyme = frozenset({"maestro"})
        assert normalisiere_zahlungskategorie("MAESTRO", synonyme=synonyme) == ZahlungsKategorie.EC_KARTE


class TestRandFaelle:
    """T7/T8: Randwerte und Gross-/Kleinschreibung."""

    def test_none_liefert_unbekannt(self):
        assert normalisiere_zahlungskategorie(None) == ZahlungsKategorie.UNBEKANNT

    def test_leerer_string_liefert_unbekannt(self):
        assert normalisiere_zahlungskategorie("") == ZahlungsKategorie.UNBEKANNT

    def test_nur_leerzeichen_liefert_unbekannt(self):
        assert normalisiere_zahlungskategorie("   ") == ZahlungsKategorie.UNBEKANNT

    def test_ec_karte_grossschreibung_funktioniert(self):
        assert normalisiere_zahlungskategorie("EC-KARTE") == ZahlungsKategorie.EC_KARTE

    def test_card_payment_kleinschreibung_funktioniert(self):
        assert normalisiere_zahlungskategorie("CARDPAYMENT") == ZahlungsKategorie.EC_KARTE
