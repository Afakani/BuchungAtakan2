"""Unit-Tests Matching-Core Scorer (BANK-04).

Abgedeckte Anforderungen (T1-T14 aus Auftrag):
  T1:  Exakter Betrag → stark positives Signal BETRAG_EXAKT (+50).
  T2:  Abweichender Betrag > 50 EUR → negatives Signal BETRAG_ABWEICHUNG (-30).
  T3:  Plausibles Datum (0-90 Tage) → positives Signal DATUM_PLAUSIBEL (+15).
  T4:  Unplausibles Datum (> 365 Tage) → negatives Signal DATUM_SEHR_SPAET (-20).
  T5:  Rechnungsnummer im Verwendungszweck → stark positives Signal (+40).
  T6:  Fehlende Rechnungsnummer kein automatischer Ausschluss.
  T7:  Anbieter-/Gegenparteiname nachvollziehbar normalisiert und verglichen.
  T8:  Mehrere positive Signale erhoehen Score.
  T9:  Negatives Signal reduziert Score.
  T10: Identischer Input → identischer Score und Signalliste.
  T11: Inaktive Rechnung wird nicht bewertet (Ausschluss vor Scorer-Aufruf).
  T12: Fremder Mandant kann nicht in Kandidatensatz (Mandantenfilerung im Service).
  T13: Score-Schwellen korrekt klassifiziert (STARK/UNSICHER/KEIN_KANDIDAT).
  T14: Rechnungsbetrag exakt und ohne Float in Cent konvertiert.
"""
from datetime import date
from decimal import Decimal
from uuid import UUID

import pytest

from packages.core.matching.scorer import (
    _bewerte_anbieter,
    _bewerte_betrag,
    _bewerte_datum,
    _bewerte_rechnungsnummer,
    _decimal_zu_cent,
    berechne_match,
)
from packages.core.matching.signale import SCHWELLE_STARK, SCHWELLE_UNSICHER

_BID = UUID("00000000-0000-4000-b000-000000000001")
_RID = UUID("00000000-0000-4000-c000-000000000001")

_BASIS = dict(
    bankbuchung_id=_BID,
    bank_betrag_cent=-11900,
    bank_buchungsdatum=date(2024, 2, 15),
    bank_verwendungszweck="RE-2024-001 Lieferant GmbH",
    bank_gegenpartei_name="Lieferant GmbH",
    rechnung_id=_RID,
    rechnung_gesamtbetrag=Decimal("119.00"),
    rechnung_datum="01.02.2024",
    rechnung_nummer="RE-2024-001",
    rechnung_lieferant="Lieferant GmbH",
)


class TestBetragsSignal:
    def test_exakter_betrag_stark_positiv(self):
        """T1: exakter Betrag → BETRAG_EXAKT (+50)."""
        signale = _bewerte_betrag(-11900, 11900)
        assert len(signale) == 1
        assert signale[0].typ == "BETRAG_EXAKT"
        assert signale[0].punkte == 50

    def test_exakter_betrag_positiv_positiv(self):
        """T1: auch wenn beide positiv → exakt."""
        signale = _bewerte_betrag(11900, 11900)
        assert signale[0].typ == "BETRAG_EXAKT"

    def test_abweichung_kleiner_10eur(self):
        """Abweichung 5 EUR → BETRAG_NAH (+20)."""
        signale = _bewerte_betrag(-11900, 11400)  # 500 Cent Diff
        assert signale[0].typ == "BETRAG_NAH"
        assert signale[0].punkte == 20

    def test_abweichung_kleiner_50eur(self):
        """Abweichung 30 EUR → BETRAG_GROB (+5)."""
        signale = _bewerte_betrag(-11900, 8900)  # 3000 Cent Diff
        assert signale[0].typ == "BETRAG_GROB"
        assert signale[0].punkte == 5

    def test_grosse_abweichung_negativ(self):
        """T2: Abweichung > 50 EUR → BETRAG_ABWEICHUNG (-30)."""
        signale = _bewerte_betrag(-11900, 5000)  # 6900 Cent Diff
        assert signale[0].typ == "BETRAG_ABWEICHUNG"
        assert signale[0].punkte == -30

    def test_fehlender_rechnungsbetrag_negativ(self):
        """Fehlender Rechnungsbetrag → BETRAG_RECHNUNG_FEHLT (-5)."""
        signale = _bewerte_betrag(-11900, None)
        assert signale[0].typ == "BETRAG_RECHNUNG_FEHLT"
        assert signale[0].punkte == -5


class TestDatumSignal:
    def test_plausibles_datum(self):
        """T3: 0-90 Tage → DATUM_PLAUSIBEL (+15)."""
        buchungsdatum = date(2024, 2, 15)  # 14 Tage nach 01.02.2024
        signale = _bewerte_datum(buchungsdatum, "01.02.2024")
        assert signale[0].typ == "DATUM_PLAUSIBEL"
        assert signale[0].punkte == 15

    def test_selbes_datum_plausibel(self):
        signale = _bewerte_datum(date(2024, 1, 1), "01.01.2024")
        assert signale[0].typ == "DATUM_PLAUSIBEL"

    def test_spaetes_datum(self):
        """91-365 Tage → DATUM_SPAET (-10)."""
        signale = _bewerte_datum(date(2024, 6, 1), "01.01.2024")  # 152 Tage
        assert signale[0].typ == "DATUM_SPAET"
        assert signale[0].punkte == -10

    def test_sehr_spaetes_datum(self):
        """T4: > 365 Tage → DATUM_SEHR_SPAET (-20)."""
        signale = _bewerte_datum(date(2025, 6, 1), "01.01.2024")  # ~517 Tage
        assert signale[0].typ == "DATUM_SEHR_SPAET"
        assert signale[0].punkte == -20

    def test_buchung_vor_rechnung(self):
        """Buchung vor Rechnungsdatum → DATUM_VOR_RECHNUNG (-5)."""
        signale = _bewerte_datum(date(2023, 12, 1), "01.01.2024")
        assert signale[0].typ == "DATUM_VOR_RECHNUNG"
        assert signale[0].punkte == -5

    def test_fehlendes_rechnungsdatum(self):
        """Kein Rechnungsdatum → DATUM_RECHNUNG_FEHLT (-2)."""
        signale = _bewerte_datum(date(2024, 1, 1), None)
        assert signale[0].typ == "DATUM_RECHNUNG_FEHLT"
        assert signale[0].punkte == -2


class TestRechnungsnummerSignal:
    def test_rechnungsnummer_gefunden(self):
        """T5: Rechnungsnr. im Verwendungszweck → RECHNUNGSNUMMER_GEFUNDEN (+40)."""
        signale = _bewerte_rechnungsnummer("RE-2024-001 Zahlung", "RE-2024-001")
        assert len(signale) == 1
        assert signale[0].typ == "RECHNUNGSNUMMER_GEFUNDEN"
        assert signale[0].punkte == 40

    def test_rechnungsnummer_nicht_gefunden_kein_ausschluss(self):
        """T6: Rechnungsnr. nicht gefunden → kein Signal (kein Ausschluss)."""
        signale = _bewerte_rechnungsnummer("Unbekannte Zahlung XYZ", "RE-2024-001")
        assert signale == []

    def test_kurze_rechnungsnummer_ignoriert(self):
        """Rechnungsnr. < 5 Zeichen → nicht gesucht (Sicherheitsregel)."""
        signale = _bewerte_rechnungsnummer("123 XYZ Zahlung", "123")
        assert signale == []

    def test_keine_rechnungsnummer_kein_signal(self):
        """T6: Keine Rechnungsnr. → kein Signal."""
        signale = _bewerte_rechnungsnummer("Zahlung XYZ", None)
        assert signale == []

    def test_kein_verwendungszweck_kein_signal(self):
        signale = _bewerte_rechnungsnummer(None, "RE-2024-001")
        assert signale == []


class TestAnbieterSignal:
    def test_anbieter_match(self):
        """T7: Wortbasierter Match — signifikantes Wort gefunden."""
        signale = _bewerte_anbieter("Lieferant GmbH Berlin", "Lieferant GmbH")
        assert len(signale) == 1
        assert signale[0].typ == "ANBIETER_MATCH"
        assert signale[0].punkte == 15

    def test_anbieter_kein_match(self):
        """T7: Kein gemeinsames Wort → ANBIETER_KEIN_MATCH (-5)."""
        signale = _bewerte_anbieter("Andere Firma AG", "Lieferant GmbH")
        assert signale[0].typ == "ANBIETER_KEIN_MATCH"
        assert signale[0].punkte == -5

    def test_fehlender_gegenpartei_neutral(self):
        """Fehlender Name → kein Signal (neutral)."""
        signale = _bewerte_anbieter(None, "Lieferant GmbH")
        assert signale == []

    def test_fehlender_lieferant_neutral(self):
        signale = _bewerte_anbieter("Gegenpartei GmbH", None)
        assert signale == []

    def test_normalisierung_case_insensitive(self):
        """T7: Gross-/Kleinschreibung ignoriert."""
        signale = _bewerte_anbieter("LIEFERANT GMBH", "lieferant gmbh")
        assert signale[0].typ == "ANBIETER_MATCH"


class TestGesamtScore:
    def test_mehrere_positive_signale_erhoehen_score(self):
        """T8: Summe positiver Signale erhoehen Gesamtscore."""
        ergebnis = berechne_match(**_BASIS)
        # Betrag exakt (+50) + Datum plausibel (+15) + Rechnungsnr (+40) + Anbieter (+15) = 120
        assert ergebnis.score == 120
        assert len(ergebnis.positive_signale) >= 3

    def test_negatives_signal_reduziert_score(self):
        """T9: Negatives Signal zieht Score runter."""
        params = {**_BASIS, "rechnung_gesamtbetrag": Decimal("999.00")}  # grosse Abweichung
        ergebnis = berechne_match(**params)
        # BETRAG_ABWEICHUNG (-30) + Rest
        betrag_punkte = sum(s.punkte for s in ergebnis.negative_signale if "BETRAG" in s.typ)
        assert betrag_punkte < 0

    def test_identischer_input_identischer_output(self):
        """T10: Deterministisch — identischer Input → identischer Output."""
        e1 = berechne_match(**_BASIS)
        e2 = berechne_match(**_BASIS)
        assert e1.score == e2.score
        assert e1.status == e2.status
        assert e1.positive_signale == e2.positive_signale
        assert e1.negative_signale == e2.negative_signale


class TestSchwellen:
    def test_score_stark(self):
        """T13: Score >= 80 → STARK."""
        ergebnis = berechne_match(**_BASIS)
        assert ergebnis.score >= 80
        assert ergebnis.status == "STARK"

    def test_score_unsicher(self):
        """T13: Score 40-79 → UNSICHER."""
        # Nur exakter Betrag (+50), kein Datum, keine Rechnungsnr.
        params = {
            **_BASIS,
            "bank_verwendungszweck": "Zahlung",  # keine Rechnungsnr
            "bank_gegenpartei_name": None,
            "rechnung_nummer": None,
            "rechnung_lieferant": None,
            "rechnung_datum": None,  # → DATUM_RECHNUNG_FEHLT (-2)
        }
        ergebnis = berechne_match(**params)
        # BETRAG_EXAKT (50) + DATUM_RECHNUNG_FEHLT (-2) = 48
        assert ergebnis.status == "UNSICHER"

    def test_score_kein_kandidat(self):
        """T13: Score < 40 → KEIN_KANDIDAT."""
        params = {
            **_BASIS,
            "bank_betrag_cent": -1000,  # 11900 - 1000 = 10900 Cent Diff → BETRAG_ABWEICHUNG (-30)
            "bank_verwendungszweck": "Unbekannte Zahlung",
            "bank_gegenpartei_name": "Andere Firma",
            "rechnung_nummer": None,
            "rechnung_lieferant": "Komplett Anderer Name",
        }
        ergebnis = berechne_match(**params)
        assert ergebnis.score < SCHWELLE_UNSICHER
        assert ergebnis.status == "KEIN_KANDIDAT"

    def test_kein_kandidat_ist_kein_kandidat(self):
        """T13: ist_kandidat False bei KEIN_KANDIDAT."""
        params = {**_BASIS, "bank_betrag_cent": -100, "rechnung_lieferant": None, "rechnung_nummer": None}
        ergebnis = berechne_match(**params)
        if ergebnis.status == "KEIN_KANDIDAT":
            assert not ergebnis.ist_kandidat


class TestCentKonvertierung:
    def test_decimal_exakt_zu_cent(self):
        """T14: Decimal ohne Float exakt in Cent."""
        assert _decimal_zu_cent(Decimal("119.00")) == 11900

    def test_decimal_mit_nachkommastellen(self):
        assert _decimal_zu_cent(Decimal("1.99")) == 199

    def test_decimal_null_ist_none(self):
        assert _decimal_zu_cent(None) is None

    def test_keine_float_arithmetik(self):
        """T14: Ergebnis ist int, kein float."""
        result = _decimal_zu_cent(Decimal("99.99"))
        assert isinstance(result, int)
        assert result == 9999

    def test_grosse_betraege_exakt(self):
        assert _decimal_zu_cent(Decimal("999999.99")) == 99999999
