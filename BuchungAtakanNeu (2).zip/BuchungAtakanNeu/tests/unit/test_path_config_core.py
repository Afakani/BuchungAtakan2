from pathlib import Path

import pytest

from packages.core.path_config import (
    DATA_ROOT_SOURCE_CONFIG_FILE,
    DATA_ROOT_SOURCE_ENV,
    DATA_ROOT_SOURCE_EXPLICIT,
    DATA_ROOT_SOURCE_FALLBACK,
    DataRootSecurityError,
    PathConfig,
    guard_data_root,
    load_path_config,
    load_path_config_with_source,
    resolve_data_root_source,
)


def test_pathconfig_expands_tilde(tmp_path):
    config = PathConfig(data_root=tmp_path)
    assert config.data_root == tmp_path


def test_pathconfig_directories(tmp_path):
    config = PathConfig(data_root=tmp_path)
    assert config.dump_dir == tmp_path / "dump"
    assert config.config_dir == tmp_path / "config"
    assert config.logs_dir == tmp_path / "logs"
    assert config.outbox_db_path == tmp_path / "outbox.db"


def test_ensure_required_directories(tmp_path):
    config = PathConfig(data_root=tmp_path / "data")
    config.ensure_required_directories()
    for d in config.required_directories():
        assert d.exists(), f"Verzeichnis fehlt: {d}"


def test_to_data_relative_absolute(tmp_path):
    config = PathConfig(data_root=tmp_path)
    abs_path = tmp_path / "dump" / "rechnung.pdf"
    rel = config.to_data_relative(abs_path)
    assert rel == Path("dump/rechnung.pdf")


def test_to_data_relative_already_relative():
    config = PathConfig(data_root=Path("/some/root"))
    rel = config.to_data_relative(Path("dump/datei.pdf"))
    assert rel == Path("dump/datei.pdf")


def test_to_data_relative_none():
    config = PathConfig(data_root=Path("/some/root"))
    assert config.to_data_relative(None) is None


def test_resolve_document_path_relative(tmp_path):
    config = PathConfig(data_root=tmp_path)
    resolved = config.resolve_document_path("dump/x.pdf")
    assert resolved == tmp_path / "dump" / "x.pdf"


def test_resolve_document_path_absolute(tmp_path):
    config = PathConfig(data_root=tmp_path)
    abs_path = tmp_path / "x.pdf"
    resolved = config.resolve_document_path(abs_path)
    assert resolved == abs_path


def test_load_path_config_explicit(tmp_path):
    config = load_path_config(explicit_data_root=tmp_path)
    assert config.data_root == tmp_path


def test_load_path_config_env(tmp_path):
    config = load_path_config(env={"BUCHUNG_ATAKAN_DATA_ROOT": str(tmp_path)})
    assert config.data_root == tmp_path


def test_load_path_config_fallback():
    config = load_path_config(env={})
    assert config.data_root is not None


def test_resolve_source_explicit(tmp_path):
    source = resolve_data_root_source(explicit_data_root=tmp_path)
    assert source == DATA_ROOT_SOURCE_EXPLICIT


def test_resolve_source_env(tmp_path):
    source = resolve_data_root_source(env={"BUCHUNG_ATAKAN_DATA_ROOT": str(tmp_path)})
    assert source == DATA_ROOT_SOURCE_ENV


def test_resolve_source_fallback():
    source = resolve_data_root_source(env={})
    assert source == DATA_ROOT_SOURCE_FALLBACK


def test_load_with_source_explicit(tmp_path):
    config, source = load_path_config_with_source(explicit_data_root=tmp_path)
    assert config.data_root == tmp_path
    assert source == DATA_ROOT_SOURCE_EXPLICIT


def test_guard_data_root_fallback_raises(tmp_path):
    config = PathConfig(data_root=tmp_path)
    with pytest.raises(DataRootSecurityError):
        guard_data_root(
            config,
            DATA_ROOT_SOURCE_FALLBACK,
            purpose="Test",
            allow_dev_fallback=False,
            stream=lambda _: None,
        )


def test_guard_data_root_fallback_allowed(tmp_path):
    config = PathConfig(data_root=tmp_path)
    result = guard_data_root(
        config,
        DATA_ROOT_SOURCE_FALLBACK,
        purpose="DevTest",
        allow_dev_fallback=True,
        stream=lambda _: None,
    )
    assert result is config


def test_guard_data_root_explicit_ok(tmp_path):
    config = PathConfig(data_root=tmp_path)
    result = guard_data_root(
        config,
        DATA_ROOT_SOURCE_EXPLICIT,
        purpose="Test",
        stream=lambda _: None,
    )
    assert result is config
