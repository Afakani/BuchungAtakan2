"""Unit-Tests fuer das Hybridpipeline-Gate in werte_lokale_erkennung_aus (HYB-07).

Deckt ab:
- Flag false/default blockiert den Einstieg in die Hybrid-Auswertung.
- Flag true erlaubt die Hybrid-Auswertung.
- Das Gate beeinflusst keine nachgelagerte Auswertungslogik (Mock-Beweis) und keine
  separaten Provider-Flags (invoice2data/PaddleOCR/Azure bleiben unabhaengig).
- Strukturbeleg (AST): Gate ist die erste Anweisung der Funktion.
"""
from __future__ import annotations

import ast
import inspect
import textwrap
from types import SimpleNamespace
from unittest.mock import patch

import pytest

from packages.core.invoice_extraction.azure_document_intelligence_provider import (
    ist_aktiviert as azure_ist_aktiviert,
)
from packages.core.invoice_extraction.document_classifier import DokumentKlasse
from packages.core.invoice_extraction.hybrid_auswertung import (
    HybridPipelineDeaktiviertFehler,
    werte_lokale_erkennung_aus,
)
from packages.core.invoice_extraction.hybrid_kandidat import HybridKandidat
from packages.core.invoice_extraction.invoice2data_provider import (
    ist_aktiviert as invoice2data_ist_aktiviert,
)
from packages.core.invoice_extraction.local_provider_orchestrator import (
    LocalOrchestratorErgebnis,
)
from packages.core.invoice_extraction.paddleocr_provider import (
    ist_aktiviert as paddleocr_ist_aktiviert,
)
from packages.core.invoice_extraction.provider_ports import InvoiceProviderResult

_MODUL = "packages.core.invoice_extraction.hybrid_auswertung"


def _settings(**flags):
    defaults = dict(
        BUCHUNG_ATAKAN_FEATURE_HYBRID_PIPELINE=False,
        BUCHUNG_ATAKAN_FEATURE_INVOICE2DATA=False,
        BUCHUNG_ATAKAN_FEATURE_PADDLE_OCR=False,
        BUCHUNG_ATAKAN_FEATURE_AZURE_DOCUMENT_INTELLIGENCE=False,
    )
    defaults.update(flags)
    return SimpleNamespace(**defaults)


def _orchestrator_ergebnis() -> LocalOrchestratorErgebnis:
    kandidaten = [
        HybridKandidat(
            feld=feld, rohwert="wert", normwert="wert", methode="regex_label",
            provider_name="pdfplumber", provider_version="1.0", confidence=0.9,
        )
        for feld in ("vendor_name", "invoice_number", "invoice_date", "total_amount")
    ]
    ergebnis = LocalOrchestratorErgebnis(dokument_klasse=DokumentKlasse.TEXT_PDF)
    ergebnis.provider_ergebnisse.append(
        InvoiceProviderResult(
            provider_name="pdfplumber", provider_version="1.0", laufstatus="success",
            kandidaten=kandidaten, fehlercode=None,
        )
    )
    return ergebnis


class TestHybridPipelineGate:
    def test_default_false_blockiert_auswertung(self):
        with pytest.raises(HybridPipelineDeaktiviertFehler):
            werte_lokale_erkennung_aus(_orchestrator_ergebnis(), _settings())

    def test_explizit_false_blockiert_auswertung(self):
        settings = _settings(BUCHUNG_ATAKAN_FEATURE_HYBRID_PIPELINE=False)
        with pytest.raises(HybridPipelineDeaktiviertFehler):
            werte_lokale_erkennung_aus(_orchestrator_ergebnis(), settings)

    def test_true_erlaubt_auswertung(self):
        settings = _settings(BUCHUNG_ATAKAN_FEATURE_HYBRID_PIPELINE=True)
        ergebnis = werte_lokale_erkennung_aus(_orchestrator_ergebnis(), settings)
        assert ergebnis.status is not None
        assert ergebnis.kandidaten

    def test_false_erreicht_keine_nachgelagerte_auswertungslogik(self):
        """Beweist: Gate stoppt VOR Normalisierung/Konflikt/Auswahl/Statuslogik.
        Beweist NICHT die Unabhaengigkeit von den Provider-Flags -- das pruefen die
        Tests weiter unten separat."""
        settings = _settings(BUCHUNG_ATAKAN_FEATURE_HYBRID_PIPELINE=False)
        with (
            patch(f"{_MODUL}.normalisiere_kandidat", side_effect=AssertionError("darf nicht laufen")),
            patch(f"{_MODUL}.erkenne_konflikte", side_effect=AssertionError("darf nicht laufen")),
            patch(f"{_MODUL}.waehle_kandidaten", side_effect=AssertionError("darf nicht laufen")),
            patch(f"{_MODUL}.berechne_finalen_status", side_effect=AssertionError("darf nicht laufen")),
        ):
            with pytest.raises(HybridPipelineDeaktiviertFehler):
                werte_lokale_erkennung_aus(_orchestrator_ergebnis(), settings)

    def test_gate_erste_anweisung_der_funktion(self):
        """Strukturbeleg (zusaetzlich zu den Verhaltenstests): der Gate-Check ist die
        erste Anweisung nach dem Docstring -- kein Code davor kann Providerpfade
        oder Auswertungslogik erreichen."""
        quelle = textwrap.dedent(inspect.getsource(werte_lokale_erkennung_aus))
        baum = ast.parse(quelle)
        funktion = baum.body[0]
        assert isinstance(funktion, ast.FunctionDef)
        koerper = funktion.body
        # body[0] ist der Docstring, body[1] muss das Gate (if ...: raise ...) sein
        erste_anweisung = koerper[1]
        assert isinstance(erste_anweisung, ast.If)
        raise_stmt = erste_anweisung.body[0]
        assert isinstance(raise_stmt, ast.Raise)


class TestPipelineFlagUnabhaengigVonProviderFlags:
    """HYB-07 verlangt: Hybridpipeline-Flag aktiviert/deaktiviert keinen Provider und
    veraendert keine bestehende Provider-Flag-Logik. Diese Tests pruefen das getrennt
    vom Auswertungs-Gate."""

    def test_pipeline_true_aktiviert_invoice2data_nicht_automatisch(self):
        settings = _settings(
            BUCHUNG_ATAKAN_FEATURE_HYBRID_PIPELINE=True,
            BUCHUNG_ATAKAN_FEATURE_INVOICE2DATA=False,
        )
        assert invoice2data_ist_aktiviert(settings) is False

    def test_pipeline_true_aktiviert_paddleocr_nicht_automatisch(self):
        settings = _settings(
            BUCHUNG_ATAKAN_FEATURE_HYBRID_PIPELINE=True,
            BUCHUNG_ATAKAN_FEATURE_PADDLE_OCR=False,
        )
        assert paddleocr_ist_aktiviert(settings) is False

    def test_pipeline_true_aktiviert_azure_nicht_automatisch(self):
        settings = _settings(
            BUCHUNG_ATAKAN_FEATURE_HYBRID_PIPELINE=True,
            BUCHUNG_ATAKAN_FEATURE_AZURE_DOCUMENT_INTELLIGENCE=False,
        )
        assert azure_ist_aktiviert(settings) is False

    def test_pipeline_false_veraendert_provider_flag_auswertung_nicht(self):
        """Provider-Flags bleiben unabhaengig vom Pipeline-Flag lesbar/wirksam --
        false auf der Pipeline-Ebene deaktiviert nicht heimlich auch die Provider-Flags."""
        settings = _settings(
            BUCHUNG_ATAKAN_FEATURE_HYBRID_PIPELINE=False,
            BUCHUNG_ATAKAN_FEATURE_INVOICE2DATA=True,
            BUCHUNG_ATAKAN_FEATURE_PADDLE_OCR=True,
        )
        assert invoice2data_ist_aktiviert(settings) is True
        assert paddleocr_ist_aktiviert(settings) is True

    def test_gate_pruefung_ruft_keine_provider_oder_netzwerkfunktion_auf(self):
        """ist_hybrid_pipeline_aktiviert() ist ein reiner Attributzugriff (getattr) --
        kein Aufruf von invoice2data/PaddleOCR/Azure-Aktivierungslogik oder Netzwerk-
        /Credential-Code. Patches wuerden bei einem Aufruf schlagen; sie schlagen nicht."""
        settings = _settings(BUCHUNG_ATAKAN_FEATURE_HYBRID_PIPELINE=True)
        with (
            patch(
                "packages.core.invoice_extraction.invoice2data_provider.ist_aktiviert",
                side_effect=AssertionError("Pipeline-Gate darf Provider-Flags nicht aufrufen"),
            ),
            patch(
                "packages.core.invoice_extraction.paddleocr_provider.ist_aktiviert",
                side_effect=AssertionError("Pipeline-Gate darf Provider-Flags nicht aufrufen"),
            ),
            patch(
                "packages.core.invoice_extraction.azure_document_intelligence_provider.ist_aktiviert",
                side_effect=AssertionError("Pipeline-Gate darf Provider-Flags nicht aufrufen"),
            ),
        ):
            werte_lokale_erkennung_aus(_orchestrator_ergebnis(), settings)
