"""Unit-Tests Cent-Konvertierung (BANK-10).

Abgedeckte Anforderungen:
  T1: Integer-Cent bleibt unveraendert.
  T2: Dezimalstring wird exakt in Cent umgewandelt.
  T3: Float-Eingaben werden abgelehnt.
  T4: Mehr als zwei Nachkommastellen werden abgelehnt.
"""
import pytest

from packages.core.bank_import.cent_konvertierung import parse_betrag_cent


class TestIntegerCent:
    def test_positiver_centwert_unveraendert(self):
        """T1: int-Cent unveraendert."""
        assert parse_betrag_cent(11900) == 11900

    def test_null_cent(self):
        assert parse_betrag_cent(0) == 0

    def test_negativer_centwert(self):
        assert parse_betrag_cent(-5000) == -5000

    def test_grosser_betrag(self):
        assert parse_betrag_cent(1_000_000_00) == 100_000_000


class TestDezimalstring:
    def test_zwei_nachkommastellen_punkt(self):
        """T2: Dezimalstring exakt in Cent."""
        assert parse_betrag_cent("119.00") == 11900

    def test_zwei_nachkommastellen_komma(self):
        """T2: Komma als Dezimaltrenner."""
        assert parse_betrag_cent("119,00") == 11900

    def test_eine_nachkommastelle(self):
        assert parse_betrag_cent("1.5") == 150

    def test_keine_nachkommastellen(self):
        assert parse_betrag_cent("100") == 10000

    def test_negativer_dezimalstring(self):
        assert parse_betrag_cent("-50.00") == -5000

    def test_null_string(self):
        assert parse_betrag_cent("0.00") == 0

    def test_whitespace_wird_getrimmt(self):
        assert parse_betrag_cent("  25.50  ") == 2550


class TestFloatAbgelehnt:
    def test_float_wirft_typeerror(self):
        """T3: float-Eingabe wird abgelehnt."""
        with pytest.raises(TypeError):
            parse_betrag_cent(1.5)

    def test_float_null_abgelehnt(self):
        with pytest.raises(TypeError):
            parse_betrag_cent(0.0)

    def test_bool_abgelehnt(self):
        with pytest.raises(TypeError):
            parse_betrag_cent(True)


class TestZuVieleNachkommastellen:
    def test_drei_nachkommastellen_abgelehnt(self):
        """T4: mehr als 2 Nachkommastellen abgelehnt."""
        with pytest.raises(ValueError):
            parse_betrag_cent("1.234")

    def test_vier_nachkommastellen_abgelehnt(self):
        with pytest.raises(ValueError):
            parse_betrag_cent("1.2345")

    def test_ungueltige_zeichenkette_abgelehnt(self):
        with pytest.raises(ValueError):
            parse_betrag_cent("abc")

    def test_leerer_string_abgelehnt(self):
        with pytest.raises(ValueError):
            parse_betrag_cent("")
