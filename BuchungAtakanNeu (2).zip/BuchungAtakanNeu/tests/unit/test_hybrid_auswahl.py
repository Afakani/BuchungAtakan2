"""Unit-Tests fuer Kandidatenauswahl (HYB-14).

Kein Provider erhaelt pauschal Vorrang; Reihenfolge der Eingabe darf das Ergebnis
nicht veraendern; Gleichstand erzwingt keine Auswahl.
"""
from packages.core.invoice_extraction.hybrid_kandidat import AuswahlStatus, HybridKandidat
from packages.core.invoice_extraction.hybrid_konflikt import erkenne_konflikte
from packages.core.invoice_extraction.hybrid_normalisierung import normalisiere_kandidat
from packages.core.invoice_extraction.hybrid_auswahl import waehle_kandidaten


def _k(feld: str, rohwert: str, provider: str, confidence: float = 0.8) -> HybridKandidat:
    roh = HybridKandidat(
        feld=feld, rohwert=rohwert, normwert=None, methode="regex_label",
        provider_name=provider, provider_version="1.0", confidence=confidence,
    )
    return normalisiere_kandidat(roh)


def _status_je_provider(kandidaten: list[HybridKandidat]) -> dict[str, AuswahlStatus]:
    return {k.provider_name: k.auswahl_status for k in kandidaten}


class TestKlareFachlicheAuswahl:
    def test_mehrheit_gewinnt_gegen_einzelabweichler(self):
        kandidaten = [
            _k("total_amount", "119,00", "pdfplumber"),
            _k("total_amount", "119.00", "invoice2data"),
            _k("total_amount", "999.99", "paddleocr"),
        ]
        konflikte = erkenne_konflikte(kandidaten)
        final, konf_final = waehle_kandidaten(kandidaten, konflikte)
        status = _status_je_provider(final)
        assert status["pdfplumber"] == AuswahlStatus.AUSGEWAEHLT
        assert status["invoice2data"] == AuswahlStatus.AUSGEWAEHLT
        assert status["paddleocr"] == AuswahlStatus.ABGELEHNT
        assert konf_final[0].aufloesungsstatus == "AUFGELOEST_MEHRHEIT"

    def test_hoehere_confidence_gewinnt_ohne_mehrheit(self):
        kandidaten = [
            _k("total_amount", "119,00", "pdfplumber", confidence=0.95),
            _k("total_amount", "199.00", "invoice2data", confidence=0.4),
        ]
        konflikte = erkenne_konflikte(kandidaten)
        final, konf_final = waehle_kandidaten(kandidaten, konflikte)
        status = _status_je_provider(final)
        assert status["pdfplumber"] == AuswahlStatus.AUSGEWAEHLT
        assert status["invoice2data"] == AuswahlStatus.ABGELEHNT
        assert konf_final[0].aufloesungsstatus == "AUFGELOEST_CONFIDENCE"

    def test_kein_konflikt_einziger_kandidat_wird_ausgewaehlt(self):
        kandidaten = [_k("invoice_number", "RE-001", "pdfplumber")]
        final, konf_final = waehle_kandidaten(kandidaten, [])
        assert final[0].auswahl_status == AuswahlStatus.AUSGEWAEHLT
        assert konf_final == []


class TestKeineEindeutigeAuswahl:
    def test_gleiche_confidence_und_kein_pdfplumber_bleibt_unsicher(self):
        kandidaten = [
            _k("total_amount", "119,00", "invoice2data", confidence=0.7),
            _k("total_amount", "199.00", "paddleocr", confidence=0.7),
        ]
        konflikte = erkenne_konflikte(kandidaten)
        final, konf_final = waehle_kandidaten(kandidaten, konflikte)
        status = _status_je_provider(final)
        assert status["invoice2data"] == AuswahlStatus.KONFLIKT
        assert status["paddleocr"] == AuswahlStatus.KONFLIKT
        assert konf_final[0].aufloesungsstatus == "UNSICHER"

    def test_pdfplumber_tie_break_nur_bei_echtem_gleichstand(self):
        kandidaten = [
            _k("total_amount", "119,00", "pdfplumber", confidence=0.7),
            _k("total_amount", "199.00", "invoice2data", confidence=0.7),
        ]
        konflikte = erkenne_konflikte(kandidaten)
        final, konf_final = waehle_kandidaten(kandidaten, konflikte)
        status = _status_je_provider(final)
        assert status["pdfplumber"] == AuswahlStatus.AUSGEWAEHLT
        assert status["invoice2data"] == AuswahlStatus.ABGELEHNT
        assert konf_final[0].aufloesungsstatus == "AUFGELOEST_PARSER_TIEBREAK"


class TestAuswahlGrund:
    def test_auswahl_grund_wird_automatisch_befuellt(self):
        kandidaten = [_k("invoice_number", "RE-001", "pdfplumber")]
        final, _ = waehle_kandidaten(kandidaten, [])
        assert final[0].auswahl_grund
        assert isinstance(final[0].auswahl_grund, str)

    def test_abgelehnter_kandidat_hat_grund_mit_gewinnerwert(self):
        kandidaten = [
            _k("total_amount", "119,00", "pdfplumber", confidence=0.95),
            _k("total_amount", "199.00", "invoice2data", confidence=0.4),
        ]
        konflikte = erkenne_konflikte(kandidaten)
        final, _ = waehle_kandidaten(kandidaten, konflikte)
        abgelehnt = next(k for k in final if k.auswahl_status == AuswahlStatus.ABGELEHNT)
        assert "119.00" in abgelehnt.auswahl_grund


class TestAusgeschlosseneKandidaten:
    def test_normalisierungsfehler_wird_abgelehnt(self):
        kandidaten = [_k("total_amount", "kaputt", "pdfplumber")]
        final, _ = waehle_kandidaten(kandidaten, [])
        assert final[0].auswahl_status == AuswahlStatus.ABGELEHNT
        assert "Normalisierung fehlgeschlagen" in final[0].auswahl_grund


class TestProviderfehlerBeeinflusstAndereNicht:
    def test_ein_nicht_normalisierbarer_kandidat_beeinflusst_anderes_feld_nicht(self):
        kandidaten = [
            _k("total_amount", "kaputt", "paddleocr"),
            _k("invoice_number", "RE-001", "pdfplumber"),
        ]
        final, _ = waehle_kandidaten(kandidaten, [])
        rechnungsnummer = next(k for k in final if k.feld == "invoice_number")
        assert rechnungsnummer.auswahl_status == AuswahlStatus.AUSGEWAEHLT


class TestReihenfolgeunabhaengigkeit:
    def test_umgekehrte_reihenfolge_liefert_gleiches_ergebnis(self):
        a = _k("total_amount", "119,00", "pdfplumber")
        b = _k("total_amount", "119.00", "invoice2data")
        c = _k("total_amount", "999.99", "paddleocr")

        konflikte_1 = erkenne_konflikte([a, b, c])
        final_1, _ = waehle_kandidaten([a, b, c], konflikte_1)

        konflikte_2 = erkenne_konflikte([c, b, a])
        final_2, _ = waehle_kandidaten([c, b, a], konflikte_2)

        status_1 = sorted((k.provider_name, str(k.auswahl_status)) for k in final_1)
        status_2 = sorted((k.provider_name, str(k.auswahl_status)) for k in final_2)
        assert status_1 == status_2
