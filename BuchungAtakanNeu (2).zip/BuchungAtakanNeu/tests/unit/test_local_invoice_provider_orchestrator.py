"""Unit-Tests fuer LocalInvoiceProviderOrchestrator (HYB-09..13).

Provider-Klassen und Dokumentklassifikation werden gefaked, damit die Orchestrierung
isoliert getestet werden kann -- kein Datei-IO, keine echten PDFs, kein invoice2data/
PaddleOCR noetig.
"""
from pathlib import Path
from unittest.mock import patch

import pytest

from packages.core.invoice_extraction.document_classifier import DokumentKlasse
from packages.core.invoice_extraction.hybrid_kandidat import HybridKandidat
from packages.core.invoice_extraction.provider_ports import InvoiceProviderResult

_MODUL = "packages.core.invoice_extraction.local_provider_orchestrator"


class _FakeProvider:
    aufrufe: list[str] = []

    def __init__(self, providername: str, wirft: bool = False):
        self._name = providername
        self._wirft = wirft

    @property
    def name(self) -> str:
        return self._name

    @property
    def version(self) -> str:
        return "1.0"

    def extract(self, pdf_path: Path) -> InvoiceProviderResult:
        _FakeProvider.aufrufe.append(self._name)
        if self._wirft:
            raise RuntimeError(f"Fehler in {self._name}")
        return InvoiceProviderResult(
            provider_name=self._name,
            provider_version="1.0",
            laufstatus="success",
            kandidaten=[
                HybridKandidat(
                    feld="invoice_number",
                    rohwert="RE-1",
                    normwert="RE-1",
                    methode="fake",
                    provider_name=self._name,
                    provider_version="1.0",
                    confidence=0.8,
                )
            ],
            fehlercode=None,
        )


def _settings(**flags):
    defaults = dict(
        BUCHUNG_ATAKAN_FEATURE_INVOICE2DATA=False,
        BUCHUNG_ATAKAN_FEATURE_PADDLE_OCR=False,
        BUCHUNG_ATAKAN_FEATURE_AZURE_DI=False,
    )
    defaults.update(flags)
    return type("S", (), defaults)()


@pytest.fixture(autouse=True)
def _reset_aufrufe():
    _FakeProvider.aufrufe = []
    yield
    _FakeProvider.aufrufe = []


class TestNurAktivierteProviderLaufen:
    def test_invoice2data_deaktiviert_laeuft_nicht(self):
        with patch(f"{_MODUL}.klassifiziere_pfad", return_value=DokumentKlasse.TEXT_PDF), \
             patch(f"{_MODUL}.PdfplumberProvider", lambda: _FakeProvider("pdfplumber")), \
             patch(f"{_MODUL}.Invoice2DataProvider", lambda: _FakeProvider("invoice2data")):
            from packages.core.invoice_extraction.local_provider_orchestrator import (
                fuehre_lokale_erkennung_aus,
            )
            fuehre_lokale_erkennung_aus(Path("dummy.pdf"), _settings())
        assert _FakeProvider.aufrufe == ["pdfplumber"]

    def test_invoice2data_aktiviert_laeuft_zusaetzlich(self):
        with patch(f"{_MODUL}.klassifiziere_pfad", return_value=DokumentKlasse.TEXT_PDF), \
             patch(f"{_MODUL}.PdfplumberProvider", lambda: _FakeProvider("pdfplumber")), \
             patch(f"{_MODUL}.Invoice2DataProvider", lambda: _FakeProvider("invoice2data")):
            from packages.core.invoice_extraction.local_provider_orchestrator import (
                fuehre_lokale_erkennung_aus,
            )
            fuehre_lokale_erkennung_aus(
                Path("dummy.pdf"), _settings(BUCHUNG_ATAKAN_FEATURE_INVOICE2DATA=True)
            )
        assert sorted(_FakeProvider.aufrufe) == ["invoice2data", "pdfplumber"]

    def test_paddleocr_nur_bei_scan_pdf_und_flag(self):
        with patch(f"{_MODUL}.klassifiziere_pfad", return_value=DokumentKlasse.SCAN_PDF), \
             patch(f"{_MODUL}.PaddleOCRProvider", lambda: _FakeProvider("paddleocr")):
            from packages.core.invoice_extraction.local_provider_orchestrator import (
                fuehre_lokale_erkennung_aus,
            )
            fuehre_lokale_erkennung_aus(
                Path("dummy.pdf"), _settings(BUCHUNG_ATAKAN_FEATURE_PADDLE_OCR=True)
            )
        assert _FakeProvider.aufrufe == ["paddleocr"]

    def test_paddleocr_deaktiviert_laeuft_nicht_bei_scan_pdf(self):
        with patch(f"{_MODUL}.klassifiziere_pfad", return_value=DokumentKlasse.SCAN_PDF), \
             patch(f"{_MODUL}.PaddleOCRProvider", lambda: _FakeProvider("paddleocr")):
            from packages.core.invoice_extraction.local_provider_orchestrator import (
                fuehre_lokale_erkennung_aus,
            )
            fuehre_lokale_erkennung_aus(Path("dummy.pdf"), _settings())
        assert _FakeProvider.aufrufe == []

    def test_sonderformat_kein_provider(self):
        with patch(f"{_MODUL}.klassifiziere_pfad", return_value=DokumentKlasse.SONDERFORMAT):
            from packages.core.invoice_extraction.local_provider_orchestrator import (
                fuehre_lokale_erkennung_aus,
            )
            ergebnis = fuehre_lokale_erkennung_aus(Path("dummy.xml"), _settings())
        assert ergebnis.provider_ergebnisse == []


class TestFehlerIsolierung:
    def test_fehler_eines_providers_blockiert_andere_nicht(self):
        with patch(f"{_MODUL}.klassifiziere_pfad", return_value=DokumentKlasse.TEXT_PDF), \
             patch(f"{_MODUL}.PdfplumberProvider", lambda: _FakeProvider("pdfplumber", wirft=True)), \
             patch(f"{_MODUL}.Invoice2DataProvider", lambda: _FakeProvider("invoice2data")):
            from packages.core.invoice_extraction.local_provider_orchestrator import (
                fuehre_lokale_erkennung_aus,
            )
            ergebnis = fuehre_lokale_erkennung_aus(
                Path("dummy.pdf"), _settings(BUCHUNG_ATAKAN_FEATURE_INVOICE2DATA=True)
            )
        status_je_provider = {r.provider_name: r.laufstatus for r in ergebnis.provider_ergebnisse}
        assert status_je_provider["pdfplumber"] == "error"
        assert status_je_provider["invoice2data"] == "success"

    def test_fehlercode_ohne_stacktrace(self):
        with patch(f"{_MODUL}.klassifiziere_pfad", return_value=DokumentKlasse.TEXT_PDF), \
             patch(f"{_MODUL}.PdfplumberProvider", lambda: _FakeProvider("pdfplumber", wirft=True)):
            from packages.core.invoice_extraction.local_provider_orchestrator import (
                fuehre_lokale_erkennung_aus,
            )
            ergebnis = fuehre_lokale_erkennung_aus(Path("dummy.pdf"), _settings())
        fehler_ergebnis = next(r for r in ergebnis.provider_ergebnisse if r.provider_name == "pdfplumber")
        assert fehler_ergebnis.fehlercode == "RuntimeError"
        assert fehler_ergebnis.kandidaten == []


class TestAzureNieInstanziiert:
    def test_azure_flag_true_hat_keine_wirkung(self):
        with patch(f"{_MODUL}.klassifiziere_pfad", return_value=DokumentKlasse.TEXT_PDF), \
             patch(f"{_MODUL}.PdfplumberProvider", lambda: _FakeProvider("pdfplumber")):
            from packages.core.invoice_extraction.local_provider_orchestrator import (
                fuehre_lokale_erkennung_aus,
            )
            ergebnis = fuehre_lokale_erkennung_aus(
                Path("dummy.pdf"), _settings(BUCHUNG_ATAKAN_FEATURE_AZURE_DI=True)
            )
        provider_namen = {r.provider_name for r in ergebnis.provider_ergebnisse}
        assert provider_namen == {"pdfplumber"}
        assert "azure" not in provider_namen

    def test_orchestrator_modul_instanziiert_keinen_cloud_provider(self):
        import packages.core.invoice_extraction.local_provider_orchestrator as modul
        quelltext = Path(modul.__file__).read_text(encoding="utf-8")
        assert "AzureInvoiceProvider" not in quelltext
        assert "CloudInvoiceProvider(" not in quelltext


class TestNochKeineFinaleAuswahl:
    def test_kandidaten_ohne_auswahl_status(self):
        with patch(f"{_MODUL}.klassifiziere_pfad", return_value=DokumentKlasse.TEXT_PDF), \
             patch(f"{_MODUL}.PdfplumberProvider", lambda: _FakeProvider("pdfplumber")), \
             patch(f"{_MODUL}.Invoice2DataProvider", lambda: _FakeProvider("invoice2data")):
            from packages.core.invoice_extraction.local_provider_orchestrator import (
                fuehre_lokale_erkennung_aus,
            )
            ergebnis = fuehre_lokale_erkennung_aus(
                Path("dummy.pdf"), _settings(BUCHUNG_ATAKAN_FEATURE_INVOICE2DATA=True)
            )
        assert len(ergebnis.kandidaten) == 2
        assert all(k.auswahl_status is None for k in ergebnis.kandidaten)
