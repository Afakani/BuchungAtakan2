import json
from pathlib import Path
from uuid import UUID

import pytest

from apps.client.config import ClientConfig


def test_create_new_generates_uuid(tmp_path):
    cfg = ClientConfig.create_new("http://localhost:8000", tmp_path)
    assert isinstance(cfg.installation_id, UUID)
    assert cfg.server_url == "http://localhost:8000"
    assert cfg.data_root == tmp_path


def test_create_new_strips_trailing_slash(tmp_path):
    cfg = ClientConfig.create_new("http://localhost:8000/", tmp_path)
    assert cfg.server_url == "http://localhost:8000"


def test_save_and_load_roundtrip(tmp_path):
    config_file = tmp_path / "client.json"
    original = ClientConfig.create_new("http://api.example.com", tmp_path / "data")
    original.save(config_file)

    loaded = ClientConfig.load(config_file)
    assert loaded.server_url == original.server_url
    assert loaded.installation_id == original.installation_id
    assert loaded.data_root == original.data_root


def test_save_creates_parent_directory(tmp_path):
    config_file = tmp_path / "sub" / "dir" / "client.json"
    cfg = ClientConfig.create_new("http://test", tmp_path)
    cfg.save(config_file)
    assert config_file.exists()


def test_save_json_structure(tmp_path):
    config_file = tmp_path / "client.json"
    cfg = ClientConfig.create_new("http://test", tmp_path / "data")
    cfg.save(config_file)

    with config_file.open() as f:
        data = json.load(f)

    assert "server_url" in data
    assert "installation_id" in data
    assert "data_root" in data
    assert "password" not in data
    assert "token" not in data
    assert "passwort" not in data


def test_load_missing_file_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        ClientConfig.load(tmp_path / "nicht_vorhanden.json")


def test_load_env_override(tmp_path, monkeypatch):
    config_file = tmp_path / "client.json"
    cfg = ClientConfig.create_new("http://original", tmp_path / "data")
    cfg.save(config_file)

    monkeypatch.setenv("BUCHUNG_ATAKAN_SERVER_URL", "http://override")
    loaded = ClientConfig.load(config_file)
    assert loaded.server_url == "http://override"


def test_two_configs_have_different_installation_ids(tmp_path):
    cfg1 = ClientConfig.create_new("http://api", tmp_path)
    cfg2 = ClientConfig.create_new("http://api", tmp_path)
    assert cfg1.installation_id != cfg2.installation_id
