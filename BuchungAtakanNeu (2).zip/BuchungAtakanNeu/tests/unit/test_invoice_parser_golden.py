"""Golden-File-Tests fuer InvoiceParser — synthetische Fixtures, keine echten PDFs."""
from pathlib import Path

import pytest

from packages.core.invoice_extraction.invoice_parser import InvoiceParser
from packages.core.invoice_extraction.invoice_parser_adapter import extract_from_text
from packages.core.invoice_extraction.extraction_result import ExtraktionsStatus

_FIXTURES = Path(__file__).parent.parent / "fixtures"
_PARSER = InvoiceParser()


def _text(filename: str) -> str:
    return (_FIXTURES / filename).read_text(encoding="utf-8")


# --- Standard-Rechnung ---

def test_standard_vendor_name():
    data = _PARSER.parse(_text("rechnung_standard.txt"))
    assert data.vendor_name is not None
    assert "Muster" in data.vendor_name


def test_standard_invoice_number():
    data = _PARSER.parse(_text("rechnung_standard.txt"))
    assert data.invoice_number == "2024-0042"


def test_standard_invoice_date():
    data = _PARSER.parse(_text("rechnung_standard.txt"))
    assert data.invoice_date == "15.01.2024"


def test_standard_total_amount():
    data = _PARSER.parse(_text("rechnung_standard.txt"))
    assert data.total_amount == pytest.approx(119.0, abs=0.01)


def test_standard_net_amount():
    data = _PARSER.parse(_text("rechnung_standard.txt"))
    assert data.net_amount == pytest.approx(100.0, abs=0.01)


def test_standard_tax_amount():
    data = _PARSER.parse(_text("rechnung_standard.txt"))
    assert data.tax_amount == pytest.approx(19.0, abs=0.01)


def test_standard_extract_from_text_ok():
    result = extract_from_text(_text("rechnung_standard.txt"))
    # Standard-Rechnung hat alle Pflichtfelder → OK oder PRUEFFALL (nicht UNVOLLSTAENDIG/MATH_FEHLER)
    assert result.status in {ExtraktionsStatus.OK, ExtraktionsStatus.PRUEFFALL}


# --- Amazon-Format ---

def test_amazon_vendor_name():
    data = _PARSER.parse(_text("rechnung_amazon.txt"))
    assert data.vendor_name is not None
    assert "Elektronik" in data.vendor_name or "Beispiel" in data.vendor_name


def test_amazon_invoice_number():
    data = _PARSER.parse(_text("rechnung_amazon.txt"))
    assert data.invoice_number is not None
    assert "98765" in data.invoice_number or "INV" in (data.invoice_number or "")


def test_amazon_total_amount():
    data = _PARSER.parse(_text("rechnung_amazon.txt"))
    assert data.total_amount == pytest.approx(11.59, abs=0.02)


# --- Kleinunternehmer §19 UStG ---

def test_kleinunternehmer_kein_steuerbetrag():
    data = _PARSER.parse(_text("rechnung_kleinunternehmer.txt"))
    # §19-Erkennung → tax_amount sollte 0 oder None sein
    assert data.tax_amount is None or data.tax_amount == pytest.approx(0.0, abs=0.01)


def test_kleinunternehmer_invoice_number():
    data = _PARSER.parse(_text("rechnung_kleinunternehmer.txt"))
    assert data.invoice_number is not None
    assert "FS-2024-003" in (data.invoice_number or "")


def test_kleinunternehmer_datum_april_englisch():
    """Regressionstest A-06: '05. April 2024' muss korrekt geparst werden."""
    data = _PARSER.parse(_text("rechnung_kleinunternehmer.txt"))
    assert data.invoice_date == "05.04.2024"


def test_kleinunternehmer_total_amount():
    data = _PARSER.parse(_text("rechnung_kleinunternehmer.txt"))
    assert data.total_amount == pytest.approx(250.0, abs=0.01)


# --- Doppelzeile: gleiche Firma als Rechnungsadresse und als Vendor ---

def test_doppelzeile_vendor_nicht_leer():
    data = _PARSER.parse(_text("rechnung_doppelzeile.txt"))
    # Parser soll Vendor finden, nicht None zurückgeben trotz Duplikat-Empfängerzeile
    assert data.vendor_name is not None
    assert "Duplikat Test" in (data.vendor_name or "")


def test_doppelzeile_invoice_number():
    data = _PARSER.parse(_text("rechnung_doppelzeile.txt"))
    assert data.invoice_number is not None


# --- Parser-Robustheit (A-08) ---

def test_parse_leerstring_kein_exception():
    data = _PARSER.parse("")
    assert data.confidence == 0.0
    assert data.vendor_name is None


def test_parse_nullbytes_kein_exception():
    data = _PARSER.parse("Test \x00\x01\x02 Inhalt")
    # Kein Exception; Ergebnis beliebig aber confidence muss float sein
    assert isinstance(data.confidence, float)
