"""Unit-Tests fuer HybridExtractionResult und berechne_hybrid_status (HYB-05/06).

Kernregel: OK entsteht NICHT allein durch gefuellte Pflichtfelder.
Konflikte bei Pflichtfeldern werden nie still priorisiert.
"""
import pytest

from packages.core.invoice_extraction.hybrid_ergebnis import (
    HybridStatus,
    berechne_hybrid_status,
)
from packages.core.invoice_extraction.hybrid_kandidat import AuswahlStatus, HybridKandidat


def _k(feld: str, confidence: float = 0.8, auswahl_status: AuswahlStatus | None = None) -> HybridKandidat:
    return HybridKandidat(
        feld=feld,
        rohwert="wert",
        normwert="wert",
        methode="regex_label",
        provider_name="pdfplumber",
        provider_version="1.0",
        confidence=confidence,
        auswahl_status=auswahl_status,
    )


_PFLICHT = ["vendor_name", "invoice_number", "invoice_date", "total_amount"]


def _alle_pflicht(confidence: float = 0.8, auswahl_status: AuswahlStatus | None = None) -> list[HybridKandidat]:
    return [_k(f, confidence=confidence, auswahl_status=auswahl_status) for f in _PFLICHT]


class TestNichtGefunden:
    def test_keine_kandidaten(self):
        status, gruende = berechne_hybrid_status([])
        assert status == HybridStatus.NICHT_GEFUNDEN
        assert any("NICHT_GEFUNDEN" in g for g in gruende)

    def test_nur_nicht_pflicht_felder(self):
        kandidaten = [_k("currency"), _k("payment_method")]
        status, _ = berechne_hybrid_status(kandidaten)
        assert status == HybridStatus.NICHT_GEFUNDEN


class TestMussPrueftWerden:
    def test_pflichtfeld_fehlt(self):
        kandidaten = [_k("vendor_name"), _k("invoice_number"), _k("invoice_date")]
        # total_amount fehlt
        status, gruende = berechne_hybrid_status(kandidaten)
        assert status == HybridStatus.MUSS_GEPRUEFT_WERDEN
        assert any("total_amount" in g for g in gruende)

    def test_konflikt_bei_pflichtfeld_nie_still(self):
        """Konflikte bei Pflichtfeldern duerfen nie still priorisiert werden (HYB-05)."""
        kandidaten = _alle_pflicht(auswahl_status=AuswahlStatus.KONFLIKT)
        status, gruende = berechne_hybrid_status(kandidaten)
        assert status == HybridStatus.MUSS_GEPRUEFT_WERDEN
        assert any("Konflikt" in g for g in gruende)

    def test_konflikt_nur_bei_einem_pflichtfeld(self):
        kandidaten = [
            _k("vendor_name", auswahl_status=AuswahlStatus.KONFLIKT),
            _k("invoice_number"),
            _k("invoice_date"),
            _k("total_amount"),
        ]
        status, gruende = berechne_hybrid_status(kandidaten)
        assert status == HybridStatus.MUSS_GEPRUEFT_WERDEN
        assert any("vendor_name" in g for g in gruende)

    def test_math_fehler(self):
        kandidaten = _alle_pflicht()
        status, gruende = berechne_hybrid_status(kandidaten, math_ok=False)
        assert status == HybridStatus.MUSS_GEPRUEFT_WERDEN
        assert any("Mathematisch" in g or "mathematisch" in g.lower() for g in gruende)

    def test_confidence_zu_niedrig(self):
        kandidaten = _alle_pflicht(confidence=0.3)
        status, gruende = berechne_hybrid_status(kandidaten)
        assert status == HybridStatus.MUSS_GEPRUEFT_WERDEN
        assert any("Confidence" in g or "confidence" in g.lower() for g in gruende)

    def test_confidence_genau_an_schwelle(self):
        # 0.5 ist genau die Schwelle — ist OK (>= 0.5)
        kandidaten = _alle_pflicht(confidence=0.5)
        status, _ = berechne_hybrid_status(kandidaten)
        assert status == HybridStatus.OK


class TestOk:
    def test_alle_bedingungen_erfuellt(self):
        """OK erfordert Pflichtfelder + Validierung + Confidence + keine Konflikte."""
        kandidaten = _alle_pflicht(confidence=0.9)
        status, gruende = berechne_hybrid_status(kandidaten)
        assert status == HybridStatus.OK
        assert any("OK" in g for g in gruende)

    def test_math_ok_none_erlaubt_ok(self):
        """math_ok=None (unbekannt) blockiert OK nicht."""
        kandidaten = _alle_pflicht()
        status, _ = berechne_hybrid_status(kandidaten, math_ok=None)
        assert status == HybridStatus.OK

    def test_nicht_pflicht_konflikt_blockiert_ok_nicht(self):
        """Konflikte bei Nicht-Pflichtfeldern sind kein Blocker."""
        kandidaten = _alle_pflicht() + [
            _k("currency", auswahl_status=AuswahlStatus.KONFLIKT)
        ]
        status, _ = berechne_hybrid_status(kandidaten)
        assert status == HybridStatus.OK

    def test_ok_nur_mit_gefuellten_feldern_reicht_nicht(self):
        """Confidence unter Schwelle verhindert OK trotz gefuellter Pflichtfelder."""
        kandidaten = _alle_pflicht(confidence=0.1)
        status, _ = berechne_hybrid_status(kandidaten)
        assert status != HybridStatus.OK

    def test_mehrere_kandidaten_je_feld_bester_entscheidet(self):
        kandidaten = [
            _k("vendor_name", confidence=0.3),
            _k("vendor_name", confidence=0.9),
            _k("invoice_number"),
            _k("invoice_date"),
            _k("total_amount"),
        ]
        status, _ = berechne_hybrid_status(kandidaten)
        assert status == HybridStatus.OK
