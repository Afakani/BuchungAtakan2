"""Unit-Tests fuer reine Statistiklogik (07-03A, HYB-18) -- kein Datenbankzugriff."""
import pytest

from packages.core.invoice_extraction.hybrid_statistik import (
    ALLE_DIMENSIONEN,
    DIM_ANBIETER,
    DIM_METHODE,
    DIM_STATUS,
    UNBEKANNT,
    StatistikZeile,
    gruppiere_statistik,
    normalisiere_anbieter,
    normalisiere_dokument_klasse,
    normalisiere_methode,
)


def _zeile(
    id_: str,
    anbieter: str = "Muster GmbH",
    dokument_klasse: str = "TEXT_PDF",
    methode: str = "pdfplumber",
    status: str = "OK",
    pflichtfelder_ok: bool = True,
    audit_korrekt: bool | None = None,
) -> StatistikZeile:
    return StatistikZeile(
        statusentscheidung_id=id_,
        anbieter=anbieter,
        dokument_klasse=dokument_klasse,
        methode=methode,
        status=status,
        pflichtfelder_ok=pflichtfelder_ok,
        audit_korrekt=audit_korrekt,
    )


class TestNormalisierung:
    def test_none_anbieter_wird_unbekannt(self):
        assert normalisiere_anbieter(None) == UNBEKANNT

    def test_blanker_anbieter_wird_unbekannt(self):
        assert normalisiere_anbieter("   ") == UNBEKANNT

    def test_gefuellter_anbieter_bleibt_erhalten(self):
        assert normalisiere_anbieter("Muster GmbH") == "Muster GmbH"

    def test_none_dokument_klasse_wird_unbekannt(self):
        assert normalisiere_dokument_klasse(None) == UNBEKANNT

    def test_gefuellte_dokument_klasse_bleibt_erhalten(self):
        assert normalisiere_dokument_klasse("SCAN_PDF") == "SCAN_PDF"

    def test_none_methode_wird_unbekannt(self):
        assert normalisiere_methode(None) == UNBEKANNT


class TestQuoten:
    def test_vollstaendigkeitsquote_zaehlt_pflichtfelder_ok(self):
        zeilen = [
            _zeile("1", pflichtfelder_ok=True),
            _zeile("2", pflichtfelder_ok=True),
            _zeile("3", pflichtfelder_ok=False),
        ]
        gruppen = gruppiere_statistik(zeilen, dimensionen=())
        assert len(gruppen) == 1
        q = gruppen[0].vollstaendigkeitsquote
        assert (q.zaehler, q.nenner) == (2, 3)
        assert q.quote == pytest.approx(2 / 3)

    def test_automatisierung_pruef_nichterkennung_summieren_sich_zu_n(self):
        zeilen = [
            _zeile("1", status="OK"),
            _zeile("2", status="MUSS_GEPRUEFT_WERDEN"),
            _zeile("3", status="NICHT_GEFUNDEN"),
            _zeile("4", status="OK"),
        ]
        gruppen = gruppiere_statistik(zeilen, dimensionen=())
        g = gruppen[0]
        assert g.automatisierungsquote.zaehler == 2
        assert g.pruefquote.zaehler == 1
        assert g.nichterkennungsquote.zaehler == 1
        assert g.automatisierungsquote.nenner == 4

    def test_richtigkeitsquote_nur_ueber_auditierte_zeilen(self):
        zeilen = [
            _zeile("1", audit_korrekt=True),
            _zeile("2", audit_korrekt=False),
            _zeile("3", audit_korrekt=None),  # nicht auditiert -> zaehlt nicht in Nenner
        ]
        gruppen = gruppiere_statistik(zeilen, dimensionen=())
        q = gruppen[0].richtigkeitsquote
        assert (q.zaehler, q.nenner) == (1, 2)
        assert q.quote == pytest.approx(0.5)

    def test_nenner_null_ergibt_quote_none_zaehler_nenner_sichtbar(self):
        zeilen = [_zeile("1", audit_korrekt=None)]
        gruppen = gruppiere_statistik(zeilen, dimensionen=())
        q = gruppen[0].richtigkeitsquote
        assert q.quote is None
        assert q.zaehler == 0
        assert q.nenner == 0


class TestGruppierungUndSortierung:
    def test_gruppierung_nach_allen_vier_dimensionen(self):
        zeilen = [
            _zeile("1", anbieter="A", dokument_klasse="TEXT_PDF", methode="pdfplumber", status="OK"),
            _zeile("2", anbieter="B", dokument_klasse="SCAN_PDF", methode="paddleocr", status="NICHT_GEFUNDEN"),
        ]
        gruppen = gruppiere_statistik(zeilen, dimensionen=ALLE_DIMENSIONEN)
        assert len(gruppen) == 2
        for g in gruppen:
            assert g.dimensionen == ALLE_DIMENSIONEN
            assert len(g.dimensionswerte) == 4

    def test_deterministische_sortierung_unabhaengig_von_eingabereihenfolge(self):
        zeilen_a = [
            _zeile("1", anbieter="Zeta"),
            _zeile("2", anbieter="Alpha"),
        ]
        zeilen_b = list(reversed(zeilen_a))
        g_a = gruppiere_statistik(zeilen_a, dimensionen=(DIM_ANBIETER,))
        g_b = gruppiere_statistik(zeilen_b, dimensionen=(DIM_ANBIETER,))
        assert [g.dimensionswerte for g in g_a] == [g.dimensionswerte for g in g_b]
        assert [g.dimensionswerte for g in g_a] == [("Alpha",), ("Zeta",)]

    def test_dedupliziert_statusentscheidung_bei_mehreren_methoden_ohne_methode_dimension(self):
        """Eine Statusentscheidung mit zwei Providern (Methoden) darf ohne die
        Dimension 'methode' nicht doppelt gezaehlt werden."""
        zeilen = [
            _zeile("1", methode="pdfplumber", status="OK"),
            _zeile("1", methode="invoice2data", status="OK"),
        ]
        gruppen = gruppiere_statistik(zeilen, dimensionen=(DIM_STATUS,))
        assert len(gruppen) == 1
        assert gruppen[0].anzahl == 1

    def test_gleiche_statusentscheidung_zaehlt_je_methode_wenn_methode_dimension_aktiv(self):
        zeilen = [
            _zeile("1", methode="pdfplumber", status="OK"),
            _zeile("1", methode="invoice2data", status="OK"),
        ]
        gruppen = gruppiere_statistik(zeilen, dimensionen=(DIM_METHODE,))
        assert len(gruppen) == 2
        assert {g.anzahl for g in gruppen} == {1}

    def test_leere_eingabe_ergibt_keine_gruppen(self):
        assert gruppiere_statistik([], dimensionen=ALLE_DIMENSIONEN) == []


class TestKeineMehrfachzaehlungBeiMehrerenProvidernOderAudits:
    """Haertet die Gruppierung gegen Mehrfachzaehlung ab -- Regression zum Fund, dass
    ein realer Testfehler (4 statt 1) auf geteilten Testdaten zwischen Testfaellen
    beruhte, nicht auf einem Gruppierungsfehler. Diese Tests beweisen die reine
    Kernlogik unabhaengig von jeder Datenbank."""

    def test_zwei_provider_gleiche_statusentscheidung_alle_fuenf_quoten_nenner_eins_ohne_methode(self):
        zeilen = [
            _zeile("1", methode="pdfplumber", status="OK", pflichtfelder_ok=True, audit_korrekt=True),
            _zeile("1", methode="invoice2data", status="OK", pflichtfelder_ok=True, audit_korrekt=True),
        ]
        gruppen = gruppiere_statistik(zeilen, dimensionen=(DIM_STATUS,))
        assert len(gruppen) == 1
        g = gruppen[0]
        assert g.anzahl == 1
        assert g.vollstaendigkeitsquote.nenner == 1
        assert g.automatisierungsquote.nenner == 1
        assert g.pruefquote.nenner == 1
        assert g.nichterkennungsquote.nenner == 1
        assert g.richtigkeitsquote.nenner == 1
        assert g.richtigkeitsquote.zaehler == 1

    def test_drei_provider_gleiche_statusentscheidung_ohne_methode_dimension_n_bleibt_eins(self):
        zeilen = [
            _zeile("1", methode="pdfplumber"),
            _zeile("1", methode="invoice2data"),
            _zeile("1", methode="paddleocr"),
        ]
        gruppen = gruppiere_statistik(zeilen, dimensionen=())
        assert len(gruppen) == 1
        assert gruppen[0].anzahl == 1

    def test_drei_provider_mit_methode_dimension_keine_duplikate_je_methodengruppe(self):
        zeilen = [
            _zeile("1", methode="pdfplumber"),
            _zeile("1", methode="invoice2data"),
            _zeile("1", methode="paddleocr"),
        ]
        gruppen = gruppiere_statistik(zeilen, dimensionen=(DIM_METHODE,))
        assert len(gruppen) == 3
        for g in gruppen:
            assert g.anzahl == 1, f"Methodengruppe {g.dimensionswerte} enthaelt Duplikate"

    def test_verschiedene_statusentscheidungen_mit_gleicher_methode_werden_nicht_wegdedupliziert(self):
        """Dedup ist ausschliesslich statusentscheidung_id-basiert -- zwei ECHT
        verschiedene Statusentscheidungen mit derselben Methode duerfen nicht auf
        eine zusammenfallen."""
        zeilen = [
            _zeile("1", methode="pdfplumber", status="OK"),
            _zeile("2", methode="pdfplumber", status="OK"),
        ]
        gruppen = gruppiere_statistik(zeilen, dimensionen=(DIM_METHODE,))
        assert len(gruppen) == 1
        assert gruppen[0].anzahl == 2

    def test_mehrere_methoden_zeilen_tragen_identisches_audit_ergebnis_ohne_doppelzaehlung(self):
        """audit_korrekt ist bereits die aufgeloeste neueste Bewertung (Repository-
        Verantwortung, siehe hybrid_audit.waehle_neueste_bewertung) -- mehrere
        Methoden-Zeilen derselben Statusentscheidung duerfen die Richtigkeitsquote
        nicht mehrfach zaehlen."""
        zeilen = [
            _zeile("1", methode="pdfplumber", audit_korrekt=False),
            _zeile("1", methode="invoice2data", audit_korrekt=False),
        ]
        gruppen = gruppiere_statistik(zeilen, dimensionen=())
        q = gruppen[0].richtigkeitsquote
        assert (q.zaehler, q.nenner) == (0, 1)

    def test_gruppierung_ohne_dimensionen_ist_globales_aggregat_ueber_alle_zeilen(self):
        """dimensionen=() ist bewusst 'keine Gruppierung' -- ein einziges Aggregat ueber
        alle uebergebenen Zeilen. Aufrufer sind dafuer verantwortlich, nur die Zeilen zu
        uebergeben, die tatsaechlich aggregiert werden sollen (Repository-/Testverantwortung,
        siehe Regressionsfund in test_hybrid_audit_bewertungen.py)."""
        zeilen = [_zeile("1"), _zeile("2"), _zeile("3")]
        gruppen = gruppiere_statistik(zeilen, dimensionen=())
        assert len(gruppen) == 1
        assert gruppen[0].anzahl == 3
