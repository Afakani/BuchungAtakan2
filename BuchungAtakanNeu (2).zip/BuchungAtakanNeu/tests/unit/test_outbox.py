import pytest

from apps.client.outbox import DokumentOutbox, OutboxStatus


@pytest.fixture
def outbox(tmp_path):
    return DokumentOutbox(tmp_path / "outbox.db")


def test_enqueue_returns_id(outbox):
    entry_id = outbox.enqueue("/api/v1/dokumente", {"sha256": "abc"})
    assert isinstance(entry_id, str) and len(entry_id) > 0


def test_pending_contains_new_entry(outbox):
    outbox.enqueue("/api/v1/dokumente", {"sha256": "abc"})
    pending = outbox.pending()
    assert len(pending) == 1
    assert pending[0].status == OutboxStatus.PENDING
    assert pending[0].payload == {"sha256": "abc"}


def test_mark_sent_removes_entry(outbox):
    entry_id = outbox.enqueue("/api/v1/dokumente", {"sha256": "abc"})
    outbox.mark_sent(entry_id)
    assert outbox.pending() == []


def test_mark_failed_sets_status(outbox):
    entry_id = outbox.enqueue("/api/v1/dokumente", {"sha256": "abc"})
    outbox.mark_failed(entry_id, "Verbindung fehlgeschlagen")
    pending = outbox.pending()
    assert len(pending) == 0  # FAILED erscheint nicht in pending()


def test_mark_failed_increments_attempt_count(outbox):
    entry_id = outbox.enqueue("/api/v1/dokumente", {"sha256": "abc"})
    outbox.mark_failed(entry_id, "Fehler 1")
    outbox.mark_failed(entry_id, "Fehler 2")
    import sqlite3
    with sqlite3.connect(outbox._db_path) as conn:
        row = conn.execute(
            "SELECT attempt_count, last_error FROM outbox WHERE id = ?", (entry_id,)
        ).fetchone()
    assert row[0] == 2
    assert row[1] == "Fehler 2"


def test_reset_failed_returns_to_pending(outbox):
    entry_id = outbox.enqueue("/api/v1/dokumente", {"sha256": "abc"})
    outbox.mark_failed(entry_id, "Fehler")
    count = outbox.reset_failed()
    assert count == 1
    pending = outbox.pending()
    assert len(pending) == 1
    assert pending[0].status == OutboxStatus.PENDING


def test_multiple_entries_sorted_by_time(outbox):
    for i in range(3):
        outbox.enqueue("/api/v1/dokumente", {"sha256": f"hash{i}"})
    pending = outbox.pending()
    assert len(pending) == 3
    created_ats = [e.created_at for e in pending]
    assert created_ats == sorted(created_ats)


def test_empty_outbox_pending(outbox):
    assert outbox.pending() == []


def test_reset_failed_no_failed_entries(outbox):
    outbox.enqueue("/api/v1/dokumente", {"sha256": "x"})
    count = outbox.reset_failed()
    assert count == 0
