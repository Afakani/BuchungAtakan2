"""Unit-Tests fuer InvoiceValidator (RECH-04/05)."""
import pytest

from packages.core.invoice_extraction.extraction_result import ExtractionResult, ExtraktionsStatus
from packages.core.invoice_extraction.invoice_validator import validate
from packages.core.invoice_extraction.kandidat import Kandidat


def _k(feld: str, normwert: str | None, confidence: float = 0.8) -> Kandidat:
    return Kandidat(feld=feld, rohwert=normwert or "", normwert=normwert, methode="regex_label", quelle="pdf_text", confidence=confidence)


def _result(*kandidaten: Kandidat, status: ExtraktionsStatus = ExtraktionsStatus.OK) -> ExtractionResult:
    return ExtractionResult(kandidaten=list(kandidaten), status=status, fehler=[], roher_text="", confidence=0.8)


def _alle_pflicht(*extra: Kandidat) -> list[Kandidat]:
    """Gibt vollständige Pflichtfeld-Kandidaten zurück, optional erweitert."""
    basis = [
        _k("vendor_name", "Test GmbH"),
        _k("invoice_number", "2024-001"),
        _k("invoice_date", "15.01.2024"),
    ]
    return basis + list(extra)


def test_math_ok_kein_fehler():
    r = _result(*_alle_pflicht(_k("total_amount", "119.00"), _k("net_amount", "100.00"), _k("tax_amount", "19.00")))
    result = validate(r)
    assert result.status == ExtraktionsStatus.OK
    assert result.fehler == []


def test_math_fehler_rech04():
    r = _result(*_alle_pflicht(_k("total_amount", "119.00"), _k("net_amount", "100.00"), _k("tax_amount", "25.00")))
    result = validate(r)
    assert result.status == ExtraktionsStatus.MATH_FEHLER
    assert any("RECH-04" in f for f in result.fehler)


def test_math_toleranz_ok():
    # Differenz 0.01 EUR — innerhalb Toleranz
    r = _result(*_alle_pflicht(_k("total_amount", "119.01"), _k("net_amount", "100.00"), _k("tax_amount", "19.00")))
    result = validate(r)
    assert result.status == ExtraktionsStatus.OK


def test_math_fehler_grenzwert():
    # Differenz 0.03 EUR — knapp ausserhalb Toleranz
    r = _result(*_alle_pflicht(_k("total_amount", "119.03"), _k("net_amount", "100.00"), _k("tax_amount", "19.00")))
    result = validate(r)
    assert result.status == ExtraktionsStatus.MATH_FEHLER


def test_ust_id_als_rechnungsnummer_rech05():
    r = _result(*_alle_pflicht(
        _k("invoice_number", "DE123456789"),
        _k("total_amount", "100.00"),
    ))
    # Überschreibe invoice_number aus _alle_pflicht durch expliziten USt-ID-Kandidat
    r2 = _result(
        _k("vendor_name", "Test GmbH"),
        _k("invoice_number", "DE123456789"),
        _k("invoice_date", "15.01.2024"),
        _k("total_amount", "100.00"),
    )
    result = validate(r2)
    assert result.status == ExtraktionsStatus.PRUEFFALL
    assert any("RECH-05" in f for f in result.fehler)


def test_versandkosten_als_steuer_prueffall():
    # Steuerbetrag 4.99 sieht nach Versand aus, erwartet wäre 15.97
    r = _result(*_alle_pflicht(_k("total_amount", "100.00"), _k("net_amount", "84.03"), _k("tax_amount", "4.99")))
    result = validate(r)
    # MATH_FEHLER tritt auf (4.99+84.03=89.02 ≠ 100.00)
    assert result.status in {ExtraktionsStatus.MATH_FEHLER, ExtraktionsStatus.PRUEFFALL}


def test_pflichtfelder_fehlen_rech02():
    r = _result(_k("vendor_name", "Test GmbH"))
    result = validate(r)
    assert result.status == ExtraktionsStatus.UNVOLLSTAENDIG
    assert any("RECH-02" in f for f in result.fehler)


def test_alle_pflichtfelder_ok():
    r = _result(
        _k("vendor_name", "Test GmbH"),
        _k("invoice_number", "2024-001"),
        _k("invoice_date", "01.01.2024"),
        _k("total_amount", "119.00"),
        _k("net_amount", "100.00"),
        _k("tax_amount", "19.00"),
    )
    result = validate(r)
    assert result.status == ExtraktionsStatus.OK


def test_bereits_prueffall_bleibt_prueffall():
    r = _result(
        _k("invoice_number", "DE999999999"),
    )
    r_prueffall = ExtractionResult(
        kandidaten=r.kandidaten, status=ExtraktionsStatus.PRUEFFALL,
        fehler=["vorher schon Prüffall"], roher_text="", confidence=0.5,
    )
    result = validate(r_prueffall)
    assert result.status == ExtraktionsStatus.PRUEFFALL
