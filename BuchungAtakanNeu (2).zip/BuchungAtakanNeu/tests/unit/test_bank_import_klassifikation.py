"""Unit-Tests Buchungsklassifikation (BANK-11).

Abgedeckte Anforderungen:
  T8:  Klassifikation MATCHBAR.
  T9:  Klassifikation NICHT_ZU_MATCHEN.
  T10: Klassifikation EC_EINZAHLUNG.
  T11: Klassifikation MANUELL_PRUEFEN.
"""
import pytest

from packages.core.bank_import.klassifikation import (
    BuchungsKlassifikation,
    klassifiziere_buchung,
)


class TestMatchbar:
    """T8: Normale Geschaeftsbuchungen → MATCHBAR."""

    def test_normale_rechnung(self):
        assert klassifiziere_buchung("Rechnung 2024-001", "Lieferant GmbH") == BuchungsKlassifikation.MATCHBAR

    def test_leerer_verwendungszweck(self):
        assert klassifiziere_buchung(None, "Lieferant GmbH") == BuchungsKlassifikation.MATCHBAR

    def test_beide_leer(self):
        assert klassifiziere_buchung(None, None) == BuchungsKlassifikation.MATCHBAR

    def test_ueberweisung_ohne_schluesselwoerter(self):
        assert klassifiziere_buchung("Ueberweisung Monatsmiete", "Hausverwaltung") == BuchungsKlassifikation.MATCHBAR

    def test_bestellung_matchbar(self):
        assert klassifiziere_buchung("Bestellung Nr. 42", "Online Shop") == BuchungsKlassifikation.MATCHBAR


class TestNichtZuMatchen:
    """T9: Gebuehren, Steuern, interne Buchungen → NICHT_ZU_MATCHEN."""

    def test_kontogebuehr(self):
        assert klassifiziere_buchung("Kontoführungsgebühr Q1", None) == BuchungsKlassifikation.NICHT_ZU_MATCHEN

    def test_zinsen(self):
        assert klassifiziere_buchung("Habenzinsen Januar", None) == BuchungsKlassifikation.NICHT_ZU_MATCHEN

    def test_steuer(self):
        assert klassifiziere_buchung("Kapitalertragsteuer", None) == BuchungsKlassifikation.NICHT_ZU_MATCHEN

    def test_kontogebuehr_gegenpartei(self):
        assert klassifiziere_buchung(None, "Kontogebühr Abrechnung") == BuchungsKlassifikation.NICHT_ZU_MATCHEN

    def test_lastschrift_entgelt(self):
        assert klassifiziere_buchung("Lastschrift Entgelt", None) == BuchungsKlassifikation.NICHT_ZU_MATCHEN

    def test_verwahrentgelt(self):
        assert klassifiziere_buchung("Verwahrentgelt", None) == BuchungsKlassifikation.NICHT_ZU_MATCHEN


class TestEcEinzahlung:
    """T10: EC-/Kartensammelauszahlungen → EC_EINZAHLUNG."""

    def test_ec_karte_verwendungszweck(self):
        assert klassifiziere_buchung("EC-Karte Einzahlung", None) == BuchungsKlassifikation.EC_EINZAHLUNG

    def test_kartenzahlung(self):
        assert klassifiziere_buchung("Kartenzahlung", None) == BuchungsKlassifikation.EC_EINZAHLUNG

    def test_card_payment(self):
        assert klassifiziere_buchung("Card Payment", None) == BuchungsKlassifikation.EC_EINZAHLUNG

    def test_maestro(self):
        assert klassifiziere_buchung("Maestro Auszahlung", None) == BuchungsKlassifikation.EC_EINZAHLUNG

    def test_girocard(self):
        assert klassifiziere_buchung("Girocard", None) == BuchungsKlassifikation.EC_EINZAHLUNG

    def test_ec_karte_gegenpartei(self):
        assert klassifiziere_buchung(None, "EC Karte Terminal") == BuchungsKlassifikation.EC_EINZAHLUNG


class TestManuellPruefen:
    """T11: Widersprüchliche Signale → MANUELL_PRUEFEN."""

    def test_ec_und_gebuehr_gleichzeitig(self):
        """EC-Schluesselwort + Gebuehr-Schluesselwort → MANUELL_PRUEFEN."""
        assert (
            klassifiziere_buchung("EC-Karte Gebühr", None)
            == BuchungsKlassifikation.MANUELL_PRUEFEN
        )

    def test_ec_und_zinsen(self):
        assert (
            klassifiziere_buchung("EC-Karte Zinsen", None)
            == BuchungsKlassifikation.MANUELL_PRUEFEN
        )
