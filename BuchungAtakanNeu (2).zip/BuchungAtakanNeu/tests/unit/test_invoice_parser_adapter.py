"""Unit-Tests fuer InvoiceParserAdapter — InvoiceData → Kandidaten (RECH-01)."""
from pathlib import Path
from unittest.mock import patch

import pytest

from packages.core.invoice_extraction.extraction_result import ExtraktionsStatus
from packages.core.invoice_extraction.invoice_data import InvoiceData
from packages.core.invoice_extraction.invoice_parser_adapter import (
    extract_from_pdf,
    extract_from_text,
    invoice_data_to_kandidaten,
)
from packages.core.invoice_extraction.kandidat import KandidatQuelle


def test_invoice_data_zu_kandidaten_alle_felder():
    data = InvoiceData(
        vendor_name="Test GmbH",
        invoice_number="2024-001",
        invoice_date="15.01.2024",
        total_amount=119.0,
        net_amount=100.0,
        tax_amount=19.0,
        currency="EUR",
        payment_method="BANK_TRANSFER",
        confidence=0.9,
    )
    kandidaten = invoice_data_to_kandidaten(data)
    felder = {k.feld for k in kandidaten}
    assert "vendor_name" in felder
    assert "invoice_number" in felder
    assert "total_amount" in felder
    assert "net_amount" in felder
    assert "tax_amount" in felder
    assert "currency" in felder
    assert "payment_method" in felder


def test_invoice_data_none_felder_nicht_in_kandidaten():
    data = InvoiceData(vendor_name="Test GmbH", confidence=0.3)
    kandidaten = invoice_data_to_kandidaten(data)
    felder = {k.feld for k in kandidaten}
    assert "vendor_name" in felder
    assert "total_amount" not in felder
    assert "tax_amount" not in felder


def test_normwert_float_formatierung():
    data = InvoiceData(total_amount=119.0, confidence=0.8)
    kandidaten = invoice_data_to_kandidaten(data)
    k = next(k for k in kandidaten if k.feld == "total_amount")
    assert k.normwert == "119.00"


def test_quelle_ist_pdf_text():
    data = InvoiceData(vendor_name="Test GmbH", confidence=0.5)
    kandidaten = invoice_data_to_kandidaten(data)
    assert all(k.quelle == KandidatQuelle.PDF_TEXT for k in kandidaten)


def test_extract_from_text_gibt_extraction_result():
    text = "Rechnungsnummer: 2024-001\nGesamtbetrag: 119,00 EUR"
    result = extract_from_text(text)
    assert result.roher_text == text
    # Partial text → Pflichtfelder fehlen → validate() setzt UNVOLLSTAENDIG
    assert result.status == ExtraktionsStatus.UNVOLLSTAENDIG
    assert isinstance(result.kandidaten, list)


def test_extract_from_text_pflichtfelder_fehlen_unvollstaendig():
    result = extract_from_text("Nur ein bisschen Text ohne erkennbare Felder")
    assert result.status == ExtraktionsStatus.UNVOLLSTAENDIG


def test_extract_from_text_ust_id_als_rechnungsnummer_prueffall():
    text = "Rechnungsnummer: DE123456789\nGesamtbetrag: 100,00 EUR"
    result = extract_from_text(text)
    assert result.status == ExtraktionsStatus.PRUEFFALL
    assert any("RECH-05" in f for f in result.fehler)


def test_extract_from_text_math_fehler():
    text = (
        "Muster GmbH\n"
        "Rechnungsnummer: 2024-042\n"
        "Rechnungsdatum: 01.01.2024\n"
        "Nettobetrag: 100,00 EUR\n"
        "MwSt 19%: 25,00 EUR\n"
        "Gesamtbetrag: 119,00 EUR\n"
    )
    result = extract_from_text(text)
    # Parser extrahiert Beträge; validate() erkennt 100+25≠119 → MATH_FEHLER
    # Falls Parser nicht alle drei Beträge findet → UNVOLLSTAENDIG (beide akzeptabel)
    assert result.status in {ExtraktionsStatus.MATH_FEHLER, ExtraktionsStatus.UNVOLLSTAENDIG}


def test_extract_from_text_leer():
    result = extract_from_text("")
    assert result.kandidaten == []
    assert result.confidence == 0.0


def test_kandidaten_haben_confidence():
    data = InvoiceData(vendor_name="Test GmbH", total_amount=100.0, confidence=0.71)
    kandidaten = invoice_data_to_kandidaten(data)
    assert all(k.confidence == 0.71 for k in kandidaten)


def test_payload_kein_bytes_feld():
    """Kein Bytes-Feld im Kandidat-Modell (analog CLI-08)."""
    data = InvoiceData(vendor_name="Test GmbH", confidence=0.5)
    kandidaten = invoice_data_to_kandidaten(data)
    for k in kandidaten:
        assert not hasattr(k, "bytes")
        assert not hasattr(k, "content")
        assert not hasattr(k, "file_data")


# --- extract_from_pdf: PDFReader gemockt ---

def test_extract_from_pdf_ruft_validate_auf_pflichtfelder_fehlen():
    """extract_from_pdf() → validate() greift → UNVOLLSTAENDIG wenn Pflichtfelder fehlen."""
    synthetic_text = "Nur minimaler Text ohne Rechnungsfelder"
    with patch(
        "packages.core.invoice_extraction.invoice_parser_adapter._READER.extract_text",
        return_value=synthetic_text,
    ):
        result = extract_from_pdf(Path("dummy_synth.pdf"))
    assert result.roher_text == synthetic_text
    assert result.status == ExtraktionsStatus.UNVOLLSTAENDIG


def test_extract_from_pdf_vollstaendige_rechnung_not_unvollstaendig():
    """extract_from_pdf() mit vollständigem Text → validate() setzt kein UNVOLLSTAENDIG."""
    synthetic_text = (
        "Muster GmbH\n"
        "Rechnungsnummer: 2024-099\n"
        "Rechnungsdatum: 15.01.2024\n"
        "Gesamtbetrag: 119,00 EUR\n"
    )
    with patch(
        "packages.core.invoice_extraction.invoice_parser_adapter._READER.extract_text",
        return_value=synthetic_text,
    ):
        result = extract_from_pdf(Path("dummy_synth.pdf"))
    assert result.status != ExtraktionsStatus.UNVOLLSTAENDIG


def test_extract_from_pdf_uebergibt_text_an_validate():
    """extract_from_pdf() gibt roher_text korrekt durch."""
    synthetic_text = "Synthesetext ohne Inhalt"
    with patch(
        "packages.core.invoice_extraction.invoice_parser_adapter._READER.extract_text",
        return_value=synthetic_text,
    ):
        result = extract_from_pdf(Path("irgendetwas.pdf"))
    assert result.roher_text == synthetic_text
