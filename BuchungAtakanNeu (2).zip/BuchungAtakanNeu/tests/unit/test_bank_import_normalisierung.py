"""Unit-Tests: IBAN-Maskierung und Textnormalisierung."""
import pytest

from packages.core.bank_import.normalisierung import maskiere_iban, normalisiere_iban, normalisiere_text


class TestMaskiereIban:
    def test_volle_iban_wird_maskiert(self):
        """Vollstaendige IBAN → nur Laenderpräfix und letzte 4 Zeichen sichtbar."""
        result = maskiere_iban("DE89370400440532013000")
        assert result.startswith("DE")
        assert result.endswith("3000")
        assert "*" in result
        assert "370400440532" not in result

    def test_bereits_maskierte_iban_unveraendert(self):
        """Bereits maskierte IBAN (enthaelt *) wird nicht nochmals veraendert."""
        masked = "DE********************3000"
        assert maskiere_iban(masked) == masked

    def test_none_bleibt_none(self):
        assert maskiere_iban(None) is None

    def test_maskierung_format_laenderpräfix_sterne_suffix(self):
        """Format: DE + N Sterne + letzte 4 Zeichen."""
        result = maskiere_iban("DE89370400440532013000")
        assert result[:2] == "DE"
        assert result[-4:] == "3000"
        # Mittelteil ausschliesslich Sterne
        mittel = result[2:-4]
        assert all(c == "*" for c in mittel)

    def test_laenge_erhalten(self):
        """Maskierte IBAN hat gleiche Laenge wie Original."""
        original = "DE89370400440532013000"
        result = maskiere_iban(original)
        assert len(result) == len(original)

    def test_andere_laenderpräfixe(self):
        """Nicht-DE IBAN wird ebenfalls korrekt maskiert."""
        result = maskiere_iban("AT611904300234573201")
        assert result.startswith("AT")
        assert result.endswith("3201")
        assert "*" in result

    def test_leerzeichen_werden_entfernt(self):
        """Leerzeichen in IBAN werden vor Maskierung entfernt."""
        result = maskiere_iban("DE89 3704 0044 0532 0130 00")
        assert " " not in result
        assert result.startswith("DE")
        assert result.endswith("3000")

    def test_kleinbuchstaben_werden_uppercase(self):
        """Kleinbuchstaben werden zu Grossbuchstaben normalisiert."""
        result = maskiere_iban("de89370400440532013000")
        assert result.startswith("DE")

    def test_kurze_iban_unveraendert(self):
        """Sehr kurze Strings (< 8 Zeichen) werden unveraendert zurueckgegeben."""
        short = "DE1234"
        result = maskiere_iban(short)
        assert result == short.upper()

    def test_leerer_string_gibt_none(self):
        """Leerer String → None."""
        assert maskiere_iban("") is None
