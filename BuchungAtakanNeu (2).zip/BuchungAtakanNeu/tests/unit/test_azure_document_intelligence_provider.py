"""Unit-Tests fuer den vorbereiteten, deaktivierten Azure-Document-Intelligence-Adapter
(07-04, HYB-20..24).

Kein SDK, kein Netzwerk -- ausschliesslich FakeAzureDocumentIntelligenceClient.
"""
from pathlib import Path
from types import SimpleNamespace

from packages.core.invoice_extraction.azure_document_intelligence_provider import (
    NAME,
    AzureAnalyseErgebnis,
    AzureDocumentIntelligenceProvider,
    AzureFeldErgebnis,
    FakeAzureDocumentIntelligenceClient,
    erstelle_provider,
    ist_aktiviert,
)


def _settings(**overrides) -> SimpleNamespace:
    defaults = dict(
        BUCHUNG_ATAKAN_FEATURE_AZURE_DOCUMENT_INTELLIGENCE=False,
        BUCHUNG_ATAKAN_FEATURE_AZURE_DI=False,
    )
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


class TestFeatureFlagUndFactory:
    def test_flag_standardmaessig_false(self):
        assert ist_aktiviert(_settings()) is False

    def test_legacy_flag_aktiviert_neuen_provider_nicht(self):
        """BUCHUNG_ATAKAN_FEATURE_AZURE_DI (07-01-Legacy) bleibt inert."""
        assert ist_aktiviert(_settings(BUCHUNG_ATAKAN_FEATURE_AZURE_DI=True)) is False

    def test_kanonisches_flag_aktiviert(self):
        assert ist_aktiviert(_settings(BUCHUNG_ATAKAN_FEATURE_AZURE_DOCUMENT_INTELLIGENCE=True)) is True

    def test_factory_liefert_bei_false_keinen_provider(self):
        aufgerufen = []

        def client_factory():
            aufgerufen.append(True)
            return FakeAzureDocumentIntelligenceClient()

        provider = erstelle_provider(_settings(), client_factory)
        assert provider is None
        assert aufgerufen == [], "client_factory darf bei deaktiviertem Flag nie aufgerufen werden"

    def test_factory_liefert_bei_true_provider_mit_client(self):
        fake_client = FakeAzureDocumentIntelligenceClient()
        provider = erstelle_provider(
            _settings(BUCHUNG_ATAKAN_FEATURE_AZURE_DOCUMENT_INTELLIGENCE=True),
            lambda: fake_client,
        )
        assert isinstance(provider, AzureDocumentIntelligenceProvider)
        assert provider.is_enabled is True

    def test_direkter_provideraufruf_bei_enabled_false_ruft_client_nicht_auf(self):
        fake_client = FakeAzureDocumentIntelligenceClient()
        provider = AzureDocumentIntelligenceProvider(client=fake_client, enabled=False)
        ergebnis = provider.extract(Path("dummy.pdf"))
        assert fake_client.aufrufe == [], "Client darf bei enabled=False nie aufgerufen werden"
        assert ergebnis.laufstatus == "skipped"
        assert ergebnis.kandidaten == []


class TestFakeClientUndMapping:
    def test_fake_client_verarbeitet_synthetische_antwort(self):
        antwort = AzureAnalyseErgebnis(felder=(
            AzureFeldErgebnis(feld="invoice_number", wert="RE-2026-001", confidence=0.9),
        ))
        client = FakeAzureDocumentIntelligenceClient(antwort=antwort)
        provider = AzureDocumentIntelligenceProvider(client=client, enabled=True)
        ergebnis = provider.extract(Path("dummy.pdf"))
        assert ergebnis.laufstatus == "success"
        assert len(ergebnis.kandidaten) == 1
        assert client.aufrufe == [Path("dummy.pdf")]

    def test_mapping_ist_deterministisch(self):
        antwort = AzureAnalyseErgebnis(felder=(
            AzureFeldErgebnis(feld="invoice_number", wert="RE-001", confidence=0.9),
            AzureFeldErgebnis(feld="total_amount", wert="123,45", confidence=0.8),
        ))
        provider = AzureDocumentIntelligenceProvider(
            client=FakeAzureDocumentIntelligenceClient(antwort=antwort), enabled=True
        )
        e1 = provider.extract(Path("a.pdf"))
        e2 = provider.extract(Path("a.pdf"))
        felder1 = [(k.feld, k.rohwert, k.normwert, k.confidence) for k in e1.kandidaten]
        felder2 = [(k.feld, k.rohwert, k.normwert, k.confidence) for k in e2.kandidaten]
        assert felder1 == felder2

    def test_mapping_auf_erlaubte_felder_begrenzt(self):
        antwort = AzureAnalyseErgebnis(felder=(
            AzureFeldErgebnis(feld="invoice_number", wert="RE-001", confidence=0.9),
            AzureFeldErgebnis(feld="unbekanntes_azure_feld", wert="irgendwas", confidence=0.9),
        ))
        provider = AzureDocumentIntelligenceProvider(
            client=FakeAzureDocumentIntelligenceClient(antwort=antwort), enabled=True
        )
        ergebnis = provider.extract(Path("a.pdf"))
        felder = {k.feld for k in ergebnis.kandidaten}
        assert felder == {"invoice_number"}

    def test_confidence_wird_korrekt_uebernommen(self):
        antwort = AzureAnalyseErgebnis(felder=(
            AzureFeldErgebnis(feld="invoice_number", wert="RE-001", confidence=0.73),
        ))
        provider = AzureDocumentIntelligenceProvider(
            client=FakeAzureDocumentIntelligenceClient(antwort=antwort), enabled=True
        )
        ergebnis = provider.extract(Path("a.pdf"))
        assert ergebnis.kandidaten[0].confidence == 0.73

    def test_ungueltige_confidence_wird_uebersprungen(self):
        antwort = AzureAnalyseErgebnis(felder=(
            AzureFeldErgebnis(feld="invoice_number", wert="RE-001", confidence=1.5),
        ))
        provider = AzureDocumentIntelligenceProvider(
            client=FakeAzureDocumentIntelligenceClient(antwort=antwort), enabled=True
        )
        ergebnis = provider.extract(Path("a.pdf"))
        assert ergebnis.kandidaten == []

    def test_providername_und_version_stabil(self):
        provider = AzureDocumentIntelligenceProvider(
            client=FakeAzureDocumentIntelligenceClient(), enabled=True
        )
        assert provider.name == NAME == "azure_document_intelligence"
        assert provider.version == "1.0"

        antwort = AzureAnalyseErgebnis(felder=(
            AzureFeldErgebnis(feld="invoice_number", wert="RE-001", confidence=0.9),
        ), model_version="2026-01-01")
        client = FakeAzureDocumentIntelligenceClient(antwort=antwort)
        ergebnis = AzureDocumentIntelligenceProvider(client=client, enabled=True).extract(Path("a.pdf"))
        assert ergebnis.kandidaten[0].provider_name == NAME
        assert ergebnis.kandidaten[0].provider_version == "2026-01-01"

    def test_fehlende_werte_werden_uebersprungen(self):
        antwort = AzureAnalyseErgebnis(felder=(
            AzureFeldErgebnis(feld="invoice_number", wert=None, confidence=0.9),
            AzureFeldErgebnis(feld="total_amount", wert="   ", confidence=0.9),
        ))
        provider = AzureDocumentIntelligenceProvider(
            client=FakeAzureDocumentIntelligenceClient(antwort=antwort), enabled=True
        )
        ergebnis = provider.extract(Path("a.pdf"))
        assert ergebnis.kandidaten == []

    def test_ungueltige_felder_erzeugen_keine_gueltigen_kandidaten(self):
        """Kombination aus unbekanntem Feld, fehlendem Wert und ungueltiger Confidence --
        keines davon darf einen Kandidaten erzeugen."""
        antwort = AzureAnalyseErgebnis(felder=(
            AzureFeldErgebnis(feld="nicht_unterstuetzt", wert="x", confidence=0.9),
            AzureFeldErgebnis(feld="vendor_name", wert=None, confidence=0.9),
            AzureFeldErgebnis(feld="net_amount", wert="10.00", confidence=-0.1),
        ))
        provider = AzureDocumentIntelligenceProvider(
            client=FakeAzureDocumentIntelligenceClient(antwort=antwort), enabled=True
        )
        ergebnis = provider.extract(Path("a.pdf"))
        assert ergebnis.kandidaten == []

    def test_validierungsbefund_ohne_dokumentpfad_oder_secrets(self):
        antwort = AzureAnalyseErgebnis(felder=(
            AzureFeldErgebnis(feld="invoice_date", wert="nicht-erkennbares-datum", confidence=0.9),
        ))
        provider = AzureDocumentIntelligenceProvider(
            client=FakeAzureDocumentIntelligenceClient(antwort=antwort), enabled=True
        )
        ergebnis = provider.extract(Path(r"C:\Users\Geheim\rechnung.pdf"))
        befund = ergebnis.kandidaten[0].validierungsbefund
        assert befund is not None
        assert "Geheim" not in befund
        assert "rechnung.pdf" not in befund
        assert "\\" not in befund

    def test_clientfehler_liefert_nur_sanitisierten_fehlertyp(self):
        client = FakeAzureDocumentIntelligenceClient(fehler=ConnectionError("geheimer-endpoint-inhalt"))
        provider = AzureDocumentIntelligenceProvider(client=client, enabled=True)
        ergebnis = provider.extract(Path("a.pdf"))
        assert ergebnis.laufstatus == "error"
        assert ergebnis.fehlercode == "ConnectionError"
        assert ergebnis.kandidaten == []

    def test_provider_entscheidet_nie_selbst_ueber_status(self):
        """InvoiceProviderResult traegt keinen Statusentscheidungswert -- nur Kandidaten."""
        from dataclasses import fields
        from packages.core.invoice_extraction.provider_ports import InvoiceProviderResult
        namen = {f.name for f in fields(InvoiceProviderResult)}
        assert "hybrid_status" not in namen
        assert "status" not in namen
