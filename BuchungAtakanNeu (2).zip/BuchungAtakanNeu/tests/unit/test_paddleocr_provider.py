"""Unit-Tests fuer PaddleOCRProvider (HYB-11).

PaddleOCR ist im Testsystem nicht installiert (bewusst, siehe Auftrag 07-02: keine
Installation erzwungen). Fake-/Mock-Engine ersetzt die echte Bibliothek fuer Tests, die
das Verhalten bei vorhandenem Provider pruefen. Der Fehlende-Dependency-Test nutzt die
echte (fehlende) Installation.
"""
from pathlib import Path
from unittest.mock import patch

import pytest

from packages.core.invoice_extraction.local_text import LocalExtractedText
from packages.core.invoice_extraction.paddleocr_provider import (
    PaddleOCRProvider,
    ist_aktiviert,
)


class _FakePdfContext:
    def __init__(self, pages):
        self.pages = pages

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False


class _FakePage:
    def to_image(self, resolution=None):
        return type("Img", (), {"original": object()})()


class _FakeEngine:
    def __init__(self, ergebnisse_je_aufruf):
        self._ergebnisse = list(ergebnisse_je_aufruf)
        self._index = 0

    def ocr(self, image, cls=True):
        ergebnis = self._ergebnisse[self._index]
        self._index += 1
        if isinstance(ergebnis, Exception):
            raise ergebnis
        return ergebnis


def _zeile(text: str, confidence: float):
    box = [[0, 0], [1, 0], [1, 1], [0, 1]]
    return [box, (text, confidence)]


def _lauf(anzahl_seiten: int, engine, text_fuer_reader: str = ""):
    seiten = [_FakePage() for _ in range(anzahl_seiten)]
    with patch(
        "packages.core.invoice_extraction.paddleocr_provider._lade_engine",
        return_value=engine,
    ), patch("pdfplumber.open", return_value=_FakePdfContext(pages=seiten)), patch(
        "packages.core.invoice_extraction.paddleocr_provider._bild_zu_array",
        side_effect=lambda bild: bild,
    ):
        return PaddleOCRProvider().extract(Path("dummy_scan.pdf"))


class TestFakeOcrErgebnis:
    def test_erkannte_zeilen_ergeben_kandidaten(self):
        seite_ergebnis = [
            _zeile("Synthetisch Muster AG", 0.95),
            _zeile("Rechnungsnummer: RE-2026-OCR-01", 0.9),
            _zeile("Rechnungsdatum: 01.07.2026", 0.9),
            _zeile("Gesamtbetrag: 119,00 EUR", 0.9),
        ]
        engine = _FakeEngine([[seite_ergebnis]])
        ergebnis = _lauf(anzahl_seiten=1, engine=engine)
        assert ergebnis.laufstatus == "success"
        felder = {k.feld for k in ergebnis.kandidaten}
        assert "invoice_number" in felder
        assert "total_amount" in felder

    def test_provider_name_gesetzt(self):
        seite_ergebnis = [_zeile("Rechnungsnummer: RE-2026-OCR-02", 0.9)]
        engine = _FakeEngine([[seite_ergebnis]])
        ergebnis = _lauf(anzahl_seiten=1, engine=engine)
        assert all(k.provider_name == "paddleocr" for k in ergebnis.kandidaten)


class TestMehrseitigerSeitenbezug:
    def test_kandidaten_tragen_korrekte_seitennummer(self):
        seite1 = [
            _zeile("Synthetisch Muster AG", 0.95),
            _zeile("Rechnungsnummer: RE-2026-OCR-03", 0.9),
            _zeile("Rechnungsdatum: 01.07.2026", 0.9),
        ]
        seite2 = [_zeile("Gesamtbetrag: 119,00 EUR", 0.9)]
        engine = _FakeEngine([[seite1], [seite2]])
        ergebnis = _lauf(anzahl_seiten=2, engine=engine)

        invoice_number_kandidat = next(k for k in ergebnis.kandidaten if k.feld == "invoice_number")
        total_amount_kandidat = next(k for k in ergebnis.kandidaten if k.feld == "total_amount")
        assert invoice_number_kandidat.seite == 1
        assert total_amount_kandidat.seite == 2
        assert ergebnis.seiten_anzahl == 2


class TestConfidenceUebernahme:
    def test_niedrige_ocr_confidence_begrenzt_kandidat_confidence(self):
        seite_ergebnis = [
            _zeile("Rechnungsnummer: RE-2026-OCR-04", 0.3),
            _zeile("Rechnungsdatum: 01.07.2026", 0.3),
            _zeile("Gesamtbetrag: 119,00 EUR", 0.3),
        ]
        engine = _FakeEngine([[seite_ergebnis]])
        ergebnis = _lauf(anzahl_seiten=1, engine=engine)
        assert ergebnis.kandidaten
        assert all(k.confidence <= 0.3 for k in ergebnis.kandidaten)


class TestEinheitlichesTextmodell:
    """HYB-12: OCR-Seiten werden auf LocalExtractedText abgebildet."""

    def test_ocr_seiten_liefert_local_extracted_text(self):
        seite_ergebnis = [_zeile("Rechnungsnummer: RE-2026-OCR-05", 0.85)]
        engine = _FakeEngine([[seite_ergebnis]])
        with patch(
            "packages.core.invoice_extraction.paddleocr_provider._lade_engine",
            return_value=engine,
        ), patch("pdfplumber.open", return_value=_FakePdfContext(pages=[_FakePage()])), patch(
            "packages.core.invoice_extraction.paddleocr_provider._bild_zu_array",
            side_effect=lambda bild: bild,
        ):
            seiten = PaddleOCRProvider()._ocr_seiten(engine, Path("dummy_scan.pdf"))
        assert len(seiten) == 1
        assert isinstance(seiten[0], LocalExtractedText)
        assert seiten[0].seite == 1
        assert seiten[0].quelle == "paddleocr"
        assert seiten[0].methode == "ocr"
        assert seiten[0].confidence == 0.85

    def test_local_extracted_text_validiert_confidence(self):
        with pytest.raises(ValueError, match="confidence"):
            LocalExtractedText(
                text="x", seite=1, quelle="paddleocr", confidence=1.5, methode="ocr"
            )


class TestDeaktiviertesFlag:
    def test_flag_default_false(self):
        settings = type("S", (), {"BUCHUNG_ATAKAN_FEATURE_PADDLE_OCR": False})()
        assert ist_aktiviert(settings) is False

    def test_flag_aktiviert(self):
        settings = type("S", (), {"BUCHUNG_ATAKAN_FEATURE_PADDLE_OCR": True})()
        assert ist_aktiviert(settings) is True


class TestFehlendeDependency:
    def test_ohne_installiertes_paddleocr_wird_skip_zurueckgegeben(self):
        """PaddleOCR ist im Testsystem nicht installiert -- echter ModuleNotFoundError-Pfad."""
        ergebnis = PaddleOCRProvider().extract(Path("dummy_scan.pdf"))
        assert ergebnis.laufstatus == "skipped"
        assert ergebnis.fehlercode == "ModuleNotFoundError"
        assert ergebnis.kandidaten == []


class TestOcrFehlerIsoliert:
    def test_ocr_ausnahme_wird_sanitisiert(self):
        engine = _FakeEngine([RuntimeError("OCR-Engine-Absturz mit /echtem/pfad")])
        ergebnis = _lauf(anzahl_seiten=1, engine=engine)
        assert ergebnis.laufstatus == "error"
        assert ergebnis.fehlercode == "RuntimeError"
        assert ergebnis.kandidaten == []

    def test_fehlercode_ohne_pfad_oder_volltext(self):
        engine = _FakeEngine([RuntimeError("OCR-Engine-Absturz mit /echtem/pfad")])
        ergebnis = _lauf(anzahl_seiten=1, engine=engine)
        assert "/" not in ergebnis.fehlercode
        assert "echtem" not in ergebnis.fehlercode


class TestKeinNetzwerk:
    def test_fehlende_dependency_konstruiert_keine_engine(self):
        """Ohne installiertes paddleocr wird PaddleOCR() nie instanziiert --
        also auch nie ein Modell-Download angestossen."""
        from packages.core.invoice_extraction import paddleocr_provider as modul
        modul._engine_cache = None
        ergebnis = PaddleOCRProvider().extract(Path("dummy_scan.pdf"))
        assert ergebnis.laufstatus == "skipped"
        assert modul._engine_cache is None
