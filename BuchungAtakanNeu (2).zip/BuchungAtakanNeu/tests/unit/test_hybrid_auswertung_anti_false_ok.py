"""Anti-False-OK- und synthetische End-to-End-Tests fuer die Hybrid-Auswertung
(Paket 07-06, Pre-Realtest-Haertung).

Deckt die im Phase-7-Audit bestaetigten False-OK-Faelle ab: ungueltige
Kalenderdaten, Tausenderpunkt-Fehlinterpretation, Waehrungswidersprueche und
fehlende Pflichtwerte duerfen den finalen Status nie unbemerkt auf OK setzen.

Nutzt den tatsaechlich vorhandenen Typ LocalOrchestratorErgebnis und ruft
werte_lokale_erkennung_aus() end-to-end auf (Normalisierung, Konflikterkennung,
Auswahl, Plausibilitaet, Statusentscheidung) -- keine echten Rechnungen, kein
Netzwerk, keine Credentials, kein externer Provider.
"""
from __future__ import annotations

from types import SimpleNamespace

from packages.core.invoice_extraction.document_classifier import DokumentKlasse
from packages.core.invoice_extraction.hybrid_auswertung import werte_lokale_erkennung_aus
from packages.core.invoice_extraction.hybrid_ergebnis import HybridStatus
from packages.core.invoice_extraction.hybrid_kandidat import HybridKandidat
from packages.core.invoice_extraction.local_provider_orchestrator import (
    LocalOrchestratorErgebnis,
)
from packages.core.invoice_extraction.provider_ports import InvoiceProviderResult

_SETTINGS = SimpleNamespace(BUCHUNG_ATAKAN_FEATURE_HYBRID_PIPELINE=True)


def _kandidat(feld: str, rohwert: str, provider: str = "pdfplumber", confidence: float = 0.9) -> HybridKandidat:
    return HybridKandidat(
        feld=feld, rohwert=rohwert, normwert=None, methode="regex_label",
        provider_name=provider, provider_version="1.0", confidence=confidence,
    )


def _orchestrator_ergebnis(*kandidaten_je_provider: tuple[str, list[HybridKandidat]]) -> LocalOrchestratorErgebnis:
    ergebnis = LocalOrchestratorErgebnis(dokument_klasse=DokumentKlasse.TEXT_PDF)
    for provider_name, kandidaten in kandidaten_je_provider:
        ergebnis.provider_ergebnisse.append(InvoiceProviderResult(
            provider_name=provider_name, provider_version="1.0", laufstatus="success",
            kandidaten=kandidaten, fehlercode=None,
        ))
    return ergebnis


def _vollstaendige_rechnung(total: str, netto: str, steuer: str, datum: str = "12.06.2026") -> list[HybridKandidat]:
    return [
        _kandidat("vendor_name", "Muster AG"),
        _kandidat("invoice_number", "RE-2026-100"),
        _kandidat("invoice_date", datum),
        _kandidat("total_amount", total),
        _kandidat("net_amount", netto),
        _kandidat("tax_amount", steuer),
        _kandidat("currency", "EUR"),
    ]


class TestHappyPath:
    def test_vollstaendige_plausible_rechnung_ergibt_ok(self):
        ergebnis = werte_lokale_erkennung_aus(
            _orchestrator_ergebnis(("pdfplumber", _vollstaendige_rechnung("119,00", "100,00", "19,00"))),
            _SETTINGS,
        )
        assert ergebnis.status == HybridStatus.OK


class TestUngueltigesKalenderdatumBlockiertOk:
    def test_31_02_darf_nie_ok_werden(self):
        ergebnis = werte_lokale_erkennung_aus(
            _orchestrator_ergebnis(("pdfplumber", _vollstaendige_rechnung("119,00", "100,00", "19,00", datum="31.02.2026"))),
            _SETTINGS,
        )
        assert ergebnis.status != HybridStatus.OK
        assert any("rechnungsdatum_plausibel" in g for g in ergebnis.gruende)

    def test_29_02_in_nicht_schaltjahr_darf_nie_ok_werden(self):
        ergebnis = werte_lokale_erkennung_aus(
            _orchestrator_ergebnis(("pdfplumber", _vollstaendige_rechnung("119,00", "100,00", "19,00", datum="29.02.2026"))),
            _SETTINGS,
        )
        assert ergebnis.status != HybridStatus.OK

    def test_29_02_in_schaltjahr_wird_nicht_faelschlich_abgelehnt(self):
        ergebnis = werte_lokale_erkennung_aus(
            _orchestrator_ergebnis(("pdfplumber", _vollstaendige_rechnung("119,00", "100,00", "19,00", datum="29.02.2024"))),
            _SETTINGS,
        )
        assert ergebnis.status == HybridStatus.OK


class TestTausenderpunktWirdKorrektNormalisiert:
    def test_1000_wird_nicht_als_1_00_interpretiert(self):
        """Regressionsbeweis fuer den im Audit bestaetigten Faktor-1000-Bug."""
        ergebnis = werte_lokale_erkennung_aus(
            _orchestrator_ergebnis(("pdfplumber", _vollstaendige_rechnung("1.000,00", "840,34", "159,66"))),
            _SETTINGS,
        )
        brutto = next(k for k in ergebnis.kandidaten if k.feld == "total_amount")
        assert brutto.normwert == "1000.00"
        assert ergebnis.status == HybridStatus.OK

    def test_reiner_tausenderpunkt_ohne_dezimalteil_wird_korrekt_normalisiert(self):
        ergebnis = werte_lokale_erkennung_aus(
            _orchestrator_ergebnis(("pdfplumber", _vollstaendige_rechnung("1.000", "840,34", "159,66"))),
            _SETTINGS,
        )
        brutto = next(k for k in ergebnis.kandidaten if k.feld == "total_amount")
        assert brutto.normwert == "1000.00"


class TestWaehrungswiderspruchBlockiertOk:
    def test_eur_usd_konflikt_darf_nie_unbemerkt_ok_bleiben(self):
        kandidaten_a = _vollstaendige_rechnung("119,00", "100,00", "19,00")
        kandidaten_b = [_kandidat("currency", "USD", provider="invoice2data")]
        ergebnis = werte_lokale_erkennung_aus(
            _orchestrator_ergebnis(
                ("pdfplumber", kandidaten_a),
                ("invoice2data", kandidaten_b),
            ),
            _SETTINGS,
        )
        assert ergebnis.status != HybridStatus.OK
        assert any("waehrung_konsistent" in g for g in ergebnis.gruende)
        # Konflikt bleibt zusaetzlich auditierbar auf Plausibilitaetsebene sichtbar.
        waehrungsbefund = next(b for b in ergebnis.plausibilitaet if b.regel == "waehrung_konsistent")
        assert waehrungsbefund.bestanden is False


class TestFehlendeOderWidersprechendePflichtwerte:
    def test_fehlendes_pflichtfeld_ergibt_nicht_ok(self):
        kandidaten = [
            _kandidat("vendor_name", "Muster AG"),
            _kandidat("invoice_date", "12.06.2026"),
            _kandidat("total_amount", "119,00"),
            # invoice_number fehlt komplett.
        ]
        ergebnis = werte_lokale_erkennung_aus(
            _orchestrator_ergebnis(("pdfplumber", kandidaten)), _SETTINGS,
        )
        assert ergebnis.status != HybridStatus.OK

    def test_widersprechende_pflichtfeld_werte_ergeben_nicht_ok(self):
        kandidaten_a = _vollstaendige_rechnung("119,00", "100,00", "19,00")
        kandidaten_b = [_kandidat("invoice_number", "RE-2026-999", provider="invoice2data")]
        ergebnis = werte_lokale_erkennung_aus(
            _orchestrator_ergebnis(
                ("pdfplumber", kandidaten_a),
                ("invoice2data", kandidaten_b),
            ),
            _SETTINGS,
        )
        assert ergebnis.status != HybridStatus.OK


class TestDeterminismus:
    def test_provider_konflikt_plus_plausibilitaetsfehler_bleibt_deterministisch(self):
        kandidaten_a = _vollstaendige_rechnung("119,00", "100,00", "19,00", datum="31.02.2026")
        kandidaten_b = [_kandidat("invoice_number", "RE-ABWEICHEND", provider="invoice2data")]

        ergebnis_1 = werte_lokale_erkennung_aus(
            _orchestrator_ergebnis(("pdfplumber", kandidaten_a), ("invoice2data", kandidaten_b)), _SETTINGS,
        )
        ergebnis_2 = werte_lokale_erkennung_aus(
            _orchestrator_ergebnis(("pdfplumber", kandidaten_a), ("invoice2data", kandidaten_b)), _SETTINGS,
        )
        assert ergebnis_1.status == ergebnis_2.status
        assert ergebnis_1.gruende == ergebnis_2.gruende
        assert ergebnis_1.status != HybridStatus.OK
