"""Unit-Tests fuer Feldnormalisierung (HYB-14).

Betraege werden ausschliesslich als Decimal-String normalisiert, niemals als float.
"""
from decimal import Decimal

from packages.core.invoice_extraction.hybrid_kandidat import HybridKandidat
from packages.core.invoice_extraction.hybrid_normalisierung import (
    normalisiere_betrag,
    normalisiere_datum,
    normalisiere_kandidat,
    normalisiere_rohwert,
    normalisiere_text,
    normalisiere_waehrung,
)


class TestBetragsformate:
    def test_deutsches_format_komma(self):
        befund = normalisiere_betrag("1.234,56")
        assert befund.ist_gueltig
        assert befund.wert == "1234.56"
        assert Decimal(befund.wert) == Decimal("1234.56")

    def test_internationales_format_punkt(self):
        befund = normalisiere_betrag("1,234.56")
        assert befund.ist_gueltig
        assert befund.wert == "1234.56"

    def test_einfaches_komma_dezimaltrennzeichen(self):
        befund = normalisiere_betrag("119,00")
        assert befund.wert == "119.00"

    def test_einfacher_punkt_dezimaltrennzeichen(self):
        befund = normalisiere_betrag("119.00")
        assert befund.wert == "119.00"

    def test_mit_waehrungssymbol(self):
        befund = normalisiere_betrag("119,00 EUR")
        assert befund.wert == "119.00"

    def test_negativer_betrag_storno(self):
        befund = normalisiere_betrag("-50,00")
        assert befund.ist_gueltig
        assert befund.wert == "-50.00"

    def test_ergebnis_ist_decimal_kompatibel_kein_float_rundungsfehler(self):
        befund = normalisiere_betrag("0,10")
        assert Decimal(befund.wert) == Decimal("0.10")


class TestDeutschesTausenderformatOhneDezimalteil:
    """Paket 07-06: Regressionsschutz fuer den im Audit bestaetigten Faktor-1000-Bug.
    Ein einzelner Punkt mit exakt 3 folgenden Ziffern ist deutsches Tausenderformat,
    kein Dezimalbruch -- "1.000" ist 1000, nicht 1.00."""

    def test_1000_wird_zu_1000_00(self):
        befund = normalisiere_betrag("1.000")
        assert befund.wert == "1000.00"

    def test_2500_wird_zu_2500_00(self):
        befund = normalisiere_betrag("2.500")
        assert befund.wert == "2500.00"

    def test_mehrfacher_tausenderpunkt_1234567(self):
        befund = normalisiere_betrag("1.234.567")
        assert befund.wert == "1234567.00"

    def test_mit_waehrungssymbol_bleibt_tausenderformat(self):
        befund = normalisiere_betrag("1.000 EUR")
        assert befund.wert == "1000.00"

    def test_negatives_tausenderformat(self):
        befund = normalisiere_betrag("-1.000")
        assert befund.wert == "-1000.00"

    def test_0_500_bleibt_dezimalwert_kein_tausenderformat(self):
        """Fuehrende 0 vor dem Punkt ist niemals Tausendergruppe -- "0.500" ist 0,50,
        keine deutsche Schreibweise fuer 500."""
        befund = normalisiere_betrag("0.500")
        assert befund.wert == "0.50"

    def test_echter_dezimalbetrag_mit_punkt_bleibt_unveraendert(self):
        # Zwei Nachkommastellen nach einzelnem Punkt sind nie ein Tausenderformat.
        befund = normalisiere_betrag("119.00")
        assert befund.wert == "119.00"

    def test_gemischtes_format_mit_komma_bleibt_deutsches_dezimalformat(self):
        # Sobald ein Komma vorkommt, greift die bestehende Komma/Punkt-Logik --
        # die Tausenderpruefung wirkt nur, wenn ausschliesslich Punkte vorkommen.
        befund = normalisiere_betrag("1.234,56")
        assert befund.wert == "1234.56"


class TestDatum:
    def test_deutsches_datum_wird_iso(self):
        befund = normalisiere_datum("15.01.2024")
        assert befund.ist_gueltig
        assert befund.wert == "2024-01-15"

    def test_iso_datum_bleibt_iso(self):
        befund = normalisiere_datum("2024-01-15")
        assert befund.wert == "2024-01-15"

    def test_monatsname_wird_erkannt(self):
        befund = normalisiere_datum("15. Januar 2024")
        assert befund.ist_gueltig

    def test_ungueltiges_datum(self):
        befund = normalisiere_datum("Kein Datum hier")
        assert not befund.ist_gueltig
        assert befund.fehler is not None

    def test_unmoegliches_kalenderdatum_31_02_wird_nie_normalisiert(self):
        """Paket 07-06: Regressionsschutz -- 31. Februar existiert nicht."""
        befund = normalisiere_datum("31.02.2026")
        assert not befund.ist_gueltig

    def test_29_02_in_nicht_schaltjahr_wird_nie_normalisiert(self):
        befund = normalisiere_datum("29.02.2026")
        assert not befund.ist_gueltig

    def test_29_02_in_schaltjahr_wird_normalisiert(self):
        befund = normalisiere_datum("29.02.2024")
        assert befund.ist_gueltig
        assert befund.wert == "2024-02-29"

    def test_unmoegliches_monatsnamendatum_wird_nie_normalisiert(self):
        befund = normalisiere_datum("31. Februar 2026")
        assert not befund.ist_gueltig


class TestWaehrung:
    def test_symbol_wird_erkannt(self):
        befund = normalisiere_waehrung("€")
        assert befund.wert == "EUR"

    def test_bekannter_code(self):
        befund = normalisiere_waehrung("eur")
        assert befund.wert == "EUR"

    def test_unbekannte_waehrung(self):
        befund = normalisiere_waehrung("XYZ")
        assert not befund.ist_gueltig


class TestRechnungsnummerUndAnbieter:
    def test_rechnungsnummer_whitespace_normalisiert(self):
        befund = normalisiere_text("  RE  2024   001  ")
        assert befund.ist_gueltig
        assert befund.wert == "re 2024 001"

    def test_anbieter_gross_klein_wird_vergleichbar(self):
        a = normalisiere_text("Muster GmbH")
        b = normalisiere_text("MUSTER GMBH")
        assert a.wert == b.wert

    def test_leerer_wert_ist_fehler(self):
        befund = normalisiere_text("   ")
        assert not befund.ist_gueltig


class TestUngueltigeWerte:
    def test_ungueltiger_betrag_wird_nicht_still_verworfen(self):
        befund = normalisiere_betrag("nicht numerisch")
        assert not befund.ist_gueltig
        assert "nicht numerisch" in befund.fehler or befund.fehler is not None

    def test_leerer_betrag_ist_fehler(self):
        befund = normalisiere_betrag("")
        assert not befund.ist_gueltig


class TestDispatcherUndKandidat:
    def test_normalisiere_rohwert_waehlt_betragslogik(self):
        befund = normalisiere_rohwert("total_amount", "119,00")
        assert befund.wert == "119.00"

    def test_normalisiere_rohwert_waehlt_datumslogik(self):
        befund = normalisiere_rohwert("invoice_date", "15.01.2024")
        assert befund.wert == "2024-01-15"

    def test_normalisiere_kandidat_liefert_kopie_mit_befund(self):
        k = HybridKandidat(
            feld="total_amount", rohwert="119,00", normwert=None, methode="regex_label",
            provider_name="pdfplumber", provider_version="1.0", confidence=0.9,
        )
        normalisiert = normalisiere_kandidat(k)
        assert normalisiert is not k
        assert normalisiert.normwert == "119.00"
        assert normalisiert.validierungsbefund == "NORMALISIERT_OK"
        assert k.normwert is None  # Original unveraendert (frozen)

    def test_normalisierungsfehler_wird_als_befund_sichtbar(self):
        k = HybridKandidat(
            feld="total_amount", rohwert="kaputt", normwert=None, methode="regex_label",
            provider_name="pdfplumber", provider_version="1.0", confidence=0.9,
        )
        normalisiert = normalisiere_kandidat(k)
        assert normalisiert.validierungsbefund.startswith("NORMALISIERUNGSFEHLER")
