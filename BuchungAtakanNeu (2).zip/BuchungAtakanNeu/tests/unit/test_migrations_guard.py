"""Unit-Tests fuer migrations/migration_guard.py.

Kein Alembic-Kontext, keine Datenbankverbindung.
Prueft isoliert: URL-Extraktion, URL-Konvertierung, Sicherheitsguard.
"""
import os
import pytest

from migrations.migration_guard import db_name_aus_url, zu_psycopg2_url, pruefe_migrationsziel


class TestDbNameAusUrl:
    def test_einfache_url(self):
        assert db_name_aus_url("postgresql://u:p@host:5432/buchungatakan") == "buchungatakan"

    def test_test_db(self):
        assert db_name_aus_url("postgresql://u:p@host:5432/buchungatakan_test") == "buchungatakan_test"

    def test_query_param_ignoriert(self):
        assert db_name_aus_url("postgresql://u:p@host/db?sslmode=require") == "db"

    def test_trailing_slash_ignoriert(self):
        assert db_name_aus_url("postgresql://u:p@host/db/") == "db"

    def test_credentials_nicht_in_ausgabe(self):
        url = "postgresql://buchungatakan_migrations:geheimespasswort@localhost:5432/buchungatakan_test"
        result = db_name_aus_url(url)
        assert result == "buchungatakan_test"
        assert "geheimespasswort" not in result
        assert "buchungatakan_migrations" not in result

    def test_psycopg2_url(self):
        assert db_name_aus_url("postgresql+psycopg2://u:p@h/mydb") == "mydb"

    def test_asyncpg_url(self):
        assert db_name_aus_url("postgresql+asyncpg://u:p@h/mydb") == "mydb"


class TestZuPsycopg2Url:
    def test_asyncpg_wird_zu_psycopg2(self):
        result = zu_psycopg2_url("postgresql+asyncpg://u:p@h/db")
        assert result.startswith("postgresql+psycopg2://")

    def test_plain_postgresql_wird_zu_psycopg2(self):
        result = zu_psycopg2_url("postgresql://u:p@h/db")
        assert result.startswith("postgresql+psycopg2://")

    def test_psycopg2_url_unveraendert(self):
        url = "postgresql+psycopg2://u:p@h/db"
        assert zu_psycopg2_url(url) == url

    def test_db_name_erhalten(self):
        result = zu_psycopg2_url("postgresql+asyncpg://u:p@h/buchungatakan_test")
        assert result.endswith("/buchungatakan_test")


class TestPruefeMigrationsziel:
    def test_kein_test_url_kein_guard(self, monkeypatch):
        """Ohne TEST_DATABASE_URL: kein Guard, keine Exception."""
        monkeypatch.delenv("TEST_DATABASE_URL", raising=False)
        # Kein Fehler, auch fuer Dev-DB-URL
        pruefe_migrationsziel("postgresql://u:p@h/buchungatakan")

    def test_migration_auf_test_db_ok(self, monkeypatch):
        """TEST_DATABASE_URL gesetzt, Ziel ist buchungatakan_test -- kein Fehler."""
        monkeypatch.setenv("TEST_DATABASE_URL", "postgresql://u:p@h/buchungatakan_test")
        pruefe_migrationsziel("postgresql://u:p@h/buchungatakan_test")

    def test_migration_auf_dev_db_abgelehnt(self, monkeypatch):
        """TEST_DATABASE_URL gesetzt, Ziel ist dev-DB (kein 'test') -- RuntimeError.

        Dieser Test beweist, dass der alte env.py-Bug (Ueberschreiben mit settings.DATABASE_URL)
        durch den Guard erkannt worden waere.
        """
        monkeypatch.setenv("TEST_DATABASE_URL", "postgresql://u:p@h/buchungatakan_test")
        with pytest.raises(RuntimeError, match="SICHERHEITSFEHLER"):
            pruefe_migrationsziel("postgresql://u:p@h/buchungatakan")

    def test_db_ohne_test_im_namen_abgelehnt(self, monkeypatch):
        """TEST_DATABASE_URL gesetzt, Ziel-DB-Name ohne 'test' -- RuntimeError."""
        monkeypatch.setenv("TEST_DATABASE_URL", "postgresql://u:p@h/buchungatakan_test")
        with pytest.raises(RuntimeError, match="SICHERHEITSFEHLER"):
            pruefe_migrationsziel("postgresql://u:p@h/produktion")

    def test_andere_test_db_abgelehnt(self, monkeypatch):
        """TEST_DATABASE_URL gesetzt, Ziel ist andere test-DB als erwartet -- RuntimeError."""
        monkeypatch.setenv("TEST_DATABASE_URL", "postgresql://u:p@h/buchungatakan_test")
        with pytest.raises(RuntimeError, match="SICHERHEITSFEHLER"):
            pruefe_migrationsziel("postgresql://u:p@h/other_test")

    def test_fehlermeldung_enthaelt_keine_credentials(self, monkeypatch):
        """Guard-Fehlermeldung gibt keine Passwoerter aus."""
        monkeypatch.setenv("TEST_DATABASE_URL", "postgresql://user:geheimespasswort@h/buchungatakan_test")
        try:
            pruefe_migrationsziel("postgresql://user:anderes_passwort@h/buchungatakan")
        except RuntimeError as e:
            msg = str(e)
            assert "geheimespasswort" not in msg
            assert "anderes_passwort" not in msg
            # Aber DB-Name darf sichtbar sein
            assert "buchungatakan" in msg
        else:
            pytest.fail("RuntimeError expected")

    def test_db_name_ohne_secret_ausgabe(self, monkeypatch):
        """db_name_aus_url gibt kein Passwort aus -- Basisgarantie."""
        monkeypatch.delenv("TEST_DATABASE_URL", raising=False)
        url = "postgresql://buchungatakan_migrations:supersecret@localhost:5432/buchungatakan_test"
        name = db_name_aus_url(url)
        assert name == "buchungatakan_test"
        assert "supersecret" not in name
        assert "buchungatakan_migrations" not in name

    def test_psycopg2_url_akzeptiert(self, monkeypatch):
        """Guard akzeptiert auch psycopg2-URLs."""
        monkeypatch.setenv("TEST_DATABASE_URL", "postgresql://u:p@h/buchungatakan_test")
        pruefe_migrationsziel("postgresql+psycopg2://u:p@h/buchungatakan_test")

    def test_fehlender_test_url_kein_dev_fallback(self, monkeypatch):
        """Ohne TEST_DATABASE_URL faellt Guard auf kein Dev zurück -- er prueft schlicht nicht.

        Der Conftest (conftest.py) verantwortet den Skip wenn TEST_DATABASE_URL nicht gesetzt.
        Guard-Verantwortung: nur wenn gesetzt.
        """
        monkeypatch.delenv("TEST_DATABASE_URL", raising=False)
        # Kein Fehler = Guard nicht aktiv, keine stille Dev-Weiterleitung durch Guard
        pruefe_migrationsziel("postgresql://u:p@h/buchungatakan")

    def test_explizite_url_wuerde_nicht_ueberschrieben_werden(self, monkeypatch):
        """Beweist durch Guard-Verhalten: explizite Test-URL pasiert, Dev-URL nicht.

        Der URL-Prioritaetsmechanismus in env.py (if not cfg.get('sqlalchemy.url'))
        stellt sicher, dass eine gesetzte URL nicht ueberschrieben wird.
        Der Guard faengt den Fall ab, wenn die URL trotzdem falsch waere.
        """
        monkeypatch.setenv("TEST_DATABASE_URL", "postgresql://u:p@h/buchungatakan_test")

        # Szenario: explizite URL korrekt gesetzt -- kein Fehler
        pruefe_migrationsziel("postgresql://u:p@h/buchungatakan_test")

        # Szenario: alter Bug -- env.py haette mit settings.DATABASE_URL ueberschrieben
        # Guard haette das erkannt und abgebrochen:
        with pytest.raises(RuntimeError, match="SICHERHEITSFEHLER"):
            pruefe_migrationsziel("postgresql://u:p@h/buchungatakan")
