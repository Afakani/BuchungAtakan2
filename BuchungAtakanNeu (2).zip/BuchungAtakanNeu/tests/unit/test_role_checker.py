"""Unit-Tests fuer RoleChecker und Rolle-Enum -- kein DB-Zugriff."""
from dataclasses import dataclass
from unittest.mock import MagicMock

import pytest
from fastapi import HTTPException

from apps.server.auth.dependencies import RoleChecker
from apps.server.models.benutzer import Rolle


@dataclass
class _FakeUser:
    rolle: Rolle
    aktiv: bool = True


def test_all_four_roles_present():
    """SRV-11: Genau vier Rollen."""
    roles = list(Rolle)
    assert set(roles) == {
        Rolle.SYSTEM_ADMIN,
        Rolle.UNTERNEHMEN_ADMIN,
        Rolle.BEARBEITER,
        Rolle.LESER,
    }
    assert len(roles) == 4


def test_role_checker_allows_matching_role():
    checker = RoleChecker([Rolle.BEARBEITER])
    user = _FakeUser(rolle=Rolle.BEARBEITER)
    result = checker.__call__(current_user=user)
    assert result is user


def test_role_checker_denies_lower_role():
    checker = RoleChecker([Rolle.UNTERNEHMEN_ADMIN])
    user = _FakeUser(rolle=Rolle.LESER)
    with pytest.raises(HTTPException) as exc_info:
        checker.__call__(current_user=user)
    assert exc_info.value.status_code == 403


def test_role_checker_allows_system_admin_when_listed():
    checker = RoleChecker([Rolle.SYSTEM_ADMIN, Rolle.UNTERNEHMEN_ADMIN])
    user = _FakeUser(rolle=Rolle.SYSTEM_ADMIN)
    result = checker.__call__(current_user=user)
    assert result is user


def test_role_checker_denies_system_admin_when_not_listed():
    checker = RoleChecker([Rolle.BEARBEITER])
    user = _FakeUser(rolle=Rolle.SYSTEM_ADMIN)
    with pytest.raises(HTTPException) as exc_info:
        checker.__call__(current_user=user)
    assert exc_info.value.status_code == 403
