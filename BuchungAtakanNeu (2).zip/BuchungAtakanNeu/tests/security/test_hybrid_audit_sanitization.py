"""Sicherheitstests fuer Audit-Booleanmodell und Statistik (07-03A, HYB-17/18).

Prueft: nur strukturierte Booleanfelder im Audit, keine Volltexte/Pfade/Hashes/Secrets
in Statistikobjekten, kein Azure, kein Netzwerk.
"""
from dataclasses import fields
from pathlib import Path

import packages.core.invoice_extraction.hybrid_audit as audit_modul
import packages.core.invoice_extraction.hybrid_statistik as statistik_modul
from packages.core.invoice_extraction.hybrid_audit import AuditBewertungFelder, BewertungEintrag
from packages.core.invoice_extraction.hybrid_statistik import Quote, StatistikGruppe, StatistikZeile

_VERBOTENE_FELDNAMEN = {
    "password", "secret", "token", "api_key", "credential",
    "notiz", "kommentar", "freitext", "originalwert",
    "volltext", "rohtext", "ocr_text", "dateiname", "pfad", "hash",
}

_ERLAUBTE_AUDIT_FELDER = {
    "rechnungsnummer_korrekt", "rechnungsdatum_korrekt", "gesamtbetrag_korrekt",
    "lieferant_korrekt", "steuerwerte_korrekt", "empfaenger_korrekt",
}


class TestAuditNurStrukturierteBooleanfelder:
    def test_auditbewertungfelder_hat_ausschliesslich_erlaubte_felder(self):
        namen = {f.name for f in fields(AuditBewertungFelder)}
        assert namen == _ERLAUBTE_AUDIT_FELDER

    def test_kein_gesamtergebnis_korrekt_feld_gespeichert(self):
        """gesamtergebnis_korrekt wird abgeleitet, nicht gespeichert (Auftrag 07-03A)."""
        namen = {f.name for f in fields(AuditBewertungFelder)}
        assert "gesamtergebnis_korrekt" not in namen

    def test_keine_verbotenen_feldnamen_im_auditmodell(self):
        namen = {f.name.lower() for f in fields(AuditBewertungFelder)}
        for verboten in _VERBOTENE_FELDNAMEN:
            assert not any(verboten in name for name in namen)

    def test_bewertungeintrag_kennt_keine_originalwerte(self):
        namen = {f.name for f in fields(BewertungEintrag)}
        assert namen == {"id", "bewertet_am", "felder"}


class TestStatistikKeineOriginalinhalte:
    def test_statistikzeile_keine_verbotenen_feldnamen(self):
        namen = {f.name.lower() for f in fields(StatistikZeile)}
        for verboten in _VERBOTENE_FELDNAMEN:
            assert not any(verboten in name for name in namen)

    def test_statistikgruppe_keine_verbotenen_feldnamen(self):
        namen = {f.name.lower() for f in fields(StatistikGruppe)}
        for verboten in _VERBOTENE_FELDNAMEN:
            assert not any(verboten in name for name in namen)

    def test_quote_traegt_nur_zahlen(self):
        namen = {f.name for f in fields(Quote)}
        assert namen == {"zaehler", "nenner", "quote"}


class TestKeinAzureKeinNetzwerk:
    def test_kein_modul_referenziert_azure(self):
        for modul in (audit_modul, statistik_modul):
            quelltext = Path(modul.__file__).read_text(encoding="utf-8")
            assert "Azure" not in quelltext

    def test_kein_modul_importiert_netzwerkbibliothek(self):
        for modul in (audit_modul, statistik_modul):
            quelltext = Path(modul.__file__).read_text(encoding="utf-8")
            for verboten in ("import requests", "import httpx", "import socket", "import urllib"):
                assert verboten not in quelltext

    def test_module_referenzieren_keine_secrets(self):
        for modul in (audit_modul, statistik_modul):
            quelltext = Path(modul.__file__).read_text(encoding="utf-8")
            assert "SECRET_KEY" not in quelltext
            assert "DATABASE_URL" not in quelltext
