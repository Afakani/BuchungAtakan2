"""Sicherheitstests fuer Mehrprovider-Auswertung (07-03, HYB-14..16).

Prueft: keine Volltexte/Pfade/Secrets in Auswertungsobjekten, keine untrusted
unternehmen_id, kein Azure, kein Netzwerk.
"""
from dataclasses import fields
from pathlib import Path

import packages.core.invoice_extraction.hybrid_auswertung as auswertung_modul
import packages.core.invoice_extraction.hybrid_auswahl as auswahl_modul
import packages.core.invoice_extraction.hybrid_konflikt as konflikt_modul
import packages.core.invoice_extraction.hybrid_normalisierung as normalisierung_modul
import packages.core.invoice_extraction.hybrid_qualitaetsentscheidung as status_modul
from packages.core.invoice_extraction.hybrid_auswertung import HybridAuswertungsErgebnis
from packages.core.invoice_extraction.hybrid_konflikt import KonfliktBefund
from packages.core.invoice_extraction.hybrid_normalisierung import NormalisierungsBefund

_VERBOTENE_FELDNAMEN = {"password", "secret", "token", "api_key", "credential"}


class TestKeineVolltexteGespeichert:
    def test_hybrid_auswertungsergebnis_hat_kein_volltext_feld(self):
        namen = {f.name for f in fields(HybridAuswertungsErgebnis)}
        for verboten in ("volltext", "rohtext", "ocr_text", "seitentext"):
            assert verboten not in namen

    def test_konfliktbefund_speichert_nur_normwerte_keine_volltexte(self):
        namen = {f.name for f in fields(KonfliktBefund)}
        assert "werte" in namen
        for verboten in ("volltext", "rohtext"):
            assert verboten not in namen


class TestKeinePfadeGespeichert:
    def test_normalisierungsbefund_kennt_keine_pfade(self):
        namen = {f.name for f in fields(NormalisierungsBefund)}
        assert "pfad" not in namen
        assert "dateiname" not in namen


class TestKeineSecrets:
    def test_module_referenzieren_keine_secrets(self):
        for modul in (auswertung_modul, auswahl_modul, konflikt_modul, normalisierung_modul, status_modul):
            quelltext = Path(modul.__file__).read_text(encoding="utf-8")
            assert "SECRET_KEY" not in quelltext
            assert "DATABASE_URL" not in quelltext
            assert "password" not in quelltext.lower()

    def test_keine_verbotenen_feldnamen_in_datenklassen(self):
        for klasse in (HybridAuswertungsErgebnis, KonfliktBefund, NormalisierungsBefund):
            namen = {f.name.lower() for f in fields(klasse)}
            for verboten in _VERBOTENE_FELDNAMEN:
                assert not any(verboten in name for name in namen)


class TestKeineUntrustedUnternehmenId:
    def test_auswertungsergebnis_kennt_keine_unternehmen_id(self):
        """unternehmen_id gehoert zur Persistenzschicht (Service), nicht zur
        provider-/mandantenneutralen Auswertungslogik."""
        namen = {f.name for f in fields(HybridAuswertungsErgebnis)}
        assert "unternehmen_id" not in namen

    def test_konfliktbefund_kennt_keine_unternehmen_id(self):
        namen = {f.name for f in fields(KonfliktBefund)}
        assert "unternehmen_id" not in namen


class TestKeinAzureKeinNetzwerk:
    def test_kein_modul_referenziert_azure(self):
        """status_modul (hybrid_qualitaetsentscheidung.py) ist seit Paket 07-04 bewusst
        ausgenommen: der Azure-only-Statusguard referenziert Azure absichtlich per
        Namensliteral, ohne Import/SDK/Netzwerk -- siehe TestAzureOnlyGuardBleibtTextuell."""
        for modul in (auswertung_modul, auswahl_modul, konflikt_modul, normalisierung_modul):
            quelltext = Path(modul.__file__).read_text(encoding="utf-8")
            assert "Azure" not in quelltext
            assert "AzureInvoiceProvider" not in quelltext

    def test_kein_modul_importiert_netzwerkbibliothek(self):
        for modul in (auswertung_modul, auswahl_modul, konflikt_modul, normalisierung_modul, status_modul):
            quelltext = Path(modul.__file__).read_text(encoding="utf-8")
            for verboten in ("import requests", "import httpx", "import socket", "import urllib"):
                assert verboten not in quelltext


class TestAzureOnlyGuardBleibtTextuell:
    """Paket 07-04: der Statusguard in hybrid_qualitaetsentscheidung.py darf Azure nur als
    Namensliteral kennen -- kein SDK-Import, kein AzureInvoiceProvider-Typ, kein Client."""

    def test_kein_azure_sdk_import_im_status_modul(self):
        quelltext = Path(status_modul.__file__).read_text(encoding="utf-8")
        for verboten in ("import azure", "from azure", "AzureInvoiceProvider", "DocumentAnalysisClient", "AzureKeyCredential"):
            assert verboten not in quelltext

    def test_status_modul_instanziiert_keinen_azure_client(self):
        quelltext = Path(status_modul.__file__).read_text(encoding="utf-8")
        assert "AzureDocumentIntelligenceClient" not in quelltext
        assert "AzureDocumentIntelligenceProvider" not in quelltext
        assert ".analyze(" not in quelltext
