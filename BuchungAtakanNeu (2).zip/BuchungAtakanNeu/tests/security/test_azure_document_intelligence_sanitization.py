"""Sicherheitstests fuer den vorbereiteten, deaktivierten Azure-Adapter (07-04, HYB-20..24).

Prueft: kein Azure-SDK, kein Netzwerk, keine Credentials/Secrets/Tokens/Endpunkte,
keine Dokumentinhalte, `.env.example` nicht um Azure-Credentials ergaenzt.
"""
from pathlib import Path

import packages.core.invoice_extraction.azure_document_intelligence_provider as azure_modul
from packages.core.invoice_extraction.azure_document_intelligence_provider import (
    AzureAnalyseErgebnis,
    AzureFeldErgebnis,
)

_MODUL_PFAD = Path(azure_modul.__file__)

_VERBOTENE_NETZWERKIMPORTE = ("import requests", "import httpx", "import socket", "import urllib")
_VERBOTENE_SDK_IMPORTE = ("import azure", "from azure")
_VERBOTENE_SDK_TYPEN = ("DocumentAnalysisClient", "AzureKeyCredential")


class TestKeinNetzwerkImport:
    def test_kein_netzwerkbibliothek_import(self):
        quelltext = _MODUL_PFAD.read_text(encoding="utf-8")
        for verboten in _VERBOTENE_NETZWERKIMPORTE:
            assert verboten not in quelltext


class TestKeinAzureSdk:
    def test_kein_azure_sdk_import_statement(self):
        quelltext = _MODUL_PFAD.read_text(encoding="utf-8")
        for verboten in _VERBOTENE_SDK_IMPORTE:
            assert verboten not in quelltext

    def test_keine_azure_sdk_typen_referenziert(self):
        quelltext = _MODUL_PFAD.read_text(encoding="utf-8")
        for verboten in _VERBOTENE_SDK_TYPEN:
            assert verboten not in quelltext

    def test_kein_azure_sdk_paket_installiert_referenziert(self):
        """Modul funktioniert vollstaendig ohne installiertes azure-ai-* Paket --
        kein Lazy Import wie bei PaddleOCR, weil in 07-04 gar kein SDK existieren darf."""
        import ast
        baum = ast.parse(_MODUL_PFAD.read_text(encoding="utf-8"))
        for knoten in ast.walk(baum):
            if isinstance(knoten, ast.Import):
                for alias in knoten.names:
                    assert not alias.name.startswith("azure")
            if isinstance(knoten, ast.ImportFrom) and knoten.module:
                assert not knoten.module.startswith("azure")


class TestKeineCredentialsSecretsTokens:
    def test_keine_verbotenen_begriffe_im_modul(self):
        quelltext = _MODUL_PFAD.read_text(encoding="utf-8").lower()
        for verboten in ("secret_key", "database_url", "password", "api_key", "bearer "):
            assert verboten not in quelltext

    def test_keine_endpoint_konfiguration(self):
        quelltext = _MODUL_PFAD.read_text(encoding="utf-8").lower()
        for verboten in ("endpoint=", "https://", "http://", ".cognitiveservices.", ".azure.com"):
            assert verboten not in quelltext

    def test_dataclasses_haben_keine_credential_felder(self):
        from dataclasses import fields
        for klasse in (AzureAnalyseErgebnis, AzureFeldErgebnis):
            namen = {f.name.lower() for f in fields(klasse)}
            for verboten in ("password", "secret", "token", "api_key", "credential", "key"):
                assert not any(verboten in name for name in namen)

    def test_provider_result_und_kandidat_kennen_keine_credentials(self):
        from dataclasses import fields
        from packages.core.invoice_extraction.hybrid_kandidat import HybridKandidat
        from packages.core.invoice_extraction.provider_ports import InvoiceProviderResult
        for klasse in (InvoiceProviderResult, HybridKandidat):
            namen = {f.name.lower() for f in fields(klasse)}
            for verboten in ("password", "secret", "token", "api_key", "credential"):
                assert not any(verboten in name for name in namen)


class TestKeineDokumentinhalte:
    def test_kein_pfad_oder_dateisystemzugriff_im_modul(self):
        """Modul liest/schreibt nie selbst Dateien -- pdf_path wird nur durchgereicht."""
        quelltext = _MODUL_PFAD.read_text(encoding="utf-8")
        for verboten in ("open(", ".read_text(", ".write_text("):
            assert verboten not in quelltext


class TestEnvExampleUnveraendert:
    def test_env_example_enthaelt_keine_azure_credential_variablen(self):
        env_example = Path(".env.example")
        if not env_example.exists():
            return
        inhalt = env_example.read_text(encoding="utf-8").lower()
        for verboten in (
            "azure_document_intelligence_key",
            "azure_document_intelligence_endpoint",
            "azure_client_secret",
            "cognitiveservices",
        ):
            assert verboten not in inhalt


class TestCloudInvoiceProviderVertragEingehalten:
    def test_is_enabled_property_vorhanden(self):
        """CloudInvoiceProvider-Protokoll (HYB-20) verlangt is_enabled -- muss bei
        deaktiviertem Flag False liefern (hier ueber Provider-Instanz geprueft)."""
        from packages.core.invoice_extraction.azure_document_intelligence_provider import (
            AzureDocumentIntelligenceProvider,
            FakeAzureDocumentIntelligenceClient,
        )
        provider = AzureDocumentIntelligenceProvider(
            client=FakeAzureDocumentIntelligenceClient(), enabled=False
        )
        assert provider.is_enabled is False
