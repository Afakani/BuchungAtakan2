"""Sicherheitstests fuer lokale Rechnungserkennungs-Provider (07-02, HYB-13).

Prueft: keine echten Pfade/Volltexte in Fehlern, keine Credentials, keine
unternehmen_id aus untrusted Input auf Provider-Ebene, kein Netzwerkzugriff.
"""
from dataclasses import fields
from pathlib import Path
from unittest.mock import patch

import packages.core.invoice_extraction.invoice2data_provider as invoice2data_modul
import packages.core.invoice_extraction.paddleocr_provider as paddleocr_modul
import packages.core.invoice_extraction.pdfplumber_provider as pdfplumber_modul
from packages.core.invoice_extraction.hybrid_kandidat import HybridKandidat
from packages.core.invoice_extraction.invoice2data_provider import Invoice2DataProvider
from packages.core.invoice_extraction.paddleocr_provider import PaddleOCRProvider
from packages.core.invoice_extraction.pdfplumber_provider import PdfplumberProvider
from packages.core.invoice_extraction.provider_ports import InvoiceProviderResult

_ECHTER_PFAD = r"C:\Users\User\Firma GmbH\Belege\Rechnung_Kunde_Muster_2026.pdf"


class TestKeineEchtenPfadeInFehlern:
    def test_pdfplumber_fehlercode_ohne_pfad(self):
        with patch(
            "packages.core.invoice_extraction.invoice_parser_adapter._READER.extract_text",
            side_effect=FileNotFoundError(_ECHTER_PFAD),
        ):
            ergebnis = PdfplumberProvider().extract(Path(_ECHTER_PFAD))
        assert ergebnis.fehlercode == "FileNotFoundError"
        assert "Firma GmbH" not in ergebnis.fehlercode
        assert "\\" not in ergebnis.fehlercode

    def test_invoice2data_fehlercode_ohne_pfad(self):
        with patch(
            "packages.core.invoice_extraction.invoice2data_provider._READER.extract_text",
            side_effect=OSError(_ECHTER_PFAD),
        ):
            ergebnis = Invoice2DataProvider().extract(Path(_ECHTER_PFAD))
        assert ergebnis.fehlercode == "OSError"
        assert "Firma GmbH" not in ergebnis.fehlercode

    def test_paddleocr_fehlercode_ohne_pfad(self):
        # PaddleOCR ist nicht installiert -- ModuleNotFoundError-Pfad, ebenfalls sauber.
        ergebnis = PaddleOCRProvider().extract(Path(_ECHTER_PFAD))
        assert ergebnis.fehlercode == "ModuleNotFoundError"
        assert "Firma GmbH" not in ergebnis.fehlercode


class TestKeineVolltexteInFehlercode:
    def test_fehlercode_enthaelt_keinen_zeilenumbruch(self):
        with patch(
            "packages.core.invoice_extraction.invoice_parser_adapter._READER.extract_text",
            side_effect=ValueError("Volltext:\nRechnungsnummer RE-123\nGesamtbetrag 100 EUR"),
        ):
            ergebnis = PdfplumberProvider().extract(Path("dummy.pdf"))
        assert "\n" not in ergebnis.fehlercode
        assert "Traceback" not in ergebnis.fehlercode
        assert ergebnis.fehlercode == "ValueError"


class TestKeineCredentials:
    def test_invoice_provider_result_hat_keine_credential_felder(self):
        namen = {f.name for f in fields(InvoiceProviderResult)}
        verbotene_begriffe = {"password", "secret", "token", "api_key", "credential"}
        for name in namen:
            assert not any(begriff in name.lower() for begriff in verbotene_begriffe)

    def test_hybrid_kandidat_hat_keine_credential_felder(self):
        namen = {f.name for f in fields(HybridKandidat)}
        verbotene_begriffe = {"password", "secret", "token", "api_key", "credential"}
        for name in namen:
            assert not any(begriff in name.lower() for begriff in verbotene_begriffe)

    def test_provider_module_referenzieren_keine_secrets(self):
        for modul in (invoice2data_modul, paddleocr_modul, pdfplumber_modul):
            quelltext = Path(modul.__file__).read_text(encoding="utf-8")
            assert "SECRET_KEY" not in quelltext
            assert "DATABASE_URL" not in quelltext
            assert "password" not in quelltext.lower()


class TestKeineUnternehmenIdAusUntrustedInput:
    def test_hybrid_kandidat_kennt_keine_unternehmen_id(self):
        """Provider-Ebene ist mandantenneutral -- unternehmen_id gehoert zur
        Persistenzschicht (07-01), nie zum Provider-/Kandidatenmodell."""
        namen = {f.name for f in fields(HybridKandidat)}
        assert "unternehmen_id" not in namen

    def test_invoice_provider_result_kennt_keine_unternehmen_id(self):
        namen = {f.name for f in fields(InvoiceProviderResult)}
        assert "unternehmen_id" not in namen


class TestKeinNetzwerkzugriff:
    def test_invoice2data_provider_importiert_keine_netzwerkbibliothek(self):
        quelltext = Path(invoice2data_modul.__file__).read_text(encoding="utf-8")
        for verboten in ("import requests", "import httpx", "import socket", "import urllib"):
            assert verboten not in quelltext

    def test_paddleocr_provider_importiert_keine_netzwerkbibliothek_direkt(self):
        quelltext = Path(paddleocr_modul.__file__).read_text(encoding="utf-8")
        for verboten in ("import requests", "import httpx", "import socket", "import urllib"):
            assert verboten not in quelltext

    def test_invoice2data_nutzt_platzhalterpfad_statt_echten_pfad(self):
        """invoice2data erhaelt nie den echten Dateipfad -- nur den Text (siehe
        _PreExtractedTextInput) und einen Platzhalternamen fuer Cache-/Log-Zwecke."""
        assert invoice2data_modul._PLATZHALTER_PFAD == "invoice2data_input.pdf"
