"""Sicherheitstests fuer Excel-Export der Hybrid-Qualitaetsstatistik (07-03B, HYB-19).

Prueft mit absichtlich sensibel aussehenden synthetischen Strings, dass das Workbook
keine Originalinhalte enthaelt -- nur aggregierte Statistikdaten.
"""
from io import BytesIO
from pathlib import Path

from openpyxl import load_workbook

from packages.core.invoice_extraction.hybrid_statistik import Quote, StatistikGruppe
from packages.core.invoice_extraction.hybrid_statistik_export import (
    erstelle_hybrid_statistik_workbook_bytes,
)

_VERBOTENE_STRINGS = (
    "RE-2026-00042",           # Rechnungsnummer
    "31.12.2025",              # Rechnungsdatum
    "12345.67",                # Einzelbetrag
    "C:\\Users\\Geheim\\rechnung.pdf",  # Pfad
    "/home/user/geheim/rechnung.pdf",   # Pfad
    "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",  # Hash
    "geheime_rechnung_2026.pdf",  # Dateiname
    "Sehr geehrte Damen und Herren, anbei die Rechnung",  # Volltext
    "OCR_ROHTEXT_SEITE_1: Lorem ipsum dolor sit amet",  # OCR-Rohdatum
    "kandidat_rohwert_original_123",  # Kandidaten-Rohwert
    "sk-proj-abc123SECRET",  # Secret/Token
    "DATABASE_URL=postgresql://user:pass@host",  # Credential
    "Traceback (most recent call last):",  # Stacktrace
)


def _quote(z: int, n: int, q: float | None) -> Quote:
    return Quote(zaehler=z, nenner=n, quote=q)


def _gruppe(anbieter: str = "Muster GmbH") -> StatistikGruppe:
    return StatistikGruppe(
        dimensionen=("anbieter", "status"),
        dimensionswerte=(anbieter, "OK"),
        anzahl=1,
        vollstaendigkeitsquote=_quote(1, 1, 1.0),
        richtigkeitsquote=_quote(1, 1, 1.0),
        automatisierungsquote=_quote(1, 1, 1.0),
        pruefquote=_quote(0, 1, 0.0),
        nichterkennungsquote=_quote(0, 1, 0.0),
    )


def _alle_zellwerte_als_text(data: bytes) -> str:
    wb = load_workbook(BytesIO(data))
    werte = []
    for sheet in wb.sheetnames:
        for row in wb[sheet].iter_rows(values_only=True):
            for zelle in row:
                if zelle is not None:
                    werte.append(str(zelle))
    return "\n".join(werte)


class TestKeineOriginalinhalteImWorkbook:
    def test_synthetisch_sensible_strings_nicht_im_workbook(self):
        """Die verbotenen Strings sind NICHT Teil der StatistikGruppe-Eingabe --
        Test beweist, dass die Exportfunktion selbst (Header, Definitionen, Formate)
        keine solchen Inhalte einstreut."""
        data = erstelle_hybrid_statistik_workbook_bytes([_gruppe()], ("anbieter", "status"))
        text = _alle_zellwerte_als_text(data)
        for verboten in _VERBOTENE_STRINGS:
            assert verboten not in text, f"Verbotener Inhalt im Workbook gefunden: {verboten}"

    def test_anbieter_nur_wenn_angeforderte_dimension(self):
        """Anbieter erscheint nur, wenn 'anbieter' Teil der angeforderten Dimensionen ist."""
        gruppe_ohne_anbieter_dimension = StatistikGruppe(
            dimensionen=("status",),
            dimensionswerte=("OK",),
            anzahl=1,
            vollstaendigkeitsquote=_quote(1, 1, 1.0),
            richtigkeitsquote=_quote(1, 1, 1.0),
            automatisierungsquote=_quote(1, 1, 1.0),
            pruefquote=_quote(0, 1, 0.0),
            nichterkennungsquote=_quote(0, 1, 0.0),
        )
        data = erstelle_hybrid_statistik_workbook_bytes([gruppe_ohne_anbieter_dimension], ("status",))
        text = _alle_zellwerte_als_text(data)
        assert "Anbieter" not in text

    def test_anbieter_als_aggregierter_gruppenschluessel_erlaubt(self):
        """Wenn 'anbieter' angeforderte Dimension ist, ist der aggregierte Gruppenwert
        (nicht Originaldaten) zulaessig -- keine Pseudonymisierung in diesem Paket."""
        data = erstelle_hybrid_statistik_workbook_bytes(
            [_gruppe(anbieter="Muster GmbH")], ("anbieter", "status")
        )
        text = _alle_zellwerte_als_text(data)
        assert "Muster GmbH" in text
        assert "Anbieter" in text

    def test_keine_verbotenen_feldnamen_im_modul(self):
        modul_pfad = Path(
            "packages/core/invoice_extraction/hybrid_statistik_export.py"
        )
        quelltext = modul_pfad.read_text(encoding="utf-8")
        for verboten in ("rechnungsnummer=", "dateiname=", "pfad=", "hash=", "volltext="):
            assert verboten not in quelltext.lower()

    def test_keine_secrets_im_modul(self):
        modul_pfad = Path(
            "packages/core/invoice_extraction/hybrid_statistik_export.py"
        )
        quelltext = modul_pfad.read_text(encoding="utf-8")
        assert "SECRET_KEY" not in quelltext
        assert "DATABASE_URL" not in quelltext
        assert "password" not in quelltext.lower()

    def test_kein_netzwerk_kein_dateisystem_import(self):
        modul_pfad = Path(
            "packages/core/invoice_extraction/hybrid_statistik_export.py"
        )
        quelltext = modul_pfad.read_text(encoding="utf-8")
        for verboten in ("import requests", "import httpx", "import socket", "open(", "Path("):
            assert verboten not in quelltext
