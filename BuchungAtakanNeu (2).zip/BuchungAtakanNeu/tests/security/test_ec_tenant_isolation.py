"""Security-Tests EC-Tenant-Isolation — Phase 06, Paket 2.

T22: Tenant-A kann keine EC-Belege von Tenant-B lesen (DB-seitig, via RLS)
T23: Tenant-A kann keine Sammelzuordnungen von Tenant-B lesen
T24: Rematch mit Bankkonto-ID eines anderen Mandanten wird abgelehnt
T25: Composite FK verhindert Cross-Tenant-Beleg-Zuordnung auf DB-Ebene
"""
import os

import pytest
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

TENANT_A = "00000000-0000-4000-a000-000000000001"
TENANT_B = "00000000-0000-4000-a000-000000000002"


async def _login(client, username: str, password: str = "testpassword123") -> str:
    resp = await client.post(
        "/api/v1/auth/login",
        data={"username": username, "password": password},
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    assert resp.status_code == 200, f"Login fehlgeschlagen: {resp.text}"
    return resp.json()["access_token"]


def _auth(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


async def _konto_anlegen(client, token: str, anzeigename: str = "Sicherheitskonto") -> str:
    resp = await client.post(
        "/api/v1/bankkonten",
        json={"anzeigename": anzeigename},
        headers=_auth(token),
    )
    assert resp.status_code == 201
    return resp.json()["id"]


@pytest.mark.asyncio
async def test_t22_ec_belege_rls_tenant_isolation(http_client):
    """T22: Tenant-A kann EC-Belege von Tenant-B nicht per API lesen."""
    tok_a = await _login(http_client, "admin_a")
    tok_b = await _login(http_client, "admin_b")
    konto_a = await _konto_anlegen(http_client, tok_a, "Sicherheit-A")
    konto_b = await _konto_anlegen(http_client, tok_b, "Sicherheit-B")

    # Tenant-B importiert einen Beleg
    resp_b = await http_client.post(
        "/api/v1/ec/belege/importe",
        json={
            "bankkonto_id": konto_b,
            "quell_referenz": "sicherheit-b.csv",
            "belege": [{
                "buchungsdatum": "2024-10-01",
                "betrag_cent": 99999,
                "waehrung": "EUR",
                "quell_position": "0",
            }],
        },
        headers=_auth(tok_b),
    )
    assert resp_b.status_code == 201

    # Tenant-A fragt ab (nur eigenes Konto)
    resp_a = await http_client.get(
        f"/api/v1/ec/belege?bankkonto_id={konto_a}",
        headers=_auth(tok_a),
    )
    assert resp_a.status_code == 200
    belege_a = resp_a.json()
    betraege_a = [b["betrag_cent"] for b in belege_a]
    assert 99999 not in betraege_a, "Tenant-A sieht Beleg von Tenant-B"


@pytest.mark.asyncio
async def test_t23_sammelzuordnungen_rls_tenant_isolation(http_client):
    """T23: Tenant-A sieht keine Sammelzuordnungen von Tenant-B."""
    tok_a = await _login(http_client, "admin_a")
    tok_b = await _login(http_client, "admin_b")
    konto_a = await _konto_anlegen(http_client, tok_a, "SZ-Sicherheit-A")
    konto_b = await _konto_anlegen(http_client, tok_b, "SZ-Sicherheit-B")

    for tok, konto in [(tok_a, konto_a), (tok_b, konto_b)]:
        await http_client.post(
            "/api/v1/bankbuchungen/importe",
            json={"bankkonto_id": konto, "quell_referenz": "t.mt940", "buchungen": [{
                "buchungsdatum": "2024-10-05",
                "betrag_cent": 2000,
                "waehrung": "EUR",
                "verwendungszweck": "EC-Karte Abrechnung",
                "quell_position": 0,
            }]},
            headers=_auth(tok),
        )
        await http_client.post(
            "/api/v1/ec/belege/importe",
            json={"bankkonto_id": konto, "quell_referenz": "t.csv", "belege": [{
                "buchungsdatum": "2024-10-04", "betrag_cent": 2000, "waehrung": "EUR", "quell_position": "0",
            }]},
            headers=_auth(tok),
        )
        await http_client.post(
            "/api/v1/ec/sammelzuordnungen/rematch",
            json={"bankkonto_id": konto},
            headers=_auth(tok),
        )

    resp_a = await http_client.get("/api/v1/ec/sammelzuordnungen", headers=_auth(tok_a))
    ids_a = {z["id"] for z in resp_a.json()}

    resp_b = await http_client.get("/api/v1/ec/sammelzuordnungen", headers=_auth(tok_b))
    ids_b = {z["id"] for z in resp_b.json()}

    assert ids_a.isdisjoint(ids_b), "Tenant-Isolation verletzt: Sammelzuordnungen teilen IDs"


@pytest.mark.asyncio
async def test_t24_rematch_cross_tenant_bankkonto(http_client):
    """T24: Rematch mit fremdem Bankkonto → 404 (kein Cross-Tenant-Matching)."""
    tok_a = await _login(http_client, "admin_a")
    tok_b = await _login(http_client, "admin_b")
    konto_b = await _konto_anlegen(http_client, tok_b, "Cross-Tenant-B")

    resp = await http_client.post(
        "/api/v1/ec/sammelzuordnungen/rematch",
        json={"bankkonto_id": konto_b},
        headers=_auth(tok_a),
    )
    assert resp.status_code == 404
    assert "gefunden" in resp.json()["detail"].lower()


@pytest.mark.asyncio
async def test_t25_composite_fk_verhindert_cross_tenant_beleg():
    """T25: DB-seitiger Composite-FK lehnt Cross-Tenant-Beleg-Zuordnung ab."""
    test_url = os.environ.get("TEST_DATABASE_URL")
    if not test_url:
        pytest.skip("TEST_DATABASE_URL nicht gesetzt")

    from uuid import uuid4
    from sqlalchemy.engine import make_url as _make_url

    async_url = _make_url(test_url).set(drivername="postgresql+asyncpg").render_as_string(hide_password=False)
    engine = create_async_engine(async_url, echo=False)
    factory = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

    try:
        async with factory() as session:
            # Tenant-A Kontext setzen
            await session.execute(
                text("SELECT set_config('app.current_tenant', :tid, false)"),
                {"tid": TENANT_A},
            )

            # Versuche einen Beleg von Tenant-A mit Bankkonto-ID von Tenant-B zu verknuepfen
            # Da fk_ec_belege_bankkonto_tenant (bankkonto_id, unternehmen_id) → bankkonten
            # wird kein gueltiger Eintrag fuer (konto_b_id, TENANT_A) in bankkonten existieren
            fake_konto_b_id = uuid4()
            with pytest.raises((IntegrityError, Exception)):
                await session.execute(text("""
                    INSERT INTO ec_belege
                        (unternehmen_id, bankkonto_id, betrag_cent, buchungsdatum,
                         zahlungskategorie, status, waehrung, import_fingerprint)
                    VALUES
                        (:tenant_a, :konto_b, 1000, '2024-01-01',
                         'UNBEKANNT', 'VERFUEGBAR', 'EUR', :fp)
                """), {
                    "tenant_a": TENANT_A,
                    "konto_b": fake_konto_b_id,
                    "fp": f"cross-tenant-test-{uuid4()}",
                })
                await session.commit()
    finally:
        await engine.dispose()
