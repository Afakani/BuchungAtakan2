"""Sicherheitstests: Error-Sanitisierung (SRV-08, T-03-01).
Kein PostgreSQL noetig -- testet HTTP-Schicht gegen FastAPI-App.
"""
import pytest
from httpx import ASGITransport, AsyncClient


@pytest.fixture
def test_app():
    """FastAPI-App mit zusaetzlichem /test-error-Endpunkt (nur fuer Tests)."""
    from apps.server.main import create_app
    app = create_app()

    @app.get("/test-error")
    async def raise_error():
        raise RuntimeError(
            "SQL: SELECT * FROM benutzer WHERE password='geheimnis'"
        )

    return app


@pytest.fixture
async def http_client_secure(test_app):
    # raise_app_exceptions=False: httpx gibt die HTTP-Response zurueck statt die Exception
    # weiterzuleiten -- noetig damit der Exception-Handler 500+reference_id liefern kann
    async with AsyncClient(
        transport=ASGITransport(app=test_app, raise_app_exceptions=False),
        base_url="http://test",
    ) as client:
        yield client


@pytest.mark.asyncio
async def test_unhandled_exception_returns_500_with_reference_id(http_client_secure):
    """T-03-01: Ungefangene Exception -> 500 mit reference_id, keine internen Details."""
    resp = await http_client_secure.get("/test-error")
    assert resp.status_code == 500
    data = resp.json()
    assert "reference_id" in data
    assert "detail" in data
    assert data["detail"] == "Interner Serverfehler"


@pytest.mark.asyncio
async def test_500_response_has_no_sql_fragment(http_client_secure):
    """T-03-01: 500-Response enthaelt kein SQL."""
    resp = await http_client_secure.get("/test-error")
    body = resp.text.lower()
    forbidden = ["select", "insert", "from", "where", "geheimnis", "password"]
    for kw in forbidden:
        assert kw not in body, f"Verbotenes Wort im Response: {kw!r}"


@pytest.mark.asyncio
async def test_validation_error_422_no_internal_details(http_client_secure):
    """SRV-08: 422 enthaelt keine internen Python-Details."""
    resp = await http_client_secure.post(
        "/api/v1/auth/login",
        data={},
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    assert resp.status_code == 422
    body = resp.text.lower()
    assert "database_url" not in body
    assert "traceback" not in body
    assert "file" not in body


@pytest.mark.asyncio
async def test_invalid_token_returns_401_safe(http_client_secure):
    """SRV-08: Invalider Token -> 401 ohne SECRET_KEY oder DATABASE_URL."""
    resp = await http_client_secure.get(
        "/api/v1/unternehmen/me",
        headers={"Authorization": "Bearer INVALIDER_TOKEN"},
    )
    assert resp.status_code == 401
    body = resp.text.lower()
    assert "secret_key" not in body
    assert "database_url" not in body
    assert "traceback" not in body


@pytest.mark.asyncio
async def test_health_endpoint_always_200(http_client_secure):
    """Liveness-Probe ohne Auth."""
    resp = await http_client_secure.get("/health")
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}
