"""Gemeinsame Test-Infrastruktur fuer alle Test-Suiten (integration, security).

Sicherheitsregeln:
- TEST_DATABASE_URL nicht gesetzt  -> Integrationstests werden UEBERSPRUNGEN (pytest.skip).
  Lokale Entwicklung ohne Test-DB bleibt dadurch nutzbar; Unit-Tests laufen unberuehrt.
- TEST_DATABASE_URL gesetzt, aber gefaehrlich konfiguriert -> HARTES SCHEITERN:
    * DB-Name ist nicht exakt 'buchungatakan_test'
    * URL aequivalent zur originalen DATABASE_URL (Dev-DB wuerde beschrieben)
  Sicherheitspruefung laeuft in pytest_configure VOR dem DATABASE_URL-Override.
- Kein automatisches alembic downgrade -- Testdatenbank bleibt nach Tests bestehen.
- DATABASE_URL wird in pytest_configure auf TEST_DATABASE_URL umgeleitet, nachdem
  die URL validiert wurde -- App und direkte DB-Sessions verwenden dieselbe Testdatenbank.
- Alle destruktiven Operationen (TRUNCATE, DROP TABLE) pruefen den DB-Namen erneut
  vor jedem Aufruf -- doppelte Absicherung gegen Fehlkonfiguration.
"""
import asyncio
import os
from urllib.parse import urlparse, urlunparse

import pytest
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from tests.db_guard import ERLAUBTER_DB_NAME, pruefe_test_db_url

# Beide URLs zum Modullade-Zeitpunkt sichern (vor pytest_configure-Override).
TEST_DB_URL: str | None = os.environ.get("TEST_DATABASE_URL")
_ORIGINAL_DB_URL: str = os.environ.get("DATABASE_URL", "")

# APP_DATABASE_URL: separate, nicht privilegierte Verbindung (buchungatakan_app) fuer
# echte RLS-Isolationsnachweise (P-10). Ohne diese Variable bleiben die betroffenen
# Tests ein sauberer, dokumentierter Infrastruktur-Skip -- kein Fallback auf
# TEST_DATABASE_URL, das waere ein RLS-Test ohne Aussagekraft, wenn diese Rolle
# Superuser oder BYPASSRLS ist (siehe docs/OPEN_POINTS.md P-09/P-10).
APP_DB_URL: str | None = os.environ.get("APP_DATABASE_URL")


def _normalize_db_url(url: str) -> str:
    p = urlparse(url)
    return urlunparse((
        p.scheme.lower(),
        p.netloc.lower(),
        p.path.rstrip("/") or "/",
        p.params,
        p.query,
        p.fragment,
    ))


def _check_url_safety(test_url: str, original_url: str) -> str | None:
    # Exakter Namensabgleich -- kein Substring, kein endswith
    fehler = pruefe_test_db_url(test_url)
    if fehler:
        return fehler

    if original_url and _normalize_db_url(test_url) == _normalize_db_url(original_url):
        return (
            "SICHERHEITSFEHLER: TEST_DATABASE_URL ist aequivalent zur originalen "
            "DATABASE_URL. Separate, isolierte Testdatenbank verwenden."
        )

    return None


def pytest_configure(config) -> None:
    os.environ.setdefault("BUCHUNG_ATAKAN_SEED_TEST_DATA", "1")
    test_url = os.environ.get("TEST_DATABASE_URL")
    if not test_url:
        return

    error = _check_url_safety(test_url, _ORIGINAL_DB_URL)
    if error:
        pytest.exit(error + " Integrationstests abgebrochen.", returncode=1)

    os.environ["DATABASE_URL"] = test_url


def _validate_test_db_url() -> None:
    if not TEST_DB_URL:
        pytest.skip(
            "TEST_DATABASE_URL nicht gesetzt -- Integrationstests werden uebersprungen. "
            "TEST_DATABASE_URL mit Testdatenbank (Name muss 'test' enthalten) setzen.",
        )


_PRIVILEGE_CHECK_SQL = "SELECT rolsuper, rolbypassrls FROM pg_roles WHERE rolname = current_user"


def _validate_app_db_url() -> None:
    """P-10-Guard fuer echte RLS-Isolationstests (Nicht-Superuser-/Nicht-BYPASSRLS-Nachweis).

    Ohne APP_DATABASE_URL: sauberer Skip, kein Phase-7-Blocker (Infrastrukturthema
    P-09/P-10 -- buchungatakan_app-Passwort ist ein manueller DBA-Schritt).
    Mit APP_DATABASE_URL: derselbe Namensguard wie TEST_DATABASE_URL (exakt
    buchungatakan_test) und ein Schutz gegen blinde Wiederverwendung derselben URL wie
    TEST_DATABASE_URL -- sonst koennte eine privilegierte Verbindung unbemerkt als
    "App-Rolle" durchgereicht werden und einen falsch-gruenen RLS-Nachweis erzeugen.
    """
    if not APP_DB_URL:
        pytest.skip(
            "P-10: APP_DATABASE_URL nicht gesetzt -- echte RLS-Isolationstests (Nicht-"
            "Superuser-/Nicht-BYPASSRLS-Nachweis als buchungatakan_app) werden "
            "uebersprungen. Siehe docs/OPEN_POINTS.md P-09/P-10. Kein Phase-7-Blocker."
        )

    fehler = pruefe_test_db_url(APP_DB_URL)
    if fehler:
        pytest.fail(fehler)

    if TEST_DB_URL and _normalize_db_url(APP_DB_URL) == _normalize_db_url(TEST_DB_URL):
        pytest.fail(
            "SICHERHEITSFEHLER: APP_DATABASE_URL ist identisch mit TEST_DATABASE_URL. "
            "Eine echte RLS-Isolationspruefung erfordert eine eigene, von der "
            "(moeglicherweise privilegierten) Testverbindung getrennte App-Rollen-"
            "Verbindung -- blinde Wiederverwendung ist nicht zulaessig."
        )


def _pruefe_rolle_nicht_privilegiert(row) -> None:
    """Faellt hart, statt still gruen zu werden, wenn APP_DATABASE_URL privilegiert ist.

    Keine Rueckgabe der URL oder Credentials in der Fehlermeldung -- nur die beiden
    booleschen Katalogwerte.
    """
    if row is None:
        pytest.fail("APP_DATABASE_URL: current_user nicht in pg_roles auffindbar.")
    rolsuper, rolbypassrls = row
    if rolsuper or rolbypassrls:
        pytest.fail(
            "SICHERHEITSFEHLER: APP_DATABASE_URL verbindet mit einer privilegierten "
            f"Rolle (rolsuper={rolsuper}, rolbypassrls={rolbypassrls}). Eine echte "
            "RLS-Isolationspruefung ist mit dieser Rolle nicht moeglich -- "
            "buchungatakan_app darf weder Superuser noch BYPASSRLS sein."
        )


@pytest.fixture(scope="session")
def event_loop():
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


_TRANSAKTIONALE_TABELLEN = (
    "rechnungs_kandidaten",
    "hybrid_audit_bewertungen",
    "hybrid_statusentscheidungen",
    "hybrid_konflikte",
    "hybrid_kandidaten",
    "hybrid_erkennungslaeufe",
    "erkennungslaeufe",
    "zuordnungsvorschlaege",
    "ec_sammelzuordnung_belege",
    "ec_sammelzuordnungen",
    "ec_sammellaeufe",
    "ec_belege",
    "bankbuchungen",
    "kontoauszugsimporte",
    "bankkonten",
    "rechnungen",
    "dokumente",
    "installationen",
)


def _bereinige_transaktionsdaten(sync_url: str) -> None:
    # Guard VOR jeder Datenaenderung -- kein TRUNCATE ohne erfolgreiche Pruefung
    fehler = pruefe_test_db_url(sync_url)
    if fehler:
        raise RuntimeError(fehler)

    from sqlalchemy import create_engine, text as sa_text

    tabellen = ", ".join(_TRANSAKTIONALE_TABELLEN)
    engine = create_engine(sync_url)
    try:
        with engine.begin() as conn:
            conn.execute(sa_text(f"TRUNCATE {tabellen}"))
    finally:
        engine.dispose()


def _ensure_seed_data(sync_url: str) -> None:
    if os.environ.get("BUCHUNG_ATAKAN_SEED_TEST_DATA") != "1":
        return

    from pwdlib import PasswordHash
    from sqlalchemy import create_engine, text as sa_text

    _TENANT_A = "00000000-0000-4000-a000-000000000001"
    _TENANT_B = "00000000-0000-4000-a000-000000000002"
    pw_hash = PasswordHash.recommended().hash("testpassword123")

    seed = [
        (_TENANT_A, "Test GmbH A", [("admin_a", "UNTERNEHMEN_ADMIN"), ("leser_a", "LESER")]),
        (_TENANT_B, "Test GmbH B", [("admin_b", "UNTERNEHMEN_ADMIN")]),
    ]

    engine = create_engine(sync_url)
    try:
        for tenant_id, tenant_name, benutzer_rows in seed:
            with engine.begin() as conn:
                conn.execute(sa_text("SELECT set_config('app.current_tenant', :tid, true)"), {"tid": tenant_id})
                conn.execute(
                    sa_text("INSERT INTO unternehmen (id, name) VALUES (:id, :name) ON CONFLICT (id) DO NOTHING"),
                    {"id": tenant_id, "name": tenant_name},
                )
                for benutzername, rolle in benutzer_rows:
                    conn.execute(
                        sa_text(
                            "INSERT INTO benutzer "
                            "(id, unternehmen_id, benutzername, hashed_password, rolle) "
                            "VALUES (gen_random_uuid(), :tid, :bn, :pw, :rolle) "
                            "ON CONFLICT (benutzername) DO NOTHING"
                        ),
                        {"tid": tenant_id, "bn": benutzername, "pw": pw_hash, "rolle": rolle},
                    )
    finally:
        engine.dispose()


def _handle_ec_schema_drift(sync_url: str) -> None:
    # Guard VOR jeder Schemaaenderung
    fehler = pruefe_test_db_url(sync_url)
    if fehler:
        raise RuntimeError(fehler)

    from sqlalchemy import create_engine, text as sa_text

    engine = create_engine(sync_url)
    try:
        with engine.begin() as conn:
            try:
                ver = conn.execute(sa_text("SELECT version_num FROM alembic_version")).scalar()
            except Exception:
                return

            if ver != "010":
                return

            result = conn.execute(sa_text("""
                SELECT column_name FROM information_schema.columns
                WHERE table_schema = 'public'
                  AND table_name = 'ec_belege'
                  AND column_name = 'bankkonto_id'
            """))
            if result.fetchone() is not None:
                return

            conn.execute(sa_text("DROP TABLE IF EXISTS ec_sammelzuordnung_belege CASCADE"))
            conn.execute(sa_text("DROP TABLE IF EXISTS ec_sammelzuordnungen CASCADE"))
            conn.execute(sa_text("DROP TABLE IF EXISTS ec_sammellaeufe CASCADE"))
            conn.execute(sa_text("DROP TABLE IF EXISTS ec_belege CASCADE"))
            conn.execute(sa_text(
                "ALTER TABLE bankbuchungen "
                "DROP CONSTRAINT IF EXISTS uq_bankbuchungen_id_unternehmen"
            ))
            conn.execute(sa_text("UPDATE alembic_version SET version_num = '009'"))
    finally:
        engine.dispose()


@pytest.fixture(scope="session")
def apply_migrations():
    """Fuehrt alembic upgrade head auf der validierten Testdatenbank aus."""
    _validate_test_db_url()

    from alembic import command
    from alembic.config import Config
    from sqlalchemy import create_engine, text
    from sqlalchemy.engine import make_url

    sync_url = make_url(TEST_DB_URL).set(drivername="postgresql+psycopg2").render_as_string(hide_password=False)
    alembic_cfg = Config("alembic.ini")
    alembic_cfg.set_main_option("sqlalchemy.url", sync_url)

    engine = create_engine(sync_url)
    with engine.connect() as conn:
        conn.execute(text("""
            DO $$
            BEGIN
              IF NOT EXISTS (
                SELECT FROM pg_catalog.pg_roles WHERE rolname = 'buchungatakan_app'
              ) THEN
                CREATE ROLE buchungatakan_app LOGIN;
              END IF;
            END $$;
        """))
        conn.commit()
    engine.dispose()

    _handle_ec_schema_drift(sync_url)
    command.upgrade(alembic_cfg, "head")
    _bereinige_transaktionsdaten(sync_url)
    _ensure_seed_data(sync_url)

    import apps.server.database as _app_db
    from sqlalchemy.pool import NullPool as _NullPool
    _null_engine = create_async_engine(
        make_url(TEST_DB_URL).set(drivername="postgresql+asyncpg"),
        poolclass=_NullPool,
    )
    _app_db.engine = _null_engine
    _app_db.async_session_factory = async_sessionmaker(
        _null_engine, expire_on_commit=False, class_=AsyncSession
    )

    yield


@pytest.fixture
async def db_session(apply_migrations):
    """Direkte DB-Session gegen validierte Testdatenbank."""
    from sqlalchemy.engine import make_url
    engine = create_async_engine(
        make_url(TEST_DB_URL).set(drivername="postgresql+asyncpg"),
        echo=False,
    )
    factory = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)
    async with factory() as session:
        yield session
    await engine.dispose()


@pytest.fixture
def app_role_sync_engine(apply_migrations):
    """Sync-Engine als App-Rolle (buchungatakan_app) fuer echte RLS-Isolationstests.

    P-10: skip ohne APP_DATABASE_URL (_validate_app_db_url). Verifiziert vor jeder
    Nutzung per Katalogabfrage, dass die verbundene Rolle weder Superuser noch
    BYPASSRLS ist -- sonst harter Fehlschlag statt eines falsch-gruenen RLS-Nachweises.
    """
    _validate_app_db_url()
    from sqlalchemy import create_engine, text as sa_text
    from sqlalchemy.engine import make_url

    url = make_url(APP_DB_URL).set(drivername="postgresql+psycopg2").render_as_string(hide_password=False)
    engine = create_engine(url)
    try:
        with engine.connect() as conn:
            row = conn.execute(sa_text(_PRIVILEGE_CHECK_SQL)).fetchone()
            _pruefe_rolle_nicht_privilegiert(row)
        yield engine
    finally:
        engine.dispose()


@pytest.fixture
async def app_role_async_engine(apply_migrations):
    """Async-Engine als App-Rolle -- siehe app_role_sync_engine."""
    _validate_app_db_url()
    from sqlalchemy import text as sa_text
    from sqlalchemy.engine import make_url

    engine = create_async_engine(
        make_url(APP_DB_URL).set(drivername="postgresql+asyncpg"),
        echo=False,
    )
    try:
        async with engine.connect() as conn:
            result = await conn.execute(sa_text(_PRIVILEGE_CHECK_SQL))
            row = result.fetchone()
            _pruefe_rolle_nicht_privilegiert(row)
        yield engine
    finally:
        await engine.dispose()


@pytest.fixture
async def app_role_session(app_role_async_engine):
    """Async-Session als App-Rolle -- fuer scharfe (nicht tolerante) Tenant-Isolationstests.

    Im Unterschied zu db_session verbindet diese Session garantiert nicht als
    Superuser/BYPASSRLS (Laufzeitpruefung in app_role_async_engine) -- eine
    "Tenant B sieht Tenant A nicht"-Assertion ist damit tatsaechlich aussagekraeftig.
    """
    factory = async_sessionmaker(app_role_async_engine, expire_on_commit=False, class_=AsyncSession)
    async with factory() as session:
        yield session


@pytest.fixture
async def http_client(apply_migrations):
    """HTTP-TestClient gegen App -- verwendet garantiert Testdatenbank."""
    from apps.server.main import app
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        yield client
