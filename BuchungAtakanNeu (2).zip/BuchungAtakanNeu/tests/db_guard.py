"""Sicherheitsguard fuer Testdatenbank-URL.

Erlaubt ausschliesslich buchungatakan_test als Datenbankname.
Kein Substring- oder endswith-Vergleich -- exakter Namensabgleich erforderlich.

Fehlermeldungen nennen nur den DB-Namen, keine vollstaendige URL und keine Credentials.
"""

ERLAUBTER_DB_NAME = "buchungatakan_test"


def pruefe_test_db_url(url: str) -> str | None:
    """Gibt Fehlermeldung zurueck wenn DB-Name nicht buchungatakan_test, sonst None."""
    try:
        db_name = url.split("?")[0].rstrip("/").rsplit("/", 1)[-1].lower()
    except Exception:
        db_name = ""
    if db_name != ERLAUBTER_DB_NAME:
        return (
            f"SICHERHEITSFEHLER: Datenbankname '{db_name}' ist nicht erlaubt. "
            f"Nur '{ERLAUBTER_DB_NAME}' wird als Testdatenbank akzeptiert."
        )
    return None
