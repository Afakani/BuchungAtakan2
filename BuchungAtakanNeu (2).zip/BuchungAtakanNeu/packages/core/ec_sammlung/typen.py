"""Typen, Dataclasses und Enums fuer EC-Sammelzuordnung (Phase 06, Paket 1)."""
from dataclasses import dataclass, field
from datetime import date
from enum import StrEnum
from uuid import UUID


class ZahlungsKategorie(StrEnum):
    """Normalisierte Zahlungskategorie eines EC-Belegs."""
    EC_KARTE = "EC_KARTE"
    UNBEKANNT = "UNBEKANNT"
    MANUELL_PRUEFEN = "MANUELL_PRUEFEN"


class EcBelegStatus(StrEnum):
    """Lebenszyklusstatus eines EC-Belegs."""
    VERFUEGBAR = "VERFUEGBAR"
    FINAL_ZUGEORDNET = "FINAL_ZUGEORDNET"


class EcBelegRolle(StrEnum):
    """Rolle eines Belegs innerhalb einer EC-Sammelzuordnung."""
    AKTIV = "AKTIV"
    ENTFERNT_VERSCHOBEN = "ENTFERNT_VERSCHOBEN"


class EcSammelStatus(StrEnum):
    """Status einer EC-Sammelzuordnung."""
    STARK = "STARK"
    UNSICHER = "UNSICHER"
    MANUELL_BESTAETIGT = "MANUELL_BESTAETIGT"
    MANUELL_ABGELEHNT = "MANUELL_ABGELEHNT"
    OFFENE_PERIODE = "OFFENE_PERIODE"


@dataclass(frozen=True)
class EcSignal:
    """Erklaersignal fuer eine EC-Sammelzuordnung."""
    typ: str
    beschreibung: str
    punkte: int

    def als_dict(self) -> dict:
        return {"typ": self.typ, "beschreibung": self.beschreibung, "punkte": self.punkte}


@dataclass(frozen=True)
class EcBeleg:
    """Einzelner EC-Kartenbeleg aus dem Kassensystem.

    betrag_cent muss > 0 sein (EC-Einnahme, nicht Ausgabe).
    """
    id: UUID
    betrag_cent: int
    buchungsdatum: date

    def __post_init__(self) -> None:
        if not isinstance(self.betrag_cent, int):
            raise TypeError(f"betrag_cent muss int sein, nicht {type(self.betrag_cent).__name__}")
        if self.betrag_cent <= 0:
            raise ValueError(f"betrag_cent muss > 0 sein, erhalten: {self.betrag_cent}")


@dataclass
class EcGruppierungsErgebnis:
    """Ergebnis der deterministischen EC-Beleggruppierung."""
    aktive_belege: list[EcBeleg]
    entfernte_belege: list[EcBeleg]
    summe_cent: int
    differenz_cent: int
    positive_signale: list[EcSignal]
    negative_signale: list[EcSignal]
    score: int
    status: EcSammelStatus
