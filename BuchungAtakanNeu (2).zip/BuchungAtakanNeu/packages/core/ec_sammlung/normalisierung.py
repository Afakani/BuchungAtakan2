"""Zahlungskategorie-Normalisierung fuer EC-Belege (Phase 06, Paket 1).

Sichere Normalisierung (immer EC_KARTE):
  CardPayment, EC_Karte, EC-Karte, ec karte, orthografische Varianten.

Nicht automatisch als EC_KARTE anerkannt:
  Debit, Maestro, Visa Debit, allgemeine Kartenbegriffe.
  Diese werden als UNBEKANNT klassifiziert, sofern sie nicht in der
  optionalen Synonymliste konfiguriert sind.
"""
import re

from packages.core.ec_sammlung.typen import ZahlungsKategorie


def _normalisiere(rohwert: str) -> str:
    """Lowercase, Whitespace und Sonderzeichen kollabieren."""
    s = rohwert.lower().strip()
    s = re.sub(r"[\s_\-]+", " ", s)
    return s


# Orthografisch sichere EC-KARTE-Varianten (nach Normalisierung).
# Nur exakte Schreibungsvarianten von "EC-Karte" und "CardPayment".
_SICHERE_EC_KARTE: frozenset[str] = frozenset({
    "cardpayment",
    "card payment",
    "eckarte",
    "ec karte",
})


def normalisiere_zahlungskategorie(
    rohwert: str | None,
    synonyme: frozenset[str] | None = None,
) -> ZahlungsKategorie:
    """Normalisiert einen Rohkategorie-Wert zu einer ZahlungsKategorie.

    Parameters
    ----------
    rohwert:
        Roher String aus der Quelldatei (z. B. "CardPayment", "EC-Karte").
    synonyme:
        Optionale, explizit gepflegte Synonymliste (nach Normalisierung).
        Werte darin werden als EC_KARTE anerkannt.
        Standardmaessig leer — keine stillen Erweiterungen.

    Returns
    -------
    ZahlungsKategorie.EC_KARTE     bei sicherer Erkennung
    ZahlungsKategorie.UNBEKANNT    bei unbekanntem oder zu allgemeinem Begriff
    """
    if not rohwert or not rohwert.strip():
        return ZahlungsKategorie.UNBEKANNT

    normiert = _normalisiere(rohwert)

    if normiert in _SICHERE_EC_KARTE:
        return ZahlungsKategorie.EC_KARTE

    if synonyme and normiert in synonyme:
        return ZahlungsKategorie.EC_KARTE

    return ZahlungsKategorie.UNBEKANNT
