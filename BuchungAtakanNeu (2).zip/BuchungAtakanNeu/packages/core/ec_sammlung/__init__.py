"""EC-Sammelzuordnung Core — Phase 06, Paket 1."""
from packages.core.ec_sammlung.typen import (
    EcBeleg,
    EcBelegRolle,
    EcBelegStatus,
    EcGruppierungsErgebnis,
    EcSammelStatus,
    EcSignal,
    ZahlungsKategorie,
)
from packages.core.ec_sammlung.normalisierung import normalisiere_zahlungskategorie
from packages.core.ec_sammlung.gruppierung import gruppiere_belege
from packages.core.ec_sammlung.scorer import berechne_ec_score, EC_SCHWELLE_STARK, EC_SCHWELLE_UNSICHER

__all__ = [
    "EcBeleg",
    "EcBelegRolle",
    "EcBelegStatus",
    "EcGruppierungsErgebnis",
    "EcSammelStatus",
    "EcSignal",
    "ZahlungsKategorie",
    "normalisiere_zahlungskategorie",
    "gruppiere_belege",
    "berechne_ec_score",
    "EC_SCHWELLE_STARK",
    "EC_SCHWELLE_UNSICHER",
]
