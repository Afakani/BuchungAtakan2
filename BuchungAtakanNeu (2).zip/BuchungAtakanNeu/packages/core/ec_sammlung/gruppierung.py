"""Deterministische EC-Beleggruppierung (Phase 06, Paket 1).

Fachregel (keine kombinatorische Suche):
  1. Belege chronologisch sortieren (aelteste zuerst; bei gleichem Buchungsdatum
     zaehlt der kleinere Betrag als "aelter" — er bleibt eher stehen, da er
     naeher an der Zieleinzahlung liegt).
  2. Summe bilden.
  3. Bei Ueberdeckung (summe > einzahlung_cent): neuesten Beleg entfernen.
  4. Summe erneut pruefen.
  5. Wiederholen bis summe <= einzahlung_cent.
  6. Entfernte Belege als ENTFERNT_VERSCHOBEN protokollieren.
  7. Entfernte Belege bleiben fuer naechste Sammelgruppe verfuegbar.

Offene Periode:
  Wenn offene_periode=True: keine Belege entfernen, kein finaler Status,
  Kandidaten vollstaendig erhalten, Status = OFFENE_PERIODE.
"""
from datetime import date

from packages.core.ec_sammlung.scorer import berechne_ec_score, bestimme_status
from packages.core.ec_sammlung.typen import (
    EcBeleg,
    EcGruppierungsErgebnis,
    EcSammelStatus,
    EcSignal,
)

_OFFENE_PERIODE_SIGNAL = EcSignal(
    "OFFENE_PERIODE",
    "Kein Folgeeinzahlungsdatum — Belege bleiben verfuegbar",
    0,
)


def gruppiere_belege(
    einzahlung_cent: int,
    belege: list[EcBeleg],
    einzahlungsdatum: date,
    max_verzoegerung_tage: int = 2,
    offene_periode: bool = False,
) -> EcGruppierungsErgebnis:
    """Gruppiert EC-Belege deterministisch einer Sammeleinzahlung zu.

    Parameters
    ----------
    einzahlung_cent:
        Betrag der Sammeleinzahlung in Cent (positiv).
    belege:
        Verfuegbare EC-Belege (alle betrag_cent > 0).
    einzahlungsdatum:
        Datum der Sammeleinzahlung (Anker fuer Verzoegerungsberechnung).
    max_verzoegerung_tage:
        Maximale Differenz in Tagen zwischen Belegdatum und Einzahlungsdatum
        fuer STARK-Klassifikation.
    offene_periode:
        True wenn kein naechster Einzahlungstermin existiert.
        In diesem Fall: kein Entfernen, kein STARK/UNSICHER, Status = OFFENE_PERIODE.

    Returns
    -------
    EcGruppierungsErgebnis mit aktiven und entfernten Belegen, Score und Status.
    """
    # Stabile chronologische Sortierung (aelteste zuerst). Bei gleichem
    # Buchungsdatum entscheidet der Betrag (kleiner = "aelter" = bleibt eher
    # stehen), erst danach die UUID als letzter, betragsneutraler Tie-Breaker.
    # Ohne den Betrag als Zwischenkriterium waere bei Betragsgleichstand-freien
    # Ties die Entfernungsreihenfolge vom Zufall der UUID-Generierung abhaengig
    # und koennte den exakt passenden Beleg statt des zu grossen entfernen.
    sortiert: list[EcBeleg] = sorted(belege, key=lambda b: (b.buchungsdatum, b.betrag_cent, b.id))

    # Offene Periode: alle Kandidaten erhalten, kein finaler Status
    if offene_periode:
        summe = sum(b.betrag_cent for b in sortiert)
        return EcGruppierungsErgebnis(
            aktive_belege=list(sortiert),
            entfernte_belege=[],
            summe_cent=summe,
            differenz_cent=einzahlung_cent - summe,
            positive_signale=[],
            negative_signale=[_OFFENE_PERIODE_SIGNAL],
            score=0,
            status=EcSammelStatus.OFFENE_PERIODE,
        )

    # Fachregel: Ueberdeckung durch Entfernen des neuesten Belegs abbauen
    aktiv: list[EcBeleg] = list(sortiert)
    entfernt: list[EcBeleg] = []

    while aktiv and sum(b.betrag_cent for b in aktiv) > einzahlung_cent:
        neuester = aktiv.pop()  # neuester (letzte Position nach chronologischer Sortierung)
        entfernt.append(neuester)

    # Entfernte Belege in umgekehrter Reihenfolge ablegen (chronologisch aelteste zuerst)
    entfernt_chronologisch = list(reversed(entfernt))

    summe = sum(b.betrag_cent for b in aktiv)
    differenz = einzahlung_cent - summe

    # Zeitfenster-Prüfung
    zeitfenster_ueberschritten = any(
        (einzahlungsdatum - b.buchungsdatum).days > max_verzoegerung_tage
        for b in aktiv
    )

    score, pos, neg = berechne_ec_score(
        differenz_cent=differenz,
        entfernte_belege_cnt=len(entfernt),
        zeitfenster_ueberschritten=zeitfenster_ueberschritten,
        aktive_belege_cnt=len(aktiv),
    )

    status = bestimme_status(
        score=score,
        differenz_cent=differenz,
        entfernte_belege_cnt=len(entfernt),
        zeitfenster_ueberschritten=zeitfenster_ueberschritten,
        aktive_belege_cnt=len(aktiv),
    )

    return EcGruppierungsErgebnis(
        aktive_belege=aktiv,
        entfernte_belege=entfernt_chronologisch,
        summe_cent=summe,
        differenz_cent=differenz,
        positive_signale=pos,
        negative_signale=neg,
        score=score,
        status=status,
    )
