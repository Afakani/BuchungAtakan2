"""Scoring-Engine fuer EC-Sammelzuordnungen (Phase 06, Paket 1).

Score-Gewichte:
  SUMME_EXAKT          +50  differenz_cent == 0
  KEINE_ENTFERNTEN     +25  keine Belege entfernt
  ZEITFENSTER_OK       +20  alle Belege im Verzoegerungsfenster
  MINDESTENS_EIN_BELEG  +5  mindestens ein aktiver Beleg

  ENTFERNTE_BELEGE     -20  Belege wegen Ueberdeckung entfernt
  ZEITFENSTER_UEBER    -15  mindestens ein Beleg ausserhalb Fenster
  UNTERDECKUNG         -10  differenz_cent > 100 (mehr als 1 EUR Unterdeckung)

Maximum-Score: 100 (alle positiven Bedingungen erfuellt)
STARK-Schwelle: 90 (nur erreichbar wenn alle 4 positiven Signale aktiv)
UNSICHER-Schwelle: 40

STARK-Bedingungen (alle muessen erfuellt sein):
  1. score >= EC_SCHWELLE_STARK
  2. differenz_cent == 0
  3. len(entfernte_belege) == 0
  4. max_verzoegerung nicht ueberschritten
  5. mindestens ein aktiver Beleg
"""
from packages.core.ec_sammlung.typen import EcSammelStatus, EcSignal

EC_SCHWELLE_STARK = 90
EC_SCHWELLE_UNSICHER = 40

MATCHER_VERSION = "1.0"


def berechne_ec_score(
    differenz_cent: int,
    entfernte_belege_cnt: int,
    zeitfenster_ueberschritten: bool,
    aktive_belege_cnt: int,
) -> tuple[int, list[EcSignal], list[EcSignal]]:
    """Berechnet Score und Signale fuer eine EC-Sammelgruppe.

    Parameters
    ----------
    differenz_cent:
        einzahlung_cent - summe_cent. Muss >= 0 (nach Ueberdeckungsbereinigung).
    entfernte_belege_cnt:
        Anzahl wegen Ueberdeckung entfernter Belege.
    zeitfenster_ueberschritten:
        True wenn mindestens ein Beleg ausserhalb max_verzoegerung_tage.
    aktive_belege_cnt:
        Anzahl Belege in der aktiven Gruppe.

    Returns
    -------
    (score, positive_signale, negative_signale)
    """
    pos: list[EcSignal] = []
    neg: list[EcSignal] = []

    # Positiv: exakte Summe
    if differenz_cent == 0:
        pos.append(EcSignal("SUMME_EXAKT", "Belegsumme trifft Einzahlung exakt", 50))
    elif differenz_cent <= 100:
        pos.append(EcSignal("SUMME_NAH", f"Unterdeckung <= 1 EUR ({differenz_cent} Cent)", 10))

    # Positiv: keine entfernten Belege
    if entfernte_belege_cnt == 0:
        pos.append(EcSignal("KEINE_ENTFERNTEN", "Keine Belege wegen Ueberdeckung entfernt", 25))
    else:
        neg.append(EcSignal(
            "ENTFERNTE_BELEGE",
            f"{entfernte_belege_cnt} Beleg(e) wegen Ueberdeckung verschoben",
            -20,
        ))

    # Positiv: Zeitfenster eingehalten
    if not zeitfenster_ueberschritten:
        pos.append(EcSignal("ZEITFENSTER_OK", "Alle Belege im Verzoegerungsfenster", 20))
    else:
        neg.append(EcSignal(
            "ZEITFENSTER_UEBER",
            "Mindestens ein Beleg ausserhalb max. Verzoegerung",
            -15,
        ))

    # Positiv: mindestens ein aktiver Beleg
    if aktive_belege_cnt > 0:
        pos.append(EcSignal("MINDESTENS_EIN_BELEG", f"{aktive_belege_cnt} aktiver Beleg(e)", 5))
    else:
        neg.append(EcSignal("KEINE_BELEGE", "Keine aktiven Belege in Gruppe", -99))

    # Negativ: Unterdeckung > 1 EUR
    if differenz_cent > 100:
        neg.append(EcSignal(
            "UNTERDECKUNG",
            f"Unterdeckung {differenz_cent} Cent (> 1 EUR)",
            -10,
        ))

    score = sum(s.punkte for s in pos) + sum(s.punkte for s in neg)

    return score, pos, neg


def bestimme_status(
    score: int,
    differenz_cent: int,
    entfernte_belege_cnt: int,
    zeitfenster_ueberschritten: bool,
    aktive_belege_cnt: int,
) -> EcSammelStatus:
    """Bestimmt Status aus Score und STARK-Bedingungen."""
    stark_bedingungen = (
        score >= EC_SCHWELLE_STARK
        and differenz_cent == 0
        and entfernte_belege_cnt == 0
        and not zeitfenster_ueberschritten
        and aktive_belege_cnt > 0
    )
    if stark_bedingungen:
        return EcSammelStatus.STARK
    if score >= EC_SCHWELLE_UNSICHER:
        return EcSammelStatus.UNSICHER
    return EcSammelStatus.UNSICHER  # kein Vorschlag unter Schwelle → Caller entscheidet
