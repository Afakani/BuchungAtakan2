from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path, PureWindowsPath
from typing import Any, Mapping


DATA_ROOT_ENV_VAR = "BUCHUNG_ATAKAN_DATA_ROOT"
CONFIG_FILE_ENV_VAR = "BUCHUNG_ATAKAN_CONFIG_FILE"

DEFAULT_CONFIG_FILE = Path.home() / ".buchungatakan" / "buchungatakan_config.json"
DEFAULT_DATA_ROOT = Path.home() / ".buchungatakan" / "data"

DATA_ROOT_SOURCE_EXPLICIT = "EXPLICIT"
DATA_ROOT_SOURCE_ENV = "ENV"
DATA_ROOT_SOURCE_CONFIG_FILE = "CONFIG_FILE"
DATA_ROOT_SOURCE_FALLBACK = "FALLBACK"


@dataclass(frozen=True)
class PathConfig:
    data_root: Path

    def __post_init__(self) -> None:
        object.__setattr__(self, "data_root", Path(self.data_root).expanduser())

    @property
    def dump_dir(self) -> Path:
        return self.data_root / "dump"

    @property
    def config_dir(self) -> Path:
        return self.data_root / "config"

    @property
    def logs_dir(self) -> Path:
        return self.data_root / "logs"

    @property
    def outbox_db_path(self) -> Path:
        return self.data_root / "outbox.db"

    def required_directories(self) -> list[Path]:
        return [
            self.data_root,
            self.dump_dir,
            self.config_dir,
            self.logs_dir,
        ]

    def ensure_required_directories(self) -> None:
        for directory in self.required_directories():
            directory.mkdir(parents=True, exist_ok=True)

    def to_data_relative(self, path: str | Path | None) -> Path | None:
        if path is None:
            return None
        resolved = Path(path)
        if str(resolved).strip() == "":
            return None
        if not _is_absolute_path_value(resolved):
            return resolved
        try:
            return resolved.relative_to(self.data_root)
        except ValueError:
            return resolved

    def resolve_document_path(self, path: str | Path | None) -> Path | None:
        if path is None:
            return None
        candidate = Path(path)
        if str(candidate).strip() == "":
            return None
        if _is_absolute_path_value(candidate):
            return candidate
        return self.data_root / candidate


class DataRootSecurityError(RuntimeError):
    """Ausgeloest wenn produktiver Ablauf den konfigurierten Fallback-DATA_ROOT nutzen wuerde."""


def load_path_config(
    *,
    explicit_data_root: str | Path | None = None,
    config_file: str | Path | None = None,
    env: Mapping[str, str] | None = None,
) -> PathConfig:
    environment = os.environ if env is None else env
    selected_config_file = _select_config_file(config_file, environment)
    file_values = _read_config_file(selected_config_file)

    data_root = (
        explicit_data_root
        or environment.get(DATA_ROOT_ENV_VAR)
        or file_values.get("data_root")
        or DEFAULT_DATA_ROOT
    )
    return PathConfig(data_root=_path_from_config_value(data_root, selected_config_file))


def resolve_data_root_source(
    *,
    explicit_data_root: str | Path | None = None,
    config_file: str | Path | None = None,
    env: Mapping[str, str] | None = None,
) -> str:
    environment = os.environ if env is None else env
    if explicit_data_root:
        return DATA_ROOT_SOURCE_EXPLICIT
    if environment.get(DATA_ROOT_ENV_VAR):
        return DATA_ROOT_SOURCE_ENV
    selected_config_file = _select_config_file(config_file, environment)
    file_values = _read_config_file(selected_config_file)
    if file_values.get("data_root"):
        return DATA_ROOT_SOURCE_CONFIG_FILE
    return DATA_ROOT_SOURCE_FALLBACK


def load_path_config_with_source(
    *,
    explicit_data_root: str | Path | None = None,
    config_file: str | Path | None = None,
    env: Mapping[str, str] | None = None,
) -> tuple[PathConfig, str]:
    config = load_path_config(
        explicit_data_root=explicit_data_root,
        config_file=config_file,
        env=env,
    )
    source = resolve_data_root_source(
        explicit_data_root=explicit_data_root,
        config_file=config_file,
        env=env,
    )
    return config, source


def guard_data_root(
    path_config: PathConfig,
    source: str,
    *,
    purpose: str,
    allow_dev_fallback: bool = False,
    stream: Any = print,
) -> PathConfig:
    stream(f"[{purpose}] Datenwurzel: {path_config.data_root}")
    stream(f"[{purpose}] Quelle:      {source}")
    if source == DATA_ROOT_SOURCE_FALLBACK and not allow_dev_fallback:
        raise DataRootSecurityError(
            f"[{purpose}] ABBRUCH: Keine Datenwurzel konfiguriert. "
            f"Setze {DATA_ROOT_ENV_VAR} oder 'data_root' in der Konfigurationsdatei."
        )
    return path_config


def _select_config_file(config_file: str | Path | None, env: Mapping[str, str]) -> Path:
    if config_file:
        return Path(config_file).expanduser()
    env_config_file = env.get(CONFIG_FILE_ENV_VAR)
    if env_config_file:
        return Path(env_config_file).expanduser()
    return DEFAULT_CONFIG_FILE


def _read_config_file(config_file: Path) -> dict[str, Any]:
    if not config_file.exists():
        return {}
    with config_file.open("r", encoding="utf-8") as handle:
        data = json.load(handle)
    if not isinstance(data, dict):
        raise ValueError(f"Konfigurationsdatei muss ein JSON-Objekt sein: {config_file}")
    return data


def _path_from_config_value(value: str | Path, config_file: Path) -> Path:
    path = Path(value).expanduser()
    if _is_absolute_path_value(path):
        return path
    return config_file.parent / path


def _is_absolute_path_value(path: str | Path) -> bool:
    value = str(path)
    return Path(value).is_absolute() or PureWindowsPath(value).is_absolute()
