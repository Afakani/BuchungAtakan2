import mimetypes
from pathlib import Path

_MAGIC: list[tuple[bytes, str]] = [
    (b"%PDF", "application/pdf"),
    (b"\x89PNG\r\n\x1a\n", "image/png"),
    (b"\xff\xd8\xff", "image/jpeg"),
    (b"PK\x03\x04", "application/zip"),
]

_HEADER_READ = 8


def detect_mime_type(path: Path) -> str:
    try:
        with path.open("rb") as f:
            header = f.read(_HEADER_READ)
        for magic, mime in _MAGIC:
            if header.startswith(magic):
                return mime
    except OSError:
        pass

    mime, _ = mimetypes.guess_type(str(path))
    return mime or "application/octet-stream"
