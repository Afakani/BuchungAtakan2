"""MT940-Parser fuer Volksbank-Kontoauszuege (SWIFT MT940).

Unterstuetzte Tags: :20: :25: :28C?: :60F: :60M: :61: :86: :62F: :62M:
Encoding-Strategie: UTF-8 zuerst, dann CP1252 (Windows-1252), nie stil verlieren.

Stabile Quellposition: 1-basierter Zaehler der :61:-Tags in Dateireihenfolge.
Quellfingerprint: SHA-256 der rohen Bytes (kein Dateipfad, nicht veraenderlich).
"""
import hashlib
import re
from dataclasses import dataclass
from datetime import date, datetime

from packages.core.bank_import.cent_konvertierung import parse_betrag_cent


# ── Fehlertypen ───────────────────────────────────────────────────────────────

class MT940FormatFehler(Exception):
    """Unbekanntes oder strukturell ungueltiges MT940-Format."""


class MT940BetragFehler(Exception):
    """Betrag in :61: nicht parsierbar."""


class MT940DatumFehler(Exception):
    """Datum in :61: nicht parsierbar."""


# ── Ausgabemodell ─────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class MT940Buchung:
    buchungsdatum: date
    wertstellungsdatum: date | None
    betrag_cent: int          # negativ = Lastschrift/Debit
    waehrung: str             # 3-stelliger ISO-Code
    buchungstext: str | None  # :86: ?00 — Transaktionstyp-Text der Bank
    verwendungszweck: str | None
    gegenpartei_name: str | None
    gegenpartei_iban: str | None  # roh, unmaskiert — Maskierung im Router
    gegenpartei_bic: str | None
    externe_referenz: str | None  # EREF oder KREF aus :86: ?20-?29
    quell_position: int           # 1-basiert, stabil, reproduzierbar
    swift_code: str | None        # z.B. NTRF, NDDT, NMSC


@dataclass
class MT940Fehler:
    quell_position: int
    meldung: str


@dataclass
class MT940Ergebnis:
    buchungen: list[MT940Buchung]
    fehler: list[MT940Fehler]
    quell_fingerprint: str     # SHA-256 hex der rohen Bytes
    datei_referenz: str | None # :20: Wert
    waehrung: str | None       # aus :60F:/:60M:


# ── Interne Regex ─────────────────────────────────────────────────────────────

_TAG_RE = re.compile(r'^:(\d{2}[A-Z0-9]?):(.*)$')
# D/C-Marker: D, C, DR, CR, RD, RC (Standard und Volksbank-Variante)
_DC_RE = re.compile(r'^([RC]?[DC][R]?)')
_BETRAG_RE = re.compile(r'^([\d,]+)')
_DATUM_YYMMDD = re.compile(r'^\d{6}$')
_MAX_BYTES = 10 * 1024 * 1024  # 10 MB


# ── Hilfsfunktionen ───────────────────────────────────────────────────────────

def _dekodiere(rohbytes: bytes) -> str:
    """UTF-8 zuerst, dann CP1252 — verlustfrei oder mit ersetzung."""
    try:
        return rohbytes.decode("utf-8")
    except UnicodeDecodeError:
        return rohbytes.decode("cp1252", errors="replace")


def _parse_datum(s: str, referenzjahr: int | None = None) -> date:
    """YYMMDD → date. Wirft ValueError bei ungueltigen Werten."""
    if not re.fullmatch(r'\d{6}', s):
        raise ValueError(f"Kein gueltiges Datum: '{s}'")
    try:
        return datetime.strptime(s, "%y%m%d").date()
    except ValueError as exc:
        raise ValueError(f"Datum nicht parsierbar: '{s}'") from exc


def _parse_datum_mmdd(s: str, referenzjahr: int) -> date | None:
    """MMDD → date mit gegebenem Jahr. Gibt None bei Fehler."""
    if not re.fullmatch(r'\d{4}', s):
        return None
    try:
        return datetime.strptime(f"{referenzjahr}{s}", "%Y%m%d").date()
    except ValueError:
        return None


def _betrag_vorzeichen(dc: str, betrag_cent: int) -> int:
    """Wendet D/C-Marker auf positiven Centwert an."""
    dc_u = dc.upper()
    if dc_u in ("D", "DR"):    # Debit — Ausgabe → negativ
        return -abs(betrag_cent)
    if dc_u in ("RD",):        # Reversal of Debit → positiv (Gutschrift)
        return abs(betrag_cent)
    if dc_u in ("C", "CR"):    # Credit — Eingang → positiv
        return abs(betrag_cent)
    if dc_u in ("RC",):        # Reversal of Credit → negativ (Ruecklastschrift)
        return -abs(betrag_cent)
    # Fallback: unveraendert
    return betrag_cent


def _fingerprint(rohbytes: bytes) -> str:
    """SHA-256-Fingerprint der rohen Bytes (kein Pfad, deterministisch)."""
    return hashlib.sha256(rohbytes).hexdigest()


# ── Tag-Kollektor ─────────────────────────────────────────────────────────────

def _sammle_tags(zeilen: list[str]) -> list[tuple[str, str]]:
    """Konvertiert MT940-Zeilen in (Tag, Inhalt)-Paare.

    Mehrzeilige Felder (z.B. :86:) werden zusammengefuehrt.
    '-' (Statement-Ende) wird als eigenes Pseudo-Tag ausgegeben.
    """
    ergebnis: list[tuple[str, str]] = []
    aktueller_tag: str | None = None
    aktueller_inhalt: list[str] = []

    def _ablegen() -> None:
        if aktueller_tag is not None:
            ergebnis.append((aktueller_tag, "".join(aktueller_inhalt)))

    for zeile in zeilen:
        m = _TAG_RE.match(zeile)
        if m:
            _ablegen()
            aktueller_tag = m.group(1)
            aktueller_inhalt = [m.group(2)]
        elif zeile.strip() == "-":
            _ablegen()
            aktueller_tag = None
            aktueller_inhalt = []
            ergebnis.append(("-", ""))
        elif aktueller_tag is not None:
            # Fortsetzungszeile — direkt anhaengen (kein Trennzeichen)
            aktueller_inhalt.append(zeile)

    _ablegen()
    return ergebnis


# ── :61:-Parser ───────────────────────────────────────────────────────────────

def _parse_61(wert: str) -> tuple[date, date | None, str, str, str, str | None]:
    """Parst :61:-Inhalt.

    Gibt zurueck: (wertstellungsdatum, buchungsdatum, dc_marker, betrag_str, swift_code, referenz)
    Wirft MT940DatumFehler oder MT940BetragFehler bei Fehler.
    """
    pos = 0

    # 1. Wertstellungsdatum YYMMDD (6 Stellen)
    if len(wert) < 6:
        raise MT940DatumFehler(f"':61:' zu kurz fuer Datum: '{wert}'")
    try:
        wertdat = _parse_datum(wert[pos:pos + 6])
    except ValueError as exc:
        raise MT940DatumFehler(str(exc)) from exc
    pos += 6

    # 2. Optionales Buchungsdatum MMDD (4 Stellen, nur wenn naechstes Zeichen Ziffer)
    buchdat: date | None = None
    if pos < len(wert) and wert[pos].isdigit():
        kandidat = wert[pos:pos + 4]
        if re.fullmatch(r'\d{4}', kandidat):
            versuch = _parse_datum_mmdd(kandidat, wertdat.year)
            if versuch is not None:
                buchdat = versuch
                pos += 4

    # 3. D/C-Marker
    dc_m = _DC_RE.match(wert[pos:])
    if not dc_m:
        raise MT940BetragFehler(f"Kein D/C-Marker in ':61:': '{wert}'")
    dc = dc_m.group(1)
    pos += len(dc)

    # 4. Optionaler Waehrungscode (1 Buchstabe — 3. Zeichen des Waehrungscodes)
    if pos < len(wert) and wert[pos].isalpha():
        pos += 1

    # 5. Betrag (Ziffern und Komma)
    betrag_m = _BETRAG_RE.match(wert[pos:])
    if not betrag_m:
        raise MT940BetragFehler(f"Kein Betrag in ':61:': '{wert}'")
    betrag_str = betrag_m.group(1)
    pos += len(betrag_str)

    # 6. SWIFT-Transaktionscode (4 Zeichen)
    swift = wert[pos:pos + 4].strip() if len(wert) > pos else ""
    pos += 4

    # 7. Rest = Referenz (optional)
    referenz = wert[pos:].strip() or None

    return wertdat, buchdat, dc, betrag_str, swift, referenz


# ── :86:-Unterfelder ─────────────────────────────────────────────────────────

def _parse_86_subfelder(wert: str) -> dict[str, str]:
    """?NN-Unterfelder aus mehrzeiligem :86:-Inhalt extrahieren."""
    # Zeilenumbrueche entfernen — Fortsetzungszeilen beginnen oft mit ?NN
    text = "".join(wert.splitlines())
    subfelder: dict[str, str] = {}
    teile = re.split(r'\?(\d{2})', text)
    i = 1
    while i + 1 < len(teile):
        subfelder[teile[i]] = teile[i + 1]
        i += 2
    return subfelder


def _verwendungszweck_aus_subfeldern(sf: dict[str, str]) -> str | None:
    """Extrahiert lesbaren Verwendungszweck aus ?20-?29."""
    teile = [sf[k] for k in sorted(sf) if "20" <= k <= "29"]
    if not teile:
        return None
    combined = "".join(teile).strip()
    # Bevorzuge SVWZ+-Wert (strukturierter Verwendungszweck)
    svwz_m = re.search(r'SVWZ\+([^?]+?)(?=\s*(?:EREF|KREF|MREF|CRED|DEBT|PURP|ORDP|ULTD)\+|$)',
                       combined, re.IGNORECASE)
    if svwz_m:
        return svwz_m.group(1).strip() or None
    return combined or None


def _externe_referenz_aus_subfeldern(sf: dict[str, str]) -> str | None:
    """EREF+ oder KREF+ aus ?20-?29 extrahieren."""
    teile = [sf[k] for k in sorted(sf) if "20" <= k <= "29"]
    combined = "".join(teile)
    for praefix in ("EREF+", "KREF+"):
        m = re.search(rf'{praefix}(\S{{1,35}})', combined, re.IGNORECASE)
        if m and m.group(1).upper() not in ("NONREF", "KREF+"):
            return m.group(1)
    return None


def _gegenpartei_name_aus_subfeldern(sf: dict[str, str]) -> str | None:
    """Gegenparteiname aus ?32 (+ optionalem ?33) zusammensetzen."""
    n1 = sf.get("32", "").strip()
    n2 = sf.get("33", "").strip()
    if n1 and n2:
        return f"{n1} {n2}"
    return n1 or n2 or None


# ── Hauptparser ───────────────────────────────────────────────────────────────

def parse_mt940(rohbytes: bytes) -> MT940Ergebnis:
    """Parst rohe MT940-Bytes und gibt strukturierte Buchungen zurueck.

    Args:
        rohbytes: Rohe Bytes der MT940-Datei (beliebiges Encoding).

    Returns:
        MT940Ergebnis mit Buchungen, Fehlern und Metadaten.

    Raises:
        MT940FormatFehler: Leere Datei oder kein MT940-Inhalt erkannt.
    """
    if not rohbytes:
        raise MT940FormatFehler("Leere Datei — kein MT940-Inhalt.")

    if len(rohbytes) > _MAX_BYTES:
        raise MT940FormatFehler(
            f"Datei zu gross ({len(rohbytes)} Bytes). Maximum: {_MAX_BYTES} Bytes."
        )

    fingerprint = _fingerprint(rohbytes)
    inhalt = _dekodiere(rohbytes)

    zeilen = inhalt.splitlines()
    tags = _sammle_tags(zeilen)

    # Schnellpruefung: mindestens ein bekannter MT940-Tag vorhanden?
    tag_namen = {t for t, _ in tags}
    if not tag_namen.intersection({"20", "25", "28C", "28", "60F", "60M", "61"}):
        raise MT940FormatFehler("Kein gueltiger MT940-Tag gefunden. Unbekanntes Format.")

    buchungen: list[MT940Buchung] = []
    fehler: list[MT940Fehler] = []

    datei_referenz: str | None = None
    waehrung: str | None = None

    quell_position = 0           # global, 1-basiert
    aktuelle_buchung_raw: dict | None = None  # zwischenzustand fuer :61:

    def _buchung_abschliessen() -> None:
        """Aktive Rohbuchung in MT940Buchung umwandeln und ablegen."""
        nonlocal aktuelle_buchung_raw
        if aktuelle_buchung_raw is None:
            return
        raw = aktuelle_buchung_raw
        aktuelle_buchung_raw = None
        pos = raw["quell_position"]
        try:
            betrag_cent = _betrag_vorzeichen(
                raw["dc"],
                parse_betrag_cent(raw["betrag_str"]),
            )
        except (ValueError, TypeError) as exc:
            fehler.append(MT940Fehler(pos, f"Betrag-Fehler: {exc}"))
            return

        buchungen.append(MT940Buchung(
            buchungsdatum=raw.get("buchdat") or raw["wertdat"],
            wertstellungsdatum=raw["wertdat"],
            betrag_cent=betrag_cent,
            waehrung=raw.get("waehrung") or waehrung or "EUR",
            buchungstext=raw.get("buchungstext"),
            verwendungszweck=raw.get("verwendungszweck"),
            gegenpartei_name=raw.get("gegenpartei_name"),
            gegenpartei_iban=raw.get("gegenpartei_iban"),
            gegenpartei_bic=raw.get("gegenpartei_bic"),
            externe_referenz=raw.get("externe_referenz"),
            quell_position=pos,
            swift_code=raw.get("swift_code"),
        ))

    for tag, wert in tags:

        if tag == "20":
            if datei_referenz is None:
                datei_referenz = wert.strip()

        elif tag in ("60F", "60M"):
            # Format: D/C + YYMMDD + Waehrung + Betrag
            m = re.match(r'[DC](\d{6})([A-Z]{3})', wert.strip())
            if m and waehrung is None:
                waehrung = m.group(2)

        elif tag == "61":
            # Vorherige Buchung abschliessen
            _buchung_abschliessen()

            quell_position += 1
            try:
                wertdat, buchdat, dc, betrag_str, swift, _ref = _parse_61(wert.strip())
            except (MT940DatumFehler, MT940BetragFehler) as exc:
                fehler.append(MT940Fehler(quell_position, str(exc)))
                aktuelle_buchung_raw = None
                continue

            aktuelle_buchung_raw = {
                "quell_position": quell_position,
                "wertdat": wertdat,
                "buchdat": buchdat,
                "dc": dc,
                "betrag_str": betrag_str,
                "swift_code": swift or None,
                "waehrung": waehrung,
            }

        elif tag == "86" and aktuelle_buchung_raw is not None:
            sf = _parse_86_subfelder(wert)
            aktuelle_buchung_raw["buchungstext"] = sf.get("00", "").strip() or None
            aktuelle_buchung_raw["verwendungszweck"] = _verwendungszweck_aus_subfeldern(sf)
            aktuelle_buchung_raw["externe_referenz"] = _externe_referenz_aus_subfeldern(sf)
            aktuelle_buchung_raw["gegenpartei_name"] = _gegenpartei_name_aus_subfeldern(sf)
            aktuelle_buchung_raw["gegenpartei_iban"] = sf.get("31", "").strip() or None
            aktuelle_buchung_raw["gegenpartei_bic"] = sf.get("30", "").strip() or None

        elif tag == "-":
            _buchung_abschliessen()

    # Letzte ggf. offene Buchung
    _buchung_abschliessen()

    return MT940Ergebnis(
        buchungen=buchungen,
        fehler=fehler,
        quell_fingerprint=fingerprint,
        datei_referenz=datei_referenz,
        waehrung=waehrung,
    )


def parse_mt940_datei(pfad: str) -> MT940Ergebnis:
    """Convenience-Wrapper: liest Datei und parst sie.

    Nur fuer kontrollierte lokale Verwendung — kein Pfad in den Fingerprint.
    """
    import pathlib
    rohbytes = pathlib.Path(pfad).read_bytes()
    return parse_mt940(rohbytes)
