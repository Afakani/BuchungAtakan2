"""Deduplizierungs-Fingerprint fuer Bankbuchungen (BANK-02/BANK-03).

Strategie:
  1. Externe Buchungs-ID vorhanden → sie fliesst primaer ein (stabile externe Referenz).
  2. Keine externe ID: quell_referenz + quell_position muessen stabil einfliesssen.
     Fehlt quell_position, muss der Aufrufer eine ValidationError ausloesen (keine
     stille Deduplizierung potentiell identischer echter Buchungen).

Zwei Buchungen mit gleichem Betrag+Datum+Zweck+Gegenpartei, aber unterschiedlicher
quell_position, erhalten UNTERSCHIEDLICHE Fingerprints → werden beide gespeichert.

Re-Import derselben Quelle (gleiche quell_referenz, gleiche quell_position) →
GLEICHER Fingerprint → ON CONFLICT DO NOTHING → idempotent.

Der Fingerprint codiert unternehmen_id und bankkonto_id mit ein, damit er
global eindeutig ist und der DB-UNIQUE-Constraint rein auf dedup_fingerprint gesetzt
werden kann.
"""
import hashlib
from uuid import UUID

from packages.core.bank_import.normalisierung import normalisiere_iban, normalisiere_text


def berechne_fingerprint(
    *,
    unternehmen_id: UUID,
    bankkonto_id: UUID,
    buchungsdatum: str,
    betrag_cent: int,
    waehrung: str,
    verwendungszweck: str | None = None,
    gegenpartei_name: str | None = None,
    gegenpartei_iban: str | None = None,
    wertstellungsdatum: str | None = None,
    externe_buchungs_id: str | None = None,
    quell_referenz: str | None = None,
    quell_position: int | None = None,
) -> str:
    """SHA-256-Fingerprint aus allen stabilen Buchungssignalen.

    quell_referenz: Import-Quellenkennung (z.B. Dateiname, IBAN+Zeitraum).
    quell_position: Stabile Transaktionsposition innerhalb der Quelle (0-basiert).
    Beide fliessen nur ein, wenn externe_buchungs_id fehlt.

    Returns:
        Hex-String (64 Zeichen).
    """
    teile = [
        f"unt:{unternehmen_id}",
        f"kto:{bankkonto_id}",
        f"dat:{buchungsdatum}",
        f"wst:{wertstellungsdatum or ''}",
        f"bet:{betrag_cent}",
        f"wae:{waehrung.upper()}",
        f"vzw:{normalisiere_text(verwendungszweck)}",
        f"gp:{normalisiere_text(gegenpartei_name)}",
        f"iban:{normalisiere_iban(gegenpartei_iban)}",
        f"ext:{normalisiere_text(externe_buchungs_id)}",
        f"qref:{normalisiere_text(quell_referenz)}",
        f"qpos:{quell_position if quell_position is not None else ''}",
    ]
    rohdaten = "|".join(teile)
    return hashlib.sha256(rohdaten.encode()).hexdigest()
