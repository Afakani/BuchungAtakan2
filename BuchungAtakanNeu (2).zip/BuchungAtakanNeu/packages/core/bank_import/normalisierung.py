"""Textnormalisierung fuer Deduplizierungs-Fingerprints."""
import re


def normalisiere_text(text: str | None) -> str:
    """Lowercase, collapse whitespace, strip. None → leer."""
    if not text:
        return ""
    return re.sub(r"\s+", " ", text.lower().strip())


def normalisiere_iban(iban: str | None) -> str:
    """IBAN normalisieren: Leerzeichen entfernen, uppercase."""
    if not iban:
        return ""
    return re.sub(r"\s+", "", iban.upper())


def maskiere_iban(iban: str | None) -> str | None:
    """Maskiert eine IBAN: Laenderpräfix + letzte 4 Zeichen sichtbar, Rest '*'.

    Bereits maskierte IBANs (enthalten '*') werden unveraendert zurueckgegeben.
    None bleibt None.

    Beispiel: DE89370400440532013000 → DE********************3000
    """
    if iban is None:
        return None
    clean = re.sub(r"\s+", "", iban).upper()
    if not clean:
        return None
    if "*" in clean:
        return clean
    if len(clean) < 8:
        return clean
    prefix = clean[:2]
    suffix = clean[-4:]
    return prefix + "*" * (len(clean) - 6) + suffix
