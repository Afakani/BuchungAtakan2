"""Klassifikationslogik fuer Bankbuchungen (BANK-11).

Klassen:
  MATCHBAR          — normale Geschaeftsbuchung, rechnungsbezogen matchbar
  NICHT_ZU_MATCHEN  — Gebuehren, Steuern, interne Bewegungen
  EC_EINZAHLUNG     — EC-/Kartensammelauszahlung
  MANUELL_PRUEFEN   — unklarer oder widersprüchlicher Fall

Logik ist deterministisch und pur (kein DB-Zugriff).
"""
import re
from enum import StrEnum

_EC_MUSTER = re.compile(
    r"(ec[- ]?karte|kartenzahlung|card\s*payment|debitkarte|maestro|girocard"
    r"|ec[- ]?einzahlung|kartenabrechnung|ec[- ]?abrechnung)",
    re.IGNORECASE,
)

_NICHT_MATCHBAR_MUSTER = re.compile(
    r"(geb[uü]hr|kontoführung|kontogebuehr|zinsen|habenzinsen|sollzinsen"
    r"|steuer|kapitalertragsteuer|solidarit[aä]tszuschlag"
    r"|dauerauftrag|lastschrift entgelt|bankentgelt"
    r"|interne[r ]?umbuchung|umbuchung intern|verrechnungskonto"
    r"|verwahrentgelt|negativzins)",
    re.IGNORECASE,
)


class BuchungsKlassifikation(StrEnum):
    MATCHBAR = "MATCHBAR"
    NICHT_ZU_MATCHEN = "NICHT_ZU_MATCHEN"
    EC_EINZAHLUNG = "EC_EINZAHLUNG"
    MANUELL_PRUEFEN = "MANUELL_PRUEFEN"


def klassifiziere_buchung(
    verwendungszweck: str | None,
    gegenpartei_name: str | None,
) -> BuchungsKlassifikation:
    """Klassifiziert eine Bankbuchung deterministisch.

    Reihenfolge der Pruefung:
    1. Widerspruch (beide Muster matchen) → MANUELL_PRUEFEN
    2. EC-Muster → EC_EINZAHLUNG
    3. Nicht-matchbar-Muster → NICHT_ZU_MATCHEN
    4. Sonst → MATCHBAR
    """
    felder = " ".join(filter(None, [verwendungszweck, gegenpartei_name]))

    ist_ec = bool(_EC_MUSTER.search(felder))
    ist_nicht_matchbar = bool(_NICHT_MATCHBAR_MUSTER.search(felder))

    if ist_ec and ist_nicht_matchbar:
        return BuchungsKlassifikation.MANUELL_PRUEFEN
    if ist_ec:
        return BuchungsKlassifikation.EC_EINZAHLUNG
    if ist_nicht_matchbar:
        return BuchungsKlassifikation.NICHT_ZU_MATCHEN
    return BuchungsKlassifikation.MATCHBAR
