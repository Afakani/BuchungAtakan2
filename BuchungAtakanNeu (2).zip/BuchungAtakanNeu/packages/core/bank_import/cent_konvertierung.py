"""Cent-Konvertierung fuer Bankbetraege (BANK-10).

Einzige gueltige Eingabeformate:
  - int   : bereits in Cent (unveraendert)
  - str   : Dezimalstring mit maximal 2 Nachkommastellen (Punkt oder Komma)

float wird abgelehnt: keine binaere Floating-Point-Arithmetik.
Mehr als 2 Nachkommastellen werden abgelehnt: keine stille Rundung.
"""
import re
from decimal import Decimal, InvalidOperation

_DEZIMAL_MUSTER = re.compile(r"^-?\d+(?:[.,]\d{1,2})?$")


def parse_betrag_cent(wert: int | str) -> int:
    """Konvertiert Betrag in Integer-Centwert.

    Args:
        wert: int (Centwert direkt) oder str (Dezimalstring, max. 2 Nachkommastellen).

    Returns:
        Betrag in Cent als int.

    Raises:
        TypeError:  float-Eingabe.
        ValueError: ungueltiges Format oder mehr als 2 Nachkommastellen.
    """
    if isinstance(wert, float):
        raise TypeError(
            "Float-Eingabe nicht erlaubt. Integer (Cent) oder Dezimalstring verwenden."
        )
    if isinstance(wert, bool):
        raise TypeError("Bool-Eingabe nicht erlaubt.")
    if isinstance(wert, int):
        return wert
    if isinstance(wert, str):
        wert = wert.strip()
        if not _DEZIMAL_MUSTER.match(wert):
            raise ValueError(
                f"Ungueltiger Betrag '{wert}'. "
                "Erlaubt: Integer-Cent (int) oder Dezimalstring mit max. 2 Nachkommastellen."
            )
        # Komma → Punkt fuer Decimal-Parsing
        normalized = wert.replace(",", ".")
        try:
            d = Decimal(normalized)
        except InvalidOperation:
            raise ValueError(f"Betrag '{wert}' konnte nicht geparst werden.")
        # Nachkommastellen explizit pruefen (Regex erlaubt max 2, Decimal-Exponent sichert)
        cent = d * 100
        if cent != cent.to_integral_value():
            raise ValueError(
                f"Betrag '{wert}' hat mehr als 2 Nachkommastellen."
            )
        return int(cent)
    raise TypeError(f"Ungueltiger Eingabetyp {type(wert).__name__}.")
