"""Invoice2DataProvider — lokaler Adapter fuer bekannte Anbieter-Templates (HYB-10).

Eingabepfad-Entscheidung (07-02): Der Provider nutzt den bereits durch pdfplumber
extrahierten Text (ueber die bestehende PDFReader-Klasse) statt invoice2data's eigenem
PDF-Inputreader (pdftotext/pdfminer). Grund: invoice2data's Standardreader haengt an der
Systemabhaengigkeit `pdftotext` (poppler-utils); die Wiederverwendung des bereits
getesteten pdfplumber-Pfads haelt einen einzigen lokalen Text-Extraktionspfad und
vermeidet eine zusaetzliche Systemabhaengigkeit.

invoice2data ist optional: fehlt das Paket, liefert der Provider einen kontrollierten
"skipped"-Status statt zu crashen (keine Installation wird erzwungen).

Templates ersetzen nie den eigenen InvoiceParser/Validator -- sie liefern lediglich
zusaetzliche Kandidaten im selben Format wie PdfplumberProvider. Eine finale fachliche
Auswahl zwischen konkurrierenden Kandidaten trifft dieser Provider nicht (07-03).
"""
from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Any

from packages.core.invoice_extraction.hybrid_kandidat import HybridKandidat
from packages.core.invoice_extraction.pdf_reader import PDFReader
from packages.core.invoice_extraction.provider_ports import InvoiceProviderResult

_NAME = "invoice2data"
_VERSION = "1.0"

_TEMPLATES_DIR = Path(__file__).resolve().parents[3] / "config" / "invoice2data_templates"

# invoice2data-eigenes Logging stummschalten -- verhindert, dass dessen interne
# Logger (z. B. bei fehlendem Template-Match) Pfade oder Textinhalte ausgeben.
logging.getLogger("invoice2data").setLevel(logging.CRITICAL)

# Platzhalter statt echtem Dateipfad: invoice2data verwendet den uebergebenen Pfad
# nur als Cache-Key/Logmarker, nie fuer den eigentlichen Text (siehe
# _PreExtractedTextInput). Damit gelangt nie ein echter Dateiname in
# invoice2data-interne Logs oder Caches.
_PLATZHALTER_PFAD = "invoice2data_input.pdf"

_READER = PDFReader()

_FELD_REIHENFOLGE = (
    "vendor_name",
    "invoice_number",
    "invoice_date",
    "total_amount",
    "net_amount",
    "tax_amount",
    "currency",
    "payment_method",
)
_GELD_FELDER = frozenset({"total_amount", "net_amount", "tax_amount"})

_templates_cache: list[Any] | None = None


def ist_aktiviert(settings: Any) -> bool:
    return bool(getattr(settings, "BUCHUNG_ATAKAN_FEATURE_INVOICE2DATA", False))


class _PreExtractedTextInput:
    """input_module-kompatibles Objekt: liefert bereits extrahierten Text statt
    invoice2data's eigenen PDF-Inputreader (pdftotext/pdfminer) auszufuehren.
    """

    __name__ = "pre_extracted_text"

    def __init__(self, text: str) -> None:
        self._text = text

    def to_text(self, path: str) -> str:
        return self._text


def _load_templates() -> list[Any]:
    global _templates_cache
    if _templates_cache is None:
        from invoice2data.extract.loader import read_templates
        _templates_cache = read_templates(str(_TEMPLATES_DIR))
    return _templates_cache


class Invoice2DataProvider:
    """Bindet invoice2data-Templates als InvoiceCandidateProvider an (HYB-10)."""

    @property
    def name(self) -> str:
        return _NAME

    @property
    def version(self) -> str:
        return _VERSION

    def extract(self, pdf_path: Path) -> InvoiceProviderResult:
        start_ms = int(time.monotonic() * 1000)
        try:
            from invoice2data import extract_data
        except ModuleNotFoundError:
            return InvoiceProviderResult(
                provider_name=_NAME,
                provider_version=None,
                laufstatus="skipped",
                kandidaten=[],
                fehlercode="ModuleNotFoundError",
            )

        try:
            text = _READER.extract_text(pdf_path)
            templates = _load_templates()
            treffer = extract_data(
                _PLATZHALTER_PFAD,
                templates=templates,
                input_module=_PreExtractedTextInput(text),
            )
            dauer = int(time.monotonic() * 1000) - start_ms

            if not treffer:
                # Unbekanntes Layout -- kontrolliertes Leerergebnis, kein Fehler.
                return InvoiceProviderResult(
                    provider_name=_NAME,
                    provider_version=_VERSION,
                    laufstatus="success",
                    kandidaten=[],
                    fehlercode=None,
                    lauf_dauer_ms=dauer,
                )

            kandidaten = _treffer_zu_kandidaten(treffer)
            return InvoiceProviderResult(
                provider_name=_NAME,
                provider_version=_VERSION,
                laufstatus="success",
                kandidaten=kandidaten,
                fehlercode=None,
                lauf_dauer_ms=dauer,
            )
        except Exception as exc:
            dauer = int(time.monotonic() * 1000) - start_ms
            # Nur Fehlertyp -- kein Volltext, kein Dateiname, kein Stack.
            return InvoiceProviderResult(
                provider_name=_NAME,
                provider_version=_VERSION,
                laufstatus="error",
                kandidaten=[],
                fehlercode=type(exc).__name__,
                lauf_dauer_ms=dauer,
            )


def _normwert(feld: str, wert: Any) -> str:
    if feld in _GELD_FELDER:
        return f"{float(wert):.2f}"
    return str(wert).strip()


def _treffer_zu_kandidaten(treffer: dict[str, Any]) -> list[HybridKandidat]:
    """Wandelt das invoice2data-Ergebnisdict in HybridKandidat-Liste um.

    template_name (Template-Version/-Identifikation) und issuer (Anbieterkennung)
    stammen direkt aus dem invoice2data-Ergebnis (HYB-10 Nachvollziehbarkeit).
    """
    template_version = treffer.get("template_name")
    werte: dict[str, Any] = {
        "vendor_name": treffer.get("issuer"),
        "invoice_number": treffer.get("invoice_number"),
        "invoice_date": treffer.get("invoice_date"),
        "total_amount": treffer.get("total_amount"),
        "net_amount": treffer.get("net_amount"),
        "tax_amount": treffer.get("tax_amount"),
        "currency": treffer.get("currency"),
        "payment_method": treffer.get("payment_method"),
    }
    kandidaten: list[HybridKandidat] = []
    for feld in _FELD_REIHENFOLGE:
        wert = werte[feld]
        if wert is None:
            continue
        kandidaten.append(HybridKandidat(
            feld=feld,
            rohwert=str(wert),
            normwert=_normwert(feld, wert),
            methode="invoice2data_template",
            provider_name=_NAME,
            provider_version=template_version,
            confidence=0.7,
        ))
    return kandidaten
