"""Neutrale Betrags-Bereinigungsutility (Paket 07-06).

Einzige Stelle fuer die Trennzeichen-/Tausendererkennung -- sowohl InvoiceParser
(Phase 4, liefert float) als auch hybrid_normalisierung (Phase 7, liefert Decimal)
nutzen dieselbe Funktion. Keine Abhaengigkeit auf InvoiceParser oder Hybrid-Code,
damit kein Importzyklus entsteht.
"""
from __future__ import annotations

import re

#: Deutsches Tausenderformat ohne Dezimalteil: einzelne Punkte, Gruppen von exakt
#: 3 Ziffern, fuehrende Gruppe 1-3 Ziffern ohne fuehrende 0 ("1.000", "12.500",
#: "1.234.567"). "0.500" bleibt Dezimalwert -- deutsche Betraege schreiben nie
#: "0.500" fuer 500.
_TAUSENDER_OHNE_DEZIMAL = re.compile(r"^[1-9]\d{0,2}(\.\d{3})+$")


def bereinige_betrag_string(value: str) -> str | None:
    """Bereinigt einen Betrags-Rohwert zu einem dot-decimal-String (mit Vorzeichen).

    Erkennt deutsches Format (Komma als Dezimaltrennzeichen, Punkt als
    Tausendertrennzeichen), internationales Format (Punkt als Dezimaltrennzeichen)
    und deutsches Tausenderformat ohne Dezimalteil ("1.000" -> "1000").
    Liefert None bei leerer oder nicht interpretierbarer Eingabe.
    """
    if value is None:
        return None
    cleaned = value.strip().replace("EUR", "").replace("€", "").replace(" ", "").strip(".,;:")
    if not cleaned:
        return None
    is_negative = cleaned.startswith("-")
    if is_negative:
        cleaned = cleaned[1:]
    if "." in cleaned and "," in cleaned:
        if cleaned.rfind(",") > cleaned.rfind("."):
            cleaned = cleaned.replace(".", "").replace(",", ".")
        else:
            cleaned = cleaned.replace(",", "")
    elif "," in cleaned:
        cleaned = cleaned.replace(",", ".")
    elif _TAUSENDER_OHNE_DEZIMAL.match(cleaned):
        # "1.000" / "2.500" / "1.234.567" sind deutsche Tausenderformate,
        # keine Dezimalbrueche (Paket 07-06, Faktor-1000-Fix).
        cleaned = cleaned.replace(".", "")
    if not cleaned:
        return None
    return f"-{cleaned}" if is_negative else cleaned
