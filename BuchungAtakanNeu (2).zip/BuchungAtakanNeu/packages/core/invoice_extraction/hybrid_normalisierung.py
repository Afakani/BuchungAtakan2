"""Feldnormalisierung fuer Mehrprovider-Auswertung (HYB-14).

Normalisiert Rohwerte verschiedener Provider auf vergleichbare kanonische Werte:
Betraege als Decimal (niemals float), Datum als ISO (YYYY-MM-DD), Waehrung als
ISO-4217-Code, Text (Anbieter/Rechnungsnummer) als vergleichbarer Normwert.

Wiederverwendung: Datumsparsing nutzt InvoiceParser._extract_date_from_string
(bestehende Logik aus Phase 4) statt einer neuen parallelen Implementierung.

Normalisierungsfehler werden nie still verworfen -- sie werden als Befund
(validierungsbefund) auf dem zurueckgegebenen Kandidaten sichtbar.
"""
from __future__ import annotations

import dataclasses
from decimal import Decimal, InvalidOperation

from packages.core.invoice_extraction.betrag_utils import bereinige_betrag_string
from packages.core.invoice_extraction.hybrid_kandidat import HybridKandidat
from packages.core.invoice_extraction.invoice_parser import InvoiceParser

_GELD_FELDER = frozenset({"total_amount", "net_amount", "tax_amount"})
_DATUM_FELDER = frozenset({"invoice_date"})
_WAEHRUNGS_FELDER = frozenset({"currency"})
_TEXT_FELDER = frozenset({"vendor_name", "invoice_number", "payment_method"})

_WAEHRUNGS_SYMBOLE = {"€": "EUR", "$": "USD", "£": "GBP"}
_BEKANNTE_WAEHRUNGEN = frozenset({"EUR", "USD", "GBP", "CHF"})


@dataclasses.dataclass(frozen=True)
class NormalisierungsBefund:
    """Ergebnis eines Normalisierungsversuchs fuer einen einzelnen Rohwert."""

    wert: str | None
    fehler: str | None

    @property
    def ist_gueltig(self) -> bool:
        return self.fehler is None and self.wert is not None


def normalisiere_betrag(rohwert: str) -> NormalisierungsBefund:
    """Normalisiert einen Betrags-Rohwert zu einem Decimal-String (2 Nachkommastellen).

    Trennzeichen-/Tausendererkennung liegt zentral in betrag_utils.bereinige_betrag_string
    (Paket 07-06) -- Parser und Hybrid-Normalisierung teilen exakt dieselbe Logik,
    hier nur ohne float-Rundung (Ergebnis wird direkt in Decimal() geparst).
    """
    if rohwert is None or not rohwert.strip():
        return NormalisierungsBefund(wert=None, fehler="Betrag leer")
    bereinigt = bereinige_betrag_string(rohwert)
    if bereinigt is None:
        return NormalisierungsBefund(wert=None, fehler=f"Betrag nicht erkennbar: '{rohwert}'")
    try:
        wert = Decimal(bereinigt).quantize(Decimal("0.01"))
    except (InvalidOperation, ValueError):
        return NormalisierungsBefund(wert=None, fehler=f"Betrag ungueltig: '{rohwert}'")
    return NormalisierungsBefund(wert=str(wert), fehler=None)


def normalisiere_datum(rohwert: str) -> NormalisierungsBefund:
    """Normalisiert einen Datums-Rohwert zu ISO (YYYY-MM-DD) -- nutzt bestehenden Parser."""
    if rohwert is None or not rohwert.strip():
        return NormalisierungsBefund(wert=None, fehler="Datum leer")
    geparst = InvoiceParser._extract_date_from_string(rohwert)
    if geparst is None:
        return NormalisierungsBefund(wert=None, fehler=f"Datum nicht erkennbar: '{rohwert}'")
    tag, monat, jahr = geparst.split(".")
    return NormalisierungsBefund(wert=f"{jahr}-{monat}-{tag}", fehler=None)


def normalisiere_waehrung(rohwert: str) -> NormalisierungsBefund:
    """Normalisiert einen Waehrungs-Rohwert zu einem ISO-4217-Code."""
    if rohwert is None or not rohwert.strip():
        return NormalisierungsBefund(wert=None, fehler="Waehrung leer")
    bereinigt = rohwert.strip()
    code = _WAEHRUNGS_SYMBOLE.get(bereinigt, bereinigt.upper())
    if code not in _BEKANNTE_WAEHRUNGEN:
        return NormalisierungsBefund(wert=None, fehler=f"Waehrung unbekannt: '{rohwert}'")
    return NormalisierungsBefund(wert=code, fehler=None)


def normalisiere_text(rohwert: str) -> NormalisierungsBefund:
    """Normalisiert Text (Anbieter, Rechnungsnummer, Zahlungsart) fuer Vergleichszwecke."""
    if rohwert is None:
        return NormalisierungsBefund(wert=None, fehler="Text leer")
    bereinigt = " ".join(rohwert.split()).strip()
    if not bereinigt:
        return NormalisierungsBefund(wert=None, fehler="Text leer")
    return NormalisierungsBefund(wert=bereinigt.casefold(), fehler=None)


def normalisiere_rohwert(feld: str, rohwert: str) -> NormalisierungsBefund:
    """Dispatcher: waehlt die passende Normalisierungsfunktion je Feldname."""
    if feld in _GELD_FELDER:
        return normalisiere_betrag(rohwert)
    if feld in _DATUM_FELDER:
        return normalisiere_datum(rohwert)
    if feld in _WAEHRUNGS_FELDER:
        return normalisiere_waehrung(rohwert)
    return normalisiere_text(rohwert)


def normalisiere_kandidat(kandidat: HybridKandidat) -> HybridKandidat:
    """Liefert eine Kopie des Kandidaten mit aktualisiertem normwert/validierungsbefund.

    HybridKandidat ist frozen -- es wird immer eine neue Instanz zurueckgegeben.
    Normalisierungsfehler ueberschreiben ein bestehendes validierungsbefund nicht
    still, sondern werden dort sichtbar vermerkt.
    """
    befund = normalisiere_rohwert(kandidat.feld, kandidat.rohwert)
    if befund.ist_gueltig:
        befundtext = "NORMALISIERT_OK"
        normwert = befund.wert
    else:
        befundtext = f"NORMALISIERUNGSFEHLER: {befund.fehler}"
        normwert = kandidat.normwert
    return dataclasses.replace(kandidat, normwert=normwert, validierungsbefund=befundtext)
