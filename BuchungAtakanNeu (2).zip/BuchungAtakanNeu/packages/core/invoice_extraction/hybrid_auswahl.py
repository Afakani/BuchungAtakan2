"""Kandidatenauswahl je Feld -- deterministisch, nachvollziehbar (HYB-14).

Kein Provider erhaelt pauschal Vorrang. pdfplumber wirkt nur als letzter, expliziter
Tie-Break wenn Mehrheit und Confidence bereits gleich stehen -- niemals blind dominant.
Bei echtem Gleichstand wird keine Auswahl erzwungen (UNSICHER).
"""
from __future__ import annotations

import dataclasses
import statistics

from packages.core.invoice_extraction.hybrid_kandidat import AuswahlStatus, HybridKandidat
from packages.core.invoice_extraction.hybrid_konflikt import KonfliktBefund

_TIE_BREAK_PROVIDER = "pdfplumber"


def _ist_normalisiert(k: HybridKandidat) -> bool:
    return k.normwert is not None and k.validierungsbefund == "NORMALISIERT_OK"


def _gruppiere_nach_normwert(kandidaten: tuple[HybridKandidat, ...]) -> dict[str, tuple[HybridKandidat, ...]]:
    werte = sorted({k.normwert for k in kandidaten})
    return {wert: tuple(k for k in kandidaten if k.normwert == wert) for wert in werte}


def _bestimme_gewinner(
    gruppen: dict[str, tuple[HybridKandidat, ...]],
) -> tuple[str | None, str]:
    """Liefert (gewinner_normwert oder None, aufloesungsgrund)."""
    metriken = {
        wert: (
            len({k.provider_name for k in mitglieder}),
            statistics.fmean(k.confidence for k in mitglieder),
        )
        for wert, mitglieder in gruppen.items()
    }

    # Regel a: eindeutig meiste unabhaengige Provider
    max_anbieterzahl = max(anzahl for anzahl, _ in metriken.values())
    fuehrend = sorted(wert for wert, (anzahl, _) in metriken.items() if anzahl == max_anbieterzahl)
    if len(fuehrend) == 1 and max_anbieterzahl > 1:
        return fuehrend[0], "AUFGELOEST_MEHRHEIT"

    kandidaten_werte = fuehrend if len(fuehrend) > 1 else sorted(metriken.keys())

    # Regel b: eindeutig hoechste durchschnittliche Confidence unter den Fuehrenden
    max_confidence = max(metriken[wert][1] for wert in kandidaten_werte)
    fuehrend_confidence = sorted(
        wert for wert in kandidaten_werte if metriken[wert][1] == max_confidence
    )
    if len(fuehrend_confidence) == 1:
        return fuehrend_confidence[0], "AUFGELOEST_CONFIDENCE"

    # Regel c: pdfplumber nur als letzter Tie-Break unter den verbleibend Gleichstehenden
    mit_pdfplumber = [
        wert for wert in fuehrend_confidence
        if any(k.provider_name == _TIE_BREAK_PROVIDER for k in gruppen[wert])
    ]
    if len(mit_pdfplumber) == 1:
        return mit_pdfplumber[0], "AUFGELOEST_PARSER_TIEBREAK"

    # Regel d: echter Gleichstand -- keine erzwungene Auswahl
    return None, "UNSICHER"


def waehle_kandidaten(
    kandidaten: list[HybridKandidat],
    konflikte: list[KonfliktBefund],
) -> tuple[list[HybridKandidat], list[KonfliktBefund]]:
    """Trifft die Auswahlentscheidung je Feld und befuellt auswahl_status/auswahl_grund.

    Gibt (aktualisierte Kandidatenliste, aktualisierte Konfliktliste) zurueck. Beide
    Eingaben werden nie mutiert (HybridKandidat/KonfliktBefund sind frozen).
    """
    konflikt_je_feld = {k.feld: k for k in konflikte}
    ergebnis_kandidaten: list[HybridKandidat] = []
    ergebnis_konflikte: list[KonfliktBefund] = []

    for feld in sorted({k.feld for k in kandidaten}):
        feld_kandidaten = [k for k in kandidaten if k.feld == feld]
        konflikt = konflikt_je_feld.get(feld)

        # Nicht normalisierbare Kandidaten werden nie stillschweigend ausgewaehlt.
        for k in feld_kandidaten:
            if not _ist_normalisiert(k):
                ergebnis_kandidaten.append(dataclasses.replace(
                    k,
                    auswahl_status=AuswahlStatus.ABGELEHNT,
                    auswahl_grund=f"Normalisierung fehlgeschlagen: {k.validierungsbefund}",
                ))

        verwertbar = tuple(k for k in feld_kandidaten if _ist_normalisiert(k))
        if not verwertbar:
            continue

        if konflikt is None:
            for k in verwertbar:
                grund = "Kein Konflikt: einziger konsistenter Normwert" if len(verwertbar) > 1 else "Einziger Kandidat fuer dieses Feld"
                ergebnis_kandidaten.append(dataclasses.replace(
                    k, auswahl_status=AuswahlStatus.AUSGEWAEHLT, auswahl_grund=grund,
                ))
            continue

        gruppen = _gruppiere_nach_normwert(verwertbar)
        gewinner_wert, aufloesungsgrund = _bestimme_gewinner(gruppen)

        if gewinner_wert is None:
            for k in verwertbar:
                ergebnis_kandidaten.append(dataclasses.replace(
                    k, auswahl_status=AuswahlStatus.KONFLIKT,
                    auswahl_grund="Konflikt nicht eindeutig aufloesbar (Gleichstand ueber alle Kriterien)",
                ))
            ergebnis_konflikte.append(dataclasses.replace(konflikt, aufloesungsstatus="UNSICHER"))
            continue

        for wert, mitglieder in gruppen.items():
            if wert == gewinner_wert:
                for k in mitglieder:
                    ergebnis_kandidaten.append(dataclasses.replace(
                        k, auswahl_status=AuswahlStatus.AUSGEWAEHLT,
                        auswahl_grund=f"Konflikt aufgeloest ({aufloesungsgrund}): Wert '{wert}' gewinnt",
                    ))
            else:
                for k in mitglieder:
                    ergebnis_kandidaten.append(dataclasses.replace(
                        k, auswahl_status=AuswahlStatus.ABGELEHNT,
                        auswahl_grund=f"Abweichender Wert '{wert}' gegenueber Gewinner '{gewinner_wert}' ({aufloesungsgrund})",
                    ))
        ergebnis_konflikte.append(dataclasses.replace(konflikt, aufloesungsstatus=aufloesungsgrund))

    return ergebnis_kandidaten, ergebnis_konflikte
