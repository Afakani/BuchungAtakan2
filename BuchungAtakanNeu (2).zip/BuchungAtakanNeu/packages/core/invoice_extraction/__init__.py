"""packages.core.invoice_extraction — Rechnungsextraktion, Kandidaten, Validierung."""
from packages.core.invoice_extraction.extraction_result import ExtractionResult, ExtraktionsStatus
from packages.core.invoice_extraction.hybrid_ergebnis import (
    HybridExtractionResult,
    HybridStatus,
    berechne_hybrid_status,
)
from packages.core.invoice_extraction.hybrid_auswahl import waehle_kandidaten
from packages.core.invoice_extraction.hybrid_auswertung import (
    HybridAuswertungsErgebnis,
    HybridPipelineDeaktiviertFehler,
    ist_hybrid_pipeline_aktiviert,
    werte_lokale_erkennung_aus,
)
from packages.core.invoice_extraction.hybrid_kandidat import (
    AuswahlStatus,
    HybridKandidat,
    from_kandidat,
)
from packages.core.invoice_extraction.hybrid_konflikt import KonfliktBefund, erkenne_konflikte
from packages.core.invoice_extraction.hybrid_normalisierung import (
    NormalisierungsBefund,
    normalisiere_kandidat,
    normalisiere_rohwert,
)
from packages.core.invoice_extraction.hybrid_plausibilitaet import PlausibilitaetsBefund
from packages.core.invoice_extraction.hybrid_qualitaetsentscheidung import berechne_finalen_status
from packages.core.invoice_extraction.hybrid_audit import (
    AuditBewertungFelder,
    AUDIT_FELDER,
    BewertungEintrag,
    berechne_gesamtergebnis_korrekt,
    waehle_neueste_bewertung,
)
from packages.core.invoice_extraction.hybrid_statistik import (
    ALLE_DIMENSIONEN,
    Quote,
    StatistikGruppe,
    StatistikZeile,
    UNBEKANNT,
    gruppiere_statistik,
    normalisiere_anbieter,
    normalisiere_dokument_klasse,
    normalisiere_methode,
)
from packages.core.invoice_extraction.hybrid_statistik_export import (
    erstelle_hybrid_statistik_workbook_bytes,
)
from packages.core.invoice_extraction.azure_document_intelligence_provider import (
    AzureAnalyseErgebnis,
    AzureDocumentIntelligenceClient,
    AzureDocumentIntelligenceProvider,
    AzureFeldErgebnis,
    FakeAzureDocumentIntelligenceClient,
    erstelle_provider as erstelle_azure_provider,
    ist_aktiviert as azure_ist_aktiviert,
)
from packages.core.invoice_extraction.document_classifier import (
    DokumentKlasse,
    DokumentMerkmale,
    ermittle_merkmale,
    klassifiziere,
    klassifiziere_pfad,
)
from packages.core.invoice_extraction.invoice2data_provider import Invoice2DataProvider
from packages.core.invoice_extraction.invoice_data import InvoiceData
from packages.core.invoice_extraction.invoice_parser import InvoiceParser
from packages.core.invoice_extraction.invoice_parser_adapter import (
    extract_from_pdf,
    extract_from_text,
    invoice_data_to_kandidaten,
)
from packages.core.invoice_extraction.invoice_validator import validate
from packages.core.invoice_extraction.kandidat import Kandidat, KandidatQuelle, RECHNUNGS_FELDER
from packages.core.invoice_extraction.local_provider_orchestrator import (
    LocalOrchestratorErgebnis,
    fuehre_lokale_erkennung_aus,
)
from packages.core.invoice_extraction.local_text import LocalExtractedText
from packages.core.invoice_extraction.paddleocr_provider import PaddleOCRProvider
from packages.core.invoice_extraction.pdf_reader import PDFReader
from packages.core.invoice_extraction.pdfplumber_provider import PdfplumberProvider
from packages.core.invoice_extraction.ports import InvoiceExtractionPort
from packages.core.invoice_extraction.provider_ports import (
    CloudInvoiceProvider,
    InvoiceCandidateProvider,
    InvoiceProviderResult,
    InvoiceTextProvider,
)
from packages.core.invoice_extraction.text_cleaner import PDFTextCleaner

__all__ = [
    # Phase 04 — unveraendert
    "ExtractionResult",
    "ExtraktionsStatus",
    "InvoiceData",
    "InvoiceParser",
    "extract_from_pdf",
    "extract_from_text",
    "invoice_data_to_kandidaten",
    "validate",
    "Kandidat",
    "KandidatQuelle",
    "RECHNUNGS_FELDER",
    "PDFReader",
    "InvoiceExtractionPort",
    "PDFTextCleaner",
    # Phase 07 — Hybrid-Architektur (HYB-02..07)
    "AuswahlStatus",
    "HybridKandidat",
    "from_kandidat",
    "HybridStatus",
    "HybridExtractionResult",
    "berechne_hybrid_status",
    "InvoiceProviderResult",
    "InvoiceTextProvider",
    "InvoiceCandidateProvider",
    "CloudInvoiceProvider",
    "PdfplumberProvider",
    # Phase 07 Paket 07-02 — Lokale Erkennungsschienen (HYB-09..13)
    "LocalExtractedText",
    "DokumentKlasse",
    "DokumentMerkmale",
    "klassifiziere",
    "klassifiziere_pfad",
    "ermittle_merkmale",
    "Invoice2DataProvider",
    "PaddleOCRProvider",
    "LocalOrchestratorErgebnis",
    "fuehre_lokale_erkennung_aus",
    # Phase 07 Paket 07-03 — Mehrprovider-Auswertung, Qualitaetsentscheidung (HYB-14..16)
    "NormalisierungsBefund",
    "normalisiere_kandidat",
    "normalisiere_rohwert",
    "KonfliktBefund",
    "erkenne_konflikte",
    "waehle_kandidaten",
    "PlausibilitaetsBefund",
    "berechne_finalen_status",
    "HybridAuswertungsErgebnis",
    "HybridPipelineDeaktiviertFehler",
    "ist_hybrid_pipeline_aktiviert",
    "werte_lokale_erkennung_aus",
    # Phase 07 Paket 07-03A — Audit-Booleanmodell, Statistik (HYB-17/18)
    "AuditBewertungFelder",
    "AUDIT_FELDER",
    "BewertungEintrag",
    "berechne_gesamtergebnis_korrekt",
    "waehle_neueste_bewertung",
    "ALLE_DIMENSIONEN",
    "Quote",
    "StatistikGruppe",
    "StatistikZeile",
    "UNBEKANNT",
    "gruppiere_statistik",
    "normalisiere_anbieter",
    "normalisiere_dokument_klasse",
    "normalisiere_methode",
    # Phase 07 Paket 07-03B — Excel-Export der Qualitaetsstatistik (HYB-19)
    "erstelle_hybrid_statistik_workbook_bytes",
    # Phase 07 Paket 07-04 — Azure-Adapter vorbereitet, deaktiviert (HYB-20..24)
    "AzureAnalyseErgebnis",
    "AzureDocumentIntelligenceClient",
    "AzureDocumentIntelligenceProvider",
    "AzureFeldErgebnis",
    "FakeAzureDocumentIntelligenceClient",
    "erstelle_azure_provider",
    "azure_ist_aktiviert",
]
