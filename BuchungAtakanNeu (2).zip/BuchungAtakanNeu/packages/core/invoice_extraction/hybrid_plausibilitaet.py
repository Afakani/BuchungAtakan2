"""Plausibilitaetsregeln fuer die finale Qualitaetsentscheidung (HYB-15).

Regeln und Schwellen sind zentral hier definiert -- keine generische Regel-Engine,
nur die konkret geforderten Pruefungen als einzelne, testbare Funktionen.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from decimal import Decimal, InvalidOperation

#: Toleranz Brutto = Netto + USt (in Waehrungseinheiten, z.B. EUR).
BETRAGS_TOLERANZ = Decimal("0.02")

#: Rechnungsnummern, die als rein generisch/nicht aussagekraeftig gelten.
_GENERISCHE_RECHNUNGSNUMMERN = frozenset({
    "rechnung", "invoice", "n/a", "na", "-", "unbekannt", "keine", "none", "",
})

#: Plausibler Jahresbereich fuer Rechnungsdatum.
_MIN_JAHR = 2000
_MAX_JAHR = 2100


@dataclass(frozen=True)
class PlausibilitaetsBefund:
    regel: str
    bestanden: bool
    begruendung: str


def _decimal_oder_none(wert: str | None) -> Decimal | None:
    if wert is None:
        return None
    try:
        return Decimal(wert)
    except (InvalidOperation, ValueError):
        return None


def pruefe_betragsrelation(
    brutto: str | None, netto: str | None, steuer: str | None
) -> PlausibilitaetsBefund:
    """Brutto = Netto + Steuer innerhalb BETRAGS_TOLERANZ."""
    b, n, s = _decimal_oder_none(brutto), _decimal_oder_none(netto), _decimal_oder_none(steuer)
    if b is None or n is None or s is None:
        return PlausibilitaetsBefund(
            "betragsrelation", False, "Brutto/Netto/Steuer nicht vollstaendig normalisiert"
        )
    diff = abs((n + s) - b)
    if diff > BETRAGS_TOLERANZ:
        return PlausibilitaetsBefund(
            "betragsrelation", False,
            f"Netto({n}) + Steuer({s}) = {n + s} weicht von Brutto({b}) um {diff} ab",
        )
    return PlausibilitaetsBefund("betragsrelation", True, "Brutto = Netto + Steuer innerhalb Toleranz")


def pruefe_steuer_nicht_negativ(steuer: str | None) -> PlausibilitaetsBefund:
    s = _decimal_oder_none(steuer)
    if s is None:
        return PlausibilitaetsBefund("steuer_nicht_negativ", False, "Steuerbetrag nicht normalisiert")
    if s < 0:
        return PlausibilitaetsBefund("steuer_nicht_negativ", False, f"Steuerbetrag negativ: {s}")
    return PlausibilitaetsBefund("steuer_nicht_negativ", True, "Steuerbetrag nicht negativ")


def pruefe_betrag_nicht_negativ(feld: str, betrag: str | None, storno_erlaubt: bool = False) -> PlausibilitaetsBefund:
    """Brutto/Netto nicht negativ, sofern nicht ausdruecklich als Storno/Gutschrift erlaubt."""
    regel = f"{feld}_nicht_negativ"
    b = _decimal_oder_none(betrag)
    if b is None:
        return PlausibilitaetsBefund(regel, False, f"{feld} nicht normalisiert")
    if b < 0 and not storno_erlaubt:
        return PlausibilitaetsBefund(regel, False, f"{feld} negativ ohne Storno-/Gutschriftfreigabe: {b}")
    return PlausibilitaetsBefund(regel, True, f"{feld} plausibel ({b})")


def pruefe_waehrung_konsistent(waehrungen: list[str | None]) -> PlausibilitaetsBefund:
    """Alle vorhandenen (nicht-None) Waehrungswerte muessen identisch sein."""
    bekannte = {w for w in waehrungen if w is not None}
    if len(bekannte) > 1:
        return PlausibilitaetsBefund(
            "waehrung_konsistent", False, f"Widerspruechliche Waehrungen: {sorted(bekannte)}"
        )
    return PlausibilitaetsBefund("waehrung_konsistent", True, "Waehrung konsistent")


def pruefe_rechnungsdatum_plausibel(iso_datum: str | None) -> PlausibilitaetsBefund:
    """Vollstaendige Kalendervalidierung (Paket 07-06): unmoegliche Daten wie
    2026-02-31 bestehen die Pruefung nie -- kein OK mit erfundenem Datum."""
    if iso_datum is None:
        return PlausibilitaetsBefund("rechnungsdatum_plausibel", False, "Rechnungsdatum nicht normalisiert")
    try:
        jahr_s, monat_s, tag_s = iso_datum.split("-")
        geparst = date(int(jahr_s), int(monat_s), int(tag_s))
    except (ValueError, IndexError):
        return PlausibilitaetsBefund(
            "rechnungsdatum_plausibel", False, f"Rechnungsdatum kein gueltiges Kalenderdatum: {iso_datum}"
        )
    if not (_MIN_JAHR <= geparst.year <= _MAX_JAHR):
        return PlausibilitaetsBefund(
            "rechnungsdatum_plausibel", False,
            f"Rechnungsjahr ausserhalb Plausibilitaetsbereich: {geparst.year}",
        )
    return PlausibilitaetsBefund("rechnungsdatum_plausibel", True, "Rechnungsdatum plausibel")


def pruefe_rechnungsnummer_plausibel(rechnungsnummer_normalisiert: str | None) -> PlausibilitaetsBefund:
    if rechnungsnummer_normalisiert is None or not rechnungsnummer_normalisiert.strip():
        return PlausibilitaetsBefund("rechnungsnummer_plausibel", False, "Rechnungsnummer leer")
    if rechnungsnummer_normalisiert.strip() in _GENERISCHE_RECHNUNGSNUMMERN:
        return PlausibilitaetsBefund(
            "rechnungsnummer_plausibel", False,
            f"Rechnungsnummer nur generischer Text: '{rechnungsnummer_normalisiert}'",
        )
    return PlausibilitaetsBefund("rechnungsnummer_plausibel", True, "Rechnungsnummer plausibel")


def pruefe_anbieter_bestimmbar(anbieter_normalisiert: str | None) -> PlausibilitaetsBefund:
    """Anbieter ausreichend bestimmbar.

    Empfaenger wird bewusst nicht geprueft: das Domaenenmodell (RECHNUNGS_FELDER)
    kennt aktuell kein eigenes Empfaenger-Kandidatenfeld -- der Empfaenger ist
    implizit das mandantenscoped unternehmen_id, kein Extraktionskandidat.
    """
    if anbieter_normalisiert is None or not anbieter_normalisiert.strip():
        return PlausibilitaetsBefund("anbieter_bestimmbar", False, "Anbieter nicht bestimmbar")
    return PlausibilitaetsBefund("anbieter_bestimmbar", True, "Anbieter bestimmbar")
