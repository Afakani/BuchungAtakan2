"""Azure Document Intelligence — vorbereiteter, deaktivierter Cloud-Adapter (HYB-20..24).

Kein Azure-SDK, kein Netzwerk, keine Credentials, kein produktiver Cloud-Pfad in diesem
Paket. `AzureDocumentIntelligenceClient` ist ein reiner Port (Protocol) -- ein spaeteres
Paket kann ihn mit einer echten SDK-Implementierung fuellen, nach eigener, ausdruecklicher
Nutzerfreigabe. `AzureAnalyseErgebnis`/`AzureFeldErgebnis` sind synthetische, projekteigene
Dataclasses -- keine SDK-Typen.

Fail-closed: `erstelle_provider()` ruft `client_factory` nie auf, solange das kanonische
Flag `BUCHUNG_ATAKAN_FEATURE_AZURE_DOCUMENT_INTELLIGENCE` nicht aktiv ist. Das Legacy-Flag
`BUCHUNG_ATAKAN_FEATURE_AZURE_DI` (Phase 07-01) bleibt inert -- es steuert diesen Adapter
nicht und wird von diesem Modul nicht gelesen.

Provider-Vertrag (HYB-20/HYB-21):
- erhaelt den Client ausschliesslich injiziert (nie selbst instanziiert),
- verarbeitet nur synthetische Response-Objekte,
- erzeugt ausschliesslich bestehende HybridKandidat-Objekte,
- entscheidet niemals selbst ueber den finalen Rechnungsstatus (das bleibt
  hybrid_qualitaetsentscheidung.berechne_finalen_status() vorbehalten),
- nutzt die bestehende Normalisierungslogik (hybrid_normalisierung.normalisiere_kandidat),
- ist auf die bestehenden Fachfelder (RECHNUNGS_FELDER) begrenzt,
- liefert bei Clientfehlern nur den sanitisierten Fehlertyp, nie Rohdaten/Stacktraces.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Protocol

from packages.core.invoice_extraction.hybrid_kandidat import HybridKandidat
from packages.core.invoice_extraction.hybrid_normalisierung import normalisiere_kandidat
from packages.core.invoice_extraction.kandidat import RECHNUNGS_FELDER
from packages.core.invoice_extraction.provider_ports import InvoiceProviderResult

#: Providername -- auch als Literal in hybrid_qualitaetsentscheidung.py fuer den
#: Azure-only-Statusguard verwendet (gleiche Konvention wie bestehende Providernamen
#: "pdfplumber"/"invoice2data"/"paddleocr" in hybrid_konflikt.py -- kein Shared-Import
#: zwischen Provider- und Statuslogik-Modul).
NAME = "azure_document_intelligence"
_VERSION = "1.0"

#: Unterstuetzte Felder -- exakt die bestehende Hybrid-Fachfeldmenge, kein neues Feld.
_ERLAUBTE_FELDER = RECHNUNGS_FELDER


@dataclass(frozen=True)
class AzureFeldErgebnis:
    """Synthetisches Analogon zu einem einzelnen Azure-Feldergebnis -- kein SDK-Typ."""

    feld: str
    wert: str | None
    confidence: float


@dataclass(frozen=True)
class AzureAnalyseErgebnis:
    """Synthetisches Analogon zum Azure-Document-Intelligence-Analyseergebnis.

    Rein interne, projekteigene Portschnittstelle -- entspricht keinem `azure.ai`-Typ.
    """

    felder: tuple[AzureFeldErgebnis, ...]
    model_version: str | None = None


class AzureDocumentIntelligenceClient(Protocol):
    """Port fuer einen (spaeteren) Azure-Client -- kein SDK-Import, kein Netzwerk hier.

    Eine echte Implementierung braucht ein eigenes Paket und ausdrueckliche
    Nutzerfreigabe (HYB-24). Tests verwenden ausschliesslich FakeAzureDocumentIntelligenceClient.
    """

    def analyze(self, pdf_path: Path) -> AzureAnalyseErgebnis: ...


class FakeAzureDocumentIntelligenceClient:
    """Fake-Client fuer Tests -- kein Netzwerk, keine echten Credentials, deterministisch."""

    def __init__(
        self,
        antwort: AzureAnalyseErgebnis | None = None,
        fehler: Exception | None = None,
    ) -> None:
        self._antwort = antwort if antwort is not None else AzureAnalyseErgebnis(felder=())
        self._fehler = fehler
        self.aufrufe: list[Path] = []

    def analyze(self, pdf_path: Path) -> AzureAnalyseErgebnis:
        self.aufrufe.append(pdf_path)
        if self._fehler is not None:
            raise self._fehler
        return self._antwort


def ist_aktiviert(settings: Any) -> bool:
    """Nur das kanonische Flag steuert diesen Adapter (HYB-20).

    Das Legacy-Flag BUCHUNG_ATAKAN_FEATURE_AZURE_DI (Phase 07-01) wird hier bewusst
    NICHT gelesen -- es bleibt inert und aktiviert diesen Provider nicht.
    """
    return bool(getattr(settings, "BUCHUNG_ATAKAN_FEATURE_AZURE_DOCUMENT_INTELLIGENCE", False))


def _feldergebnis_gueltig(feld_ergebnis: AzureFeldErgebnis) -> bool:
    """Nur unterstuetzte Felder mit vorhandenem Wert und gueltiger Confidence.

    Unbekannte Felder, fehlende/leere Werte und Confidence ausserhalb [0.0, 1.0]
    werden nie still als gueltiger Kandidat uebernommen -- sie werden uebersprungen.
    """
    if feld_ergebnis.feld not in _ERLAUBTE_FELDER:
        return False
    if feld_ergebnis.wert is None or not feld_ergebnis.wert.strip():
        return False
    if not (0.0 <= feld_ergebnis.confidence <= 1.0):
        return False
    return True


class AzureDocumentIntelligenceProvider:
    """CloudInvoiceProvider-Implementierung (HYB-20/21/22/23/24).

    Trifft keine finale Statusentscheidung -- liefert nur Kandidaten, wie jeder andere
    InvoiceCandidateProvider auch. `berechne_finalen_status()` bleibt zustaendig.
    """

    def __init__(self, client: AzureDocumentIntelligenceClient, enabled: bool) -> None:
        self._client = client
        self._enabled = enabled

    @property
    def name(self) -> str:
        return NAME

    @property
    def version(self) -> str:
        return _VERSION

    @property
    def is_enabled(self) -> bool:
        return self._enabled

    def extract(self, pdf_path: Path) -> InvoiceProviderResult:
        if not self._enabled:
            # fail-closed: kein Clientaufruf bei deaktiviertem Provider.
            return InvoiceProviderResult(
                provider_name=NAME,
                provider_version=_VERSION,
                laufstatus="skipped",
                kandidaten=[],
                fehlercode=None,
            )

        try:
            antwort = self._client.analyze(pdf_path)
        except Exception as exc:
            # Nur Fehlertyp -- kein Volltext, kein Endpunkt, kein Token, kein Stack.
            return InvoiceProviderResult(
                provider_name=NAME,
                provider_version=_VERSION,
                laufstatus="error",
                kandidaten=[],
                fehlercode=type(exc).__name__,
            )

        kandidaten = self._antwort_zu_kandidaten(antwort)
        return InvoiceProviderResult(
            provider_name=NAME,
            provider_version=antwort.model_version or _VERSION,
            laufstatus="success",
            kandidaten=kandidaten,
            fehlercode=None,
        )

    def _antwort_zu_kandidaten(self, antwort: AzureAnalyseErgebnis) -> list[HybridKandidat]:
        """Mapping ist deterministisch: identische Eingabe liefert identische Kandidaten
        in identischer Reihenfolge. Nutzt bestehende Normalisierungslogik (HYB-14)."""
        kandidaten: list[HybridKandidat] = []
        for feld_ergebnis in antwort.felder:
            if not _feldergebnis_gueltig(feld_ergebnis):
                continue
            roh_kandidat = HybridKandidat(
                feld=feld_ergebnis.feld,
                rohwert=feld_ergebnis.wert,
                normwert=None,
                methode="azure_document_intelligence",
                provider_name=NAME,
                provider_version=antwort.model_version or _VERSION,
                confidence=feld_ergebnis.confidence,
            )
            kandidaten.append(normalisiere_kandidat(roh_kandidat))
        return kandidaten


def erstelle_provider(
    settings: Any,
    client_factory: Callable[[], AzureDocumentIntelligenceClient],
) -> AzureDocumentIntelligenceProvider | None:
    """Kontrollierte Providererzeugung (HYB-20/23) -- fail-closed.

    Liefert None, solange das kanonische Flag deaktiviert ist. `client_factory` wird
    in diesem Fall NIE aufgerufen -- kein Client wird erzeugt, kein Netzwerkpfad
    entsteht. Erst bei aktivem Flag wird der Client ueber die uebergebene Factory
    erzeugt und in den Provider injiziert.
    """
    if not ist_aktiviert(settings):
        return None
    client = client_factory()
    return AzureDocumentIntelligenceProvider(client=client, enabled=True)
