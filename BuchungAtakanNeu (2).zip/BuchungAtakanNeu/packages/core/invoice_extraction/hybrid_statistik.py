"""Reine Statistiklogik fuer Hybrid-Qualitaetsauswertung (HYB-18) -- kein Datenbankzugriff.

Berechnet Vollstaendigkeits-, Richtigkeits-, Automatisierungs-, Pruef- und
Nichterkennungsquote je Gruppe. Gruppierbar nach beliebiger Kombination aus Anbieter,
Dokumenttyp, Erkennungsmethode und Status.

Metrikdefinitionen (N = Anzahl distinct Statusentscheidungen je Gruppe):
  Vollstaendigkeitsquote  = Statusentscheidungen mit pflichtfelder_ok=True / N
  Automatisierungsquote   = Statusentscheidungen mit status=OK / N
  Pruefquote              = Statusentscheidungen mit status=MUSS_GEPRUEFT_WERDEN / N
  Nichterkennungsquote    = Statusentscheidungen mit status=NICHT_GEFUNDEN / N
  Richtigkeitsquote       = auditierte Statusentscheidungen mit neuester Bewertung
                            gesamtergebnis_korrekt=True / auditierte Statusentscheidungen
                            in der Gruppe

Bei Nenner 0 wird die Quote deterministisch als None ausgegeben -- Zaehler und Nenner
bleiben trotzdem sichtbar (kein vorgetaeuschtes 0%).
"""
from __future__ import annotations

from dataclasses import dataclass

UNBEKANNT = "UNBEKANNT"

DIM_ANBIETER = "anbieter"
DIM_DOKUMENT_KLASSE = "dokument_klasse"
DIM_METHODE = "methode"
DIM_STATUS = "status"

ALLE_DIMENSIONEN = (DIM_ANBIETER, DIM_DOKUMENT_KLASSE, DIM_METHODE, DIM_STATUS)

_STATUS_OK = "OK"
_STATUS_MUSS_GEPRUEFT = "MUSS_GEPRUEFT_WERDEN"
_STATUS_NICHT_GEFUNDEN = "NICHT_GEFUNDEN"


def normalisiere_anbieter(lieferant_name: str | None) -> str:
    """Fehlender oder blanker Anbietername wird UNBEKANNT (nie stiller Ausschluss)."""
    if lieferant_name is None or not lieferant_name.strip():
        return UNBEKANNT
    return lieferant_name.strip()


def normalisiere_dokument_klasse(dokument_klasse: str | None) -> str:
    """NULL (Altzeilen ohne dokument_klasse) wird UNBEKANNT, kein erfundener Wert."""
    if dokument_klasse is None or not dokument_klasse.strip():
        return UNBEKANNT
    return dokument_klasse


def normalisiere_methode(provider_name: str | None) -> str:
    """Fehlender Provider (kein hybrid_erkennungslauf verknuepft) wird UNBEKANNT."""
    if provider_name is None or not provider_name.strip():
        return UNBEKANNT
    return provider_name


@dataclass(frozen=True)
class StatistikZeile:
    """Eine Rohdatenzeile fuer die Statistik -- eine Statusentscheidung, ggf. je
    Erkennungsmethode dupliziert (eine Statusentscheidung kann mehrere Provider
    beteiligt haben). statusentscheidung_id dient der Deduplizierung bei Gruppierungen
    ohne die Dimension 'methode'.
    """

    statusentscheidung_id: str
    anbieter: str
    dokument_klasse: str
    methode: str
    status: str
    pflichtfelder_ok: bool
    audit_korrekt: bool | None


@dataclass(frozen=True)
class Quote:
    zaehler: int
    nenner: int
    quote: float | None


@dataclass(frozen=True)
class StatistikGruppe:
    dimensionen: tuple[str, ...]
    dimensionswerte: tuple[str, ...]
    anzahl: int
    vollstaendigkeitsquote: Quote
    richtigkeitsquote: Quote
    automatisierungsquote: Quote
    pruefquote: Quote
    nichterkennungsquote: Quote


def _quote(zaehler: int, nenner: int) -> Quote:
    if nenner == 0:
        return Quote(zaehler=zaehler, nenner=nenner, quote=None)
    return Quote(zaehler=zaehler, nenner=nenner, quote=zaehler / nenner)


def _dedupliziere(zeilen: list[StatistikZeile]) -> list[StatistikZeile]:
    """Eine Zeile je statusentscheidung_id -- bei mehreren Methoden-Zeilen fuer
    dieselbe Statusentscheidung sind Status/Pflichtfelder/Audit identisch, nur
    methode unterscheidet sich. Reihenfolge der Eingabe beeinflusst das Ergebnis nicht.
    """
    eindeutig: dict[str, StatistikZeile] = {}
    for zeile in zeilen:
        eindeutig[zeile.statusentscheidung_id] = zeile
    return [eindeutig[k] for k in sorted(eindeutig)]


def _gruppenschluessel(zeile: StatistikZeile, dimensionen: tuple[str, ...]) -> tuple[str, ...]:
    werte = {
        DIM_ANBIETER: zeile.anbieter,
        DIM_DOKUMENT_KLASSE: zeile.dokument_klasse,
        DIM_METHODE: zeile.methode,
        DIM_STATUS: zeile.status,
    }
    return tuple(werte[d] for d in dimensionen)


def gruppiere_statistik(
    zeilen: list[StatistikZeile],
    dimensionen: tuple[str, ...] = ALLE_DIMENSIONEN,
) -> list[StatistikGruppe]:
    """Gruppiert Statistikzeilen nach den gewaehlten Dimensionen und berechnet je
    Gruppe alle fuenf Qualitaetsquoten. Deterministisch sortiert nach Gruppenschluessel --
    Reihenfolge der Eingabeliste beeinflusst das Ergebnis nicht.
    """
    rohgruppen: dict[tuple[str, ...], list[StatistikZeile]] = {}
    for zeile in zeilen:
        schluessel = _gruppenschluessel(zeile, dimensionen)
        rohgruppen.setdefault(schluessel, []).append(zeile)

    ergebnis: list[StatistikGruppe] = []
    for schluessel in sorted(rohgruppen):
        eindeutige = _dedupliziere(rohgruppen[schluessel])
        n = len(eindeutige)

        vollstaendig = sum(1 for z in eindeutige if z.pflichtfelder_ok)
        automatisiert = sum(1 for z in eindeutige if z.status == _STATUS_OK)
        zu_pruefen = sum(1 for z in eindeutige if z.status == _STATUS_MUSS_GEPRUEFT)
        nicht_erkannt = sum(1 for z in eindeutige if z.status == _STATUS_NICHT_GEFUNDEN)

        auditiert = [z for z in eindeutige if z.audit_korrekt is not None]
        richtig = sum(1 for z in auditiert if z.audit_korrekt is True)

        ergebnis.append(StatistikGruppe(
            dimensionen=dimensionen,
            dimensionswerte=schluessel,
            anzahl=n,
            vollstaendigkeitsquote=_quote(vollstaendig, n),
            richtigkeitsquote=_quote(richtig, len(auditiert)),
            automatisierungsquote=_quote(automatisiert, n),
            pruefquote=_quote(zu_pruefen, n),
            nichterkennungsquote=_quote(nicht_erkannt, n),
        ))

    return ergebnis
