"""ExtractionResult und ExtraktionsStatus fuer Phase-04-Rechnungsextraktion."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum

from packages.core.invoice_extraction.kandidat import Kandidat, RECHNUNGS_FELDER


class ExtraktionsStatus(StrEnum):
    OK = "OK"
    PRUEFFALL = "PRUEFFALL"
    UNVOLLSTAENDIG = "UNVOLLSTAENDIG"
    MATH_FEHLER = "MATH_FEHLER"


_PFLICHT_FELDER = frozenset({"vendor_name", "invoice_number", "invoice_date", "total_amount"})


@dataclass
class ExtractionResult:
    kandidaten: list[Kandidat]
    status: ExtraktionsStatus
    fehler: list[str]
    roher_text: str
    confidence: float = 0.0

    def kandidaten_fuer_feld(self, feld: str) -> list[Kandidat]:
        return [k for k in self.kandidaten if k.feld == feld]

    def bestes_fuer_feld(self, feld: str) -> Kandidat | None:
        treffer = self.kandidaten_fuer_feld(feld)
        if not treffer:
            return None
        return max(treffer, key=lambda k: k.confidence)

    @property
    def fehlende_pflichtfelder(self) -> frozenset[str]:
        vorhandene = {k.feld for k in self.kandidaten}
        return _PFLICHT_FELDER - vorhandene
