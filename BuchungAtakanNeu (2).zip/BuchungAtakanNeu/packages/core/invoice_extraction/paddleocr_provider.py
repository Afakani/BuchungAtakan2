"""PaddleOCRProvider — lokaler OCR-Adapter fuer Scan-PDFs (HYB-11).

Lazy Import: PaddleOCR wird erst beim tatsaechlichen extract()-Aufruf importiert und
initialisiert. Kein Cloud-Fallback, kein Azure. OCR-Text durchlaeuft denselben
Parser-/Validierungspfad wie eingebetteter PDF-Text (extract_from_text mit integrierter
Validierung). Rasterbilder pro Seite werden nur im Speicher gehalten, nie persistiert.

Hinweis Betrieb: PaddleOCR laedt Modellgewichte beim ersten Start ueber das Netzwerk,
falls sie nicht bereits lokal zwischengespeichert sind. Das Vorhalten lokaler
Modell-Caches ist Betriebsvoraussetzung, nicht Teil von Paket 07-02.
"""
from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Any

from packages.core.invoice_extraction.hybrid_kandidat import HybridKandidat
from packages.core.invoice_extraction.invoice_parser_adapter import extract_from_text
from packages.core.invoice_extraction.local_text import LocalExtractedText
from packages.core.invoice_extraction.provider_ports import InvoiceProviderResult

_NAME = "paddleocr"
_VERSION = "1.0"
_OCR_SPRACHE = "de"
_RESOLUTION = 200

# PaddleOCR-eigenes Logging stummschalten -- verhindert Volltext-/Pfad-Ausgabe
# ueber dessen interne Logger (Logger-Name "ppocr").
logging.getLogger("ppocr").setLevel(logging.CRITICAL)

_engine_cache: Any = None


def ist_aktiviert(settings: Any) -> bool:
    return bool(getattr(settings, "BUCHUNG_ATAKAN_FEATURE_PADDLE_OCR", False))


def _lade_engine() -> Any:
    global _engine_cache
    if _engine_cache is None:
        from paddleocr import PaddleOCR
        _engine_cache = PaddleOCR(use_angle_cls=True, lang=_OCR_SPRACHE)
    return _engine_cache


class PaddleOCRProvider:
    """Bindet PaddleOCR als InvoiceCandidateProvider an (HYB-11)."""

    @property
    def name(self) -> str:
        return _NAME

    @property
    def version(self) -> str:
        return _VERSION

    def extract(self, pdf_path: Path) -> InvoiceProviderResult:
        start_ms = int(time.monotonic() * 1000)
        try:
            engine = _lade_engine()
        except ModuleNotFoundError:
            return InvoiceProviderResult(
                provider_name=_NAME,
                provider_version=None,
                laufstatus="skipped",
                kandidaten=[],
                fehlercode="ModuleNotFoundError",
            )

        try:
            seiten = self._ocr_seiten(engine, pdf_path)
            dauer = int(time.monotonic() * 1000) - start_ms

            if not seiten:
                return InvoiceProviderResult(
                    provider_name=_NAME,
                    provider_version=_VERSION,
                    laufstatus="success",
                    kandidaten=[],
                    fehlercode=None,
                    seiten_anzahl=0,
                    lauf_dauer_ms=dauer,
                )

            kandidaten = self._seiten_zu_kandidaten(seiten)
            return InvoiceProviderResult(
                provider_name=_NAME,
                provider_version=_VERSION,
                laufstatus="success",
                kandidaten=kandidaten,
                fehlercode=None,
                seiten_anzahl=len(seiten),
                lauf_dauer_ms=dauer,
            )
        except Exception as exc:
            dauer = int(time.monotonic() * 1000) - start_ms
            # Nur Fehlertyp -- kein Volltext, kein Dateiname, kein Stack.
            return InvoiceProviderResult(
                provider_name=_NAME,
                provider_version=_VERSION,
                laufstatus="error",
                kandidaten=[],
                fehlercode=type(exc).__name__,
                lauf_dauer_ms=dauer,
            )

    def _ocr_seiten(self, engine: Any, pdf_path: Path) -> list[LocalExtractedText]:
        """Rendert jede PDF-Seite im Speicher und laesst PaddleOCR Text/Confidence liefern.

        Bildet jede erkannte Seite auf das einheitliche Textmodell ab (HYB-12).
        """
        import pdfplumber

        ergebnisse: list[LocalExtractedText] = []
        with pdfplumber.open(pdf_path) as pdf:
            for index, page in enumerate(pdf.pages, start=1):
                bild = page.to_image(resolution=_RESOLUTION).original
                ocr_ergebnis = engine.ocr(_bild_zu_array(bild), cls=True)
                zeilen, confidences = _ocr_ergebnis_auswerten(ocr_ergebnis)
                if not zeilen:
                    continue
                text = "\n".join(zeilen)
                confidence = sum(confidences) / len(confidences) if confidences else 0.0
                ergebnisse.append(LocalExtractedText(
                    text=text,
                    seite=index,
                    quelle=_NAME,
                    confidence=confidence,
                    methode="ocr",
                    provider_version=_VERSION,
                ))
        return ergebnisse

    def _seiten_zu_kandidaten(self, seiten: list[LocalExtractedText]) -> list[HybridKandidat]:
        kandidaten: list[HybridKandidat] = []
        for seite in seiten:
            ergebnis = extract_from_text(seite.text)
            for kandidat in ergebnis.kandidaten:
                kandidaten.append(HybridKandidat(
                    feld=kandidat.feld,
                    rohwert=kandidat.rohwert,
                    normwert=kandidat.normwert,
                    methode=kandidat.methode,
                    provider_name=_NAME,
                    provider_version=_VERSION,
                    # OCR-Confidence begrenzt die Parser-Confidence nach oben,
                    # da OCR-Fehler die Zuverlaessigkeit staerker einschraenken
                    # koennen als ein Regex-Treffer auf sauberem Text.
                    confidence=min(kandidat.confidence, seite.confidence),
                    seite=seite.seite,
                ))
        return kandidaten


def _bild_zu_array(bild: Any) -> Any:
    import numpy as np
    return np.array(bild.convert("RGB"))


def _ocr_ergebnis_auswerten(ocr_ergebnis: Any) -> tuple[list[str], list[float]]:
    """Extrahiert Zeilentext und Confidence aus PaddleOCR-Rohergebnis.

    PaddleOCR liefert je Bild eine Liste von [box, (text, confidence)]-Eintraegen
    (oder None bei keinem Treffer). Robust gegen leere/fehlende Ergebnisse.
    """
    zeilen: list[str] = []
    confidences: list[float] = []
    if not ocr_ergebnis:
        return zeilen, confidences
    for seiten_ergebnis in ocr_ergebnis:
        if not seiten_ergebnis:
            continue
        for eintrag in seiten_ergebnis:
            try:
                _box, (text, confidence) = eintrag
            except (ValueError, TypeError):
                continue
            zeilen.append(text)
            confidences.append(float(confidence))
    return zeilen, confidences
