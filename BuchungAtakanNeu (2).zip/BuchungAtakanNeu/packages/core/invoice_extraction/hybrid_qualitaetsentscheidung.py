"""Finale Statusentscheidung nach Mehrprovider-Auswertung (HYB-14/15/16).

Ergaenzt die bestehende berechne_hybrid_status() (07-01, hybrid_ergebnis.py) um
Konflikt-, Plausibilitaets- und Providerfehler-Kriterien -- ersetzt sie nicht.
07-01-Funktion und -Tests bleiben unveraendert.

OK entsteht niemals allein aus Vollstaendigkeit; jeder offene Pflichtfeld-Konflikt,
jede gescheiterte Plausibilitaetsregel und jeder kritische Providerausfall fuehrt
zu MUSS_GEPRUEFT_WERDEN statt eines stillen OK.
"""
from __future__ import annotations

from packages.core.invoice_extraction.hybrid_ergebnis import PFLICHT_FELDER, HybridStatus
from packages.core.invoice_extraction.hybrid_kandidat import AuswahlStatus, HybridKandidat
from packages.core.invoice_extraction.hybrid_konflikt import KonfliktBefund
from packages.core.invoice_extraction.hybrid_plausibilitaet import PlausibilitaetsBefund
from packages.core.invoice_extraction.provider_ports import InvoiceProviderResult

CONFIDENCE_SCHWELLE = 0.5

#: Literal statt Import aus azure_document_intelligence_provider.py -- gleiche
#: Konvention wie bestehende Providernamen-Literale ("paddleocr" etc.) in
#: hybrid_konflikt.py. Azure-Kandidaten duerfen Pflichtfelder nie allein bestaetigen
#: (Paket 07-04 Akzeptanzkriterium: "Azure-Ergebnisse sind spaeter nur zusaetzliche
#: Kandidaten") -- diese Regel kennt nur den Namen, nicht das Providermodul.
_AZURE_PROVIDER_NAME = "azure_document_intelligence"


def berechne_finalen_status(
    kandidaten: list[HybridKandidat],
    konflikte: list[KonfliktBefund],
    plausibilitaet: list[PlausibilitaetsBefund],
    provider_ergebnisse: list[InvoiceProviderResult] | None = None,
) -> tuple[HybridStatus, list[str]]:
    """Berechnet HybridStatus gemaess HYB-14/15/16-Statusregeln.

    Deterministisch: identische Eingaben liefern immer denselben Status. Kein
    Zeitstempel, keine UUID- oder DB-Reihenfolge beeinflusst das Ergebnis.
    """
    provider_ergebnisse = provider_ergebnisse or []
    ausgewaehlt = [k for k in kandidaten if k.auswahl_status == AuswahlStatus.AUSGEWAEHLT]
    vorhandene_pflichtfelder = {k.feld for k in ausgewaehlt} & PFLICHT_FELDER
    fehlende_pflichtfelder = PFLICHT_FELDER - vorhandene_pflichtfelder

    alle_provider_fehlgeschlagen = bool(provider_ergebnisse) and all(
        p.laufstatus != "success" for p in provider_ergebnisse
    )

    if not ausgewaehlt or fehlende_pflichtfelder == PFLICHT_FELDER or alle_provider_fehlgeschlagen:
        return HybridStatus.NICHT_GEFUNDEN, [
            "NICHT_GEFUNDEN: keine verwertbaren Kandidaten fuer Pflichtfelder "
            "(kein lokaler Provider lieferte ein brauchbares Ergebnis)"
        ]

    gruende: list[str] = []

    if fehlende_pflichtfelder:
        gruende.append(f"Pflichtfelder ohne ausgewaehlten Kandidaten: {sorted(fehlende_pflichtfelder)}")

    pflicht_kandidaten = [k for k in ausgewaehlt if k.feld in PFLICHT_FELDER]
    pflicht_provider = {k.provider_name for k in pflicht_kandidaten}
    if pflicht_kandidaten and pflicht_provider <= {_AZURE_PROVIDER_NAME}:
        gruende.append(
            "Pflichtfelder ausschliesslich durch Azure Document Intelligence bestaetigt -- "
            "Cloud-Kandidaten allein reichen nie fuer OK (Paket 07-04)"
        )

    offene_pflicht_konflikte = [k for k in konflikte if k.feld in PFLICHT_FELDER]
    for konflikt in offene_pflicht_konflikte:
        gruende.append(
            f"Konflikt bei Pflichtfeld '{konflikt.feld}' ({konflikt.aufloesungsstatus}): {konflikt.begruendung}"
        )

    for k in ausgewaehlt:
        if k.feld in PFLICHT_FELDER and k.confidence < CONFIDENCE_SCHWELLE:
            gruende.append(f"Confidence fuer Pflichtfeld '{k.feld}' zu niedrig ({k.confidence:.2f})")

    for befund in plausibilitaet:
        if not befund.bestanden:
            gruende.append(f"Plausibilitaetsregel '{befund.regel}' nicht bestanden: {befund.begruendung}")

    kritische_providerfehler = [p for p in provider_ergebnisse if p.laufstatus == "error"]
    for p in kritische_providerfehler:
        gruende.append(f"Providerfehler bei '{p.provider_name}': {p.fehlercode}")

    if gruende:
        return HybridStatus.MUSS_GEPRUEFT_WERDEN, gruende

    return HybridStatus.OK, [
        "OK: Pflichtfelder vollstaendig und ausgewaehlt, keine offenen Pflichtfeld-Konflikte, "
        "Confidence ausreichend, alle Plausibilitaetsregeln bestanden, keine kritischen Providerfehler"
    ]
