"""HybridKandidat — erweitertes Kandidatenmodell fuer Phase 07 (HYB-03/04)."""
from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Any

from packages.core.invoice_extraction.kandidat import Kandidat


class AuswahlStatus(StrEnum):
    AUSGEWAEHLT = "AUSGEWAEHLT"
    ABGELEHNT = "ABGELEHNT"
    KONFLIKT = "KONFLIKT"
    UNSICHER = "UNSICHER"


@dataclass(frozen=True)
class HybridKandidat:
    """Kandidat mit vollstaendiger Provider-Herkunft und Auswahlstatus (HYB-03/04).

    Erweiterung von Kandidat: provider_name statt quelle (freier String), plus
    provider_version, seite, bbox, validierungsbefund, konflikt_gruppe, auswahl_status.
    Keine sensiblen Volltexte oder Dateinamen im bbox-Feld erlaubt.
    """

    feld: str
    rohwert: str
    normwert: str | None
    methode: str
    provider_name: str
    provider_version: str | None
    confidence: float
    seite: int | None = None
    bbox: dict[str, Any] | None = None
    validierungsbefund: str | None = None
    konflikt_gruppe: str | None = None
    auswahl_status: AuswahlStatus | None = None
    auswahl_grund: str | None = None

    def __post_init__(self) -> None:
        if not self.feld:
            raise ValueError("feld darf nicht leer sein")
        if self.rohwert is None:
            raise ValueError("rohwert darf nicht None sein")
        if not (0.0 <= self.confidence <= 1.0):
            raise ValueError(
                f"confidence muss zwischen 0.0 und 1.0 liegen, war: {self.confidence}"
            )
        if not self.methode:
            raise ValueError("methode darf nicht leer sein")
        if not self.provider_name:
            raise ValueError("provider_name darf nicht leer sein")


def from_kandidat(
    k: Kandidat,
    provider_version: str | None = None,
    seite: int | None = None,
    provider_name: str | None = None,
) -> HybridKandidat:
    """Konvertiert Legacy-Kandidat in HybridKandidat (Adapter fuer bestehenden Parser-Pfad).

    provider_name muss vom aufrufenden InvoiceCandidateProvider explizit uebergeben
    werden (z.B. "pdfplumber") -- ohne explizite Angabe faellt dies auf k.quelle
    zurueck (Phase-4-KandidatQuelle wie "pdf_text"). Ein Provider, der from_kandidat()
    nutzt, MUSS provider_name setzen: sonst landet die Kandidatenquelle statt des
    tatsaechlichen Providernamens in HybridKandidat.provider_name -- das erzeugt
    Phantom-Eintraege in hybrid_erkennungslaeufe (kein InvoiceProviderResult mit
    diesem Namen) und verhindert providerbasierte Tie-Break-/Konfliktlogik
    (hybrid_auswahl._TIE_BREAK_PROVIDER == "pdfplumber" kann sonst nie greifen).
    """
    return HybridKandidat(
        feld=k.feld,
        rohwert=k.rohwert,
        normwert=k.normwert,
        methode=k.methode,
        provider_name=provider_name if provider_name is not None else str(k.quelle),
        provider_version=provider_version,
        confidence=k.confidence,
        seite=seite,
    )
