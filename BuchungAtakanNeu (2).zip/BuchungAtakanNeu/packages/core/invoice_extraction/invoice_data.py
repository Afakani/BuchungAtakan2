"""InvoiceData — portiert aus Altprojekt src/invoice/invoice_data.py (Zwischenrepraesentation)."""
from dataclasses import dataclass
from typing import Optional


@dataclass
class InvoiceData:
    vendor_name: Optional[str] = None
    invoice_number: Optional[str] = None
    invoice_date: Optional[str] = None
    total_amount: Optional[float] = None
    net_amount: Optional[float] = None
    tax_amount: Optional[float] = None
    currency: Optional[str] = None
    payment_method: Optional[str] = None
    raw_text: Optional[str] = None
    confidence: float = 0.0
