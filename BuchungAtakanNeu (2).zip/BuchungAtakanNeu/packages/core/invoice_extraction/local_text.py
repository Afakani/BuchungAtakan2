"""LocalExtractedText — einheitliches Text-/Seitenmodell fuer lokale Provider (HYB-12).

Alle lokalen Provider (pdfplumber, invoice2data, PaddleOCR) bilden ihre Rohtextausgabe
auf dieses Modell ab, bevor der Text an Parser/Validierung weitergereicht wird. Es werden
keine Originaltexte dauerhaft zentral gespeichert -- das Modell ist ein Laufzeit-Objekt.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class LocalExtractedText:
    """Ein extrahiertes Textsegment (i.d.R. eine Seite) mit Herkunftsangaben."""

    text: str
    seite: int | None
    quelle: str
    confidence: float
    methode: str
    provider_version: str | None = None

    def __post_init__(self) -> None:
        if self.text is None:
            raise ValueError("text darf nicht None sein")
        if not self.quelle:
            raise ValueError("quelle darf nicht leer sein")
        if not self.methode:
            raise ValueError("methode darf nicht leer sein")
        if not (0.0 <= self.confidence <= 1.0):
            raise ValueError(
                f"confidence muss zwischen 0.0 und 1.0 liegen, war: {self.confidence}"
            )
