"""Excel-Export der Hybrid-Qualitaetsstatistik (HYB-19) -- kein Datenbank-, kein
Dateisystemzugriff. Nimmt ausschliesslich bereits aggregierte StatistikGruppe-Daten
entgegen (siehe hybrid_statistik.py) und erzeugt ein .xlsx-Workbook vollstaendig im
Speicher.

Enthaelt ausschliesslich: Gruppierungsdimensionen, aggregierte Gruppenschluessel,
Zaehler, Nenner, Quoten, statische Metrikdefinitionen. Keine Rechnungsnummern, keine
Rechnungsdaten, keine Einzelbetraege, keine Empfaengerdaten, keine Dateinamen, keine
Pfade, keine Hashes, keine Volltexte, keine OCR-Rohdaten, keine Kandidaten-Rohwerte,
keine Secrets. Anbietername erscheint nur als aggregierter Gruppenschluessel, wenn die
Dimension 'anbieter' angefordert wurde -- keine Pseudonymisierung in diesem Paket.
"""
from __future__ import annotations

from io import BytesIO

from openpyxl import Workbook

from packages.core.invoice_extraction.hybrid_statistik import (
    DIM_ANBIETER,
    DIM_DOKUMENT_KLASSE,
    DIM_METHODE,
    DIM_STATUS,
    StatistikGruppe,
)

_PROZENT_FORMAT = "0.00%"

_DIMENSION_SPALTE = {
    DIM_ANBIETER: "Anbieter",
    DIM_DOKUMENT_KLASSE: "Dokumenttyp",
    DIM_METHODE: "Methode",
    DIM_STATUS: "Status",
}

#: Reihenfolge und Namen der Quoten -- identisch zur bestehenden HYB-18-Reihenfolge
#: (hybrid_statistik.py-Docstring, StatistikGruppe-Feldreihenfolge, Router-Response).
_QUOTEN_SPALTEN = (
    ("Vollstaendigkeitsquote", "vollstaendigkeitsquote"),
    ("Richtigkeitsquote", "richtigkeitsquote"),
    ("Automatisierungsquote", "automatisierungsquote"),
    ("Pruefquote", "pruefquote"),
    ("Nichterkennungsquote", "nichterkennungsquote"),
)

_METRIK_DEFINITIONEN = (
    ("Vollstaendigkeitsquote", "Statusentscheidungen mit pflichtfelder_ok=True / Anzahl Statusentscheidungen je Gruppe"),
    ("Richtigkeitsquote", "Auditierte Statusentscheidungen mit neuester Bewertung gesamtergebnis_korrekt=True / auditierte Statusentscheidungen je Gruppe"),
    ("Automatisierungsquote", "Statusentscheidungen mit Status OK / Anzahl Statusentscheidungen je Gruppe"),
    ("Pruefquote", "Statusentscheidungen mit Status MUSS_GEPRUEFT_WERDEN / Anzahl Statusentscheidungen je Gruppe"),
    ("Nichterkennungsquote", "Statusentscheidungen mit Status NICHT_GEFUNDEN / Anzahl Statusentscheidungen je Gruppe"),
    ("Nenner 0", "Quote wird als leere Zelle ausgegeben -- kein vorgetaeuschtes 0%. Zaehler und Nenner bleiben sichtbar."),
)


def _statistik_header(dimensionen: tuple[str, ...]) -> list[str]:
    header = [_DIMENSION_SPALTE.get(d, d) for d in dimensionen]
    header.append("Anzahl")
    for name, _ in _QUOTEN_SPALTEN:
        header.extend([f"{name} Zaehler", f"{name} Nenner", f"{name} Quote"])
    return header


def _schreibe_statistik_sheet(ws, gruppen: list[StatistikGruppe], dimensionen: tuple[str, ...]) -> None:
    header = _statistik_header(dimensionen)
    ws.append(header)

    anzahl_spalte = len(dimensionen) + 1
    for gruppe in sorted(gruppen, key=lambda g: g.dimensionswerte):
        zeile: list[object] = list(gruppe.dimensionswerte) + [gruppe.anzahl]
        for _, attr in _QUOTEN_SPALTEN:
            quote = getattr(gruppe, attr)
            zeile.extend([quote.zaehler, quote.nenner, quote.quote])
        ws.append(zeile)

    # Spalten je Metrik: Zaehler, Nenner, Quote -- die "Quote"-Spalte ist die dritte
    # je 3er-Block, direkt nach "Anzahl" beginnend.
    erste_quote_spalte = anzahl_spalte + 3
    for zeilen_idx in range(2, ws.max_row + 1):
        for metrik_idx in range(len(_QUOTEN_SPALTEN)):
            quote_spalte = erste_quote_spalte + metrik_idx * 3
            zelle = ws.cell(row=zeilen_idx, column=quote_spalte)
            zelle.number_format = _PROZENT_FORMAT


def _schreibe_uebersicht_sheet(ws, gruppen: list[StatistikGruppe], dimensionen: tuple[str, ...]) -> None:
    dimensions_namen = ", ".join(_DIMENSION_SPALTE.get(d, d) for d in dimensionen) or "(keine)"
    ws.append(["Hybrid-Qualitaetsstatistik"])
    ws.append(["Gruppierung", dimensions_namen])
    ws.append(["Anzahl Gruppen", len(gruppen)])
    ws.append(["Status", "OK" if gruppen else "LEER"])


def _schreibe_metriken_sheet(ws) -> None:
    ws.append(["Metrik", "Definition"])
    for name, definition in _METRIK_DEFINITIONEN:
        ws.append([name, definition])


def erstelle_hybrid_statistik_workbook_bytes(
    gruppen: list[StatistikGruppe],
    dimensionen: tuple[str, ...],
) -> bytes:
    """Erzeugt ein .xlsx-Workbook vollstaendig im Speicher und gibt dessen Bytes zurueck.

    Kein Datenbankzugriff, kein Dateisystemzugriff. Deterministisch: gleiche Eingabe
    ergibt gleiche Zellwerte, Struktur und Sortierung -- Reihenfolge der Eingabeliste
    beeinflusst das Ergebnis nicht (Gruppen werden nach dimensionswerte sortiert).
    Leere Statistik erzeugt ein gueltiges Workbook mit Headern und Status 'LEER'.
    """
    workbook = Workbook()

    uebersicht = workbook.active
    uebersicht.title = "Uebersicht"
    _schreibe_uebersicht_sheet(uebersicht, gruppen, dimensionen)

    statistik = workbook.create_sheet("Statistik")
    _schreibe_statistik_sheet(statistik, gruppen, dimensionen)

    metriken = workbook.create_sheet("Metriken")
    _schreibe_metriken_sheet(metriken)

    puffer = BytesIO()
    workbook.save(puffer)
    return puffer.getvalue()
