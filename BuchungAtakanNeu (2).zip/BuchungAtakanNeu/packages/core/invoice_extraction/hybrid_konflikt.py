"""Automatische Konflikterkennung zwischen Kandidaten mehrerer Provider (HYB-14).

Nimmt bereits normalisierte Kandidaten (siehe hybrid_normalisierung.normalisiere_kandidat)
entgegen und gruppiert sie je Feld. Abweichende Normwerte werden nie still aufgeloest --
sie werden als KonfliktBefund sichtbar. Die Erkennung selbst ist rein strukturell
(deterministisch nach Feld/Normwert sortiert); die fachliche Aufloesung liegt bei
hybrid_auswahl.
"""
from __future__ import annotations

from dataclasses import dataclass

from packages.core.invoice_extraction.hybrid_ergebnis import PFLICHT_FELDER
from packages.core.invoice_extraction.hybrid_kandidat import HybridKandidat


@dataclass(frozen=True)
class KonfliktBefund:
    """Ein erkannter Konflikt zwischen Kandidaten desselben Feldes."""

    feld: str
    kandidaten: tuple[HybridKandidat, ...]
    werte: tuple[str, ...]
    provider: tuple[str, ...]
    konfliktart: str
    begruendung: str
    schweregrad: str
    aufloesungsstatus: str = "OFFEN"


def _konfliktart(feld: str, provider: tuple[str, ...]) -> str:
    if "paddleocr" in provider:
        return "OCR_VS_TEXT_ABWEICHUNG"
    if "invoice2data" in provider and "pdfplumber" in provider:
        return "PARSER_VS_TEMPLATE_ABWEICHUNG"
    return "PROVIDER_WERTABWEICHUNG"


def erkenne_konflikte(kandidaten: list[HybridKandidat]) -> list[KonfliktBefund]:
    """Erkennt Konflikte je Feld unter bereits normalisierten Kandidaten.

    Ein Konflikt entsteht, sobald mindestens zwei verwertbare (erfolgreich
    normalisierte) Kandidaten desselben Feldes unterschiedliche Normwerte tragen.
    Reihenfolge der Eingabeliste beeinflusst das Ergebnis nicht (Gruppierung +
    deterministische Sortierung).
    """
    felder = sorted({k.feld for k in kandidaten})
    konflikte: list[KonfliktBefund] = []

    for feld in felder:
        verwertbar = [
            k for k in kandidaten
            if k.feld == feld and k.normwert is not None
            and k.validierungsbefund == "NORMALISIERT_OK"
        ]
        distinct_werte = sorted({k.normwert for k in verwertbar})
        if len(distinct_werte) < 2:
            continue

        beteiligt = sorted(verwertbar, key=lambda k: (k.normwert, k.provider_name, k.rohwert))
        provider = tuple(sorted({k.provider_name for k in beteiligt}))
        schweregrad = "HOCH" if feld in PFLICHT_FELDER else "MITTEL"
        konfliktart = _konfliktart(feld, provider)
        begruendung = (
            f"Feld '{feld}': {len(distinct_werte)} abweichende Werte "
            f"{list(distinct_werte)} von Providern {list(provider)}"
        )
        konflikte.append(KonfliktBefund(
            feld=feld,
            kandidaten=tuple(beteiligt),
            werte=tuple(distinct_werte),
            provider=provider,
            konfliktart=konfliktart,
            begruendung=begruendung,
            schweregrad=schweregrad,
        ))

    return konflikte
