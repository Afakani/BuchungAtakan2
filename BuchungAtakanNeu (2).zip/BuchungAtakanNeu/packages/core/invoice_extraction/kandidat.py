"""Kandidat-Modell fuer RECH-01: Per-Feld-Nachvollziehbarkeit bei Rechnungsextraktion."""
from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class KandidatQuelle(StrEnum):
    PDF_TEXT = "pdf_text"
    OCR = "ocr"
    E_RECHNUNG = "e_rechnung"


RECHNUNGS_FELDER = frozenset({
    "vendor_name",
    "invoice_number",
    "invoice_date",
    "total_amount",
    "net_amount",
    "tax_amount",
    "currency",
    "payment_method",
})


@dataclass(frozen=True)
class Kandidat:
    feld: str
    rohwert: str
    normwert: str | None
    methode: str
    quelle: str
    confidence: float

    def __post_init__(self) -> None:
        if not self.feld:
            raise ValueError("feld darf nicht leer sein")
        if self.rohwert is None:
            raise ValueError("rohwert darf nicht None sein")
        if not (0.0 <= self.confidence <= 1.0):
            raise ValueError(f"confidence muss zwischen 0.0 und 1.0 liegen, war: {self.confidence}")
        if not self.methode:
            raise ValueError("methode darf nicht leer sein")
        if not self.quelle:
            raise ValueError("quelle darf nicht leer sein")
