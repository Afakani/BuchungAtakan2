"""LocalInvoiceProviderOrchestrator — schlanke lokale Provider-Orchestrierung (HYB-09..13).

Waehlt anhand Dokumentklasse und Feature-Flags aktive lokale Provider aus, ruft sie auf,
isoliert Providerfehler und sammelt Kandidaten/Befunde ein. Trifft KEINE finale fachliche
Auswahl zwischen konkurrierenden Kandidaten (07-03) und instanziiert nie einen
Cloud-Provider -- Azure bleibt deaktiviert und unberuehrt.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from packages.core.invoice_extraction.document_classifier import (
    DokumentKlasse,
    klassifiziere_pfad,
)
from packages.core.invoice_extraction.hybrid_kandidat import HybridKandidat
from packages.core.invoice_extraction.invoice2data_provider import (
    Invoice2DataProvider,
    ist_aktiviert as invoice2data_ist_aktiviert,
)
from packages.core.invoice_extraction.paddleocr_provider import (
    PaddleOCRProvider,
    ist_aktiviert as paddleocr_ist_aktiviert,
)
from packages.core.invoice_extraction.pdfplumber_provider import PdfplumberProvider
from packages.core.invoice_extraction.provider_ports import (
    InvoiceCandidateProvider,
    InvoiceProviderResult,
)


@dataclass
class LocalOrchestratorErgebnis:
    """Gesammelte Provider-Ergebnisse eines lokalen Erkennungslaufs -- keine finale Auswahl."""

    dokument_klasse: DokumentKlasse
    provider_ergebnisse: list[InvoiceProviderResult] = field(default_factory=list)

    @property
    def kandidaten(self) -> list[HybridKandidat]:
        return [k for ergebnis in self.provider_ergebnisse for k in ergebnis.kandidaten]


def _aktive_provider(
    dokument_klasse: DokumentKlasse, settings: Any
) -> list[InvoiceCandidateProvider]:
    """Waehlt aktivierte lokale Provider passend zur Dokumentklasse aus.

    pdfplumber laeuft fuer TEXT_PDF (HYB-09, bestehender Pfad bleibt massgeblich).
    invoice2data laeuft zusaetzlich fuer TEXT_PDF, wenn per Flag aktiviert (HYB-10).
    PaddleOCR laeuft fuer SCAN_PDF, wenn per Flag aktiviert (HYB-11).
    Fuer SONDERFORMAT/UNBEKANNT laeuft kein lokaler Provider (Umfang 07-02).
    Cloud-Provider werden hier nie instanziiert.
    """
    provider: list[InvoiceCandidateProvider] = []

    if dokument_klasse == DokumentKlasse.TEXT_PDF:
        provider.append(PdfplumberProvider())
        if invoice2data_ist_aktiviert(settings):
            provider.append(Invoice2DataProvider())
    elif dokument_klasse == DokumentKlasse.SCAN_PDF:
        if paddleocr_ist_aktiviert(settings):
            provider.append(PaddleOCRProvider())

    return provider


def fuehre_lokale_erkennung_aus(pdf_path: Path, settings: Any) -> LocalOrchestratorErgebnis:
    """Klassifiziert das Dokument, ruft aktive lokale Provider auf und sammelt Ergebnisse.

    Ein Providerfehler blockiert die anderen Provider nicht (HYB-13). Es wird keine
    finale fachliche Auswahl zwischen konkurrierenden Kandidaten getroffen.
    """
    dokument_klasse = klassifiziere_pfad(pdf_path)
    ergebnis = LocalOrchestratorErgebnis(dokument_klasse=dokument_klasse)

    for provider in _aktive_provider(dokument_klasse, settings):
        ergebnis.provider_ergebnisse.append(_sicher_ausfuehren(provider, pdf_path))

    return ergebnis


def _sicher_ausfuehren(provider: InvoiceCandidateProvider, pdf_path: Path) -> InvoiceProviderResult:
    """Ruft provider.extract() auf; faengt auch unerwartete Provider-Bugs ab (HYB-13).

    Provider fangen ihre eigenen Fehler bereits selbst ab; dieser zusaetzliche Schutz
    verhindert, dass ein defekter Provider die Orchestrierung insgesamt abbricht.
    """
    try:
        return provider.extract(pdf_path)
    except Exception as exc:
        return InvoiceProviderResult(
            provider_name=provider.name,
            provider_version=getattr(provider, "version", None),
            laufstatus="error",
            kandidaten=[],
            fehlercode=type(exc).__name__,
        )
