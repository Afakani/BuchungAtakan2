"""PDF-Textextraktion — portiert aus Altprojekt src/pdf/pdf_reader.py."""
from pathlib import Path

import pdfplumber

from packages.core.invoice_extraction.text_cleaner import PDFTextCleaner


class PDFReader:
    def __init__(self) -> None:
        self._cleaner = PDFTextCleaner()

    def extract_text(self, pdf_path: Path) -> str:
        pdf_path = Path(pdf_path)
        if not pdf_path.exists():
            raise FileNotFoundError(f"PDF nicht gefunden: {pdf_path}")
        if not pdf_path.is_file():
            raise ValueError(f"Pfad ist kein Datei: {pdf_path}")
        if pdf_path.suffix.lower() != ".pdf":
            raise ValueError(f"Keine PDF-Datei: {pdf_path}")

        pages_text: list[str] = []
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                text = page.extract_text()
                if text:
                    pages_text.append(text)

        full_text = "\n\n".join(pages_text)
        return self._cleaner.clean_text(full_text)

    def has_extractable_text(self, pdf_path: Path) -> bool:
        return len(self.extract_text(pdf_path).strip()) > 0
