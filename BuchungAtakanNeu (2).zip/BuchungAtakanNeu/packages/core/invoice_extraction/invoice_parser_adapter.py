"""InvoiceParserAdapter — wandelt InvoiceData-Felder in Kandidat-Liste um (RECH-01)."""
from __future__ import annotations

from pathlib import Path

from packages.core.invoice_extraction.extraction_result import ExtractionResult, ExtraktionsStatus
from packages.core.invoice_extraction.invoice_data import InvoiceData
from packages.core.invoice_extraction.invoice_parser import InvoiceParser
from packages.core.invoice_extraction.invoice_validator import validate
from packages.core.invoice_extraction.kandidat import Kandidat, KandidatQuelle
from packages.core.invoice_extraction.pdf_reader import PDFReader

_PARSER = InvoiceParser()
_READER = PDFReader()

_METHODE = "regex_label"
_QUELLE = KandidatQuelle.PDF_TEXT


def _float_normwert(value: float | None) -> str | None:
    return f"{value:.2f}" if value is not None else None


def _str_normwert(value: str | None) -> str | None:
    return value.strip() if value else None


def invoice_data_to_kandidaten(data: InvoiceData, confidence_override: float | None = None) -> list[Kandidat]:
    """Wandelt InvoiceData in eine Liste von Kandidaten um (ein Kandidat pro gefülltem Feld)."""
    conf = confidence_override if confidence_override is not None else data.confidence
    kandidaten: list[Kandidat] = []

    field_map: list[tuple[str, object, str | None]] = [
        ("vendor_name", data.vendor_name, _str_normwert(data.vendor_name)),
        ("invoice_number", data.invoice_number, _str_normwert(data.invoice_number)),
        ("invoice_date", data.invoice_date, _str_normwert(data.invoice_date)),
        ("total_amount", data.total_amount, _float_normwert(data.total_amount)),
        ("net_amount", data.net_amount, _float_normwert(data.net_amount)),
        ("tax_amount", data.tax_amount, _float_normwert(data.tax_amount)),
        ("currency", data.currency, _str_normwert(data.currency)),
        ("payment_method", data.payment_method, _str_normwert(data.payment_method)),
    ]

    for feld, rohwert_raw, normwert in field_map:
        if rohwert_raw is None:
            continue
        rohwert = str(rohwert_raw)
        kandidaten.append(Kandidat(
            feld=feld,
            rohwert=rohwert,
            normwert=normwert,
            methode=_METHODE,
            quelle=_QUELLE,
            confidence=conf,
        ))

    return kandidaten


def extract_from_text(text: str) -> ExtractionResult:
    """Extrahiert aus rohem Text; wendet validate() an; gibt validiertes ExtractionResult zurück."""
    data = _PARSER.parse(text)
    kandidaten = invoice_data_to_kandidaten(data)
    raw_result = ExtractionResult(
        kandidaten=kandidaten,
        status=ExtraktionsStatus.OK,
        fehler=[],
        roher_text=text,
        confidence=data.confidence,
    )
    return validate(raw_result)


def extract_from_pdf(pdf_path: Path) -> ExtractionResult:
    """Liest PDF, extrahiert Text, gibt ExtractionResult zurück."""
    raw_text = _READER.extract_text(pdf_path)
    return extract_from_text(raw_text)
