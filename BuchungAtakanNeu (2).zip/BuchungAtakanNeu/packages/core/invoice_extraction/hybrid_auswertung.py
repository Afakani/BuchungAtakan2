"""Mehrprovider-Auswertung -- verbindet 07-02-Provider-Orchestrierung mit der
Qualitaetsentscheidung aus Paket 07-03 (HYB-14/15/16, HYB-07).

werte_lokale_erkennung_aus() gatet sich selbst ueber ist_hybrid_pipeline_aktiviert():
bei deaktiviertem Flag wird HybridPipelineDeaktiviertFehler ausgeloest, bevor
Normalisierung, Konflikterkennung, Auswahl oder Statusentscheidung laufen. Das Flag
steuert ausschliesslich diesen Auswertungsschritt -- die vorgelagerte Providerausfuehrung
(fuehre_lokale_erkennung_aus, 07-02) bleibt unabhaengig davon und wird weiterhin
ausschliesslich durch die jeweils eigenen, separaten Provider-Flags gesteuert.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from packages.core.invoice_extraction.document_classifier import DokumentKlasse
from packages.core.invoice_extraction.hybrid_auswahl import waehle_kandidaten
from packages.core.invoice_extraction.hybrid_ergebnis import HybridStatus
from packages.core.invoice_extraction.hybrid_kandidat import AuswahlStatus, HybridKandidat
from packages.core.invoice_extraction.hybrid_konflikt import KonfliktBefund, erkenne_konflikte
from packages.core.invoice_extraction.hybrid_normalisierung import normalisiere_kandidat
from packages.core.invoice_extraction.hybrid_plausibilitaet import (
    PlausibilitaetsBefund,
    pruefe_anbieter_bestimmbar,
    pruefe_betrag_nicht_negativ,
    pruefe_betragsrelation,
    pruefe_rechnungsdatum_plausibel,
    pruefe_rechnungsnummer_plausibel,
    pruefe_steuer_nicht_negativ,
    pruefe_waehrung_konsistent,
)
from packages.core.invoice_extraction.hybrid_qualitaetsentscheidung import berechne_finalen_status
from packages.core.invoice_extraction.local_provider_orchestrator import LocalOrchestratorErgebnis
from packages.core.invoice_extraction.provider_ports import InvoiceProviderResult


def ist_hybrid_pipeline_aktiviert(settings: Any) -> bool:
    return bool(getattr(settings, "BUCHUNG_ATAKAN_FEATURE_HYBRID_PIPELINE", False))


class HybridPipelineDeaktiviertFehler(RuntimeError):
    """Fail-closed: Hybrid-Auswertung angefordert, obwohl das Pipeline-Flag aus ist."""


@dataclass(frozen=True)
class HybridAuswertungsErgebnis:
    """Vollstaendiges, auditierbares Ergebnis der Mehrprovider-Auswertung."""

    kandidaten: list[HybridKandidat] = field(default_factory=list)
    konflikte: list[KonfliktBefund] = field(default_factory=list)
    plausibilitaet: list[PlausibilitaetsBefund] = field(default_factory=list)
    status: HybridStatus = HybridStatus.NICHT_GEFUNDEN
    gruende: list[str] = field(default_factory=list)
    provider_ergebnisse: list[InvoiceProviderResult] = field(default_factory=list)
    #: DokumentKlasse des zugrundeliegenden Dokuments (07-03A) -- None wenn unbekannt.
    dokument_klasse: DokumentKlasse | None = None


def _wert_fuer_feld(kandidaten: list[HybridKandidat], feld: str) -> str | None:
    for k in kandidaten:
        if k.feld == feld and k.auswahl_status == AuswahlStatus.AUSGEWAEHLT:
            return k.normwert
    return None


def _alle_normalisierten_werte(kandidaten: list[HybridKandidat], feld: str) -> list[str | None]:
    """Alle erfolgreich normalisierten Werte eines Feldes -- unabhaengig vom
    Auswahlstatus. Fuer die Waehrungskonsistenz (Paket 07-06) zaehlt jeder
    Provider-Kandidat: ein Widerspruch EUR/USD darf nie unbemerkt bleiben, auch
    wenn die Auswahl einen Gewinner bestimmt hat."""
    return [
        k.normwert for k in kandidaten
        if k.feld == feld and k.normwert is not None
        and k.validierungsbefund == "NORMALISIERT_OK"
    ]


def _berechne_plausibilitaet(kandidaten: list[HybridKandidat]) -> list[PlausibilitaetsBefund]:
    brutto = _wert_fuer_feld(kandidaten, "total_amount")
    netto = _wert_fuer_feld(kandidaten, "net_amount")
    steuer = _wert_fuer_feld(kandidaten, "tax_amount")
    datum = _wert_fuer_feld(kandidaten, "invoice_date")
    rechnungsnummer = _wert_fuer_feld(kandidaten, "invoice_number")
    anbieter = _wert_fuer_feld(kandidaten, "vendor_name")
    alle_waehrungen = _alle_normalisierten_werte(kandidaten, "currency")

    return [
        pruefe_betragsrelation(brutto, netto, steuer),
        pruefe_steuer_nicht_negativ(steuer),
        pruefe_betrag_nicht_negativ("total_amount", brutto),
        pruefe_betrag_nicht_negativ("net_amount", netto),
        pruefe_waehrung_konsistent(alle_waehrungen),
        pruefe_rechnungsdatum_plausibel(datum),
        pruefe_rechnungsnummer_plausibel(rechnungsnummer),
        pruefe_anbieter_bestimmbar(anbieter),
    ]


def werte_lokale_erkennung_aus(
    orchestrator_ergebnis: LocalOrchestratorErgebnis,
    settings: Any,
) -> HybridAuswertungsErgebnis:
    """Fuehrt Normalisierung, Konflikterkennung, Auswahl, Plausibilitaet und
    finale Statusentscheidung fuer die Kandidaten eines 07-02-Erkennungslaufs aus.

    Fail-closed (HYB-07): Ist BUCHUNG_ATAKAN_FEATURE_HYBRID_PIPELINE nicht aktiviert,
    wird HybridPipelineDeaktiviertFehler ausgeloest, bevor irgendeine Normalisierungs-,
    Konflikt-, Auswahl- oder Statuslogik ausgefuehrt wird. Provider wurden zu diesem
    Zeitpunkt (orchestrator_ergebnis) bereits unabhaengig ueber eigene Flags gelaufen --
    dieses Gate beeinflusst das nicht.
    """
    if not ist_hybrid_pipeline_aktiviert(settings):
        raise HybridPipelineDeaktiviertFehler(
            "BUCHUNG_ATAKAN_FEATURE_HYBRID_PIPELINE ist deaktiviert -- "
            "Hybrid-Auswertung wird nicht ausgefuehrt."
        )

    normalisiert = [normalisiere_kandidat(k) for k in orchestrator_ergebnis.kandidaten]
    konflikte = erkenne_konflikte(normalisiert)
    kandidaten_final, konflikte_final = waehle_kandidaten(normalisiert, konflikte)
    plausibilitaet = _berechne_plausibilitaet(kandidaten_final)
    status, gruende = berechne_finalen_status(
        kandidaten_final, konflikte_final, plausibilitaet, orchestrator_ergebnis.provider_ergebnisse,
    )
    return HybridAuswertungsErgebnis(
        kandidaten=kandidaten_final,
        konflikte=konflikte_final,
        plausibilitaet=plausibilitaet,
        status=status,
        gruende=gruende,
        provider_ergebnisse=orchestrator_ergebnis.provider_ergebnisse,
        dokument_klasse=orchestrator_ergebnis.dokument_klasse,
    )
