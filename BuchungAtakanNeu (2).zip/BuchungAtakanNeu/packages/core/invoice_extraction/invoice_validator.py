"""InvoiceValidator — RECH-04/05: Mathematische und Feldtyp-Validierung."""
from __future__ import annotations

import re

from packages.core.invoice_extraction.extraction_result import ExtractionResult, ExtraktionsStatus
from packages.core.invoice_extraction.kandidat import Kandidat

_MATH_TOLERANCE = 0.02
_UST_ID_PATTERN = re.compile(r"^DE\d{9}$|^[A-Z]{2}\d{7,12}$", re.IGNORECASE)


def validate(result: ExtractionResult) -> ExtractionResult:
    """Prüft ExtractionResult; gibt neues Objekt mit aktualisiertem Status zurück."""
    fehler = list(result.fehler)
    status = result.status

    total_k = result.bestes_fuer_feld("total_amount")
    net_k = result.bestes_fuer_feld("net_amount")
    tax_k = result.bestes_fuer_feld("tax_amount")

    total = _as_float(total_k)
    net = _as_float(net_k)
    tax = _as_float(tax_k)

    # RECH-04: Netto + Steuer ≈ Gesamt
    if total is not None and net is not None and tax is not None:
        diff = abs((net + tax) - total)
        if diff > _MATH_TOLERANCE:
            fehler.append(f"RECH-04: Netto({net}) + Steuer({tax}) = {net+tax:.2f} ≠ Gesamt({total}), Differenz {diff:.2f}")
            if status == ExtraktionsStatus.OK:
                status = ExtraktionsStatus.MATH_FEHLER

    # RECH-05: Steuerbetrag ≠ Versandkosten (häufige Werte: 4.99, 5.99, 6.99)
    if tax is not None and total is not None and net is not None:
        expected_tax = round(total - net, 2) if total > net else None
        if expected_tax is not None and abs(tax - expected_tax) > _MATH_TOLERANCE:
            if tax in {4.99, 5.99, 6.99, 7.99, 3.99, 2.99}:
                fehler.append(f"RECH-05: Steuerbetrag ({tax}) sieht nach Versandkosten aus, erwartet {expected_tax:.2f}")
                if status == ExtraktionsStatus.OK:
                    status = ExtraktionsStatus.PRUEFFALL

    # RECH-05: USt-ID darf nicht als Rechnungsnummer freigegeben werden
    inv_nr_k = result.bestes_fuer_feld("invoice_number")
    if inv_nr_k is not None:
        rohwert = inv_nr_k.rohwert.strip().replace(" ", "")
        if _UST_ID_PATTERN.match(rohwert):
            fehler.append(f"RECH-05: invoice_number '{rohwert}' sieht wie eine USt-ID aus — Freigabesperre")
            if status == ExtraktionsStatus.OK:
                status = ExtraktionsStatus.PRUEFFALL

    # Pflichtfelder fehlen?
    missing = result.fehlende_pflichtfelder
    if missing and status == ExtraktionsStatus.OK:
        fehler.append(f"RECH-02: Pflichtfelder fehlen: {', '.join(sorted(missing))}")
        status = ExtraktionsStatus.UNVOLLSTAENDIG

    return ExtractionResult(
        kandidaten=result.kandidaten,
        status=status,
        fehler=fehler,
        roher_text=result.roher_text,
        confidence=result.confidence,
    )


def _as_float(k: Kandidat | None) -> float | None:
    if k is None or k.normwert is None:
        return None
    try:
        return float(k.normwert)
    except (ValueError, TypeError):
        return None
