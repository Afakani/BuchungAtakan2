"""InvoiceExtractionPort — Erweiterungspunkt per ENTWICKLUNGSPLAN §5."""
from pathlib import Path
from typing import Protocol

from packages.core.invoice_extraction.extraction_result import ExtractionResult


class InvoiceExtractionPort(Protocol):
    def extract(self, pdf_path: Path) -> ExtractionResult: ...
