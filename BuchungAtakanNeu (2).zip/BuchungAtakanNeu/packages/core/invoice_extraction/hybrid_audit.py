"""Strukturiertes Audit-Booleanmodell fuer HybridStatusentscheidungen (HYB-17).

Ausschliesslich strukturierte Feldbewertungen -- kein Freitext, keine Notiz, kein
Kommentar, keine Originalwerte, keine Rechnungsnummer, keine Betraege, keine
Rechnungsdaten, keine Dateinamen, keine Pfade, keine Hashes, keine Volltexte.

Audit-Bewertungen sind append-only (Persistenzschicht) -- dieses Modul kennt keine
Datenbank und trifft keine Aussage ueber Historie ausser der reinen Auswahl der
neuesten Bewertung aus einer bereits geladenen Liste.
"""
from __future__ import annotations

from dataclasses import dataclass, fields
from datetime import datetime
from uuid import UUID

#: Reihenfolge der strukturierten Auditfelder -- massgeblich fuer Ableitung und Tests.
AUDIT_FELDER = (
    "rechnungsnummer_korrekt",
    "rechnungsdatum_korrekt",
    "gesamtbetrag_korrekt",
    "lieferant_korrekt",
    "steuerwerte_korrekt",
    "empfaenger_korrekt",
)


@dataclass(frozen=True)
class AuditBewertungFelder:
    """Strukturierte Feldbewertung -- jedes Feld ist ein reiner Boolean.

    `bool` ist in Python eine Unterklasse von `int`; die explizite isinstance-Pruefung
    in __post_init__ lehnt trotzdem alles ab, was kein echter Boolean ist (z. B. Freitext).
    """

    rechnungsnummer_korrekt: bool
    rechnungsdatum_korrekt: bool
    gesamtbetrag_korrekt: bool
    lieferant_korrekt: bool
    steuerwerte_korrekt: bool
    empfaenger_korrekt: bool

    def __post_init__(self) -> None:
        for feld in fields(self):
            wert = getattr(self, feld.name)
            if not isinstance(wert, bool):
                raise TypeError(
                    f"{feld.name} muss ein Boolean sein, war: {type(wert).__name__}"
                )


def berechne_gesamtergebnis_korrekt(felder: AuditBewertungFelder) -> bool:
    """Leitet gesamtergebnis_korrekt deterministisch aus den Feldbewertungen ab.

    Korrekt nur, wenn alle Einzelfelder korrekt sind. Wird nicht gespeichert --
    die Persistenzschicht speichert ausschliesslich die Einzelfelder (HYB-17).
    """
    return all(getattr(felder, name) for name in AUDIT_FELDER)


@dataclass(frozen=True)
class BewertungEintrag:
    """Minimale Repraesentation einer persistierten Auditbewertung fuer die
    Auswahl der neuesten Bewertung -- kein Freitext, keine Originalwerte."""

    id: UUID
    bewertet_am: datetime
    felder: AuditBewertungFelder


def waehle_neueste_bewertung(bewertungen: list[BewertungEintrag]) -> BewertungEintrag | None:
    """Waehlt die neueste Bewertung: bewertet_am DESC, bei Gleichstand id DESC.

    Append-only-Bewertungen ueberschreiben sich nie -- fuer Statistik und
    Latest-Endpunkt zaehlt ausschliesslich diese deterministische Auswahl.
    """
    if not bewertungen:
        return None
    return max(bewertungen, key=lambda b: (b.bewertet_am, b.id))
