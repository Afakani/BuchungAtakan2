"""PDF-Textbereinigung — portiert aus Altprojekt src/pdf/pdf_text_cleaner.py."""
import re


class PDFTextCleaner:
    @staticmethod
    def clean_text(text: str) -> str:
        if not text:
            return ""
        text = text.replace("\r\n", "\n").replace("\r", "\n")
        lines = text.split("\n")
        cleaned_lines = [PDFTextCleaner.clean_line(ln) for ln in lines if PDFTextCleaner.clean_line(ln)]
        cleaned_text = "\n".join(cleaned_lines)
        return PDFTextCleaner.reduce_empty_lines(cleaned_text).strip()

    @staticmethod
    def clean_line(line: str) -> str:
        if not line:
            return ""
        return re.sub(r"[ \t]+", " ", line.strip())

    @staticmethod
    def reduce_empty_lines(text: str) -> str:
        return re.sub(r"\n{3,}", "\n\n", text)
