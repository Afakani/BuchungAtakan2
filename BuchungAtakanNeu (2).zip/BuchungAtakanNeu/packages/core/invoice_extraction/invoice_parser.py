"""InvoiceParser — portiert aus Altprojekt src/invoice/invoice_parser.py.

Paket 07-06 (Pre-Realtest-Haertung): Betragsbereinigung nach betrag_utils.py
ausgelagert (Tausenderpunkt-Fix, gemeinsam mit hybrid_normalisierung genutzt) und
Kalendervalidierung in _extract_date_from_string ergaenzt -- sonst unveraendert.
"""
import re
from datetime import date
from typing import Optional

from packages.core.invoice_extraction.betrag_utils import bereinige_betrag_string
from packages.core.invoice_extraction.invoice_data import InvoiceData


class InvoiceParser:
    """
    Extrahiert strukturierte Rechnungsdaten aus PDF-Text.
    Label-basiert, damit OCR-Müllzahlen nicht als Beträge gespeichert werden.
    """

    AMOUNT_PATTERN = r"-?(?:\d{1,3}(?:[.\s]\d{3})+|\d+)(?:[,.]\d{1,2})"
    AMOUNT_PATTERN_OCR = r"-?(?:\d{1,3}(?:[.\s]\d{3})+|\d+)(?:[,.\s]\s?\d{1,2})"

    MONTHS = {
        "januar": "01", "jan": "01",
        "februar": "02", "feb": "02",
        "märz": "03", "maerz": "03", "mrz": "03",
        "april": "04", "apr": "04",
        "mai": "05",
        "juni": "06", "jun": "06",
        "juli": "07", "jul": "07",
        "august": "08", "aug": "08",
        "september": "09", "sep": "09", "sept": "09",
        "oktober": "10", "okt": "10",
        "november": "11", "nov": "11",
        "dezember": "12", "dez": "12",
        "january": "01", "february": "02", "march": "03", "april": "04",
        "may": "05", "june": "06", "july": "07", "august": "08",
        "september": "09", "october": "10", "november": "11", "december": "12",
    }

    def parse(self, text: str) -> InvoiceData:
        if not text:
            return InvoiceData(raw_text=text, confidence=0.0)
        try:
            cleaned_text = self._normalize_text(text)
            invoice_data = InvoiceData(
                vendor_name=self.extract_vendor_name(cleaned_text),
                invoice_number=self.extract_invoice_number(cleaned_text),
                invoice_date=self.extract_invoice_date(cleaned_text),
                total_amount=self.extract_total_amount(cleaned_text),
                net_amount=self.extract_net_amount(cleaned_text),
                tax_amount=self.extract_tax_amount(cleaned_text),
                currency=self.extract_currency(cleaned_text),
                payment_method=self.extract_payment_method(cleaned_text),
                raw_text=text,
            )
            self._reconcile_amounts(invoice_data)
            invoice_data.confidence = self.calculate_confidence(invoice_data)
            return invoice_data
        except Exception:
            return InvoiceData(raw_text=text, confidence=0.0)

    @staticmethod
    def _normalize_text(text: str) -> str:
        text = text.replace("\r\n", "\n").replace("\r", "\n").replace("\xa0", " ").replace("−", "-")
        text = re.sub(r"[ \t]+", " ", text)
        return text.strip()

    @classmethod
    def _normalize_amount_text(cls, text: str) -> str:
        normalized = cls._normalize_text(text)
        normalized = re.sub(
            r"(\d{1,6})[,\.](\s)(\d{1,2})\s*C[b]?\b",
            lambda m: f"{m.group(1)},{m.group(3)} EUR",
            normalized,
            flags=re.IGNORECASE,
        )
        normalized = re.sub(r"(\d{1,6}[,.]\s?\d{1,2})\s*C\b", r"\1 EUR", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"(\d{1,6}[,.]\s?\d{1,2})\s*Cb\b", r"\1 EUR", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"(\d{1,6})[,\.][ \t](\d{2})\b", r"\1,\2", normalized)
        normalized = re.sub(r"(\d{1,6})[,\.]\s+(\d{1,2})\b", r"\1,\2", normalized)
        normalized = re.sub(r"(?<!\d)(\d)\s+(\d)\s*%", r"\1\2%", normalized)
        normalized = re.sub(r"\bEUlt\b", "EUR", normalized, flags=re.IGNORECASE)
        return normalized

    def extract_vendor_name(self, text: str) -> Optional[str]:
        lines = self._non_empty_lines(text)

        label_patterns = [
            r"Verkauft\s+von\s+([^\n]+)",
            r"Informationen\s+zum\s+Verkäufer\s*:?\s*([^\n]+)",
            r"Der\s+Verkauf\s+erfolgte\s+im\s+Namen\s+und\s+auf\s+Rechnung\s+von\s+([^\n\.]+)",
            r"Rechnungsaussteller\s*:?\s*([^\n]+)",
            r"Seller\s*:?\s*([^\n]+)",
            r"Vendor\s*:?\s*([^\n]+)",
            r"Empfänger\s*:\s*([^\n]+(?:GmbH|UG|AG|KG|GbR|Ltd|Limited|S\.?A\.?|S\.à\s*r\.l\.)[^\n]*)",
        ]

        for pattern in label_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                vendor = self._clean_vendor_name(match.group(1))
                if vendor and not self._looks_like_private_person(vendor):
                    return vendor

        for index, line in enumerate(lines[:30]):
            if "|" not in line:
                continue
            if self._line_index_is_in_recipient_context(lines, index):
                continue
            if self._find_amounts_in_line(line) or re.search(
                r"\b(pos|artikel|produkt|beschreibung|menge|preis|gesamt|sku)\b", line, re.IGNORECASE
            ):
                continue
            raw_vendor = line.split("|")[0].strip(" .,:;|-/")
            vendor = self._clean_vendor_name(raw_vendor) or raw_vendor
            if vendor and not self._is_bad_vendor_line(vendor) and 3 <= len(vendor) <= 100:
                return vendor

        for index, line in enumerate(lines[:12]):
            if self._line_is_inside_recipient_block(lines, line, index):
                continue
            vendor = self._clean_vendor_name(line)
            if vendor and self._has_legal_form(vendor):
                return vendor

        for line in lines[:12]:
            m = re.match(r"^(MM\s+[A-Za-zÄÖÜäöüß -]{3,40})\b", line.strip())
            if m:
                vendor = self._clean_vendor_name(m.group(1)) or m.group(1).strip()
                if vendor:
                    return vendor

        for match in re.finditer(r"(?m)^\s*([A-ZÄÖÜa-zäöüß][A-ZÄÖÜa-zäöüß0-9 &.\-]{2,55})\s+Nr\.?\s+\d{3,}\s*$", text):
            vendor = self._clean_vendor_name(match.group(1))
            if vendor and not self._is_bad_vendor_line(vendor) and not self._looks_like_private_person(vendor):
                return vendor

        address_label_patterns = [
            r"Anschrift\s*:\s*([^,\n]{3,100})\s*,",
            r"Kontakt\s*:\s*([^,\n]{3,100})\s*,",
            r"Firma\s*:\s*([^\n]{3,100})",
        ]
        for pattern in address_label_patterns:
            for match in re.finditer(pattern, text, re.IGNORECASE):
                vendor = self._clean_vendor_name(match.group(1))
                if vendor and not self._looks_like_private_person(vendor):
                    return vendor

        footer_vendor = self._extract_vendor_from_supplier_context(lines)
        if footer_vendor:
            return footer_vendor

        company_candidates: list[tuple[int, str]] = []
        for index, line in enumerate(lines[:260]):
            if self._line_index_is_in_recipient_context(lines, index):
                continue
            vendor = self._clean_vendor_name(line)
            if not vendor or not self._has_legal_form(vendor) or self._is_bad_vendor_line(vendor):
                continue
            score = self._score_vendor_candidate(line, index)
            company_candidates.append((score, vendor))

        if company_candidates:
            company_candidates.sort(key=lambda item: item[0], reverse=True)
            seen: set[str] = set()
            for _, candidate in company_candidates:
                key = candidate.lower()
                if key not in seen:
                    return candidate
                seen.add(key)

        n = len(lines)
        tail_start = max(0, n - 60)
        _vendor_search: list[tuple[int, str]] = [(i, ln) for i, ln in enumerate(lines) if i < 25 or i >= tail_start]
        for idx, line in _vendor_search:
            if self._line_is_inside_recipient_block(lines, line, idx):
                continue
            l = line.strip()
            if self._is_bad_vendor_line(l) or "@" in l:
                continue
            if self._find_amounts_in_line(l) or re.search(r"\b(product|service|beschreibung|kvm|spiel|artikel|menge)\b", l, re.IGNORECASE):
                continue
            if re.search(r"\b(?:www\.)?[a-z0-9][a-z0-9-]+\.(?:de|com|shop|net|eu)\b", l, re.IGNORECASE):
                domain = re.search(r"\b(?:www\.)?([a-z0-9][a-z0-9-]+)\.(?:de|com|shop|net|eu)\b", l, re.IGNORECASE)
                if domain:
                    vendor = self._clean_vendor_name(domain.group(1).replace("-", " ").title())
                    if vendor and not self._looks_like_private_person(vendor):
                        return vendor

        for index, line in enumerate(lines[:25]):
            if self._line_index_is_in_recipient_context(lines, index):
                continue
            l = line.strip()
            lower = l.lower()
            if self._is_bad_vendor_line(l) or self._looks_like_private_person(l):
                continue
            if not (3 <= len(l) <= 55):
                continue
            if re.search(r"\d{3,}|@|iban|bic|ust|vat", lower):
                continue
            if re.search(r"[A-Za-zÄÖÜäöüß]", l):
                return self._clean_vendor_name(l)

        return None

    def extract_invoice_number(self, text: str) -> Optional[str]:
        patterns = [
            r"(?m)^Nummer\s+([0-9]{5,})\s*$",
            r"\bRECHNUNG:\s*([A-Z0-9][A-Z0-9_\-/\.]{2,})",
            r"\bRECHNUNG\s*[:]\s*([A-Z0-9][A-Z0-9_\-/\.\s]{2,})",
            r"\bRechnungsnummer\s+([\d][\d\s]{4,24}[\d])",
            r"\bRechnung[ \t]*[-]?[ \t]*Nr\.?[ \t]*[:.]?[ \t]*([A-Z0-9][A-Z0-9_\-/\. ]{1,})",
            r"\bRechnungs[ \t]*[-]?[ \t]*Nr\.?[ \t]*[:.]?[ \t]*([A-Z0-9][A-Z0-9_\-/\. ]{1,})",
            r"\bRechnungsnummer\s*[:.]?\s*([A-Z0-9][A-Z0-9_\-/\.]{1,})",
            r"(?m)^\s*Rechnung[ \t]+([A-Z0-9][A-Z0-9_\-/\.]{2,})\b",
            r"\bRECHNUNG\s*#\s*([A-Z0-9][A-Z0-9_\-/\.]{2,})",
            r"\b#\s*([0-9]{3,}[-/][A-Z0-9_\-/\.]+|[0-9]{3,})\b",
            r"\bInvoice\s*Number\s*[:.]?\s*([A-Z0-9][A-Z0-9_\-/\.]{2,})",
            r"\bInvoice\s*No\.?\s*[:.]?\s*([A-Z0-9][A-Z0-9_\-/\.]{2,})",
            r"\bInvoice\s*Nr\.?\s*[:.]?\s*([A-Z0-9][A-Z0-9_\-/\.]{2,})",
            r"\bQuittungs\s*[-]?\s*Nr\.?\s*[:.]?\s*([A-Z0-9][A-Z0-9_\-/\.]{2,})",
            r"\bBeleg\s*[-]?\s*Nr\.?\s*[:.]?\s*([A-Z0-9][A-Z0-9_\-/\.]{2,})",
            r"\bBon\s*[-]?\s*Nr\.?\s*[:.]?\s*([A-Z0-9][A-Z0-9_\-/\.]{2,})",
            r"\bRECHNUNG\s*/\s*QUITTUNG\s*Nr\.?\s*[:.]?\s*([A-Z0-9][A-Z0-9_\-/\.]{2,})",
        ]

        blacklist = {
            "anzugeben", "rechnung", "rechnungsnummer", "datum", "kunden", "kunden-nr",
            "nr", "rechnungsdatum", "bestellnummer", "lieferdatum", "zahlung",
        }

        for pattern in patterns:
            for match in re.finditer(pattern, text, re.IGNORECASE | re.DOTALL):
                value = match.group(1).strip()
                value = re.split(
                    r"\s+(?:Rechnungsdatum|Rech\.-Datum|Datum|Kunden-Nr|Kundennummer|Bestellnummer|Bestelldatum|Lieferdatum|Zahlungsmittel|IBAN|BIC)\b",
                    value, maxsplit=1, flags=re.IGNORECASE,
                )[0]
                value = re.split(r"\s{2,}|\n", value)[0]
                value = re.sub(r"\s+", "", value)
                value = value.strip(".,;:*-#")
                value = re.sub(r"(\d{3,})(\d{2}\.\d{2}\.\d{4})$", r"\1", value)

                if value.lower() in blacklist or not re.search(r"\d", value) or len(value) < 3:
                    continue
                return value

        return None

    def extract_invoice_date(self, text: str) -> Optional[str]:
        invoice_context_patterns = [
            r"Rechnung\s+Nr\.?\s*[:.]?\s*[A-Z0-9_\-/\.]+\s+(\d{1,2}\.\d{1,2}\.\d{2,4})",
            r"Rechnungsnummer\s*[:.]?\s*[A-Z0-9_\-/\.]+\s+Rechnungsdatum\s+([^\n]+)",
            r"Rechnung\s+[A-Z0-9_\-/\.]+\s+Rechnungsdatum\s*\n\s*([^\n]+)",
            r"RECHNUNG\s*/\s*QUITTUNG\s*Nr\.?\s*[:.]?\s*[A-Z0-9_\-/\.]+\s*[-–]\s*(\d{4}/\d{1,2}/\d{1,2})",
        ]
        for pattern in invoice_context_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                date = self._extract_date_from_string(match.group(1))
                if date:
                    return date

        city_date = re.search(r"\b[A-ZÄÖÜ][A-Za-zÄÖÜäöüß\-]+,\s*(\d{1,2}\.\d{1,2}\.\d{2,4})", text)
        if city_date:
            date = self._extract_date_from_string(city_date.group(1))
            if date:
                return date

        labeled_patterns = [
            r"Rechnungsdatum[:\s]+([^\n]+)",
            r"Rech\.-Datum[:\s]+([^\n]+)",
            r"Invoice Date[:\s]+([^\n]+)",
            r"(?m)^\s*Datum[:\s]+([^\n]+)",
            r"(?m)^\s*Date[:\s]+([^\n]+)",
        ]
        for pattern in labeled_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                date = self._extract_date_from_string(match.group(1))
                if date:
                    return date

        return self._extract_date_from_string(text)

    def extract_total_amount(self, text: str) -> Optional[float]:
        text = self._normalize_amount_text(text)

        direct_total_patterns = [
            r"Gesamtbetrag\s+von\s*(" + self.AMOUNT_PATTERN + r")\s*(?:EUR|€)",
            r"Der\s+Gesamtbetrag\s+von\s*(" + self.AMOUNT_PATTERN + r")\s*(?:EUR|€)",
        ]
        for pattern in direct_total_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                parsed = self._parse_amount(match.group(1))
                if parsed is not None:
                    return parsed

        high_priority_labels = [
            r"Rechnungsgesamtbetrag", r"Gesamtbetrag(?:\s*\(inkl\.?\s*MwSt\.?\))?",
            r"Gesamtbetrag\s+brutto", r"Gesamt[- ]?Brutto", r"Endsumme", r"Endbetrag",
            r"Zahlungsbetrag", r"Zahlbetrag", r"Rechnungsbetrag", r"Bruttobetrag",
            r"Gesamtsumme(?:\s+inkl\.\s*Mwst\.?)?", r"Gesamt\s+in\s+EUR", r"Gesamt\s*\(EUR\)",
            r"Gesamtpreis", r"Gesamtartikelpreis", r"Bestellbetrag",
            r"Total\s+with\s+VAT", r"Grand\s+Total",
        ]
        amount = self._extract_amount_by_labels(
            text, high_priority_labels, prefer_last=False, allow_previous_line=True,
            previous_line_first=False,
            exclude_line_patterns=[r"gesamt\s+netto", r"gesamtbetrag\s+netto", r"gesamt\s+ohne\s+mwst", r"summe\s+netto"],
        )
        if amount is not None:
            return amount

        amount = self._extract_from_tax_table(text, "total")
        if amount is not None:
            return amount

        return self._extract_amount_by_labels(
            text, [r"\bTotal\b", r"\bGesamt\b"], prefer_last=False, allow_previous_line=True,
            previous_line_first=True,
            exclude_line_patterns=[r"gesamt\s+netto", r"gesamtbetrag\s+netto", r"gesamt\s+ohne\s+mwst", r"summe\s+netto", r"zwischensumme"],
        )

    def extract_net_amount(self, text: str) -> Optional[float]:
        text = self._normalize_amount_text(text)
        amount = self._extract_from_tax_table(text, "net")
        if amount is not None:
            return amount
        amount = self._extract_tax_base_amount(text)
        if amount is not None:
            return amount
        m = re.search(r"Summe\s+Betrag\s*(" + self.AMOUNT_PATTERN + r")\s*(?:EUR|€)?", text, re.IGNORECASE)
        if m:
            parsed = self._parse_amount(m.group(1))
            if parsed is not None:
                return parsed
        labels = [
            r"Zwischensumme\s+Nettobetrag", r"Gesamtbetrag\s+netto", r"Nettobetrag",
            r"Netto\s+zu\s+\d{1,2}(?:[,.]\d{1,2})?%\s*Mwst\.?", r"Gesamt\s+ohne\s+MwSt\.?",
            r"Gesamt\s+Netto", r"Gesamt\s+netto", r"Summe\s+Netto", r"Sub\s+Total", r"Subtotal",
        ]
        return self._extract_amount_by_labels(text, labels, prefer_last=False)

    def extract_tax_amount(self, text: str) -> Optional[float]:
        text = self._normalize_amount_text(text)
        amount = self._extract_from_tax_table(text, "tax")
        if amount is not None:
            return amount
        amount = self._extract_tax_amount_from_ust_von_line(text)
        if amount is not None:
            return amount
        labels = [
            r"darin\s+enthaltene\s+\d{1,2}(?:[,.]\d{1,2})?%\s*Mwst\.?", r"Enthält",
            r"Umsatzsteuer", r"Mehrwertsteuer", r"MwSt\.?(?:\s*Betrag)?",
            r"Mwst\.?(?:\s*Betrag)?", r"USt\.?(?:\s*Betrag)?", r"Steuerbetrag", r"VAT", r"Tax",
        ]
        return self._extract_amount_by_labels(
            text, labels, prefer_last=True,
            exclude_line_patterns=["gesamtbetrag", "gesamtpreis", "zahlbetrag", "bruttobetrag", "endbetrag", "endsumme"],
        )

    def extract_currency(self, text: str) -> Optional[str]:
        normalized = self._normalize_amount_text(text)
        if "€" in normalized or re.search(r"\bEUR\b", normalized, re.IGNORECASE):
            return "EUR"
        if re.search(r"\d{1,6}[,.]\d{2}\s*C\b", text, re.IGNORECASE):
            return "EUR"
        return None

    def extract_payment_method(self, text: str) -> str:
        if not text:
            return "UNKNOWN"
        text_lower = text.lower()

        ec_card_keywords = [
            "cardpayment", "card payment", "card-payment", "ec-karte", "ec karte", "ec_card",
            "ec cash", "ec-cash", "electronic cash", "kartenzahlung", "karten zahlung",
            "kartenzahlung erfolgt", "zahlung erfolgt", "kundenbeleg", "girocard", "maestro",
            "mastercard", "visa", "debitkarte", "debit card", "kreditkarte", "contactless",
            "kontaktlos", "terminal-id", "terminal id", "trace-nr", "trace nr",
            "genehmigungs-nr", "genehmigungs nr", "autorisiert", "autorisierung", "pin-eingabe",
            "pin eingabe", "per ec", "per ec/lastschrift", "ec/lastschrift", "ec-lastschrift",
            "kartenumsatz",
        ]
        for kw in ec_card_keywords:
            if kw in text_lower:
                return "EC_CARD"

        for kw in ["paypal", "zahlart paypal", "zahlungsmethode paypal", "zahlung per paypal", "paid with paypal"]:
            if kw in text_lower:
                return "PAYPAL"

        for kw in ["banküberweisung", "bankueberweisung", "überweisung", "ueberweisung", "vorkasse",
                   "bitte überweisen", "bitte ueberweisen", "zahlung per überweisung",
                   "zahlung per ueberweisung", "zahlbar per überweisung", "zahlbar per ueberweisung"]:
            if kw in text_lower:
                return "BANK_TRANSFER"

        for kw in ["lastschrift", "sepa-lastschrift", "sepa lastschrift", "abbuchung", "wird abgebucht",
                   "buchen wir ab", "wird eingezogen", "ziehen wir ein", "mandatsreferenz",
                   "gläubiger-id", "glaeubiger-id"]:
            if kw in text_lower:
                return "DIRECT_DEBIT"

        for kw in ["barzahlung", "bar bezahlt", "betrag bar", "cash"]:
            if kw in text_lower:
                return "CASH"

        return "UNKNOWN"

    def calculate_confidence(self, invoice_data: InvoiceData) -> float:
        score = sum([
            bool(invoice_data.vendor_name),
            bool(invoice_data.invoice_number),
            bool(invoice_data.invoice_date),
            invoice_data.total_amount is not None,
            invoice_data.net_amount is not None,
            invoice_data.tax_amount is not None,
            bool(invoice_data.currency),
        ])
        return round(score / 7, 2)

    @staticmethod
    def _reconcile_amounts(invoice_data: InvoiceData) -> None:
        total = invoice_data.total_amount
        net = invoice_data.net_amount
        tax = invoice_data.tax_amount

        if tax in {7, 19, 0, 5, 10}:
            if total is not None and net is not None and total > net:
                invoice_data.tax_amount = round(total - net, 2)
                tax = invoice_data.tax_amount

        raw_lower = (invoice_data.raw_text or "").lower()

        if total == 0:
            invoice_data.net_amount = 0.0
            invoice_data.tax_amount = 0.0
            return

        if "kleinunternehmer" in raw_lower and ("umsatzsteuer nicht" in raw_lower or "§ 19" in raw_lower):
            if invoice_data.total_amount is not None:
                invoice_data.net_amount = invoice_data.total_amount
                invoice_data.tax_amount = 0.0
                return

        if total is not None and net is not None and tax is not None:
            if abs(total - net) < 0.01 and tax > 0:
                invoice_data.total_amount = round(net + tax, 2)
                total = invoice_data.total_amount
            if tax > net and tax > total * 0.5 and net < total * 0.35:
                invoice_data.net_amount = tax
                invoice_data.tax_amount = net
                net = invoice_data.net_amount
                tax = invoice_data.tax_amount
            if abs(tax - total) < 0.01 or abs(tax - net) < 0.01:
                if total > net:
                    invoice_data.tax_amount = round(total - net, 2)
                    tax = invoice_data.tax_amount

        if total is not None and tax is not None and net is None and total >= tax:
            invoice_data.net_amount = round(total - tax, 2)
        if total is not None and net is not None and tax is None and total >= net:
            invoice_data.tax_amount = round(total - net, 2)
        if total is None and net is not None and tax is not None:
            invoice_data.total_amount = round(net + tax, 2)

        net = invoice_data.net_amount
        tax = invoice_data.tax_amount
        total = invoice_data.total_amount
        if total == 0 and tax == 0 and net is None:
            invoice_data.net_amount = 0.0

    @classmethod
    def _extract_amount_by_labels(
        cls,
        text: str,
        labels: list[str],
        prefer_last: bool = False,
        allow_previous_line: bool = False,
        previous_line_first: bool = False,
        exclude_line_patterns: Optional[list[str]] = None,
    ) -> Optional[float]:
        lines = cls._non_empty_lines(text)
        matches: list[float] = []
        exclude_line_patterns = exclude_line_patterns or []

        for label in labels:
            for index, line in enumerate(lines):
                if cls._is_table_header_line(line):
                    continue
                lower_line = line.lower()
                if "ust-id" in lower_line or "ust.id" in lower_line or "ust id" in lower_line:
                    continue
                if any(re.search(pattern, lower_line, re.IGNORECASE) for pattern in exclude_line_patterns):
                    continue
                label_match = re.search(label, line, re.IGNORECASE)
                if not label_match:
                    continue
                is_subtotal_line = bool(re.search(r"\bsub\s*total\b|\bsubtotal\b|zwischensumme", lower_line))
                is_subtotal_label = label in {r"Sub\s+Total", r"Subtotal"} or "Zwischensumme" in label
                if is_subtotal_line and not is_subtotal_label:
                    continue

                after_label = line[label_match.end():]
                amounts_after = cls._find_amounts_in_line(after_label)
                if amounts_after:
                    matches.append(amounts_after[-1])
                    continue

                compact_label_line = len(re.sub(label, "", line, flags=re.IGNORECASE).strip(" :.-")) <= 10
                if compact_label_line:
                    neighbor_amounts: list[float] = []
                    if allow_previous_line and previous_line_first:
                        for previous_line in reversed(lines[max(0, index - 2):index]):
                            if cls._is_table_header_line(previous_line):
                                continue
                            neighbor_amounts = cls._find_amounts_in_line(previous_line)
                            if neighbor_amounts:
                                matches.append(neighbor_amounts[-1])
                                break
                        if neighbor_amounts:
                            continue

                    for next_line in lines[index + 1:index + 3]:
                        if cls._is_table_header_line(next_line):
                            continue
                        neighbor_amounts = cls._find_amounts_in_line(next_line)
                        if neighbor_amounts:
                            matches.append(neighbor_amounts[0])
                            break

                    if neighbor_amounts:
                        continue

                    if allow_previous_line and not previous_line_first:
                        for previous_line in reversed(lines[max(0, index - 2):index]):
                            if cls._is_table_header_line(previous_line):
                                continue
                            neighbor_amounts = cls._find_amounts_in_line(previous_line)
                            if neighbor_amounts:
                                matches.append(neighbor_amounts[-1])
                                break
                    continue

                amounts_line = cls._find_amounts_in_line(line)
                if amounts_line:
                    matches.append(amounts_line[-1])

        if not matches:
            return None
        return matches[-1] if prefer_last else matches[0]

    @classmethod
    def _extract_from_tax_table(cls, text: str, field: str) -> Optional[float]:
        lines = cls._non_empty_lines(text)
        for index, line in enumerate(lines):
            lower = line.lower()
            has_header = ("nettobetrag" in lower and ("steuerbetrag" in lower or "ust" in lower or "mwst" in lower or "steuer" in lower) and ("bruttobetrag" in lower or "gesamt" in lower))
            has_ust_summary = lower.strip().startswith("ust") and "zwischensumme" in lower
            has_mwst_netto_mwst_brutto = "netto" in lower and "brutto" in lower and "mwst" in lower
            has_ust_netto_brutto = (re.search(r"\bust\b", lower) is not None and "netto" in lower and "brutto" in lower and "zwischensumme" not in lower and "mobilstation" not in lower)
            has_otto_header = "brutto" in lower and "steuer" in lower and "netto" in lower and "endpreis" in lower
            has_rewe_header = re.search(r"steuer\s*%", lower) is not None and "netto" in lower and "brutto" in lower

            if not any([has_header, has_ust_summary, has_mwst_netto_mwst_brutto, has_ust_netto_brutto, has_otto_header, has_rewe_header]):
                continue

            for next_line in lines[index + 1:index + 8]:
                amounts = cls._find_amounts_in_line(next_line)
                if not amounts:
                    continue
                start = 1 if (len(amounts) >= 4 and amounts[0] in {7.0, 19.0, 5.0, 10.0, 0.0}) else 0

                if has_header and len(amounts) >= start + 3:
                    if field == "net": return amounts[start]
                    if field == "tax": return amounts[start + 1]
                    if field == "total": return amounts[start + 2]
                if has_mwst_netto_mwst_brutto and len(amounts) >= start + 3:
                    if field == "net": return amounts[start]
                    if field == "tax": return amounts[start + 1]
                    if field == "total": return amounts[start + 2]
                if has_ust_netto_brutto and len(amounts) >= start + 2:
                    if field == "net": return amounts[start]
                    if field == "total": return amounts[start + 1]
                    if field == "tax": return round(amounts[start + 1] - amounts[start], 2)
                if has_ust_summary and len(amounts) >= start + 2:
                    if field == "net": return amounts[start]
                    if field == "tax": return amounts[start + 1]
                if has_otto_header and len(amounts) >= 4:
                    if field == "total": return amounts[-1]
                    if field == "tax": return amounts[-3]
                    if field == "net": return amounts[-2]

            if has_rewe_header:
                net_total = tax_total = brutto_total = 0.0
                found_any = False
                for tax_line in lines[index + 1:index + 8]:
                    tl_lower = tax_line.lower()
                    tax_row = re.search(
                        r"[a-z]=?\s*\d{1,2}[,.]\d%?\s+(\d+[,.]\d+)\s+(\d+[,.]\d+)\s+(\d+[,.]\d+)",
                        tax_line, re.IGNORECASE,
                    )
                    if tax_row:
                        n = cls._parse_amount(tax_row.group(1))
                        t = cls._parse_amount(tax_row.group(2))
                        b = cls._parse_amount(tax_row.group(3))
                        if n is not None and t is not None and b is not None:
                            net_total += n; tax_total += t; brutto_total += b; found_any = True
                    elif "gesamtbetrag" in tl_lower or "summe" in tl_lower:
                        break
                if found_any:
                    if field == "net": return round(net_total, 2)
                    if field == "tax": return round(tax_total, 2)
                    if field == "total": return round(brutto_total, 2)

        return None

    @classmethod
    def _extract_tax_base_amount(cls, text: str) -> Optional[float]:
        patterns = [
            r"\+\s*(?:USt|Umsatzsteuer|MwSt)\.?\s*\d{1,2}\s*%\s*(?:von|auf)\s*" + cls.AMOUNT_PATTERN + r"\s+" + cls.AMOUNT_PATTERN,
            r"\+\s*\d{1,2}\s*%\s*(?:USt|Umsatzsteuer|MwSt)\.?\s*(?:von|auf)\s*" + cls.AMOUNT_PATTERN + r"\s+" + cls.AMOUNT_PATTERN,
            r"(?:MwSt|USt|Umsatzsteuer)[^\n]{0,80}?EUR\s*" + cls.AMOUNT_PATTERN + r"[^\n]{0,80}?auf\s+EUR\s*" + cls.AMOUNT_PATTERN,
        ]
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                amounts = cls._find_amounts_in_line(match.group(0))
                if len(amounts) >= 2:
                    if re.search(r"auf\s+EUR", match.group(0), re.IGNORECASE):
                        return amounts[-1]
                    return amounts[-2]
        return None

    @classmethod
    def _extract_tax_amount_from_ust_von_line(cls, text: str) -> Optional[float]:
        patterns = [
            r"\+\s*(?:USt|Umsatzsteuer|MwSt)\.?\s*\d{1,2}\s*%\s*(?:von|auf)\s*" + cls.AMOUNT_PATTERN + r"\s+" + cls.AMOUNT_PATTERN,
            r"\+\s*\d{1,2}\s*%\s*(?:USt|Umsatzsteuer|MwSt)\.?\s*(?:von|auf)\s*" + cls.AMOUNT_PATTERN + r"\s+" + cls.AMOUNT_PATTERN,
            r"(?:MwSt|USt|Umsatzsteuer)[^\n]{0,80}?EUR\s*" + cls.AMOUNT_PATTERN + r"[^\n]{0,80}?auf\s+EUR\s*" + cls.AMOUNT_PATTERN,
        ]
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                amounts = cls._find_amounts_in_line(match.group(0))
                if len(amounts) >= 2:
                    if re.search(r"auf\s+EUR", match.group(0), re.IGNORECASE):
                        return amounts[-2]
                    return amounts[-1]
        return None

    @classmethod
    def _find_amounts_in_line(cls, line: str) -> list[float]:
        amounts: list[float] = []
        for match in re.finditer(cls.AMOUNT_PATTERN, line):
            raw = match.group(0)
            before = line[max(0, match.start() - 3):match.start()]
            after = line[match.end():match.end() + 6]
            if re.match(r"^\.\d{2,4}", after): continue
            if re.search(r"\d\.$", before) and re.match(r"^\d{2,4}", after): continue
            if re.search(r"\d{1,2}\.\d{1,2}\.$", before): continue
            if re.match(r"^:\d{2}", after): continue
            if re.match(r"\s*%", after): continue
            amount = cls._parse_amount(raw)
            if amount is None or abs(amount) > 100000:
                continue
            amounts.append(amount)
        return amounts

    @staticmethod
    def _parse_amount(value: Optional[str]) -> Optional[float]:
        if value is None:
            return None
        cleaned = bereinige_betrag_string(value)
        if cleaned is None:
            return None
        try:
            return round(float(cleaned), 2)
        except ValueError:
            return None

    @classmethod
    def _extract_date_from_string(cls, value: str) -> Optional[str]:
        numeric_patterns = [
            r"(\d{1,2})\.(\d{1,2})\.(\d{2,4})",
            r"(\d{4})-(\d{1,2})-(\d{1,2})",
            r"(\d{4})/(\d{1,2})/(\d{1,2})",
            r"(\d{1,2})/(\d{1,2})/(\d{2,4})",
            r"(\d{1,2})\s+(\d{1,2})\s+(20\d{2})\b",
        ]
        for pattern in numeric_patterns:
            match = re.search(pattern, value)
            if not match:
                continue
            groups = match.groups()
            if len(groups[0]) == 4:
                year, month, day = groups
            else:
                day, month, year = groups
            if len(year) == 2:
                year = "20" + year
            d, mo, y = int(day), int(month), int(year)
            if not (1 <= d <= 31 and 1 <= mo <= 12 and 2000 <= y <= 2099):
                continue
            # Kalendervalidierung (Paket 07-06): 31.02. etc. nie als Datum akzeptieren.
            try:
                date(y, mo, d)
            except ValueError:
                continue
            return f"{d:02d}.{mo:02d}.{y}"

        month_names = "|".join(sorted(cls.MONTHS.keys(), key=len, reverse=True))
        match = re.search(rf"(\d{{1,2}})\.?\s+({month_names})\s+(\d{{4}})", value, re.IGNORECASE)
        if match:
            day, month_name, year = match.groups()
            month = cls.MONTHS.get(month_name.lower().replace("ä", "ae"), cls.MONTHS.get(month_name.lower()))
            if month:
                # Kalendervalidierung (Paket 07-06) auch fuer Monatsnamen-Daten.
                try:
                    date(int(year), int(month), int(day))
                except ValueError:
                    return None
                return f"{int(day):02d}.{month}.{year}"

        return None

    @staticmethod
    def _non_empty_lines(text: str) -> list[str]:
        return [line.strip() for line in text.splitlines() if line.strip()]

    @staticmethod
    def _is_table_header_line(line: str) -> bool:
        lower_line = line.lower()
        header_words = ["pos", "description", "beschreibung", "qty", "quantity", "menge", "price", "preis", "unit", "amount", "total", "gesamt", "steuersatz", "nettobetrag", "steuerbetrag", "bruttobetrag"]
        hits = sum(1 for word in header_words if word in lower_line)
        if hits >= 4 and not re.search(InvoiceParser.AMOUNT_PATTERN, line):
            return True
        if "gesamtpreis" in lower_line and ("einzelpreis" in lower_line or "elnzelpre" in lower_line):
            return True
        if "beschreibung" in lower_line and "total" in lower_line:
            return True
        if "leistung" in lower_line and "zeitraum" in lower_line and ("nettopreis" in lower_line or "einzelpreis" in lower_line):
            return True
        return False

    @staticmethod
    def _extract_vendor_from_supplier_context(lines: list[str]) -> Optional[str]:
        context_words = [
            "geschäftsführer", "geschaeftsfuehrer", "handelsregister", "amtsgericht",
            "hrb", "hra", "sitz der gesellschaft", "ust-id", "ust.id", "ust-idnr",
            "steuernummer", "steuer-nr", "bankverbindung", "gläubiger", "glaeubiger",
            "pers. haft.", "persönlich haft", "persoenlich haft",
        ]
        candidates: list[tuple[int, str]] = []
        for index, line in enumerate(lines):
            raw = line.strip()
            if not raw:
                continue
            lower = raw.lower()
            window = " ".join(lines[index:index + 4]).lower()
            previous = " ".join(lines[max(0, index - 4):index]).lower()
            if InvoiceParser._line_index_is_in_recipient_context(lines, index):
                continue
            if re.search(r"^\s*(fon|fax|tel|telefon)\b", raw, re.IGNORECASE):
                continue
            vendor = InvoiceParser._clean_vendor_name(raw)
            if not vendor or not InvoiceParser._has_legal_form(vendor) or re.match(r"^\d", vendor):
                continue
            score = 0
            if any(word in lower for word in context_words): score += 80
            if any(word in window for word in context_words): score += 60
            if any(word in previous for word in context_words): score += 30
            if index > 20: score += 10
            if re.search(r"GmbH\s*&\s*Co\.?\s*KG", vendor, re.IGNORECASE): score += 70
            if re.search(r"Verwaltungs\s+GmbH", vendor, re.IGNORECASE): score -= 50
            if re.search(r"\b(pos|artikel|menge|preis|gesamt|sku|produkt|bezeichnung)\b", lower): score -= 100
            if InvoiceParser._find_amounts_in_line(raw): score -= 30
            if score >= 40:
                candidates.append((score, vendor))
        if not candidates:
            return None
        candidates.sort(key=lambda item: item[0], reverse=True)
        return candidates[0][1]

    @staticmethod
    def _has_legal_form(value: str) -> bool:
        if not value:
            return False
        legal_patterns = [
            r"\bGmbH\b", r"\bUG\b", r"\bAG\b", r"\bKG\b", r"\bKGaA\b",
            r"\bGbR\b", r"\boHG\b", r"\be\.K\.\b", r"\bLtd\b", r"\bLimited\b",
            r"\bS\.à\s*r\.l\.?\b", r"\bS\.a\.r\.L\.?\b", r"\bS\.A\.?\b",
            r"\bCompany\b", r"\bCorporation\b", r"\bInc\.?\b",
        ]
        return any(re.search(pattern, value, re.IGNORECASE) for pattern in legal_patterns)

    @staticmethod
    def _is_bad_vendor_line(line: str) -> bool:
        lower = line.lower().strip()
        bad_words = [
            "rechnung", "rechnungsnummer", "rechnungsdatum", "invoice", "date",
            "lieferadresse", "rechnungsadresse", "kundendaten", "kunden-nr", "kundennummer",
            "bestellnummer", "auftragsnummer", "referenz", "seite", "gesamt", "betrag",
            "menge", "preis", "description", "bestelldetails", "iban", "bic", "ust-id",
            "ust.id", "steuer-nr", "steuernummer", "zahlungsbetrag", "zahlbetrag",
            "e-mail", "email", "telefon", "fax", "straße", "strasse", "str.", "platz",
            "weg", "allee", "gasse", "hof",
        ]
        if InvoiceParser._has_legal_form(line):
            severe = ["lieferadresse", "rechnungsadresse", "kundendaten", "kundennummer", "kunden-nr", "bestellnummer", "auftragsnummer", "zahlungsbetrag", "gesamtbetrag", "artikel", "menge", "preis", "gesamt", "produkt", "sku"]
            return any(word in lower for word in severe)
        return any(word in lower for word in bad_words)

    @staticmethod
    def _score_vendor_candidate(original_line: str, index: int) -> int:
        lower = original_line.lower()
        score = 100 - min(index, 80)
        for word in ["postfach", "hausanschrift", "geschäftsführer", "handelsregister", "ust-id", "ust.id", "web:", "e-mail"]:
            if word in lower: score += 10
        for word in ["kundendaten", "kundennummer", "kunden-nr", "lieferadresse", "rechnungsadresse", "rahmenvertragsnummer"]:
            if word in lower: score -= 80
        return score

    @staticmethod
    def _line_index_is_in_recipient_context(lines: list[str], index: int) -> bool:
        current = lines[index].strip().lower()
        previous = "\n".join(lines[max(0, index - 4):index]).lower()
        recipient_markers = [
            "rechnungsadresse", "lieferadresse", "anschrift", "verrechnet an", "rechnung an",
            "kundendaten", "kundenadresse", "ihre kundendaten", "herrn", "herr ", "frau ",
            "kunden-nr", "kundennummer", "steuer-nr", "steuernummer", "erfasser",
        ]
        if any(marker in previous for marker in recipient_markers):
            if any(marker in previous for marker in ["kundendaten", "rahmenvertragsnummer", "kundenkonto", "kunden-nr", "kundennummer", "steuer-nr", "steuernummer", "erfasser"]):
                return True
            if InvoiceParser._looks_like_private_person(lines[index]):
                return True
            if re.search(r"\b(?:straße|strasse|str\.|platz|weg|allee|gasse|hof)\b", current):
                return True
            if re.search(r"\b\d{5}\b", current):
                return True
        return False

    @staticmethod
    def _line_is_inside_recipient_block(lines: list[str], line: str, index: int | None = None) -> bool:
        if index is None:
            try:
                index = lines.index(line)
            except ValueError:
                return False
        return InvoiceParser._line_index_is_in_recipient_context(lines, index)

    @staticmethod
    def _looks_like_private_person(value: str) -> bool:
        if not value:
            return False
        v = value.strip(" .,:;|-/")
        lower = v.lower()
        if InvoiceParser._has_legal_form(v):
            return False
        business_indicators = [
            "shop", "store", "tech", "server", "host", "serverhost", "handy", "doc", "media",
            "markt", "mm ", "thalia", "prozis", "amazon", "vodafone", "telekom", "rewe",
            "scouter", "computer", "republik", "trade", "service", "gebäudereinigung", "getränke",
        ]
        if any(word in lower for word in business_indicators):
            return False
        if re.search(r"\b(herr|herrn|frau|familie)\b", lower):
            return True
        parts = v.split()
        if 2 <= len(parts) <= 4 and not re.search(r"\d|@|/|\\|\.|,", v):
            name_like_parts = sum(1 for part in parts if re.match(r"^[A-ZÄÖÜ][a-zäöüßA-ZÄÖÜ-]{1,}$", part))
            if name_like_parts == len(parts):
                return True
        return False

    @staticmethod
    def _clean_vendor_name(vendor: str) -> Optional[str]:
        if not vendor:
            return None
        vendor = vendor.strip()
        vendor = re.sub(
            r"^(Verkauft von|Informationen zum Verkäufer:?|Rechnungsaussteller:?|Leistungen der|Leistungen von|Empfänger:|Firma:)\s*",
            "", vendor, flags=re.IGNORECASE,
        ).strip()
        vendor = re.sub(r"^[^A-Za-zÄÖÜäöüß0-9]+", "", vendor).strip()
        vendor = re.split(
            r"\s+(?:[A-ZÄÖÜ]?[a-zäöüß]+str\.?|straße|strasse|weg|platz|allee|gasse|hof|damm|ring)\b|\s+\d{5}\b",
            vendor, maxsplit=1, flags=re.IGNORECASE,
        )[0].strip()
        legal_match = re.search(
            r"([A-Za-zÄÖÜäöüß0-9][A-Za-zÄÖÜäöüß0-9 &'().,\-/]{1,120}?\b(?:GmbH\s*&\s*Co\.\s*KG|GmbH|UG|AG|KG|KGaA|GbR|oHG|e\.K\.|Ltd|Limited|S\.à\s*r\.l\.?|S\.a\.r\.L\.?|S\.A\.?)\b)",
            vendor, re.IGNORECASE,
        )
        if legal_match:
            vendor = legal_match.group(1).strip()
        else:
            for sep in [" · ", " • ", " | ", " - ", ", "]:
                if sep in vendor:
                    first = vendor.split(sep)[0].strip()
                    if 3 <= len(first) <= 100:
                        vendor = first
                        break
        vendor = vendor.strip(" .,:;|-/")
        vendor = re.sub(r"^\d+\s+\d{5,}\s+", "", vendor).strip()
        vendor = re.sub(r"^\d+\s+", "", vendor).strip()
        vendor = re.sub(r"\bGetr[a-zA-Z0-9/\\]*ke\b", "Getränke", vendor, flags=re.IGNORECASE)
        vendor = re.sub(r"\bLogl[a-zA-Z0-9/\\]*k\b", "Logistik", vendor, flags=re.IGNORECASE)
        vendor = re.sub(r"(?<=[a-zäöüß])(?=GmbH\b)", " ", vendor)
        vendor = vendor.replace("TelekomDeutschland", "Telekom Deutschland")
        vendor = re.sub(r"\s+", " ", vendor)
        if re.match(r"^\d", vendor) or re.match(r"^(fon|fax|tel|telefon)\b", vendor, re.IGNORECASE):
            return None
        if len(vendor) < 3 or len(vendor) > 120:
            return None
        bad_values = {"rechnung", "kunde", "anschrift", "lieferadresse", "rechnungsadresse", "bestelldetails", "herr", "herrn", "frau", "empfänger", "website", "business name", "business address", "client name"}
        if vendor.lower() in bad_values or "[" in vendor or "]" in vendor:
            return None
        if any(part in vendor.lower() for part in ["nicht relevant", "internet:", "www…", "kunden_b"]):
            return None
        if InvoiceParser._looks_like_private_person(vendor):
            return None
        return vendor
