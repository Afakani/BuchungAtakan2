"""HybridExtractionResult und Statusregeln fuer Phase 07 (HYB-05/06).

Statusregeln:
- NICHT_GEFUNDEN: Kein einziger Kandidat fuer irgendeines der Pflichtfelder.
- MUSS_GEPRUEFT_WERDEN: Pflichtfelder unvollstaendig, Konflikte bei Pflichtfeldern,
  mathematische Validierung fehlgeschlagen, Confidence zu niedrig.
- OK: Alle Pflichtfelder vorhanden, Validierung bestanden, Confidence ausreichend,
  keine Konflikte bei Pflichtfeldern.

Provider duerfen niemals selbst OK setzen (HYB-06).
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from packages.core.invoice_extraction.hybrid_kandidat import AuswahlStatus, HybridKandidat

_PFLICHT_FELDER = frozenset({"vendor_name", "invoice_number", "invoice_date", "total_amount"})
_CONFIDENCE_SCHWELLE = 0.5

#: Oeffentlicher Alias -- wiederverwendbar durch Paket 07-03 (Konflikterkennung/Auswahl),
#: statt die Pflichtfeldliste dort erneut zu definieren.
PFLICHT_FELDER = _PFLICHT_FELDER


class HybridStatus(StrEnum):
    OK = "OK"
    MUSS_GEPRUEFT_WERDEN = "MUSS_GEPRUEFT_WERDEN"
    NICHT_GEFUNDEN = "NICHT_GEFUNDEN"


@dataclass
class HybridExtractionResult:
    """Ergebnisobjekt der Hybrid-Pipeline fuer einen einzelnen Provider-Lauf."""

    kandidaten: list[HybridKandidat]
    status: HybridStatus
    gruende: list[str]
    provider_name: str
    provider_version: str | None
    laufstatus: str
    fehlercode: str | None

    def kandidaten_fuer_feld(self, feld: str) -> list[HybridKandidat]:
        return [k for k in self.kandidaten if k.feld == feld]

    def bestes_fuer_feld(self, feld: str) -> HybridKandidat | None:
        treffer = self.kandidaten_fuer_feld(feld)
        if not treffer:
            return None
        return max(treffer, key=lambda k: k.confidence)

    @property
    def fehlende_pflichtfelder(self) -> frozenset[str]:
        vorhandene = {k.feld for k in self.kandidaten}
        return _PFLICHT_FELDER - vorhandene

    @property
    def konflikte(self) -> list[HybridKandidat]:
        return [k for k in self.kandidaten if k.auswahl_status == AuswahlStatus.KONFLIKT]


def berechne_hybrid_status(
    kandidaten: list[HybridKandidat],
    math_ok: bool | None = None,
) -> tuple[HybridStatus, list[str]]:
    """Berechnet HybridStatus gemaess HYB-06-Statusregeln.

    Ein OK entsteht NICHT allein dadurch, dass Pflichtfelder gefuellt sind.
    Konflikte bei Pflichtfeldern werden nie still priorisiert.
    """
    gruende: list[str] = []
    vorhandene = {k.feld for k in kandidaten}
    fehlende = _PFLICHT_FELDER - vorhandene

    # Kein einziger Kandidat fuer irgendein Pflichtfeld
    if fehlende == _PFLICHT_FELDER:
        gruende.append(
            f"NICHT_GEFUNDEN: Keine Kandidaten fuer Pflichtfelder {sorted(fehlende)}"
        )
        return HybridStatus.NICHT_GEFUNDEN, gruende

    # Einzelne Pflichtfelder fehlen
    if fehlende:
        gruende.append(
            f"MUSS_GEPRUEFT_WERDEN: Pflichtfelder ohne Kandidat: {sorted(fehlende)}"
        )
        return HybridStatus.MUSS_GEPRUEFT_WERDEN, gruende

    # Konflikte bei Pflichtfeldern — darf nie still aufgeloest werden (HYB-05)
    pflicht_konflikte = [
        k for k in kandidaten
        if k.feld in _PFLICHT_FELDER and k.auswahl_status == AuswahlStatus.KONFLIKT
    ]
    if pflicht_konflikte:
        felder = sorted({k.feld for k in pflicht_konflikte})
        gruende.append(
            f"MUSS_GEPRUEFT_WERDEN: Nicht aufgeloester Konflikt bei Pflichtfeld(ern): {felder}"
        )
        return HybridStatus.MUSS_GEPRUEFT_WERDEN, gruende

    # Mathematische Validierung (HYB-15)
    if math_ok is False:
        gruende.append("MUSS_GEPRUEFT_WERDEN: Mathematische Validierung fehlgeschlagen")
        return HybridStatus.MUSS_GEPRUEFT_WERDEN, gruende

    # Confidence-Schwelle je Pflichtfeld
    for feld in sorted(_PFLICHT_FELDER):
        bester = max(
            (k for k in kandidaten if k.feld == feld),
            key=lambda k: k.confidence,
            default=None,
        )
        if bester is not None and bester.confidence < _CONFIDENCE_SCHWELLE:
            gruende.append(
                f"MUSS_GEPRUEFT_WERDEN: Confidence fuer '{feld}' zu niedrig"
                f" ({bester.confidence:.2f} < {_CONFIDENCE_SCHWELLE})"
            )
            return HybridStatus.MUSS_GEPRUEFT_WERDEN, gruende

    gruende.append(
        "OK: Pflichtfelder vollstaendig, Validierung bestanden, "
        "Confidence ausreichend, Konflikte bei Pflichtfeldern: keine"
    )
    return HybridStatus.OK, gruende
