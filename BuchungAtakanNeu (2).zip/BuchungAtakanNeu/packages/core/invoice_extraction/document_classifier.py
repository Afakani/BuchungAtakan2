"""Deterministische lokale Dokumentklassifikation (HYB-09..12 Vorstufe).

Klassifiziert ein Dokument anhand einfacher, zentral definierter Schwellen in
TEXT_PDF / SCAN_PDF / SONDERFORMAT / UNBEKANNT. Die Klassifikation arbeitet auf bereits
ermittelten Merkmalen (keine Datei-IO in dieser Funktion) und ist damit vollstaendig
synthetisch testbar.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path

#: Mindestanzahl Zeichen extrahierten Texts pro Seite, ab der ein PDF als
#: digitaler Text-PDF gilt (statt Scan).
MIN_ZEICHEN_PRO_SEITE = 20

#: Bekannte, aktuell nicht unterstuetzte Formate.
_SONDERFORMAT_SUFFIXE = frozenset({".xml", ".zip", ".tif", ".tiff", ".png", ".jpg", ".jpeg"})


class DokumentKlasse(StrEnum):
    TEXT_PDF = "TEXT_PDF"
    SCAN_PDF = "SCAN_PDF"
    SONDERFORMAT = "SONDERFORMAT"
    UNBEKANNT = "UNBEKANNT"


@dataclass(frozen=True)
class DokumentMerkmale:
    """Rohmerkmale eines Dokuments, Grundlage der Klassifikation."""

    suffix: str
    seiten_anzahl: int
    text_zeichen_gesamt: int


def klassifiziere(merkmale: DokumentMerkmale) -> DokumentKlasse:
    """Deterministische Klassifikation anhand Suffix und Textdichte pro Seite."""
    suffix = merkmale.suffix.lower()

    if suffix in _SONDERFORMAT_SUFFIXE:
        return DokumentKlasse.SONDERFORMAT
    if suffix != ".pdf":
        return DokumentKlasse.UNBEKANNT
    if merkmale.seiten_anzahl <= 0:
        return DokumentKlasse.UNBEKANNT

    zeichen_pro_seite = merkmale.text_zeichen_gesamt / merkmale.seiten_anzahl
    if zeichen_pro_seite >= MIN_ZEICHEN_PRO_SEITE:
        return DokumentKlasse.TEXT_PDF
    return DokumentKlasse.SCAN_PDF


def ermittle_merkmale(pdf_path: Path) -> DokumentMerkmale:
    """Liest Suffix, Seitenzahl und Textmenge eines PDFs fuer die Klassifikation.

    Nur fuer .pdf-Pfade gedacht; andere Suffixe werden ohne Datei-Zugriff eingeordnet.
    """
    pdf_path = Path(pdf_path)
    suffix = pdf_path.suffix.lower()
    if suffix != ".pdf":
        return DokumentMerkmale(suffix=suffix, seiten_anzahl=0, text_zeichen_gesamt=0)

    import pdfplumber

    with pdfplumber.open(pdf_path) as pdf:
        seiten_anzahl = len(pdf.pages)
        text_zeichen_gesamt = sum(len(page.extract_text() or "") for page in pdf.pages)

    return DokumentMerkmale(
        suffix=suffix,
        seiten_anzahl=seiten_anzahl,
        text_zeichen_gesamt=text_zeichen_gesamt,
    )


def klassifiziere_pfad(pdf_path: Path) -> DokumentKlasse:
    """Bequemlichkeitsfunktion: Merkmale ermitteln und klassifizieren."""
    return klassifiziere(ermittle_merkmale(pdf_path))
