"""PdfplumberProvider — bestehenden pdfplumber→InvoiceParser-Pfad als InvoiceCandidateProvider.

Erster Provider der Hybrid-Pipeline (HYB-07). Keine echten Rechnungen, kein Realtest.
"""
from __future__ import annotations

import time
from pathlib import Path

from packages.core.invoice_extraction.hybrid_kandidat import HybridKandidat, from_kandidat
from packages.core.invoice_extraction.invoice_parser_adapter import extract_from_pdf
from packages.core.invoice_extraction.provider_ports import InvoiceProviderResult

_NAME = "pdfplumber"
_VERSION = "1.0"


class PdfplumberProvider:
    """Verbindet pdfplumber/InvoiceParser mit Hybrid-Architektur (HYB-07)."""

    @property
    def name(self) -> str:
        return _NAME

    @property
    def version(self) -> str:
        return _VERSION

    def extract(self, pdf_path: Path) -> InvoiceProviderResult:
        start_ms = int(time.monotonic() * 1000)
        try:
            result = extract_from_pdf(pdf_path)
            hybrid_kandidaten: list[HybridKandidat] = [
                from_kandidat(k, provider_version=_VERSION, provider_name=_NAME)
                for k in result.kandidaten
            ]
            dauer = int(time.monotonic() * 1000) - start_ms
            return InvoiceProviderResult(
                provider_name=_NAME,
                provider_version=_VERSION,
                laufstatus="success",
                kandidaten=hybrid_kandidaten,
                fehlercode=None,
                lauf_dauer_ms=dauer,
            )
        except Exception as exc:
            dauer = int(time.monotonic() * 1000) - start_ms
            # Nur Fehlertyp — kein Volltext, kein Dateiname, kein Stack
            return InvoiceProviderResult(
                provider_name=_NAME,
                provider_version=_VERSION,
                laufstatus="error",
                kandidaten=[],
                fehlercode=type(exc).__name__,
                lauf_dauer_ms=dauer,
            )
