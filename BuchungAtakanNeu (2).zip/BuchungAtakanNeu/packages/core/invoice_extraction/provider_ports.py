"""Provider-Ports fuer Phase 07 — HYB-02.

InvoiceTextProvider:   extrahiert PDF-Text (fuer Parser-basierte Provider).
InvoiceCandidateProvider: liefert direkt Kandidaten (vollstaendiger Provider-Lauf).
CloudInvoiceProvider:  abstrakter Port fuer Cloud-Provider; kein Impl in Phase 07 (HYB-20).

Provider-Results enthalten keinen Volltext, keine Dateinamen, keine Credentials.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from packages.core.invoice_extraction.hybrid_kandidat import HybridKandidat


@dataclass
class InvoiceProviderResult:
    """Ergebnis eines einzelnen Provider-Laufs (HYB-02/03/04).

    fehlercode ist sanitisiert: nur Fehlertyp (z.B. 'FileNotFoundError'),
    kein Stacktrace, kein Dateiname, kein Volltext.
    """

    provider_name: str
    provider_version: str | None
    laufstatus: str
    kandidaten: list[HybridKandidat]
    fehlercode: str | None
    seiten_anzahl: int | None = None
    lauf_dauer_ms: int | None = None


class InvoiceTextProvider(Protocol):
    """Port fuer Provider, die reinen PDF-Text extrahieren."""

    @property
    def name(self) -> str: ...

    @property
    def version(self) -> str: ...

    def extract_text(self, pdf_path: Path) -> str: ...


class InvoiceCandidateProvider(Protocol):
    """Port fuer Provider, die vollstaendige Kandidatenlisten liefern (HYB-02)."""

    @property
    def name(self) -> str: ...

    @property
    def version(self) -> str: ...

    def extract(self, pdf_path: Path) -> InvoiceProviderResult: ...


class CloudInvoiceProvider(Protocol):
    """Abstrakter Port fuer Cloud-Provider (HYB-20).

    Implementiert von AzureDocumentIntelligenceProvider (Paket 07-04) -- vorbereitet,
    aber deaktiviert: kein SDK, kein Netzwerk, keine Credentials. is_enabled muss False
    zurueckgeben, solange BUCHUNG_ATAKAN_FEATURE_AZURE_DOCUMENT_INTELLIGENCE deaktiviert ist.
    """

    @property
    def name(self) -> str: ...

    @property
    def version(self) -> str: ...

    @property
    def is_enabled(self) -> bool: ...

    def extract(self, pdf_path: Path) -> InvoiceProviderResult: ...
