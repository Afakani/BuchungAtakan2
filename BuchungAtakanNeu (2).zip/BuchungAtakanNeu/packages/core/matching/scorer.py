"""Deterministischer Scorer fuer Bankbuchung-Rechnungs-Matching (BANK-04).

Alle Regeln sind dokumentiert und nachvollziehbar.
Kein KI, kein Fuzzy-Modell, keine zeitabhaengige Zufaelligkeit.
Identischer Input → identischer Output.
"""
import re
from datetime import datetime
from decimal import Decimal
from uuid import UUID

from packages.core.bank_import.normalisierung import normalisiere_text
from packages.core.matching.signale import (
    GEWICHTE,
    MATCHER_VERSION,
    SCHWELLE_STARK,
    SCHWELLE_UNSICHER,
    MatchErgebnis,
    Signal,
)

# Rechnungsnummer-Mindestlaenge fuer sichere Suche (BANK-04: kein Falsch-Positiv)
_MIN_RECHNUNGSNR_LAENGE = 5

# Signifikante Wortlaenge fuer Anbieter-Vergleich
_MIN_WORTLAENGE_ANBIETER = 4


def _parse_rechnungsdatum(datum_str: str | None):
    """Parst DD.MM.YYYY. Gibt date oder None zurueck."""
    if not datum_str:
        return None
    try:
        return datetime.strptime(datum_str.strip(), "%d.%m.%Y").date()
    except ValueError:
        return None


def _decimal_zu_cent(betrag: Decimal | None) -> int | None:
    """Exakte Dezimal-zu-Cent-Konvertierung ohne Float (BANK-10)."""
    if betrag is None:
        return None
    return int(betrag * 100)


def _bewerte_betrag(bank_cent: int, rechnung_cent: int | None) -> list[Signal]:
    """Betragsvergleich auf absoluten Werten (Richtungsunabhaengig in Paket 2)."""
    if rechnung_cent is None:
        return [Signal(
            typ="BETRAG_RECHNUNG_FEHLT",
            beschreibung="Rechnungsbetrag nicht vorhanden",
            punkte=GEWICHTE["BETRAG_RECHNUNG_FEHLT"],
        )]

    differenz = abs(abs(bank_cent) - abs(rechnung_cent))

    if differenz == 0:
        return [Signal(
            typ="BETRAG_EXAKT",
            beschreibung=f"Betrag stimmt exakt ({bank_cent} Cent)",
            punkte=GEWICHTE["BETRAG_EXAKT"],
        )]
    if differenz <= 1000:
        return [Signal(
            typ="BETRAG_NAH",
            beschreibung=f"Betragsabweichung {differenz} Cent (<= 10 EUR)",
            punkte=GEWICHTE["BETRAG_NAH"],
        )]
    if differenz <= 5000:
        return [Signal(
            typ="BETRAG_GROB",
            beschreibung=f"Betragsabweichung {differenz} Cent (<= 50 EUR)",
            punkte=GEWICHTE["BETRAG_GROB"],
        )]
    return [Signal(
        typ="BETRAG_ABWEICHUNG",
        beschreibung=f"Betragsabweichung {differenz} Cent (> 50 EUR)",
        punkte=GEWICHTE["BETRAG_ABWEICHUNG"],
    )]


def _bewerte_datum(buchungsdatum, rechnungsdatum_str: str | None) -> list[Signal]:
    """Datumsbewertung: Abstand zwischen Rechnungsdatum und Buchungsdatum."""
    rechnungsdatum = _parse_rechnungsdatum(rechnungsdatum_str)

    if rechnungsdatum is None:
        return [Signal(
            typ="DATUM_RECHNUNG_FEHLT",
            beschreibung="Rechnungsdatum nicht vorhanden",
            punkte=GEWICHTE["DATUM_RECHNUNG_FEHLT"],
        )]

    tage_diff = (buchungsdatum - rechnungsdatum).days

    if tage_diff < 0:
        return [Signal(
            typ="DATUM_VOR_RECHNUNG",
            beschreibung=f"Buchung {abs(tage_diff)} Tage VOR Rechnungsdatum",
            punkte=GEWICHTE["DATUM_VOR_RECHNUNG"],
        )]
    if tage_diff <= 90:
        return [Signal(
            typ="DATUM_PLAUSIBEL",
            beschreibung=f"Buchung {tage_diff} Tage nach Rechnungsdatum (plausibel)",
            punkte=GEWICHTE["DATUM_PLAUSIBEL"],
        )]
    if tage_diff <= 365:
        return [Signal(
            typ="DATUM_SPAET",
            beschreibung=f"Buchung {tage_diff} Tage nach Rechnungsdatum (spaet)",
            punkte=GEWICHTE["DATUM_SPAET"],
        )]
    return [Signal(
        typ="DATUM_SEHR_SPAET",
        beschreibung=f"Buchung {tage_diff} Tage nach Rechnungsdatum (sehr spaet)",
        punkte=GEWICHTE["DATUM_SEHR_SPAET"],
    )]


def _bewerte_rechnungsnummer(
    verwendungszweck: str | None,
    rechnungsnummer: str | None,
) -> list[Signal]:
    """Sucht normalisierte Rechnungsnr. im Verwendungszweck (mind. 5 Zeichen)."""
    if not rechnungsnummer or not verwendungszweck:
        return []

    norm_rn = normalisiere_text(rechnungsnummer)
    norm_vzw = normalisiere_text(verwendungszweck)

    if len(norm_rn) < _MIN_RECHNUNGSNR_LAENGE:
        return []  # Zu kurz fuer sichere Suche

    if norm_rn in norm_vzw:
        return [Signal(
            typ="RECHNUNGSNUMMER_GEFUNDEN",
            beschreibung=f"Rechnungsnr. '{rechnungsnummer}' im Verwendungszweck gefunden",
            punkte=GEWICHTE["RECHNUNGSNUMMER_GEFUNDEN"],
        )]
    return []


def _bewerte_anbieter(
    gegenpartei_name: str | None,
    lieferant_name: str | None,
) -> list[Signal]:
    """Wortbasierter Anbieter-Match: signifikantes Wort (>= 4 Zeichen) aus
    lieferant_name im gegenpartei_name gefunden.

    Keine KI, kein Fuzzy-Modell — dokumentierte einfache Regel.
    """
    if not gegenpartei_name or not lieferant_name:
        return []

    norm_gp = normalisiere_text(gegenpartei_name)
    norm_lief = normalisiere_text(lieferant_name)

    woerter = [w for w in re.split(r"\W+", norm_lief) if len(w) >= _MIN_WORTLAENGE_ANBIETER]

    if not woerter:
        return []

    for wort in woerter:
        if wort in norm_gp:
            return [Signal(
                typ="ANBIETER_MATCH",
                beschreibung=f"Lieferant '{lieferant_name}' im Gegenparteinamen erkannt",
                punkte=GEWICHTE["ANBIETER_MATCH"],
            )]

    return [Signal(
        typ="ANBIETER_KEIN_MATCH",
        beschreibung=f"Lieferant '{lieferant_name}' nicht im Gegenparteinamen erkannt",
        punkte=GEWICHTE["ANBIETER_KEIN_MATCH"],
    )]


def berechne_match(
    *,
    bankbuchung_id: UUID,
    bank_betrag_cent: int,
    bank_buchungsdatum,
    bank_verwendungszweck: str | None,
    bank_gegenpartei_name: str | None,
    rechnung_id: UUID,
    rechnung_gesamtbetrag: Decimal | None,
    rechnung_datum: str | None,
    rechnung_nummer: str | None,
    rechnung_lieferant: str | None,
) -> MatchErgebnis:
    """Berechnet Matching-Score und Signale fuer ein Buchung-Rechnung-Paar.

    Deterministisch. Identischer Input → identisches Ergebnis.
    Kein DB-Zugriff. Keine Nebenwirkungen.
    """
    rechnung_cent = _decimal_zu_cent(rechnung_gesamtbetrag)

    alle_signale: list[Signal] = []
    alle_signale.extend(_bewerte_betrag(bank_betrag_cent, rechnung_cent))
    alle_signale.extend(_bewerte_datum(bank_buchungsdatum, rechnung_datum))
    alle_signale.extend(_bewerte_rechnungsnummer(bank_verwendungszweck, rechnung_nummer))
    alle_signale.extend(_bewerte_anbieter(bank_gegenpartei_name, rechnung_lieferant))

    positive = tuple(s for s in alle_signale if s.punkte > 0)
    negative = tuple(s for s in alle_signale if s.punkte < 0)
    score = sum(s.punkte for s in alle_signale)

    if score >= SCHWELLE_STARK:
        status = "STARK"
    elif score >= SCHWELLE_UNSICHER:
        status = "UNSICHER"
    else:
        status = "KEIN_KANDIDAT"

    return MatchErgebnis(
        bankbuchung_id=bankbuchung_id,
        rechnung_id=rechnung_id,
        score=score,
        status=status,
        positive_signale=positive,
        negative_signale=negative,
        matcher_version=MATCHER_VERSION,
    )
