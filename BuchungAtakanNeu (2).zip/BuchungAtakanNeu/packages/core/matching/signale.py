"""Signaltypen, Gewichte und Ergebnisobjekte fuer erklaerbares Matching (BANK-04).

Scorebereich: unbegrenzt; in der Praxis -75 bis +120.
Schwellen:
  STARK     >= 80  starker Kandidat (hohe Verlässlichkeit)
  UNSICHER  >= 40  schwacher Kandidat (manuelle Pruefung empfohlen)
  < 40            kein sinnvoller Kandidat (nicht gespeichert)

Dokumentierte Gewichte:
  BETRAG_EXAKT             +50  Betrag stimmt auf Cent exakt
  BETRAG_NAH               +20  Abweichung <= 10 EUR (1000 Cent)
  BETRAG_GROB               +5  Abweichung <= 50 EUR (5000 Cent)
  BETRAG_ABWEICHUNG        -30  Abweichung > 50 EUR
  BETRAG_RECHNUNG_FEHLT     -5  Rechnungsbetrag nicht vorhanden
  DATUM_PLAUSIBEL          +15  Buchung 0-90 Tage nach Rechnungsdatum
  DATUM_SPAET              -10  Buchung 91-365 Tage nach Rechnungsdatum
  DATUM_SEHR_SPAET         -20  Buchung > 365 Tage nach Rechnungsdatum
  DATUM_VOR_RECHNUNG        -5  Buchung vor Rechnungsdatum
  DATUM_RECHNUNG_FEHLT      -2  Rechnungsdatum nicht vorhanden
  RECHNUNGSNUMMER_GEFUNDEN +40  Rechnungsnr. im Verwendungszweck gefunden
  ANBIETER_MATCH           +15  Lieferantenname im Gegenparteinamen erkannt
  ANBIETER_KEIN_MATCH       -5  Beide Namen vorhanden, kein Wortmatch
"""
from dataclasses import dataclass
from uuid import UUID

MATCHER_VERSION = "1.0"

SCHWELLE_STARK = 80
SCHWELLE_UNSICHER = 40

GEWICHTE: dict[str, int] = {
    "BETRAG_EXAKT": 50,
    "BETRAG_NAH": 20,
    "BETRAG_GROB": 5,
    "BETRAG_ABWEICHUNG": -30,
    "BETRAG_RECHNUNG_FEHLT": -5,
    "DATUM_PLAUSIBEL": 15,
    "DATUM_SPAET": -10,
    "DATUM_SEHR_SPAET": -20,
    "DATUM_VOR_RECHNUNG": -5,
    "DATUM_RECHNUNG_FEHLT": -2,
    "RECHNUNGSNUMMER_GEFUNDEN": 40,
    "ANBIETER_MATCH": 15,
    "ANBIETER_KEIN_MATCH": -5,
}


@dataclass(frozen=True)
class Signal:
    typ: str
    beschreibung: str
    punkte: int

    def als_dict(self) -> dict:
        return {"typ": self.typ, "beschreibung": self.beschreibung, "punkte": self.punkte}


@dataclass(frozen=True)
class MatchErgebnis:
    bankbuchung_id: UUID
    rechnung_id: UUID
    score: int
    status: str
    positive_signale: tuple[Signal, ...]
    negative_signale: tuple[Signal, ...]
    matcher_version: str

    @property
    def ist_kandidat(self) -> bool:
        return self.score >= SCHWELLE_UNSICHER
