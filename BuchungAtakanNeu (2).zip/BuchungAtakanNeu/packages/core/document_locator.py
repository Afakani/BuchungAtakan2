from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class DokumentVerfuegbarkeit(StrEnum):
    LOCAL_AVAILABLE = "LOCAL_AVAILABLE"
    LOCAL_MISSING = "LOCAL_MISSING"
    UNKNOWN = "UNKNOWN"


class DokumentQuelle(StrEnum):
    DUMP = "DUMP"
    UPLOAD = "UPLOAD"
    SCANNER = "SCANNER"


@dataclass(frozen=True)
class DokumentLocator:
    relative_path: str
    sha256: str
    dateigroesse: int
    mime_type: str
    quelle: DokumentQuelle = DokumentQuelle.DUMP

    def __post_init__(self) -> None:
        if not self.relative_path or not self.relative_path.strip():
            raise ValueError("relative_path darf nicht leer sein")
        if self.relative_path.startswith("/") or (
            len(self.relative_path) >= 2 and self.relative_path[1] == ":"
        ):
            raise ValueError(
                f"relative_path muss relativ sein (kein absoluter Pfad): {self.relative_path!r}"
            )
        if len(self.sha256) != 64:
            raise ValueError(f"sha256 muss 64 Hex-Zeichen haben, got {len(self.sha256)}")
        if self.dateigroesse < 0:
            raise ValueError("dateigroesse darf nicht negativ sein")
