# Projektkontext – BuchungAtakan (Neuaufbau)

**Stand:** 2026-06-25
**Autoritative Quellen:** `docs/ENTWICKLUNGSPLAN.md`, `docs/PHASENUEBERSICHT.md`
**Historische Quelle:** Altprojekt `C:\Users\User\PycharmProjects\BuchungAtakan`

---

## 1. Was das ist

BuchungAtakan ist eine **Mehrmandanten-Buchhaltungs- und Dokumentabgleichsplattform**.
Sie importiert Rechnungen und Kontoauszüge, ordnet Rechnungen den passenden Bankbuchungen zu,
verarbeitet EC-/Telexpert-Sammeleinzahlungen und holt fehlende Belege per Gmail nach.

Das System wird technisch **neu aufgebaut**: vom bisherigen lokalen Einzelmandanten-Desktop
(SQLite) hin zu einer zentralen Client-Server-Architektur mit mehreren Standorten/Unternehmen.

Nutzer:
- Mitarbeitende je Unternehmen über einen **lokalen Windows-Client (PySide6)**.
- Später authentifizierter Web-Zugriff (z. B. Steuerberater).

## 2. Kernwert

> Rechnungen, Bankbuchungen und Belege werden je Unternehmen sicher getrennt verarbeitet und
> zuverlässig einander zugeordnet – Originaldokumente bleiben lokal, zentral liegen nur die
> strukturierten Daten.

## 3. Zielbild (Soll-Architektur)

- Zentrale **FastAPI** (Aachen) + zentrale **PostgreSQL**.
- Lokale Clients je Standort; **kein direkter DB-Zugriff**, nur über die API.
- **Mandantentrennung** über `unternehmen_id`; Benutzer, Rollen und Installationen zentral.
- **Originaldokumente bleiben lokal** (`DATA_ROOT`); zentral nur Metadaten, Hash und relative
  Pfade. Offline-Outbox + idempotente Synchronisation.

Details: `docs/ARCHITECTURE.md`.

## 4. Geschäftlicher Funktionsumfang (aus Altprojekt bestätigt)

- Rechnungsverarbeitung (PDF-Text/OCR/Parser), Kandidaten- vs. freigegebene Daten,
  Duplikat-/Versionsregel, Lieferantenerkennung, manuelle Prüffälle.
- Kontoauszugsimport und zentrale Bankbuchungen.
- Matching über Betrag, Partner, IBAN, Text, Rechnungsnummer und Datum.
- EC-/Telexpert-Logik mit Einzahlungszeiträumen und Belegsperre.
- Gmail-Mehrpostfachbetrieb, Anhangsimport, Scan-Historie, Nachsuche.
- Excel-/CSV-/JSON-Berichte; Einrichtungsassistent und tägliche Bedienoberfläche.

Verbindliche Detailregeln: `docs/BUSINESS_RULES.md`.

## 5. Nicht im Kern-MVP (später / optional)

- DATEV-Export.
- GoBD-orientierte Audit-, Aufbewahrungs- und WORM-Funktionen.
- **Optional C – verschlüsselte zentrale Dokumentkopie / Dokumentreplikation**
  (Nachfolger der aufgehobenen UNC-Idee, siehe `docs/OPEN_POINTS.md`).
- Cloud-OCR, weitere Mailanbieter und Banken.
- Optionale KI-Hilfe für schwierige Sonderfälle.

## 6. Verhältnis zum Altprojekt

Das Altprojekt ist ein **funktional reifes** Einzelmandanten-System (SQLite, Desktop), das die
Fachlogik bereits umgesetzt und getestet hat (zuletzt 162 Pytests grün). Es dient als
**Referenz- und Wiederverwendungsquelle**, nicht als aktuelle Architekturvorgabe.

Aufgehobene Alt-Festlegungen (durch ENTWICKLUNGSPLAN ersetzt):
- SQLite/Einzelmandant → zentrale PostgreSQL + Mandantentrennung.
- Direkter DB-Zugriff → API-only.
- Zentrale UNC-/Tailscale-Dokumentablage → Originale bleiben lokal.

Siehe `docs/CURRENT_STATUS.md` und `docs/OPEN_POINTS.md`.
