# Geschäftsregeln – BuchungAtakan

**Stand:** 2026-06-25
**Status:** Autoritative Fachregeln, übernommen aus dem Altprojekt und mit
`docs/ENTWICKLUNGSPLAN.md` abgeglichen. **Keine erfundenen Regeln.**

Quellen:
- Altprojekt-Kontextpaket: `DECISIONS_TIMELINE.md`, `REQUIREMENTS_MATRIX.md`,
  `PROJECT_CONTEXT.md`, alt `AGENTS.md`.
- Autoritativ bei Widerspruch: `docs/ENTWICKLUNGSPLAN.md` (Akzeptanzkriterien Phasen 3–7).

Fachlogik wird **unverändert** übernommen. Nur **Ablage- und Zugriffsregeln** wurden gemäß
neuer Architektur angepasst (lokale Dokumente, zentrale Daten, Mandantentrennung) – siehe §10.

---

## 1. Mandantentrennung (neu, verbindlich)

- Jede fachliche Entität gehört zu genau einem Unternehmen (`unternehmen_id`).
- Lesen und Schreiben sind sicher nach `unternehmen_id` zu filtern; mandantenfremde Daten
  dürfen nie sichtbar werden.
- Clients greifen ausschließlich über die authentifizierte API zu (kein direkter DB-Zugriff).

## 2. Beträge und Zahlungsarten

- EC-Beträge werden als **Integer-Centwerte** geführt.
- `CardPayment` und `EC_Karte` sind **dieselbe** fachliche Kategorie und werden in dieselbe
  EC-Karten-Kategorie / denselben Ordner normalisiert.

## 3. Rechnungsverarbeitung

- PDFs werden erkannt, verarbeitet, gespeichert und einsortiert.
- Rechnungsdaten umfassen u. a.: Firma/Lieferant, Rechnungsnummer, Datum, Brutto/Netto/Steuer,
  Währung, Zahlungsart.
- Kandidaten- und freigegebene Rechnungsdaten werden getrennt gehalten; mathematische und
  formale Prüfungen werden durchgeführt.
- Problemfälle landen in **Unsicher / Nicht erkannt** (manuelle Prüfung).

### 3.1 Rechnungsduplikate / Versionsregel (endgültig)
1. Gleiche Rechnungsnummer → Rechnungsdatum vergleichen.
2. Neueres Rechnungsdatum gewinnt.
3. Bei identischem Rechnungsdatum gewinnt die **zuletzt importierte** Datei.
4. Bestehender DB-Eintrag wird aktualisiert.
5. Ältere Version darf **nicht** mehr fürs Matching verwendet werden.
6. Identische Dateien werden über **Hash** erkannt.

## 4. Dokumentklassifikation (Monatsarchive sind gemischt)

Jedes Dokument wird **vor** dem Import klassifiziert; nicht alle PDFs sind Rechnungen.
- Rechnungsimport nur für `AUSGANGSRECHNUNG_*`, `EINGANGSRECHNUNG`, `GUTSCHRIFT`.
- `Umsaetze_*`-PDFs und `.mta` → Bank-/Umsatzdokumente, **nicht** in `invoices`.
- `KASSENBERICHT` → inventarisieren, nicht als Rechnung speichern.
- Motion/Sumup → `EC_SETTLEMENT` getrennt inventarisieren.
- Motion/Provision → `PROVISIONSABRECHNUNG`, nicht blind als Rechnung.
- Monatskontext aus Ordnernamen (z. B. „April 2026“) wird im Dokumentinventar gespeichert.
- Inventar-Hash bleibt eindeutig; identische Dateien werden nicht mehrfach inventarisiert.

## 5. Kontoauszüge

- Kontoauszüge werden vollständig importiert; Buchungen extrahiert und gespeichert.
- Duplikate werden über Hash/Importlogik verhindert.
- Kontoauszüge werden nach Import-/Ablagedatum einsortiert.

> Dokumentierter Altbefund: erkannte Kontoauszugs-PDFs erzeugten zuletzt **keine**
> Bankbuchungen (Parsergrenze). Offen, siehe `docs/OPEN_POINTS.md`.

## 6. Matching (Rechnung ↔ Bankbuchung)

- Zuerst lokale SQL-/Regelsuche.
- Kriterien/Signale: Betrag, Firma/Name, Verwendungszweck, Rechnungsnummernfragmente, Datum,
  Zahlungsart (gemäß ENTWICKLUNGSPLAN zusätzlich IBAN).
- Status:
  - `GEFUNDEN`
  - `UNSICHER`
  - `NICHT_GEFUNDEN`
  - `MANUELL_GEPRUEFT`
  - `NICHT_ZU_MATCHEN` (Bankbuchung, die nicht zugeordnet werden soll)
- Sichere Treffer werden automatisch gespeichert und organisiert.
- Unsichere Treffer werden **nicht** automatisch organisiert.

### 6.1 Manuelle unsichere Zuordnungen
Entscheidungen: `OFFEN`, `ANGENOMMEN`, `ABGELEHNT`.
- Annahme erzeugt sichere Zuordnung und organisiert die Dateien.
- Ablehnung bleibt gespeichert; abgelehnte Vorschläge werden bei späteren Läufen **nicht**
  wieder offen.
- Offene Vorschläge erscheinen im Excel-Blatt `Unsicher`, abgelehnte im Blatt `Abgelehnt`.

## 7. EC-/Telexpert-Sammelzahlungen (endgültige Regel)

1. Zwischen zwei erkannten Karteneinzahlungen werden passende offene EC-/Telexpert-Belege
   gesammelt.
2. Die Belege werden summiert.
3. **Exakte Summe:** alle verwendeten Belege als erledigt markieren.
4. **Summe größer als Einzahlung:**
   - **neueste** Belege zuerst entfernen (Auszahlung kann bis zu zwei Tage verzögert erscheinen),
   - nach jeder Entfernung neu summieren, bis exakte Summe erreicht ist,
   - **keine** beliebige Kombinationssuche.
5. Entfernte neuere Belege bleiben offen für den nächsten Zeitraum.
6. **Summe kleiner als Einzahlung:** Status `UNVOLLSTAENDIG`, Fehlbetrag ausweisen (Belege fehlen).
7. Verwendete Belege dürfen **nie** erneut verwendet werden (Belegsperre bei finaler Zuordnung).
8. Zeitraum und verwendete Belege werden protokolliert und in eigener Ordnerstruktur abgelegt.

Nicht-finale Status (sperren **keine** Belege): `UNVOLLSTAENDIG`, `WARTE_AUF_EINZAHLUNG`,
`UNSICHER_KEINE_EXAKTE_REDUKTION`. Manuell angenommene/abgelehnte unsichere EC-Fälle werden
aus der EC-Kandidatenliste ausgeschlossen. Die EC-Dateiablage **kopiert** nur, löscht keine
Originale. Eigenes Excel-Blatt `EC-Sammel`. Zweiter Lauf erzeugt keine Duplikate (Idempotenz).

## 8. Gmail

- Mehrere Postfächer; je Mailbox eigener Unterordner unter `<DATA_ROOT>/config/gmail/<mailbox_key>`
  mit eigener `credentials.json`/`token.json`; Discovery automatisch, kein hartcodierter Count.
- `mailbox_key` = stabiler technischer Schlüssel; echte Gmail-Adresse nach Login aus Profil.
- Verarbeitung stabil sortiert, Mailbox für Mailbox; Fehler einer Mailbox isoliert andere nicht.
- Zeiträume: Eingabe inklusive Kalendertage; Gmail-`before` intern auf Folgetag (exklusiv).
- Pagination vollständig; PDF-Anhänge rekursiv in MIME erkennen.
- Dedup über `mailbox_key + gmail_message_id`; Raw-Dedup über SHA-256
  (`__2`/`__3` bei Namenskonflikt, kein Überschreiben/Verschieben/Löschen).
- Raw-Ablage unter `<DATA_ROOT>/_dump/gmail/<mailbox_email>/<gmail_message_id>/`.
- Nach Raw-Speicherung wird der **bestehende** Rechnungsimport verwendet – keine zweite
  Importarchitektur.
- **Gmail-Nachsuche** für offene Bankbuchungen: nur suchberechtigte Buchungen
  (nicht `NICHT_ZU_MATCHEN`, nicht reine Karteneinzahlung, nicht bereits zugeordnet);
  Referenzfragment hat höchste Priorität; generische/zu kurze Begriffe werden verworfen;
  Treffer → bestehender Import → erneutes Matching; idempotent (kein Doppel-Datensatz).
- Gmail-Secrets werden nicht geloggt, exportiert oder in der DB gespeichert.

## 9. Berichte und Betrieb

- **Excel-Bericht**, Blätter: `Übersicht`, `Alles`, `Zugeordnet`, `Unsicher`, `Abgelehnt`,
  `Nicht zugeordnet`, `EC-Sammel`. Farben: gefunden grün, unsicher gelb, nicht zugeordnet
  rot/orange; positive Bankbeträge grün, negative rot; neueste Buchungen zuerst.
  Klick-Hyperlinks auf Rechnung, Kontoauszug, Protokoll.
- Begriff **`Zuordnungen`** (nicht „Matches“).
- Zwei Betriebsarten ohne doppelte Fachlogik: **Erstimport** (historisch, chronologisch bis
  heute) und **laufender Betrieb** (nur neue/offene Daten seit letztem erfolgreichem Stand).
  Beide nutzen dieselben Kernmodule.
- **Processing State:** Laufstart, Erfolg, Fehler, letzter erfolgreicher Zeitpunkt, Erfolgszähler.

## 10. Ablage- und Sicherheitsregeln (an neue Architektur angepasst)

- **Originaldokumente bleiben lokal** auf `DATA_ROOT`; zentral nur Metadaten, Hash und
  **relative** Locator. *(Ersetzt die aufgehobene zentrale UNC-/Tailscale-Ablage; Hyperlinks
  öffnen lokal statt über Netzwerkstamm.)*
- Normale Reports/Exporte erzeugen **keine** PDF-Duplikate.
- Reset/Reset-Befehle: nie stillschweigend, nur mit Pfadanzeige + TEST-Kennzeichnung +
  Sicherheitsabfrage; PRODUKTIONS-Modus blockiert. Produktivdaten werden nie automatisch
  gelöscht.
- Parser-Feinoptimierung ist Spätarbeit; nur blockierende Parserfehler sofort minimal beheben.

## 11. KI

- Nicht Teil der Kernlogik. Später nur für Sonderfälle (schlechte OCR, unklare Rechnungsdaten,
  unsichere Zuordnungen, ungewöhnliche Verwendungszwecke, Vorschläge zur manuellen Prüfung).

---
*Alle Regeln dieses Dokuments stammen aus dokumentierten Altprojekt-Entscheidungen bzw. den
Akzeptanzkriterien des ENTWICKLUNGSPLAN. Es wurden keine neuen Fachregeln erfunden.*
