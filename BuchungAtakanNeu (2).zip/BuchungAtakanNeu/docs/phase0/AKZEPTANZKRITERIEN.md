# Akzeptanzkriterien-Bewertung – Phase 0

**Stand:** 2026-06-26
**Bewertet durch:** Claude (Analyse-Agent), GSD-Plan 01-03
**Grundlage:** Alle Phase-0-Lieferobjekte (Wave 1–3), REQUIREMENTS.md ARCH-01..11

---

## Bewertungsschema

| Status | Bedeutung |
|--------|-----------|
| **ERFÜLLT** | Lieferobjekt vorhanden und inhaltlich vollständig |
| **NICHT ERFÜLLT** | Lieferobjekt fehlt oder unvollständig |
| **NICHT GETESTET** | Nicht automatisiert prüfbar (z. B. Nutzerfreigabe) |

---

## Kriterien (ARCH-01..11)

### ARCH-01 — Bestehender Teststand unverändert ausgeführt und dokumentiert

| Feld | Inhalt |
|------|--------|
| **Status** | **ERFÜLLT** |
| **Nachweis** | `docs/phase0/BASELINE_TESTS.md` |
| **Abschnitt** | `## Testergebnis` |
| **Ergebnis** | 162 Tests, 162 bestanden, 0 fehlgeschlagen, Laufzeit 16.71s, Exit-Code 0 |
| **Bewertungsbasis** | Testlauf mit `pytest --tb=short -q --no-header --ignore=tmpk595lbow` im Altprojektverzeichnis |

**Begründung:** Der Teststand des Altprojekts wurde am 2026-06-26 read-only ausgeführt und
lieferte exakt das erwartete Ergebnis (162 grün, laut CURRENT_STATUS.md Stand 2026-06-24).
Die Dokumentation ist in `docs/phase0/BASELINE_TESTS.md` vollständig vorhanden.

---

### ARCH-02 — Kein Produktivcode/Datenbestand in Phase 0 destruktiv verändert

| Feld | Inhalt |
|------|--------|
| **Status** | **ERFÜLLT** |
| **Nachweis** | `docs/phase0/BESTANDSAUFNAHME.md` (READ-ONLY-Vermerk), `docs/phase0/BASELINE_TESTS.md` (git status Prüfung) |
| **Abschnitt** | Constraint-Block BESTANDSAUFNAHME.md §1; BASELINE_TESTS.md § Altprojekt-Git-Status |

**Begründung:** BESTANDSAUFNAHME.md dokumentiert explizit: „Dieses Dokument ist rein
dokumentarisch. Das Altprojekt wurde nicht verändert. Alle Zugriffe auf das Altprojekt
erfolgten ausschließlich lesend." Der Testlauf-Abschnitt in BASELINE_TESTS.md dokumentiert
den git-Status: Die vorgefundenen Modifikationen im Altprojekt-Arbeitsverzeichnis sind
vorbestehende Arbeitsstand-Änderungen, keine Konsequenz des Testlaufs.

---

### ARCH-03 — Jedes Haupt-Altmodul eindeutig Client / Server / Shared Core zugeordnet

| Feld | Inhalt |
|------|--------|
| **Status** | **ERFÜLLT** |
| **Nachweis** | `docs/phase0/MODULKLASSIFIKATION.md` |
| **Abschnitt** | `## Modulklassifikation` (Tabelle mit 14 Modulen) |

**Ergebnis der Tabelle:**

| Kategorie | Zugeordnete Module |
|-----------|--------------------|
| Shared Core | `ec` (Kernlogik), `invoice`, `matching`, `pdf`, `utils`, Teile von `bank`, Teile von `gmail`, Teile von `models` |
| Lokaler Client | `config`, `filesystem`, `logging_system`, Teile von `bank`, Teile von `gmail`, Teile von `pipeline`, `reports` |
| GEMISCHT → aufzuteilen | `bank`, `gmail`, `models`, `pipeline` |
| AUFZULÖSEN / Infrastruktur-Adapter | `database` |

Alle 14 Module aus `src/` sind in der Tabelle erfasst und klassifiziert.

---

### ARCH-04 — Alle direkten DB-/SQLite-Zugriffe inventarisiert

| Feld | Inhalt |
|------|--------|
| **Status** | **ERFÜLLT** |
| **Nachweis** | `docs/phase0/BESTANDSAUFNAHME.md` |
| **Abschnitt** | `## DB-Zugriffe (SQLite)` |

**Ergebnis:** 14 `sqlite3.connect()`-Aufrufe in 11 Modulen sind tabellarisch erfasst
(Datei, Zeile, Muster, Klassifikation, Kontext). Module mit `import sqlite3` sind vollständig
aufgelistet. Bewertung für Zielarchitektur ist dokumentiert.

---

### ARCH-05 — Alle absoluten/UNC-Dokumentpfadannahmen inventarisiert

| Feld | Inhalt |
|------|--------|
| **Status** | **ERFÜLLT** |
| **Nachweis** | `docs/phase0/BESTANDSAUFNAHME.md` |
| **Abschnitt** | `## Pfadannahmen` |

**Ergebnis:** Drei Unterabschnitte:
1. Absolute/UNC-Pfade (werden in Zielarchitektur eliminiert) — `network_document_root`-Stellen
   als SUPERSEDED per D6 dokumentiert.
2. DATA_ROOT- und PathConfig-Nutzung (wiederverwendbar) — Tabelle mit Datei, Zeile, Muster.
3. Umgebungsvariablen-Mapping (Altname → Zielname) — `BUCHUNG_CUMCU_*` → `BUCHUNG_ATAKAN_*`.

---

### ARCH-06 — Je Alttabelle dokumentiert: zentral, lokal oder abzulösen

| Feld | Inhalt |
|------|--------|
| **Status** | **ERFÜLLT** |
| **Nachweis** | `docs/phase0/MIGRATIONSPLAN.md` |
| **Abschnitt** | `## Tabellen-Mapping (ARCH-06)` |

**Ergebnis:** 9 Primärtabellen aus der ARCH-06-Anforderung sind vollständig erfasst und
bewertet. Zusätzlich 3 ergänzende Tabellen aus dem Altschema. Je Tabelle sind dokumentiert:
Alt-Tabellenname, Zielkategorie (ZENTRAL/LOKAL), Zielname (Vorschlag), Pflichtänderungen
und Bemerkungen.

Tabellen-Mapping (Kurzübersicht):

| Alt-Tabelle | Zielkategorie |
|-------------|--------------|
| `emails` | ZENTRAL |
| `invoices` | ZENTRAL |
| `bank_transactions` | ZENTRAL |
| `zuordnungen` | ZENTRAL |
| `unsichere_zuordnungen` | ZENTRAL |
| `gmail_scan_history` | ZENTRAL |
| `files` | ZENTRAL |
| `processing_state` | LOKAL |
| `gmail_bank_search` | ZENTRAL |

---

### ARCH-07 — unternehmen_id, installation_id und Dokument-Lokator formal definiert

| Feld | Inhalt |
|------|--------|
| **Status** | **ERFÜLLT** |
| **Nachweis** | `docs/phase0/API_GROBVERTRAG.md` |
| **Abschnitt** | `## Identifier-Definitionen (ARCH-07)` |

**Ergebnis:** Alle drei Identifier sind mit Typ, Format und Constraints formal definiert:

| Identifier | Typ | Format |
|------------|-----|--------|
| `unternehmen_id` | UUID v4 | `xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx` |
| `installation_id` | UUID v4 | Gleiche UUID-v4-Struktur, eindeutig je lokaler Installation |
| Dokument-Lokator | `(installation_id, source_relative_path)` | Tupel; absoluter Pfad niemals zentral gespeichert (D6) |

Constraints, Vergabe-Regeln und reservierte Test-UUIDs sind dokumentiert.

---

### ARCH-08 — Schriftlicher, reversibler Migrationspfad Ist→Ziel liegt vor

| Feld | Inhalt |
|------|--------|
| **Status** | **ERFÜLLT** |
| **Nachweis** | `docs/phase0/MIGRATIONSPLAN.md` |
| **Abschnitt** | `## Reversibler Migrationspfad (ARCH-08, per D1)` |

**Ergebnis:** 6 nummerierte Schritte (Vorbereitung → Zielschema → Mapping-Test →
Realdaten-Probe → Rollback-Test → Produktionsmigration). Jeder Schritt enthält:
Aktion, Test und Rollback-Mechanismus. Invariante explizit dokumentiert:
„`C:\Users\User\PycharmProjects\BuchungAtakan\` und die dortige SQLite-Datei werden
in keinem der obigen Schritte verändert oder gelöscht."

---

### ARCH-09 — GUI-Technologie (PySide6) entschieden, Fachlogik UI-unabhängig

| Feld | Inhalt |
|------|--------|
| **Status** | **ERFÜLLT** |
| **Nachweis** | `docs/phase0/API_GROBVERTRAG.md` § GUI-Technologie; `docs/ARCHITECTURE.md` §2 |
| **Abschnitt** | `## GUI-Technologie (ARCH-09, D3)` (API_GROBVERTRAG.md); `## 2. Technologierahmen` (ARCHITECTURE.md) |

**Ergebnis:** Entscheidung D3 ist verbindlich getroffen und in beiden Dokumenten
dokumentiert: Lokaler Windows-Client mit **PySide6**; Domänenlogik in `packages/core/`
bleibt UI-unabhängig (Ports/Adapter-Prinzip). Bindungsklausel: „Eine Änderung erfordert
explizite Nutzerfreigabe und einen neuen Architekturentscheid."

---

### ARCH-10 — API-Versionierung und Feature-Flag-System festgelegt

| Feld | Inhalt |
|------|--------|
| **Status** | **ERFÜLLT** |
| **Nachweis** | `docs/phase0/API_GROBVERTRAG.md` |
| **Abschnitt** | `## API-Struktur und Versionierung (ARCH-10)` + `## Feature-Flag-System (ARCH-10, per D4)` |

**Ergebnis:**
- URL-Präfix: `/api/v1/` (lokal: `http://localhost:8000/api/v1/`, produktiv: `https://[server-aachen]/api/v1/`)
- Feature-Flag-Präfix: `BUCHUNG_ATAKAN_FEATURE_` (Großbuchstaben + Unterstriche)
- Aktivierungsreihenfolge: Umgebungsvariable > JSON-Config > Codewert (Standard `false`)
- 5 initiale Feature-Flags dokumentiert (GMAIL_REAL_OAUTH, OPTIONAL_C_DOC_REPLICATION,
  DATEV_EXPORT, GOBD_AUDIT_TRAIL, AI_SUGGESTIONS)

---

### ARCH-11 — Nutzer hat Architektur und Phasenreihenfolge freigegeben

| Feld | Inhalt |
|------|--------|
| **Status** | **ERFÜLLT** |
| **Nachweis** | Explizite Nutzerfreigabe am 2026-06-27 ("FREIGEGEBEN") |
| **Abschnitt** | — |

**Begründung:** Nutzer hat am 2026-06-27 explizit „FREIGEGEBEN" eingegeben.
Blocking-Checkpoint aufgelöst. Phase 1 (API/PostgreSQL/Mandanten) darf starten.

---

## Gesamtbewertung

| Status | Anzahl | Kriterien |
|--------|--------|-----------|
| **ERFÜLLT** | 11 | ARCH-01, ARCH-02, ARCH-03, ARCH-04, ARCH-05, ARCH-06, ARCH-07, ARCH-08, ARCH-09, ARCH-10, ARCH-11 |
| **NICHT ERFÜLLT** | 0 | — |
| **NICHT GETESTET** | 0 | — |

**Mindestanforderung laut Plan (01-03 Verification):** ARCH-01..10 mindestens 9 als ERFÜLLT.
**Tatsächliches Ergebnis:** 10 von 10 als ERFÜLLT. Anforderung übererfüllt.

---

## Offene Punkte nach Phase 0

Die folgenden offenen Punkte aus `docs/OPEN_POINTS.md` bleiben für Folgephasen bestehen:

| ID | Punkt | Adressiert in Phase |
|----|-------|---------------------|
| P-01 | Detailliertes Tabellen-/Feld-Mapping (D1-Folge) | Dokumentiert in MIGRATIONSPLAN.md; Implementierung Phase 1 |
| P-02 | Authentifizierungs-/Rollenmodell (Server) | Phase 1 (SRV-11) |
| P-03 | Offline-Outbox & Synchronisationsstrategie | Phase 2 (CLI-06, CLI-07) |
| P-04 | `installation_id`-Konzept ausarbeiten | Phase 1–2 (SRV-01, CLI-05) |
| P-05 | Modulschnitt als Phase-0-Lieferobjekt | **ERLEDIGT** — MODULKLASSIFIKATION.md |
| P-06 | Reset-/Testdaten-Befehle auf neue Äquivalente übertragen | Phase 1–2 |
| P-07 | Excel-/Dokument-Hyperlinks auf lokale Pfadöffnung umstellen | Phase 8/9 (UI-03) |
| P-08 | Optional C, DATEV, GoBD, KI | Außerhalb Kern-MVP |
| A-01 | Kontoauszugs-PDF → keine Bankbuchungen (Parsergrenze) | Phase 4 (BANK-01) |
| A-02 | Gmail-OAuth-Realbetrieb separat freizugeben | Phase 7 (MAIL-01, Feature-Flag) |
| A-03 | GUI und Scheduler offen | Phase 7–8 |
| A-04 | Parseroptimierung Spätarbeit | Nach Phase 3 |

**Technische Schulden (hohe Priorität):**
- TS-H-01: Direkte sqlite3.connect()-Aufrufe → Phase 1–4 ersetzen
- TS-H-02: BUCHUNG_CUMCU_*-Umgebungsvariablen → Phase 2 umbenennen
- TS-H-03: File.file_path absoluter Pfad → Phase 2 (CLI-02, CLI-05)
- TS-H-04: network_document_root-Parameter entfernen → Phase 1–2
- TS-H-05: EcSettlementService DB-Kopplung → Phase 5 (EC-Architektur)
- TS-H-06: database/-Repositories gegen PostgreSQL → Phase 1
