# API-Grobvertrag – Phase 0

**Stand:** 2026-06-26
**Autoritativ:** `docs/ENTWICKLUNGSPLAN.md` §2 Betriebsarchitektur
**Entscheidungsgrundlage:** OPEN_POINTS.md D1–D6 (verbindlich, nicht neu verhandelbar)

---

## Identifier-Definitionen (ARCH-07)

### unternehmen_id

| Eigenschaft | Wert |
|-------------|------|
| **Typ** | UUID v4 (Python: `uuid.uuid4()`) |
| **Format** | RFC 4122, Kleinbuchstaben mit Bindestrichen: `xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx` |
| **Vergabe** | Ausschließlich durch den zentralen Server bei Erstanlage eines Unternehmens |
| **Unveränderlichkeit** | Einmal vergeben, für die gesamte Laufzeit des Systems unveränderlich |
| **Constraints** | `NOT NULL`, `UNIQUE` in Tabelle `unternehmen`; Fremdschlüssel in allen mandantengebundenen Tabellen |
| **Speicherort** | Zentrale PostgreSQL; jede mandantengebundene Tabelle |
| **Test-Fixture** | `00000000-0000-4000-a000-000000000001` (Mandant A), `00000000-0000-4000-a000-000000000002` (Mandant B) |

**Sicherheitsregel (T-02-03):**
> Der Client darf die `unternehmen_id` **niemals selbst setzen, übermitteln oder beeinflussen**.
> Der Server ermittelt die zulässige `unternehmen_id` ausschließlich aus der authentifizierten
> Sitzung (Bearer-Token). Jede API-Anfrage, die eine `unternehmen_id` im Request-Body oder
> Query-Parameter enthält, wird mit `400 Bad Request` abgelehnt (nicht still ignoriert).

---

### installation_id

| Eigenschaft | Wert |
|-------------|------|
| **Typ** | UUID v4 (Python: `uuid.uuid4()`) |
| **Format** | RFC 4122 |
| **Vergabe** | Bei Erststart des lokalen Clients generiert und in lokaler Konfigurationsdatei gespeichert; beim Server registriert (`POST /api/v1/installationen/`) |
| **Eindeutigkeit** | Eindeutig je Installation; `NOT NULL` in Tabellen mit Dokumenten-/Installationsbezug; global **nicht** unique (mehrere Installationen je Unternehmen möglich) |
| **Speicherort** | Lokal: Konfigurationsdatei (`BUCHUNG_ATAKAN_CONFIG_FILE`). Zentral: PostgreSQL-Tabelle `installationen` |

**Sicherheitsregel:**
> Ein Client darf ausschließlich die eigene `installation_id` verwenden.
> Der Server prüft bei jeder Anfrage: `installation_id` muss zur authentifizierten `unternehmen_id`
> gehören (`installationen.unternehmen_id = current_tenant`). Fremde `installation_id` liefert
> `403 Forbidden`.

---

### Dokument-Lokator

**Definition:** Ein Dokumentlokator identifiziert ein Originaldokument eindeutig im Kontext
einer lokalen Installation. Er besteht aus zwei Komponenten:

```
Dokumentlokator = (installation_id, relativer_pfad)
```

| Komponente | Beschreibung |
|------------|-------------|
| `installation_id` | FK auf `installationen(id)` — identifiziert die Installation |
| `relativer_pfad` | `pathlib.PurePosixPath`-Darstellung relativ zur `DATA_ROOT` der Installation |

**Speicherregeln (D6):**
- **Zentral gespeichert:** `installation_id` (FK) und `relativer_pfad` als `VARCHAR/TEXT`
- **NICHT zentral gespeichert:** Absoluter lokaler Pfad, `DATA_ROOT` selbst, Windows-Backslashes
- **Lokale Auflösung (nur auf Client):** `lokaler_abs_pfad = DATA_ROOT / relativer_pfad`
- **Format relativer Pfad:** PosixPath-Notation (Schrägstriche), z. B. `rechnungen/2026/01/rechnung_123.pdf`

**Beispiel:**
```
installation_id  = "a1b2c3d4-..."
relativer_pfad   = "rechnungen/2026/01/rechnung_muster_gmbh.pdf"
→ Lokale Auflösung: C:/Users/User/buchung_data/rechnungen/2026/01/rechnung_muster_gmbh.pdf
   (DATA_ROOT ist nur lokal bekannt; der Server kennt nur den relativen Pfad)
```

**Hinweis Optional C (D6):**
UNC-Pfade und verschlüsselte zentrale Dokumentkopien sind kein Kern-MVP.
Sie sind als „Optional C – verschlüsselte Dokumentreplikation" geparkt und können
über `BUCHUNG_ATAKAN_FEATURE_OPTIONAL_C_DOC_REPLICATION` aktiviert werden.

---

## API-Struktur und Versionierung (ARCH-10)

### Basis-URL-Schema

| Umgebung | Basis-URL |
|----------|-----------|
| Entwicklung | `http://localhost:8000/api/v1/` |
| Produktion | `https://[server-aachen]/api/v1/` |

### Versionierungsstrategie

- **URL-Präfix `/api/v1/`** für alle Endpunkte (v1 = erster stabiler Vertrag)
- **Innerhalb v1:** Additive Änderungen (neue optionale Felder) ohne Versionserhöhung zulässig
- **Breaking Changes** → `/api/v2/` (paralleler Betrieb bis alle Clients auf v2 migriert)
- **Deprecation-Prozess:** Breaking Change wird mindestens eine Phase im Voraus angekündigt;
  veraltete Endpunkte liefern `Deprecation`-HTTP-Header
- **Accept-Header-Feingranularität:** Kein Kern-MVP; optional in späteren Phasen

### Initiale API-Bereiche (Grobschnitt)

| Bereich | Präfix | Beschreibung | Phase |
|---------|--------|-------------|-------|
| Authentifizierung | `/api/v1/auth/` | Anmeldung, Token-Verwaltung, Session, Logout | Phase 1 |
| Unternehmens-Verwaltung | `/api/v1/unternehmen/` | Anlage und Verwaltung von Mandanten (nur `SYSTEM_ADMIN`) | Phase 1 |
| Installationen | `/api/v1/installationen/` | Registrierung und Verwaltung lokaler Installationen | Phase 1 |
| Dokumente | `/api/v1/dokumente/` | Dokument-Metadaten, Lokator, Verfügbarkeitsstatus | Phase 2 |
| Rechnungen | `/api/v1/rechnungen/` | Rechnungsdaten, Extraktion, Kandidaten, freigegebene Werte | Phase 3 |
| Bankbuchungen | `/api/v1/bankbuchungen/` | Kontoauszüge, Transaktionen, Matching-Status | Phase 4 |
| Zuordnungen | `/api/v1/zuordnungen/` | Matching-Ergebnisse, manuelle Freigabe | Phase 4 |
| EC-Sammelzuordnung | `/api/v1/ec-sammel/` | EC-/Telexpert-Sammelzuordnungen | Phase 5 |
| Gmail-Scan | `/api/v1/gmail-scan/` | Scan-Historie, Scan-Aufträge, Nachsucheläufe | Phase 7 |
| Hintergrund-Jobs | `/api/v1/jobs/` | Job-Status, Fortschrittsanzeige | Phase 1 |
| Systemgesundheit | `/api/v1/health/` | Health-Check, Readiness (kein Auth erforderlich) | Phase 1 |

### Standard-Fehlerformat

Alle API-Fehler verwenden einheitliches JSON:

```json
{
  "error_code": "INVOICE_NOT_FOUND",
  "message": "Rechnung mit ID 123 nicht gefunden.",
  "request_id": "f47ac10b-58cc-4372-a567-0e02b2c3d479"
}
```

**Sicherheitsregeln für Fehlerantworten:**
- Keine Passwörter, API-Schlüssel oder Bearer-Tokens
- Keine SQL-Details, Stack-Traces oder Datenbankstruktur
- Keine Daten anderer Mandanten (`unternehmen_id` darf nicht in Fehlermeldungen erscheinen)
- `404 Not Found` statt `403 Forbidden` wenn Existenz eines fremden Datensatzes nicht
  preisgegeben werden soll (Tenant-Isolation durch Nicht-Offenbarung)

### Request-ID

- HTTP-Header `X-Request-ID` (Client setzt; Server übernimmt oder erzeugt falls fehlend)
- Wird in allen strukturierten Server-Logs mitgeführt
- Format: UUID v4
- Zweck: End-to-End-Tracing über Client-Log und Server-Log

---

## GUI-Technologie (ARCH-09, per D3)

| Komponente | Technologie |
|------------|-------------|
| Lokaler Windows-Client (UI) | **PySide6** (Qt for Python) |
| Domänen- und Anwendungslogik | Vollständig UI-unabhängig (Ports/Adapter-Muster) |
| Spätere Erweiterbarkeit | Web-Frontend über separaten Adapter möglich (ohne Kernlogik-Änderung) |

**Begründung (D3, bindend):**
PySide6 erlaubt eine native Windows-Desktopanwendung, die später als EXE paketiert
werden kann (Phase 7). Die Domänenlogik in `packages/core/` bleibt vollständig testbar
ohne GUI-Initialisierung. Eine spätere Web-Oberfläche (z. B. für Steuerberater)
kann als zusätzlicher Adapter angebunden werden.

**Bindung:** Diese Entscheidung ist für alle Folgephasen verbindlich. Eine Änderung
erfordert explizite Nutzerfreigabe und einen neuen Architekturentscheid.

### Ports und Adapter (aus ENTWICKLUNGSPLAN §5)

Alle Kernmodule kommunizieren ausschließlich über diese Ports — keine direkten
Anbieter-Aufrufe in `packages/core/`:

| Port | Verantwortung |
|------|--------------|
| `DocumentStoragePort` | Lokales Speichern und Öffnen von Dokumenten |
| `InvoiceExtractionPort` | PDF-Text, OCR, E-Rechnung, weitere Parser |
| `BankStatementParserPort` | CAMT, MT940, CSV, PDF und weitere Formate |
| `MailProviderPort` | Gmail, später weitere Postfächer (IMAP, Outlook) |
| `MatchingStrategyPort` | Standard-Matching, EC-Matching, Sonderstrategien |
| `ExportProviderPort` | Excel/CSV/JSON; optional DATEV |
| `NotificationPort` | Lokale Meldung, E-Mail oder spätere Push-Benachrichtigung |
| `OptionalCompliancePort` | GoBD-orientierte Zusatzfunktionen (Optional B) |
| `AIServicePort` | Optionale KI-Unterstützung für schwierige Fälle (Optional E) |

---

## Feature-Flag-System (ARCH-10, per D4)

### Namensschema

| Eigenschaft | Regel |
|-------------|-------|
| **Präfix** | `BUCHUNG_ATAKAN_FEATURE_` |
| **Format** | `BUCHUNG_ATAKAN_FEATURE_<FUNKTIONSNAME>` (nur GROSSBUCHSTABEN und Unterstriche) |
| **Standardwert** | `false` für alle optionalen Features |
| **Sichtbarkeit** | Feature-Flags sind niemals in API-Fehlermeldungen oder Logs mit Werten sichtbar |

### Aktivierungsreihenfolge (Priorität absteigend)

1. **Umgebungsvariable** — höchste Priorität; überschreibt alle anderen Quellen
2. **JSON-Konfigurationsdatei** — lokale Installationseinstellung (`BUCHUNG_ATAKAN_CONFIG_FILE`)
3. **Codewert (Standard)** — immer `false` für optionale Features

### Initiale Feature-Flags (Kern-MVP und Optionals)

| Flag | Standardwert | Beschreibung | Freigabe |
|------|-------------|-------------|---------|
| `BUCHUNG_ATAKAN_FEATURE_GMAIL_REAL_OAUTH` | `false` | Realer Gmail-API-/OAuth-Betrieb mit echten Postfächern (A-02) | Explizite Nutzerfreigabe vor Phase 7 |
| `BUCHUNG_ATAKAN_FEATURE_OPTIONAL_C_DOC_REPLICATION` | `false` | Verschlüsselte zentrale Dokumentkopie / Dokumentreplikation (Optional C) | Kein Kern-MVP |
| `BUCHUNG_ATAKAN_FEATURE_DATEV_EXPORT` | `false` | DATEV-ASCII-/CSV-Export (Optional A) | Kein Kern-MVP |
| `BUCHUNG_ATAKAN_FEATURE_GOBD_AUDIT_TRAIL` | `false` | GoBD-orientierte unveränderliche Audit-Spur (Optional B) | Kein Kern-MVP |
| `BUCHUNG_ATAKAN_FEATURE_AI_SUGGESTIONS` | `false` | KI-Vorschläge für schwierige Match-Fälle (Optional E) | Kein Kern-MVP |

### Kompatibilitätsfallbacks (per D4, temporär während Migration)

`BUCHUNG_CUMCU_*`-Variablen werden **ausschließlich** als explizit dokumentierte Fallbacks
in Übergangsmodulen des lokalen Clients akzeptiert. In jedem Modul, das einen `BUCHUNG_CUMCU_*`-
Fallback liest, muss ein Kommentar folgender Form stehen:

```python
# MIGRATION-FALLBACK (D4): Entfernen, sobald alle Installationen auf
# BUCHUNG_ATAKAN_* migriert sind.
legacy_val = os.environ.get("BUCHUNG_CUMCU_DATA_ROOT")
```

Neuer Code in `packages/core/` und `apps/server/` verwendet **ausschließlich** `BUCHUNG_ATAKAN_*`.
Kein Server-Code darf `BUCHUNG_CUMCU_*`-Variablen lesen.

---

## Mandantentrennung — Vertragliche Regeln

Diese Regeln sind für alle API-Endpunkte und Repository-Abfragen verbindlich (ENTWICKLUNGSPLAN §2.3):

1. **Bearer-Token verpflichtend:** Jede API-Anfrage (außer `/api/v1/health/` und `/api/v1/auth/login`)
   erfordert einen gültigen Bearer-Token im `Authorization`-Header.

2. **Server ermittelt Mandant aus Token:** Der Server extrahiert `unternehmen_id` ausschließlich
   aus der validierten Sitzung — nie aus dem Request-Body oder Query-Parametern.

3. **Mandantenfilter in jedem Query:** Jede Repository-Abfrage enthält
   `WHERE unternehmen_id = :current_tenant`. Abfragen ohne diesen Filter sind
   unzulässig (Lint-Regel / Code-Review-Pflicht ab Phase 1).

4. **Row Level Security:** PostgreSQL RLS als Defense-in-Depth-Schutzschicht;
   Datenbankbenutzer für Server-Prozesse darf nur Zeilen der eigenen Policies sehen.

5. **Cross-Tenant-Tests verpflichtend:** Für alle kritischen Endpunkte (Rechnungen,
   Bankbuchungen, Zuordnungen, Dokumente) werden Mandantentrennungs-Integrationstests
   mit zwei voneinander unabhängigen Test-Mandanten durchgeführt (ab Phase 2).

6. **Fehler bei Mandantenverstoß:** Eine Anfrage auf Daten eines fremden Mandanten liefert
   `404 Not Found` (kein `403`, um Existenz fremder Datensätze nicht preiszugeben).

7. **`unternehmen_id` im Request abgelehnt:** Jede Anfrage, die eine `unternehmen_id`
   im Body oder Query-String übergibt, wird mit `400 Bad Request` und
   `"error_code": "TENANT_ID_CLIENT_SET_FORBIDDEN"` abgelehnt.
