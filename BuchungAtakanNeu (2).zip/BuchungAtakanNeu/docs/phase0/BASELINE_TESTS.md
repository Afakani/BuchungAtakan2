# Baseline-Teststand – Phase 0

**Stand:** 2026-06-26T09:22:18Z
**Altprojektpfad:** `C:\Users\User\PycharmProjects\BuchungAtakan\`
**Status:** GETESTET
**READ-ONLY:** Kein Altprojekt-Code wurde verändert. Alle Zugriffe erfolgten ausschließlich
lesend (pytest --tb=short -q --no-header --ignore=tmpk595lbow).

---

## Testergebnis

| Kennzahl | Wert |
|----------|------|
| Gesamtanzahl Tests | 162 |
| Bestanden (passed) | 162 |
| Fehlgeschlagen (failed) | 0 |
| Übersprungen (skipped) | 0 |
| Laufzeit | 16.71s |
| Pytest-Exit-Code | 0 |
| Pytest-Version | 9.1.0 |
| Python-Version | 3.12.10 |

---

## Pytest-Ausgabe (Zusammenfassung)

```
============================= test session starts =============================
collecting ... collected 162 items

[... 162 Tests PASSED ...]

============================ 162 passed in 16.71s =============================
```

Letzter Testblock (letzte Tests je Datei):

```
tests/test_pdf_document_detector.py::test_bank_statement_wins_when_more_bank_keywords_than_invoice_keywords PASSED [ 98%]
tests/test_pdf_reader_live.py::test_pdf_reader_reads_temporary_pdf PASSED [ 99%]
tests/test_pdf_real_invoice.py::test_synthetic_invoice_pdfs_can_be_read_and_detected PASSED [100%]

============================ 162 passed in 16.71s =============================
```

---

## Abgedeckte Testdateien (25 Dateien)

| Testdatei | Anzahl Tests (ca.) | Domäne |
|-----------|--------------------|--------|
| `test_bank_transaction_matching_status.py` | 8 | Bankbuchungs-Statusklassifikation |
| `test_data_root_security.py` | 10 | DATA_ROOT-Sicherheitsregeln |
| `test_database_initialization.py` | 13 | SQLite-Schema, Migrationen, Idempotenz |
| `test_date_normalization_chronology.py` | 10 | Datumsnormalisierung |
| `test_ec_chronology_regression.py` | 3 | EC-Sammelzuordnung Regressionstest |
| `test_excel_unique_bank_rows.py` | 2 | Excel-Export Eindeutigkeit |
| `test_gmail_attachment.py` | 6 | Gmail-Anhang-Datenklasse |
| `test_gmail_attachment_extra.py` | 6 | Gmail-Anhang-Randfälle |
| `test_gmail_bank_followup_search.py` | 12 | Gmail-Nachsuche |
| `test_gmail_pipeline_integration.py` | 7 | Gmail-Pipeline-Integration |
| `test_gmail_scan_intervals.py` | 14 | Scan-Intervall-Logik |
| `test_gmail_scanner.py` | 7 | Gmail-Scanner |
| `test_gmail_scanner_extra.py` | 9 | Gmail-Scanner-Randfälle |
| `test_invoice_file_organizer.py` | 2 | Rechnungs-Dateiorganisation |
| `test_invoice_parser.py` | 3 | Regex-Rechnungsparser |
| `test_invoice_processor.py` | 1 | Rechnungsverarbeitung kombiniert |
| `test_invoice_validator.py` | 7 | Fachliche Validierungsregeln |
| `test_invoice_repository.py` | (enthalten in db-init) | CRUD Rechnungen |
| `test_matching_regressions.py` | 7 | Rechnungs-Bankbuchungs-Matching |
| `test_month_archive_regressions.py` | 3 | Monatsarchiv-Klassifikation |
| `test_path_consistency.py` | 11 | Pfadkonsistenz / DATA_ROOT |
| `test_pdf_document_detector.py` | 16 | Dokumenttyp-Erkennung |
| `test_pdf_reader_live.py` | 1 | PDF-Reader (temporäre Testdatei) |
| `test_pdf_real_invoice.py` | 1 | Synthetische Rechnungs-PDF |

---

## Fehlgeschlagene Tests

Keine. Alle 162 Tests sind bestanden.

---

## Altprojekt-Git-Status nach Testlauf

```
 M AGENTS.md
 M CHANGELOG.md
 M src/database/gmail_repository.py
 M src/gmail/gmail_bank_followup_search.py
 M src/gmail/gmail_multi_mailbox.py
 M src/pipeline/buchungs_pipeline.py
 M src/pipeline/incremental_pipeline.py
 M src/pipeline/initial_import_pipeline.py
 M tests/test_gmail_bank_followup_search.py
?? src/gmail/gmail_scan_intervals.py
?? tests/test_gmail_pipeline_integration.py
?? tests/test_gmail_scan_intervals.py
```

**Bewertung:** Die angezeigten Modifikationen sind **vorbestehende Arbeitsstand-Änderungen
im Altprojekt**, die vor dem Testlauf existierten. Der Testlauf selbst (lesende pytest-Optionen,
kein schreibender conftest.py-Code) hat keine dieser Änderungen verursacht. ARCH-02 ist
vollständig erfüllt: Kein Quellcode, keine Datenbank und keine Testdaten des Altprojekts
wurden durch den Testlauf verändert.

Hinweis: Das Verzeichnis `tmpk595lbow` (temporäres Verzeichnis mit
Zugriffsbeschränkung) wurde beim Testlauf ignoriert (--ignore=tmpk595lbow). Dieses
Verzeichnis existierte bereits vor dem Testlauf.

---

## Bekannte Einschränkungen (aus CURRENT_STATUS.md)

- **A-01:** Erkannte Kontoauszugs-PDFs erzeugen aktuell **keine** Bankbuchungen
  (Parsergrenze); dokumentiert, nicht breit optimiert, solange kein Folgeblock blockiert.
- **A-02:** Realer Gmail-API-/OAuth-Betrieb mit echten Postfächern und Credentials (Rate-Limits)
  ist separat freizugeben; bisher nur Fakes, temporäre Datenbanken und synthetische Nachrichten.

Beide Einschränkungen spiegeln sich in den Tests wider: Gmail-Tests nutzen Fake-Services
und synthetische Daten; kein Test öffnet eine echte Gmail-API-Verbindung. Der Kontoauszugs-
Parser-Test (`test_month_archive_regressions.py::test_mt940_mta_transaction_is_parsed`)
ist grün, deckt jedoch nur die MTA-Dateiverarbeitung ab, nicht den vollständigen
PDF-zu-Bankbuchung-Pfad.

---

## Vergleich mit erwartetem Stand

| Erwartung | Ergebnis | Abweichung |
|-----------|----------|------------|
| ~162 pytest grün (Stand 2026-06-24, laut CURRENT_STATUS.md) | **162 passed** | Keine |

Der tatsächliche Teststand stimmt exakt mit dem erwarteten Stand überein.
