# Datenmigrations- und Schemaplan – Phase 0

**Stand:** 2026-06-26
**Grundlage:** D1 (OPEN_POINTS.md) — kein blinder Transfer, reversibler Pfad
**Autoritativ:** `docs/ENTWICKLUNGSPLAN.md` §2–§3, `docs/ARCHITECTURE.md` §7

---

## Ausgangszustand

| Dimension | Alt (Einzelmandant) | Ziel (Multi-Tenant) |
|-----------|--------------------|--------------------|
| Datenbanktyp | SQLite, lokale Datei `<DATA_ROOT>/database/buchhaltung.db` | PostgreSQL, zentrale Instanz (Aachen) |
| Mandantentrennung | keine — ein Datensatz je DB-Datei | `unternehmen_id` (UUID) in jeder mandantengebundenen Tabelle |
| Datenbankzugriff | direkt (`sqlite3.connect()`) aus Client-Code | ausschließlich über FastAPI (kein direkter Client-DB-Zugriff) |
| Pfadspeicherung | absolute Windows-Pfade (`file_path`, `stored_file_path`) | relativer Pfad + `installation_id` als Dokumentlokator (D6) |
| Schema-Management | additive manuelle Migrationen in `DatabaseManager._apply_safe_schema_migrations()` | Alembic versionierte Migrationen |
| ORM | keines — direktes `sqlite3` | SQLAlchemy 2.x + Pydantic (Server-Seite) |

---

## Tabellen-Mapping (ARCH-06)

> Bewertungsgrundlage: `docs/ARCHITECTURE.md` §7, `src/database/schema.py` (Altprojekt, READ-ONLY).
> Altschema enthält mehr Tabellen als die ursprünglich geplanten 9 — alle werden hier erfasst.

### Primär-Tabellen (aus ARCH-06-Anforderung)

| Alt-Tabelle | Zielkategorie | Zielname (Vorschlag) | Pflichtänderung(en) | Bemerkung |
|-------------|--------------|---------------------|---------------------|-----------|
| `emails` | **ZENTRAL** | `gmail_messages` | + `unternehmen_id` (FK, NOT NULL); + `installation_id` (FK, NOT NULL); `UNIQUE(mailbox, gmail_message_id)` → `UNIQUE(unternehmen_id, mailbox_key, gmail_message_id)` | Enthält Metadaten zu Gmail-Nachrichten. `body_text` und `raw_message_json` sind datenschutzsensibel — Aufbewahrungsregel prüfen. `mailbox` → `mailbox_key` als primärer Bezeichner (bereits im Altschema vorhanden). |
| `invoices` | **ZENTRAL** | `rechnungen` | + `unternehmen_id` (FK, NOT NULL); `file_path` und `stored_file_path` auf relative Pfade umstellen (D6); absoluter Pfad darf zentral nicht gespeichert werden | Kernentität. Bestehende Versionsfelder (`validation_status`, `storage_status`) bleiben erhalten. `raw_text` kann im Zielschema optional als separate Candidates-Tabelle ausgelagert werden (Phase 3). |
| `bank_transactions` | **ZENTRAL** | `bankbuchungen` | + `unternehmen_id` (FK, NOT NULL); + `bankkonto_id` (FK, für Mehrkonten-Support); `amount` von `REAL` auf `INTEGER` (Centwerte) umstellen (ENTWICKLUNGSPLAN §4 Akzeptanzkriterium) | `source_file` speichert Dateiname des Kontoauszugs — darf relativ bleiben; absoluter Pfad vermeiden. |
| `zuordnungen` | **ZENTRAL** | `zuordnungen` | + `unternehmen_id` (FK, NOT NULL); `invoice_target_path`, `bank_statement_target_path`, `report_target_path` auf relativen Dokumentlokator umstellen (D6) | Eindeutige Zuordnung Rechnung ↔ Bankbuchung; Mandantenfilter bei jedem Query-Pfad verpflichtend. |
| `unsichere_zuordnungen` | **ZENTRAL** | `unsichere_zuordnungen` | + `unternehmen_id` (FK, NOT NULL) | Enthält `decision_status` und `decision_note` für manuelle Prüffälle. Manuell bestätigte Entscheidungen dürfen durch keinen Automatiklauf überschrieben werden. |
| `gmail_scan_history` | **ZENTRAL** | `gmail_scan_history` | + `unternehmen_id` (FK, NOT NULL); + `installation_id` (FK, NOT NULL); `UNIQUE`-Constraint auf `(unternehmen_id, mailbox_key, requested_start_date, requested_end_date)` | Scan-Status wird zentral gehalten, damit mehrere Installationen je Unternehmen keine Scan-Konflikte erzeugen. Inkrementelle Marker (`last_successful_at` o. ä.) bleiben zentral für Idempotenz. |
| `files` | **ZENTRAL** | `dokumente` | + `unternehmen_id` (FK, NOT NULL); + `installation_id` (FK, NOT NULL); `file_path` → entfernen (absoluter Pfad); `source_relative_path` → als primärer Dokumentlokator (relativer Pfad unter `DATA_ROOT`) | Enthält `file_hash` für Deduplizierung. `source_root` (absoluter Pfad zur Installationswurzel) darf **nicht** zentral gespeichert werden — entfällt. `source_relative_path` bleibt als relativer Lokator (D6). |
| `processing_state` | **LOKAL** | `lokaler_verarbeitungsstatus` (lokale SQLite oder JSON-Datei) | Entfällt als zentrale Tabelle; bleibt lokal auf Client | Verfolgt den lokalen Fortschritt von Pipeline-Läufen. Keine Mandantenrelevanz. Im Neuaufbau: lokale JSON-Zustandsdatei oder minimale lokale SQLite je Installation. Zentral können Job-Statusinformationen in `jobs`-Tabelle geloggt werden. |
| `gmail_bank_search` | **ZENTRAL** | `gmail_bank_suchlaeufe` | + `unternehmen_id` (FK, NOT NULL); + `installation_id` (FK, NOT NULL) | Dokumentiert Gmail-Nachsucheläufe je Bankbuchung. Zentral gehalten für Idempotenz (keine Doppelsuche durch mehrere Clients). Felder: `bank_transaction_id`, `mailbox_key`, `query`, `status`, `messages_found`, `pdf_attachments_found`, `invoices_imported`. |

### Ergänzende Tabellen (im Altschema vorhanden, nicht in ARCH-06-Primärliste)

| Alt-Tabelle | Zielkategorie | Zielname (Vorschlag) | Bemerkung |
|-------------|--------------|---------------------|-----------|
| `gmail_attachments` | **ZENTRAL** | `gmail_anhaenge` | + `unternehmen_id`, + `installation_id`; `raw_relative_path` und `staging_relative_path` als relative Locatoren beibehalten (D6). Gehört logisch zu `gmail_messages`. |
| `ec_sammelzahlungen` | **ZENTRAL** | `ec_sammelzahlungen` | + `unternehmen_id` (FK, NOT NULL); `folder_path`, `protocol_path` auf relativen Lokator umstellen (D6). Enthält `idempotency_key` — UNIQUE-Constraint auf `(unternehmen_id, idempotency_key)`. |
| `ec_sammelzahlung_belege` | **ZENTRAL** | `ec_sammelzahlung_belege` | + `unternehmen_id` (indirekt über FK auf `ec_sammelzahlungen`). UNIQUE-Constraint auf `(ec_sammelzahlung_id, invoice_id)` beibehalten. |

---

## Reversibler Migrationspfad (ARCH-08, per D1)

> **Leitprinzip:** Altprojekt-SQLite wird zu keinem Zeitpunkt gelöscht, überschrieben
> oder verändert. PostgreSQL-Test-DB ist jederzeit droppbar, ohne Altdaten zu gefährden.
> Jeder Schritt ist einzeln testbar und rückgängig machbar.

### Schritt 1 — Vorbereitung (Read-Only-Sicherung)

**Aktion:**
- Altprojekt-SQLite `<DATA_ROOT>/database/buchhaltung.db` als Lesekopie sichern
  (z. B. `buchhaltung_alt_snapshot_YYYYMMDD.db`).
- Altprojekt-Verzeichnis `C:\Users\User\PycharmProjects\BuchungAtakan\` auf
  Read-Only-Dateisystemrechte setzen (oder explizit als READ-ONLY-Referenz kennzeichnen).
- Sicherungskopie wird **nicht** gelöscht oder verändert.

**Test:** SHA-256 der Originaldatei vor und nach Schritt 1 muss identisch sein.
**Rollback:** Nicht erforderlich — Schritt ist rein lesend.

---

### Schritt 2 — Zielschema (PostgreSQL, leer)

**Aktion:**
- PostgreSQL-Migrationen via Alembic für alle ZENTRAL-Tabellen erstellen.
- Jede mandantengebundene Tabelle erhält `unternehmen_id UUID NOT NULL REFERENCES unternehmen(id)`.
- Pflichtindizes anlegen: `idx_<tabelle>_unternehmen` auf `unternehmen_id`,
  plus Indizes für häufige Filter (Datum, Betrag, Status).
- Referenz-Tabellen anlegen: `unternehmen`, `installationen`, `benutzer`, `sessions`.
- Alembic-Skript idempotent — mehrfaches Ausführen auf leerer DB ohne Fehler.

**Test:**
```bash
alembic upgrade head         # Alle Migrationen anwenden
alembic current              # Version prüfen
alembic check                # Kein offener Delta
```
**Rollback:** `alembic downgrade base` — entfernt alle Tabellen aus der Test-PostgreSQL.

---

### Schritt 3 — Mapping-Test (synthetische Daten)

**Aktion:**
- Synthese-Skript `tools/migration/migrate_sqlite_to_postgres.py` erstellen.
- Synthetische Altdatensätze (keine Echtdaten, Testfixtures) in Altschema-Format erzeugen.
- Migration-Skript liest aus Altschema-Format und schreibt in PostgreSQL-Test-DB.
- Rückgabetest: Jeder migrierte Satz muss aus PostgreSQL lesbar und auf den Altsatz abbildbar sein.

**Test:**
```python
# Pseudocode
alt_rows = read_from_sqlite_snapshot(table="invoices")
postgres_rows = read_from_postgres(table="rechnungen", unternehmen_id=TEST_TENANT_UUID)
assert len(alt_rows) == len(postgres_rows)
assert alt_rows[0]["invoice_number"] == postgres_rows[0]["invoice_number"]
```
**Rollback:** PostgreSQL-Test-DB droppen und neu aufsetzen (`alembic downgrade base; alembic upgrade head`).

---

### Schritt 4 — Realdaten-Probe (nur nach expliziter Freigabe)

**Aktion:**
- Erst nach ausdrücklicher Nutzerfreigabe: einen definierten Altdatensatz
  (genau ein Unternehmen, klar abgegrenzter Zeitraum) in PostgreSQL-**Test**-DB migrieren.
- **Keine Produktivdaten** im Ziel zu diesem Zeitpunkt.
- Lesbarkeit und Vollständigkeit der migrierten Daten prüfen.
- Altprojekt-SQLite bleibt unverändert.

**Test:** Anzahl Sätze je Tabelle in Alt == Anzahl im Ziel (gefiltert auf `unternehmen_id`).
**Rollback:** PostgreSQL-Test-DB droppen.

---

### Schritt 5 — Rollback-Test

**Aktion:**
- Alembic downgrade ausführen: `alembic downgrade base`.
- Prüfen, dass Altprojekt-SQLite unverändert ist (SHA-256 aus Schritt 1 vergleichen).
- Prüfen, dass Altprojekt weiterhin lauffähig ist (vorhandene Tests grün).

**Test:**
```bash
sha256sum buchhaltung_alt_snapshot_YYYYMMDD.db  # Muss mit Schritt-1-Hash übereinstimmen
cd C:/Users/User/PycharmProjects/BuchungAtakan && python -m pytest tests/ -q
```
**Rollback:** Nicht erforderlich — demonstriert die Rollback-Fähigkeit.

---

### Schritt 6 — Produktionsmigration (Pilotbetrieb nach Phase 9)

**Aktion:**
- Erst nach erfolgreichem Pilotbetrieb (Phase 9 bestanden).
- Mit ausdrücklicher Nutzerfreigabe.
- Produktive Altdaten in produktive PostgreSQL migrieren.
- Altprojekt-SQLite bleibt als Archiv erhalten.

**Vorbedingungen:**
- Alle Cross-Tenant-Tests grün (Phase 1-Akzeptanzkriterium).
- Rollback-Test aus Schritt 5 erfolgreich dokumentiert.
- Teststand Phase 8 vollständig grün.
- Schriftliche Freigabe durch Nutzer.

---

## Reversibilität — Zusammenfassung

| Schritt | Reversibel? | Rollback-Mechanismus |
|---------|-------------|---------------------|
| 1 (Sicherung) | – (read-only, kein Zustand) | Entfällt |
| 2 (Zielschema) | Ja | `alembic downgrade base` |
| 3 (Mapping-Test) | Ja | PostgreSQL-Test-DB droppen |
| 4 (Realdaten-Probe) | Ja | PostgreSQL-Test-DB droppen; Altprojekt unverändert |
| 5 (Rollback-Test) | – (demonstriert Rollback) | Entfällt |
| 6 (Produktion) | Nur vor Datenlöschung | Altprojekt-SQLite als Archiv; PostgreSQL-Backup vor Migration |

**Invariante:** `C:\Users\User\PycharmProjects\BuchungAtakan\` und die dortige SQLite-Datei
werden in keinem der obigen Schritte verändert oder gelöscht.
