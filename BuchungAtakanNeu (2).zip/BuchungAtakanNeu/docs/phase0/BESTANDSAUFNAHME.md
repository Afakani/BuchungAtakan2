# Bestandsaufnahme – Altprojekt BuchungAtakan

**Stand:** 2026-06-26  
**Altprojektpfad:** `C:\Users\User\PycharmProjects\BuchungAtakan\`  
**WICHTIG:** Dieses Dokument ist rein dokumentarisch. Das Altprojekt wurde **nicht verändert**.  
**Constraint:** Alle Zugriffe auf das Altprojekt erfolgten ausschließlich lesend (Read/Grep). ARCH-02 ist erfüllt.

---

## Einstiegspunkt

**Datei:** `main.py`

Das Skript `main.py` ist der CLI-Einstiegspunkt des Altprojekts. Es initialisiert die Anwendung
(Ordnerstruktur, SQLite-Datenbank) und bietet drei Betriebsmodi über Kommandozeilenargumente:

- `--data-root <Pfad>` — optionale Datenwurzel überschreibt Umgebungsvariable / JSON-Config / Fallback
- `--run-pipeline` — startet nach Initialisierung die normale Buchungs-Pipeline
- `--scan-sensitive-tests` — scannt lokale Originaltestdaten isoliert ein

Importierte Hauptmodule beim Start:
- `src.config.settings` — Pfad- und Anwendungskonfiguration
- `src.database.db_manager.DatabaseManager` — SQLite-Initialisierung
- `src.filesystem.folder_manager.FolderManager` — Ordnerstruktur prüfen/erstellen
- `src.logging_system.logger.Logger` — Protokollierung
- `src.reports.zuordnung_report_exporter.ZuordnungReportExporter` — Excel-Export

---

## Module (`src\`)

### bank

**Zweck:** Import und Verarbeitung von Bankkontoauszügen (Volksbank CSV-Format). Erkennt
Buchungszeilen, normalisiert Felder und liefert strukturierte `BankTransaction`-Objekte.

**Hauptdateien:**
- `bank_statement_importer.py` — Datei-Importer, erwartet Ablage unter `<DATA_ROOT>\_dump\kontoauszuege`
- `bank_statement_parser.py` — CSV-Parsing und Zeilenerkennung (Volksbank-spezifisches Format)
- `bank_transaction.py` — Datenklasse `BankTransaction` (booking_date, value_date, name, transaction_type, …)
- `bank_transaction_matching_status.py` — Statusservice für Matching-Kennzeichnung von Buchungen

**Typ:** Fachlogik  
**Externe Importe:** keine (nur stdlib + eigene Module)

---

### config

**Zweck:** Zentrale Pfadkonfiguration und Anwendungseinstellungen. Stellt `PathConfig`
(frozen dataclass) und `settings`-Modul bereit. Auflösungsreihenfolge der DATA_ROOT:
explizit → Umgebungsvariable → JSON-Konfigurationsdatei → Fallback.

**Hauptdateien:**
- `path_config.py` — `PathConfig`-Dataclass, alle `data_root`-Unterpfade als Properties;
  Umgebungsvariablen `BUCHUNG_CUMCU_DATA_ROOT`, `BUCHUNG_CUMCU_NETWORK_ROOT` (superseded),
  `BUCHUNG_CUMCU_CONFIG_FILE`; `PureWindowsPath`-Validierung; Quell-Tracking (EXPLICIT/ENV/CONFIG_FILE/FALLBACK)
- `settings.py` — globales `ACTIVE_PATH_CONFIG`-Singleton, `configure_paths()`,
  `get_path_config()`, Zahlungsmethoden-Normalisierung

**Typ:** Infrastruktur  
**Externe Importe:** keine (stdlib: `os`, `json`, `dataclasses`, `pathlib`)

---

### database

**Zweck:** Gesamter SQLite-Datenbankzugriff: Schemaerstellung, additive Migrationen und alle
Repository-Klassen (Datenzugriffsobjekte) nach dem Repository-Pattern.

**Hauptdateien:**
- `db_manager.py` — `DatabaseManager`: Verbindungsmanagement, Schemainitialisierung, additive Spaltenmigrationen via `_apply_safe_schema_migrations()`
- `schema.py` — SQL-DDL-String `CREATE_TABLES` mit allen Tabellen und Indizes
- `bank_transaction_repository.py` — CRUD für Bankbuchungen
- `document_repository.py` — CRUD für Dokument-Metadaten (`files`-Tabelle)
- `ec_sammelzahlung_repository.py` — CRUD für EC-Sammelzahlungen
- `gmail_repository.py` — Persistenz für Gmail-Anhänge und Scan-Historie
- `invoice_importer.py` — Rechnungsimport-Logik (Datei → DB)
- `invoice_repository.py` — CRUD für Rechnungen
- `processing_state_repository.py` — Verarbeitungsstatus-Tracking
- `unsichere_zuordnung_repository.py` — Verwaltung unsicherer Zuordnungen
- `zuordnung_repository.py` — CRUD für bestätigte Zuordnungen
- `test_database.py` — Hilfsmodul für Testdatenbankaufbau (liegt im database-Paket)

**Typ:** Infrastruktur  
**Externe Importe:** `sqlite3` (stdlib)

---

### ec

**Zweck:** Fachlogik für EC-/Telexpert-Sammelzahlungs-Abgleich. Berechnet, welche
EC-Belege zu einer Banksammeleinzahlung passen (exakte Summation; Entfernung neuester Belege
bei Überschreitung).

**Hauptdateien:**
- `ec_settlement.py` — Kerndatenklassen (`EcDeposit`, `EcReceipt`, `EcSettlementResult`),
  Pure-Funktion `calculate_ec_settlement()`, Cent-Konvertierung, Statuswerte
- `ec_settlement_service.py` — `EcSettlementService`: lädt Daten aus DB, ruft Kernlogik auf,
  organisiert Dateien, schreibt Ergebnisse zurück

**Typ:** Fachlogik  
**Externe Importe:** keine (stdlib: `decimal`, `datetime`, `dataclasses`)

---

### filesystem

**Zweck:** Ordnerverwaltung und Dateiorganisation nach Monaten/Jahren unter `DATA_ROOT`.
Verschiebt verarbeitete Dokumente in die korrekte Ablagestruktur.

**Hauptdateien:**
- `folder_manager.py` — `FolderManager`: erstellt und prüft die gesamte Ordnerstruktur
  (Kontoauszüge, Eingangs-/Ausgangsrechnungen, Exporte, Logs, Config, Dump)
- `invoice_file_organizer.py` — verschiebt Rechnungsdateien nach Monat/Jahr
- `ec_sammelzahlung_file_organizer.py` — verschiebt EC-Belege nach Abrechnungsperiode
- `zuordnung_file_organizer.py` — organisiert zugeordnete Dokumente

**Typ:** Infrastruktur  
**Externe Importe:** keine (stdlib: `pathlib`, `shutil`)

---

### gmail

**Zweck:** Gmail-Integration: OAuth2-Authentifizierung, Postfach-Scanning, PDF-Anhangimport
und Nachsuche fehlender Belege anhand von Bankbuchungen.

**Hauptdateien:**
- `gmail_client.py` — `GmailClient`: OAuth2-Flow (InstalledAppFlow), Token-Handling,
  Google API Service-Aufbau
- `gmail_scanner.py` — Postfach nach relevanten E-Mails scannen (Datumsfilter, Kategorien)
- `gmail_pdf_importer.py` — Anhänge herunterladen, als PDFs speichern und importieren
- `gmail_mailbox.py` / `gmail_multi_mailbox.py` — Mailbox-Konfiguration und Multi-Mailbox-Support
- `gmail_bank_followup_search.py` — Nachsuche: findet E-Mails passend zu offenen Bankbuchungen
- `bank_transaction_gmail_query.py` — Hilfsfunktionen für Bankbuchungs-spezifische Gmail-Abfragen
- `gmail_attachment.py` — `GmailAttachment`-Datenklasse
- `gmail_scan_intervals.py` — Zeitintervalle für inkrementelles Scanning

**Typ:** Fachlogik  
**Externe Importe:** `google-auth` (`google.oauth2.credentials`), `google-auth-oauthlib` (`google_auth_oauthlib.flow`), `google-api-python-client` (`googleapiclient.discovery`)

---

### invoice

**Zweck:** Rechnungsimport, Textextraktion aus PDFs, Parsing von Rechnungsfeldern
(Nummer, Datum, Betrag, Lieferant) und fachliche Validierung der Erkennungsergebnisse.

**Hauptdateien:**
- `invoice_processor.py` — `InvoiceProcessor`: orchestriert Parser + Validator
- `invoice_parser.py` — Regexbasiertes Extrahieren von Rechnungsfeldern aus PDF-Text
- `invoice_validator.py` — `InvoiceValidator`: prüft Pflichtfelder, Betragsplausibilität,
  Datumsformate, gibt `InvoiceValidationResult` zurück
- `invoice_data.py` — `InvoiceData`-Datenklasse (extrahierte Rohfelder)
- `invoice_processing_result.py` / `invoice_validation_result.py` — Ergebnis-Datenklassen

**Typ:** Fachlogik  
**Externe Importe:** keine (stdlib: `re`, `dataclasses`, `datetime`)

---

### logging_system

**Zweck:** Einheitliche Protokollierung in Datei und Konsole. Jede Logdatei liegt unter
`<DATA_ROOT>\logs\<modul>.log`.

**Hauptdateien:**
- `logger.py` — `Logger`-Klasse (Wrapper um `logging`): Singleton-Cache, FileHandler + StreamHandler,
  Debug-Level in Datei, Info-Level auf Konsole

**Typ:** Infrastruktur  
**Externe Importe:** keine (stdlib: `logging`)

---

### matching

**Zweck:** Abgleich von Rechnungen und Bankbuchungen anhand von Betrag, Datum, Referenznummer
und Lieferantenname. Berechnet Matching-Scores und liefert geordnete Vorschlagslisten.

**Hauptdateien:**
- `invoice_bank_matcher.py` — `match_invoices_to_bank_transactions()`: filtert aktive Rechnungsversionen,
  berechnet Scores (Betragsübereinstimmung, Datumsähnlichkeit, Referenznummernvergleich)
- `reference_normalization.py` — `normalize_reference()`: normalisiert Umlaute, Sonderzeichen
  für Vergleiche; `normalized_reference_in_text()`

**Typ:** Fachlogik  
**Externe Importe:** keine (stdlib: `re`)

---

### models

**Zweck:** Datenmodelle (Python-Klassen ohne ORM-Framework). Kein SQLAlchemy; Datenbankzugriff
erfolgt direkt über sqlite3 im `database`-Paket.

**Hauptdateien:**
- `base.py` — `BaseModel`: generisches `to_dict()` und `__repr__()` über `__dict__`
- `invoice.py` — `Invoice`: Rechnungsfelder (Nummer, Datum, Betrag, Währung, Status, …)
- `bank_transaction.py` — `BankTransaction`-Modell (parallel zur Datenklasse in `bank/`)
- `file.py` — `File`: Dokument-Metadaten (file_type, file_path, file_hash, …); speichert
  absoluten `file_path` (wird in Zielarchitektur durch relativen Pfad ersetzt)
- `match.py` — `Match`: Zuordnung Rechnung ↔ Bankbuchung
- `email.py` — `Email`-Modell
- `gmail_scan_history.py` — `GmailScanHistory`-Modell
- `repository.py` — generisches Basisrepository-Muster

**Typ:** Gemischt (Infrastruktur + Fachlogik)  
**Externe Importe:** keine

---

### pdf

**Zweck:** PDF-Texterkennung und -bereinigung. Öffnet PDFs mit `pdfplumber`, extrahiert
Seitentext und bereinigt Artefakte für nachgelagerte Parsing-Stufen.

**Hauptdateien:**
- `pdf_reader.py` — `PdfReader`: öffnet PDF via `pdfplumber`, gibt Seitentext zurück;
  wirft `FileNotFoundError` bei fehlender Datei
- `pdf_text_cleaner.py` — `PdfTextCleaner`: normalisiert Leerzeichen, entfernt Kopf-/Fußzeilen
- `pdf_document_detector.py` — heuristisch: erkennt Dokumenttyp (Rechnung, Kontoauszug, …)
  anhand von Schlüsselwörtern im Extrakttext

**Typ:** Infrastruktur  
**Externe Importe:** `pdfplumber`

---

### pipeline

**Zweck:** Orchestrierung aller Verarbeitungsschritte (Bank-Import → Rechnungsimport →
Matching → EC-Zuordnung → Dateiorganisation). Enthält auch Werkzeuge für Testdatenbankaufbau
und Entwickler-Hilfsskripte.

**Hauptdateien:**
- `buchungs_pipeline.py` — `BuchungsPipeline` / `PipelineOptions` / `PipelineRunResult`:
  Hauptpipeline mit direktem `sqlite3.connect()`-Aufruf (außerhalb von `DatabaseManager`);
  `network_document_root`-Option vorhanden [SUPERSEDED per D6]
- `incremental_pipeline.py` — inkrementeller Lauf (nur neue Einträge seit letztem Lauf)
- `initial_import_pipeline.py` — Erstimport aller historischen Daten
- `month_archive_classifier.py` — klassifiziert Monatsarchive
- `rebuild_and_import_month_archives.py` — Monatsarchive neu aufbauen
- `rebuild_dev_test_database.py` — Entwicklungsdatenbank aus Testdaten neu aufbauen
- `reset_test_database.py` — Testdatenbank zurücksetzen
- `run_synthetic_test_e2e.py` — synthetischer End-to-End-Test (direkter sqlite3-Zugriff)
- `sensitive_testdata_import.py` — Import echter Testdaten (isoliert)
- `unsichere_zuordnung_entscheiden.py` — manuelle Entscheidungshilfe für unsichere Zuordnungen
- `bank_transaction_matching_status.py` — Status-Hilfsfunktionen (auch als eigenständige Datei)

**Typ:** Gemischt (Fachlogik + Entwicklerwerkzeuge)  
**Externe Importe:** `sqlite3` (stdlib, direkter Zugriff in mehreren Dateien)

---

### reports

**Zweck:** Excel-Export der Zuordnungsberichte. Verbindet sich direkt mit SQLite und
erstellt formatierte `.xlsx`-Dateien für die Buchhaltungsprüfung.

**Hauptdateien:**
- `zuordnung_report_exporter.py` — `ZuordnungReportExporter`: direkter sqlite3-Zugriff,
  Excel-Erzeugung mit openpyxl; enthält `network_document_root`-Parameter [SUPERSEDED per D6]

**Typ:** Fachlogik  
**Externe Importe:** `openpyxl` (`Workbook`, `Alignment`, `Border`, `Font`, `PatternFill`, `Side`, `get_column_letter`)

---

### utils

**Zweck:** Allgemeine Hilfsfunktionen, derzeit ausschließlich Datumsnormalisierung.

**Hauptdateien:**
- `date_normalization.py` — `normalize_date()`: konvertiert `str`/`date`/`datetime` robust in
  `date`; akzeptiert ISO (`YYYY-MM-DD`), deutsches Format (`DD.MM.YYYY`) und weitere Varianten;
  liefert `None` bei ungültigen Eingaben statt stiller Fehlinterpretation

**Typ:** Infrastruktur  
**Externe Importe:** keine (stdlib: `datetime`)

---

## Externe Abhängigkeiten

> Hinweis: Im Altprojekt liegt keine `requirements.txt`; die Abhängigkeiten wurden durch
> Analyse der Import-Anweisungen aller `.py`-Dateien ermittelt. Python-Version: 3.12.10
> (aus `.venv/pyvenv.cfg`).

| Paketname | Modul-Import | Verwendungszweck |
|-----------|-------------|-----------------|
| `pdfplumber` | `import pdfplumber` | PDF-Textextraktion (Seiteninhalt) |
| `google-auth` | `google.oauth2.credentials` | OAuth2-Token-Handling für Gmail |
| `google-auth-oauthlib` | `google_auth_oauthlib.flow` | OAuth2-Desktop-Flow (InstalledAppFlow) |
| `google-api-python-client` | `googleapiclient.discovery` | Gmail REST-API (Messages, Attachments) |
| `openpyxl` | `openpyxl`, `openpyxl.styles`, `openpyxl.utils` | Excel-Exportdateien erstellen |

Stdlib-Module mit zentraler Bedeutung (keine Drittanbieter-Pakete):
`sqlite3`, `pathlib`, `logging`, `json`, `os`, `re`, `datetime`, `decimal`, `dataclasses`

---

## Tests

> Testrahmen: `pytest` mit Konfiguration in `pytest.ini` (`-vv -ra`, Testpfad `tests/test*.py`).
> Verzeichnisstruktur: `tests/` (Automatiktests), `tests/manual_tests/` (manuelle/Live-Tests).

| Dateiname | Fokus |
|-----------|-------|
| `test_bank_transaction_matching_status.py` | Status-Klassifikation von Bankbuchungen (matchbar / nicht matchbar / EC / manuell) |
| `test_data_root_security.py` | Sicherheitsregeln für DATA_ROOT-Auflösung; verhindert absolute Pfade in relativen Feldern |
| `test_database_initialization.py` | SQLite-Schemaaufbau, additive Migrationen, Idempotenz |
| `test_date_normalization_chronology.py` | Chronologische Randfälle der Datumsnormalisierung |
| `test_ec_chronology_regression.py` | Regressionstest EC-Sammelzuordnung (Chronologie-Reihenfolge) |
| `test_excel_unique_bank_rows.py` | Excel-Export: keine doppelten Bankbuchungszeilen |
| `test_gmail_attachment.py` | Gmail-Anhang-Datenklasse und Download-Logik |
| `test_gmail_attachment_extra.py` | Erweiterte Gmail-Anhang-Randfälle |
| `test_gmail_bank_followup_search.py` | Gmail-Nachsuche anhand offener Bankbuchungen |
| `test_gmail_pipeline_integration.py` | Integrationstests Gmail-Pipeline (End-to-End) |
| `test_gmail_scan_intervals.py` | Zeitintervall-Logik für inkrementelles Gmail-Scanning |
| `test_gmail_scanner.py` | Gmail-Scanner: Postfach-Suche und Kategorisierung |
| `test_gmail_scanner_extra.py` | Erweiterte Gmail-Scanner-Randfälle |
| `test_invoice_file_organizer.py` | Dateiorganisation für Rechnungen (Monats-/Jahresablage) |
| `test_invoice_parser.py` | Regex-Parsing von Rechnungsfeldern aus PDF-Text |
| `test_invoice_processor.py` | Verarbeitung einer Rechnung (Parser + Validator kombiniert) |
| `test_invoice_repository.py` | Datenbankzugriff für Rechnungen (CRUD) |
| `test_invoice_validator.py` | Fachliche Validierungsregeln für Rechnungsdaten |
| `test_matching_regressions.py` | Regressionstest Rechnungs-Bankbuchungs-Matching |
| `test_month_archive_regressions.py` | Regressionstest Monatsarchiv-Klassifikation |
| `test_path_consistency.py` | Pfadkonsistenz-Tests (relative vs. absolute Pfade) |
| `test_pdf_document_detector.py` | Dokumenttyp-Erkennung anhand PDF-Text-Heuristiken |
| `test_pdf_reader_live.py` | Live-Test PDF-Reader (benötigt echte PDF-Datei) |
| `test_pdf_real_invoice.py` | Test mit echter Rechnungs-PDF (lokale Testdatei) |
| `manual_tests/test_ec_sammelzuordnung.py` | Manuelle EC-Sammelzuordnungs-Tests (interaktiv) |

---

## DB-Zugriffe (SQLite)

Das Altprojekt nutzt SQLite direkt ohne ORM-Framework. Alle Verbindungen gehen auf eine
einzige Datei: `<DATA_ROOT>\database\buchhaltung.db`. Der `DatabaseManager` ist die primäre
Abstraktionsschicht; mehrere Module öffnen jedoch eigenständige Verbindungen (direkter
`sqlite3.connect`-Aufruf), was die Schichtentrennung teilweise unterläuft.

| Datei (relativ zu `src\`) | Zeile | Muster | Klassifikation | Kontext |
|---------------------------|-------|--------|----------------|---------|
| `database/db_manager.py` | 117 | `sqlite3.connect(str(self.db_path))` | VERBINDUNGSAUFBAU | Zentraler DB-Manager; einziger regulärer Einstiegspunkt für Repositories |
| `database/processing_state_repository.py` | 190 | `sqlite3.connect(str(self.database_path))` | VERBINDUNGSAUFBAU | Repository öffnet eigene Verbindung (bypassing DatabaseManager) |
| `database/unsichere_zuordnung_repository.py` | 421 | `sqlite3.connect(str(self.database_path))` | VERBINDUNGSAUFBAU | Repository öffnet eigene Verbindung |
| `database/zuordnung_repository.py` | 231 | `sqlite3.connect(str(self.database_path))` | VERBINDUNGSAUFBAU | Repository öffnet eigene Verbindung |
| `pipeline/buchungs_pipeline.py` | 843 | `sqlite3.connect(str(DATABASE_PATH))` | VERBINDUNGSAUFBAU | **Direktzugriff außerhalb aller Repository-Klassen** — Modul-Konstante `DATABASE_PATH` |
| `pipeline/rebuild_dev_test_database.py` | 264 | `sqlite3.connect(database_path)` | VERBINDUNGSAUFBAU | Entwicklerwerkzeug: Dev-DB neu aufbauen |
| `pipeline/rebuild_dev_test_database.py` | 329 | `sqlite3.connect(database_path)` | VERBINDUNGSAUFBAU | Zweiter Connect im selben Skript |
| `pipeline/rebuild_dev_test_database.py` | 349 | `sqlite3.connect(database_path)` | VERBINDUNGSAUFBAU | Dritter Connect im selben Skript |
| `pipeline/rebuild_and_import_month_archives.py` | 514 | `sqlite3.connect(database_path)` | VERBINDUNGSAUFBAU | Monatsarchiv-Werkzeug |
| `pipeline/rebuild_and_import_month_archives.py` | 522 | `sqlite3.connect(database_path)` | VERBINDUNGSAUFBAU | Zweiter Connect im selben Skript |
| `pipeline/reset_test_database.py` | 91 | `sqlite3.connect(resolved_path)` | VERBINDUNGSAUFBAU | Testdatenbank zurücksetzen |
| `pipeline/run_synthetic_test_e2e.py` | 411 | `sqlite3.connect(str(database_path))` | VERBINDUNGSAUFBAU | Synthetischer E2E-Test; viele nachgelagerte `sqlite3.Connection`-Nutzungen |
| `pipeline/sensitive_testdata_import.py` | 211 | `sqlite3.connect(database_path)` | VERBINDUNGSAUFBAU | Import echter Testdaten |
| `reports/zuordnung_report_exporter.py` | 1132 | `sqlite3.connect(self.database_path)` | VERBINDUNGSAUFBAU | Report-Exporter öffnet eigene Verbindung (bypassing DatabaseManager) |

**Module mit `import sqlite3`** (11 Module):
`database/db_manager.py`, `database/processing_state_repository.py`,
`database/unsichere_zuordnung_repository.py`, `database/zuordnung_repository.py`,
`pipeline/buchungs_pipeline.py`, `pipeline/rebuild_and_import_month_archives.py`,
`pipeline/rebuild_dev_test_database.py`, `pipeline/reset_test_database.py`,
`pipeline/run_synthetic_test_e2e.py`, `pipeline/sensitive_testdata_import.py`,
`reports/zuordnung_report_exporter.py`

**Bewertung für Zielarchitektur:** Alle `sqlite3.connect`-Aufrufe müssen in der Zielarchitektur
durch API-Aufrufe an den zentralen FastAPI/PostgreSQL-Server ersetzt werden. Kein lokaler Client
darf direkten Datenbankzugriff behalten. Die Repository-Klassen in `database/` sind der
geeignetste Kandidat für eine servergestützte Reimplementierung.

---

## Pfadannahmen

Pfadannahmen im Altprojekt — Basis für ARCH-05 und Zielarchitektur.

### Absolute/UNC-Pfade (werden in Zielarchitektur eliminiert)

Das Altprojekt enthält **keine hartcodierten absoluten Windows-Pfade** im Produktionscode.
Es verwendet stattdessen dynamisch aufgelöste Pfade (DATA_ROOT-relativ oder PROJECT_ROOT-relativ).
Absolute Pfade entstehen nur zur Laufzeit durch Auflösung von `Path(__file__).resolve().parents[N]`
oder durch Nutzerbefehle/Umgebungsvariablen.

Die `network_document_root`-Funktion repräsentiert das superseded UNC-Konzept:

| Datei (relativ zu `src\`) | Zeile (ca.) | Muster | Art | D6-Status |
|---------------------------|-------------|--------|-----|-----------|
| `config/path_config.py` | 22 | `network_document_root: Path \| None = None` | UNC/Netzwerkpfad-Feld in `PathConfig` | **[SUPERSEDED per D6 — ENTWICKLUNGSPLAN §2.4]** |
| `config/path_config.py` | 11 | `NETWORK_ROOT_ENV_VAR = "BUCHUNG_CUMCU_NETWORK_ROOT"` | Umgebungsvariable für Netzwerkpfad | **[SUPERSEDED per D6 — ENTWICKLUNGSPLAN §2.4]** |
| `config/path_config.py` | 270–274 | `explicit_network_root=network_document_root` | Netzwerkpfad-Weiterleitung in PathConfig-Bau | **[SUPERSEDED per D6 — ENTWICKLUNGSPLAN §2.4]** |
| `config/settings.py` | 32 | `network_document_root` als Parameter in `configure_paths()` | Konfigurationspfad für Netzwerkablage | **[SUPERSEDED per D6 — ENTWICKLUNGSPLAN §2.4]** |
| `pipeline/buchungs_pipeline.py` | ~50 | `network_document_root: Path \| None = None` in `PipelineOptions` | Pipeline-Option für Netzwerkpfad | **[SUPERSEDED per D6 — ENTWICKLUNGSPLAN §2.4]** |
| `reports/zuordnung_report_exporter.py` | 24–28 | `network_document_root`-Parameter | Report-Exporter verwendet Netzwerkpfad für Dokumentöffnung | **[SUPERSEDED per D6 — ENTWICKLUNGSPLAN §2.4]** |

> **Begründung D6:** ENTWICKLUNGSPLAN §2.4 legt fest, dass Originaldokumente standardmäßig
> **nicht** auf einen zentralen Server hochgeladen werden. Die bisherige Annahme einer
> zentralen UNC/Netzwerkablage (`network_document_root`) ist damit hinfällig. Dokumente
> verbleiben lokal; zentral werden nur strukturierte Metadaten gespeichert. Diese Stellen
> sind bei der Implementierung der Zielarchitektur zu entfernen oder durch lokale Pfadlogik
> zu ersetzen.

### DATA_ROOT- und PathConfig-Nutzung (wiederverwendbar)

Das zentrale Pfadmodell über `DATA_ROOT` / `PathConfig` ist in der Zielarchitektur
weiterzuverwenden (lokaler Client-Anteil).

| Datei (relativ zu `src\`) | Zeile (ca.) | Muster |
|---------------------------|-------------|--------|
| `config/path_config.py` | 10 | `DATA_ROOT_ENV_VAR = "BUCHUNG_CUMCU_DATA_ROOT"` |
| `config/path_config.py` | 16 | `DEFAULT_DATA_ROOT = PROJECT_ROOT / ".buchung_data"` |
| `config/path_config.py` | 264 | `environment.get(DATA_ROOT_ENV_VAR)` — Auflösung DATA_ROOT aus Env |
| `config/path_config.py` | 327–330 | `DATA_ROOT_SOURCE_*`-Konstanten (EXPLICIT/ENV/CONFIG_FILE/FALLBACK) |
| `config/settings.py` | 26 | `ACTIVE_PATH_CONFIG, ACTIVE_DATA_ROOT_SOURCE = load_path_config_with_source()` |
| `config/settings.py` | 58 | `get_path_config() -> PathConfig` — zentraler Zugangspunkt für alle Module |
| `filesystem/folder_manager.py` | – | `settings.get_path_config().rechnungen_ungeordnet_dir` u. a. |
| `pipeline/buchungs_pipeline.py` | ~44–46 | `PATH_CONFIG = settings.get_path_config(); DATA_ROOT = PATH_CONFIG.data_root` |
| `bank/bank_statement_importer.py` | 21 | `<DATA_ROOT>\_dump\kontoauszuege` als Importpfad-Erwartung |
| `models/file.py` | – | `file_path: str` — speichert derzeit **absoluten** Pfad (zu migrieren auf relativen Pfad) |

### Umgebungsvariablen (Altname → Zielname)

| Variable | Altname (Altprojekt) | Zielname (Zielarchitektur per D4) | Anmerkung |
|----------|---------------------|----------------------------------|-----------|
| Datenwurzel | `BUCHUNG_CUMCU_DATA_ROOT` | `BUCHUNG_ATAKAN_DATA_ROOT` | Lokaler Client |
| Netzwerkpfad | `BUCHUNG_CUMCU_NETWORK_ROOT` | *(entfällt)* | **[SUPERSEDED per D6]** |
| Konfigurationsdatei | `BUCHUNG_CUMCU_CONFIG_FILE` | `BUCHUNG_ATAKAN_CONFIG_FILE` | Lokaler Client |

> Hinweis: Das Präfix `BUCHUNG_CUMCU_` entstammt dem früheren Projektnamen. In der
> Zielarchitektur wird `BUCHUNG_ATAKAN_*` als einheitliches Präfix verwendet (D4).
> `BUCHUNG_CUMCU_NETWORK_ROOT` wird ersatzlos gestrichen.
