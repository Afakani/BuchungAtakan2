# Modul- und Abhängigkeitskarte – Phase 0

**Stand:** 2026-06-26
**Grundlage:** `docs/phase0/BESTANDSAUFNAHME.md`
**Zielarchitektur-Referenz:** `docs/ENTWICKLUNGSPLAN.md` §2, `docs/ARCHITECTURE.md` §3

---

## Modulklassifikation

> Jedes der 14 Alt-Module aus `src/` ist einer eindeutigen Zielkategorie zugeordnet.
> Module mit gemischten Verantwortlichkeiten sind als **GEMISCHT** gekennzeichnet und
> müssen im Neuaufbau aufgeteilt werden.

| Modul | Kategorie | Zielpfad | Bemerkung |
|-------|-----------|----------|-----------|
| `bank` | **GEMISCHT → aufzuteilen** | Parser-Logik → `packages/core/bank/`; Importer → `apps/client/bank/` | `bank_statement_parser.py` + `bank_transaction.py` sind reine Fachlogik (kein Infrastrukturbezug). `bank_statement_importer.py` liest aus lokalem `DATA_ROOT/_dump/kontoauszuege` → Lokaler Client. `bank_transaction_matching_status.py` → Shared Core (zustandslose Statusklassifikation). |
| `config` | **Lokaler Client** | `apps/client/config/` | `PathConfig` und `settings` verwalten lokalen `DATA_ROOT`-Pfad, Umgebungsvariablen (`BUCHUNG_CUMCU_*` → `BUCHUNG_ATAKAN_*`) und lokale JSON-Konfigurationsdatei. Kein Serverbezug. |
| `database` | **AUFZULÖSEN / Infrastruktur-Adapter** | Repository-Klassen → `apps/server/repositories/`; SQLite-Adapter → entfällt; Client-Adapter → `apps/client/api_client/` | Enthält alle Repository-Klassen (CRUD) + `DatabaseManager` + DDL-Schema. In der Zielarchitektur übernimmt der FastAPI-Server die Server-Repositories (gegen PostgreSQL). Clients greifen nie direkt auf die DB zu. `test_database.py` → Testinfrastruktur. |
| `ec` | **Shared Core** | `packages/core/ec/` | `calculate_ec_settlement()` ist eine reine Funktion (Cent-Arithmetik, Datenklassen, keine Infrastruktur-Importe). `EcSettlementService` lädt Daten aus DB und schreibt zurück — dieser Teil muss vom Core getrennt und über Port/Adapter angebunden werden. |
| `filesystem` | **Lokaler Client** | `apps/client/filesystem/` | Alle Operationen arbeiten unter `DATA_ROOT` auf dem lokalen Dateisystem (`pathlib`, `shutil`). Keine externen Abhängigkeiten. Kein Serverbezug. |
| `gmail` | **GEMISCHT → aufzuteilen** | OAuth/Scanner/Importer → `apps/client/gmail/`; Such-Algorithmen → `packages/core/gmail/` | `GmailClient` (OAuth2, lokale Tokens), `GmailScanner` (Postfach-Zugriff), `GmailPdfImporter` (lokale Dateiablage) sind Lokaler Client. `GmailBankFollowupSearch` und `bank_transaction_gmail_query.py` enthalten Such- und Abgleichlogik, die in Shared Core heben kann, wenn die Gmail-API über `MailProviderPort` abstrahiert wird. Externe Importe: `google-auth`, `google-auth-oauthlib`, `google-api-python-client`. |
| `invoice` | **Shared Core** | `packages/core/invoice/` | `InvoiceParser`, `InvoiceValidator`, `InvoiceProcessor` und alle Ergebnis-Datenklassen haben ausschließlich Stdlib-Importe (`re`, `dataclasses`, `datetime`). Reine Extraktions- und Validierungslogik ohne Infrastrukturbindung. |
| `logging_system` | **Lokaler Client** | `apps/client/logging_system/` | Schreibt Logdateien unter `<DATA_ROOT>/logs/<modul>.log`. Abhängigkeit von lokalem Dateisystem und `DATA_ROOT`. Auf dem Server wird strukturiertes JSON-Logging (kein File-Logger-Wrapper) eingesetzt. |
| `matching` | **Shared Core** | `packages/core/matching/` | `match_invoices_to_bank_transactions()` und `normalize_reference()` sind zustandslose Funktionen ohne Infrastrukturbindung. Einziger Import: stdlib `re`. Vollständig testbar ohne Datenbank oder Dateisystem. |
| `models` | **GEMISCHT → aufzuteilen** | Domänenmodelle → `packages/core/models/`; `File`-Modell → anpassen, dann `packages/core/models/` | `Invoice`, `BankTransaction`, `Match`, `Email`, `GmailScanHistory`, `BaseModel` sind domänenseitige Datenklassen ohne Infrastruktur. `File.file_path` speichert derzeit **absoluten** Pfad — muss auf relativen Dokumentpfad umgestellt werden (→ D6). `repository.py` (generisches Basisrepository) wandert in die jeweiligen Adapter. |
| `pdf` | **Shared Core** | `packages/core/pdf/` | `PdfReader`, `PdfTextCleaner`, `PdfDocumentDetector` abstrahieren die `pdfplumber`-Abhängigkeit hinter einer klaren Schnittstelle. Die Logik ist reiner Dokumentinhalt-Zugriff ohne Infrastrukturbindung (kein DATA_ROOT, kein DB-Zugriff). `pdfplumber` bleibt als Abhängigkeit von `packages/core`. |
| `pipeline` | **GEMISCHT → aufzuteilen** | Orchestrierung → `apps/client/pipeline/`; Dev-Werkzeuge → `tools/dev/` | `BuchungsPipeline` und `IncrementalPipeline` sind Lokale-Client-Orchestrierung (direkter sqlite3-Zugriff muss durch API-Client ersetzt werden). Entwicklerwerkzeuge (`rebuild_dev_test_database.py`, `reset_test_database.py` u. a.) sind reine Hilfsskripte für die Entwicklungsumgebung und gehören nicht in `apps/`. |
| `reports` | **Lokaler Client** | `apps/client/reports/` | `ZuordnungReportExporter` öffnet eigene SQLite-Verbindung und schreibt `.xlsx`-Dateien lokal. Im Neuaufbau: Daten über API abrufen, Excel-Erzeugung mit `openpyxl` lokal ausführen. `network_document_root`-Parameter ist **SUPERSEDED** (D6). |
| `utils` | **Shared Core** | `packages/core/utils/` | `normalize_date()` ist eine reine Hilfsfunktion (stdlib `datetime`). Keine Infrastrukturabhängigkeit. |

---

## Zielstruktur-Übersicht

```
apps/
  client/
    bank/            ← bank_statement_importer.py (aus bank, GEMISCHT-Anteil)
    config/          ← path_config.py, settings.py (vollständig)
    filesystem/      ← folder_manager.py, *_file_organizer.py (vollständig)
    gmail/           ← GmailClient, GmailScanner, GmailPdfImporter (aus gmail, GEMISCHT-Anteil)
    logging_system/  ← logger.py (vollständig)
    pipeline/        ← BuchungsPipeline, IncrementalPipeline (aus pipeline, GEMISCHT-Anteil)
    reports/         ← zuordnung_report_exporter.py (vollständig, nach API-Umbau)
    api_client/      ← HTTP-Client (neu; ersetzt database-Repositories auf Client-Seite)

  server/
    repositories/    ← Neuimplementierung der database/-Repositories gegen PostgreSQL
    auth/            ← Authentifizierung, Session, Rollen (neu)
    api/             ← FastAPI-Router für alle /api/v1/-Bereiche (neu)
    jobs/            ← Hintergrund-Jobs (neu)

packages/
  core/
    bank/            ← bank_statement_parser.py, bank_transaction.py,
                        bank_transaction_matching_status.py (aus bank, GEMISCHT-Anteil)
    ec/              ← ec_settlement.py (Kernlogik; EcSettlementService über Port trennen)
    gmail/           ← gmail_bank_followup_search.py, bank_transaction_gmail_query.py,
                        gmail_scan_intervals.py, gmail_attachment.py (nach Port-Abstraktion)
    invoice/         ← invoice_parser.py, invoice_validator.py, invoice_processor.py,
                        invoice_data.py, *_result.py (vollständig)
    matching/        ← invoice_bank_matcher.py, reference_normalization.py (vollständig)
    models/          ← base.py, invoice.py, bank_transaction.py, match.py, email.py,
                        gmail_scan_history.py, file.py (nach Pfadumstellung, vollständig)
    pdf/             ← pdf_reader.py, pdf_text_cleaner.py, pdf_document_detector.py (vollständig)
    utils/           ← date_normalization.py (vollständig)
    ports/           ← DocumentStoragePort, InvoiceExtractionPort, BankStatementParserPort,
                        MailProviderPort, MatchingStrategyPort, ExportProviderPort,
                        NotificationPort, OptionalCompliancePort, AIServicePort (neu)

tools/
  dev/               ← rebuild_dev_test_database.py, reset_test_database.py, u. a.
                        (aus pipeline, GEMISCHT-Anteil; nicht in apps/)

tests/               ← pytest-Tests (Übertragung + Ergänzung aus Altprojekt tests/)
```

---

## Wiederzuverwendende Module (per D2)

> Vorgehen je Modul: Alt-Implementierung + Tests prüfen → wiederverwendbare Domänenlogik
> identifizieren → Infrastrukturabhängigkeiten trennen → nach `packages/core` heben →
> über Ports/Adapter anbinden → Verhalten per Regressionstest sichern.
> **Keine grundlose Neuschreibung.**

| Modul (Alt) | Wiederverwendungsstrategie | Begründung |
|-------------|---------------------------|------------|
| **EC** (`ec/ec_settlement.py`) | **Direkt** in `packages/core/ec/` | Reine Funktion `calculate_ec_settlement()`, kein Infrastrukturbezug, 100 % stdlib. Bestehende Regressionstests (`test_ec_chronology_regression.py`) grün halten. |
| **Gmail** (`gmail/gmail_scanner.py`, `gmail_bank_followup_search.py`) | **Nach Port-Adapter-Wrapping** | OAuth/API-Aufrufe hinter `MailProviderPort` abstrahieren; Such- und Abgleichlogik in `packages/core/gmail/` übernehmen. |
| **Invoice-Parser** (`invoice/invoice_parser.py`, `invoice_validator.py`) | **Direkt** in `packages/core/invoice/` | Regex-basierte Extraktion, vollständig stdlib, gut getestet. |
| **Matching** (`matching/invoice_bank_matcher.py`, `reference_normalization.py`) | **Direkt** in `packages/core/matching/` | Zustandslose Scoring-Funktion, kein Infrastrukturbezug. Regressionstests (`test_matching_regressions.py`) grün halten. |
| **PathConfig** (`config/path_config.py`, `settings.py`) | **Nach leichter Anpassung** in `apps/client/config/` | Umbenennung `BUCHUNG_CUMCU_*` → `BUCHUNG_ATAKAN_*` (D4); `network_document_root` entfernen (D6). Sonst weitgehend direkt übertragbar. |
| **Tests** (`tests/*.py`) | **Übernehmen + ergänzen** | Bestehende Unit-Tests (Matching, EC, Invoice, Datum, PDF) können direkt in `tests/` des Neuaufbaus übernommen werden. Neue Integrationstests (PostgreSQL, Mandanten) werden ergänzt. |
| **Bank-Parser** (`bank/bank_statement_parser.py`) | **Direkt** in `packages/core/bank/` | CSV-Parsing-Logik ist rein funktional. |
| **PDF** (`pdf/pdf_reader.py`, `pdf_text_cleaner.py`) | **Direkt** in `packages/core/pdf/` | `pdfplumber`-Wrapper ohne Infrastrukturbindung. |
| **Utils** (`utils/date_normalization.py`) | **Direkt** in `packages/core/utils/` | Reine Hilfsfunktion. |

---

## Technische Schulden (priorisiert)

### HOCH — blockiert Folgephasen

| ID | Schuld | Betroffene Datei(en) | Warum blockierend |
|----|--------|---------------------|-------------------|
| TS-H-01 | **Direkte `sqlite3.connect()`-Aufrufe außerhalb von DatabaseManager** (14 Stellen in `pipeline/` und `reports/`) | `pipeline/buchungs_pipeline.py:843`, `reports/zuordnung_report_exporter.py:1132` u. a. | Kein lokaler Client darf direkten DB-Zugriff behalten. Muss in Phase 2–4 vollständig durch API-Aufrufe ersetzt werden. |
| TS-H-02 | **`BUCHUNG_CUMCU_*`-Umgebungsvariablen** in Kernmodulen | `config/path_config.py` | Altnamen müssen auf `BUCHUNG_ATAKAN_*` umgestellt werden (D4). Altnamen nur als temporäre, explizit dokumentierte Fallbacks. |
| TS-H-03 | **`File.file_path` speichert absoluten lokalen Pfad** | `models/file.py`, `database/schema.py` (`files.file_path`) | Zentral darf kein absoluter Windows-Pfad stehen (D6, ARCH-05). Feld muss auf relativen Pfad (`source_relative_path`) umgestellt werden. |
| TS-H-04 | **`network_document_root`-Parameter** in Pipeline und Reports | `pipeline/buchungs_pipeline.py`, `reports/zuordnung_report_exporter.py`, `config/path_config.py`, `config/settings.py` | Konzept ist SUPERSEDED (D6). Muss vor Neuaufbau vollständig entfernt werden; kein Folge-Code darf darauf referenzieren. |
| TS-H-05 | **Fehlende Infrastruktur/Fachlogik-Trennung** in `ec/ec_settlement_service.py` | `ec/ec_settlement_service.py` | Lädt direkt aus DB und schreibt zurück; muss hinter `MatchingStrategyPort` / Repository-Port getrennt werden, bevor EC in `packages/core` gehoben werden kann. |
| TS-H-06 | **`database/`-Paket koppelt Repositories direkt an SQLite** | alle `*_repository.py`-Dateien | Repositories müssen gegen PostgreSQL reimplementiert werden (Server-Seite) und dürfen auf Client-Seite nur über API-Client angesprochen werden. |

### MITTEL — sollte in Migration adressiert werden

| ID | Schuld | Betroffene Datei(en) | Empfehlung |
|----|--------|---------------------|------------|
| TS-M-01 | **Logging schreibt in `DATA_ROOT/logs/`** — proprietärer File-Logger-Wrapper | `logging_system/logger.py` | Auf dem Server: strukturiertes JSON-Logging ohne Data-Root-Abhängigkeit. Client-Logging behalten, aber von Server-Logging trennen. |
| TS-M-02 | **Fehlende Typ-Annotationen** in mehreren Modulen | `matching/`, `bank/`, `pipeline/` | Verhindert zuverlässige statische Analyse. Vor Phasensplit ergänzen. |
| TS-M-03 | **`models/bank_transaction.py` doppelt** zu `bank/bank_transaction.py` | Beide Dateien | Konsolidieren auf eine kanonische Datenklasse in `packages/core/models/`. |
| TS-M-04 | **`invoice.file_path` und `invoice.stored_file_path` als absolute Pfade** in `invoices`-Tabelle | `database/schema.py`, `models/invoice.py` | Beide Felder auf relativen Lokator umstellen (→ D6, ARCH-05). |
| TS-M-05 | **Fehlende Mandanten-Guards** — alle Repositories sind Einzelmandant | alle `*_repository.py` | Im Neuaufbau: `WHERE unternehmen_id = :current_tenant` in jedem Query-Pfad verpflichtend. |
| TS-M-06 | **`processing_state`-Repository öffnet eigene Verbindung** (bypassing DatabaseManager) | `database/processing_state_repository.py:190` | Verbindungsmanagement vereinheitlichen; in Zielarchitektur: lokale Zustandsdatei oder API-Endpunkt statt direktem DB-Zugriff. |

### NIEDRIG / Spätarbeit

| ID | Schuld | Betroffene Datei(en) | Timing |
|----|--------|---------------------|--------|
| TS-L-01 | **Parser-Optimierung** (A-04 aus OPEN_POINTS.md) — Regex-basierter `invoice_parser.py` erkennt nicht alle Formate | `invoice/invoice_parser.py` | Spätarbeit nach Phase 3 (Kandidatenebene); E-Rechnung-Parser als Erweiterung. |
| TS-L-02 | **Gmail-OAuth-Realbetrieb** (A-02) mit echten Postfächern und Rate-Limits | `gmail/gmail_client.py` | Feature-Flag `BUCHUNG_ATAKAN_FEATURE_GMAIL_REAL_OAUTH` (Phase 7 Freigabe). |
| TS-L-03 | **Fehlende GUI / Zeitsteuerung** (A-03) | — | Wird in Phase 7–8 adressiert. |
| TS-L-04 | **`pdf_document_detector.py` — heuristische Klassifikation** noch unvollständig | `pdf/pdf_document_detector.py` | Kann nach Phase 3 verfeinert werden. |
| TS-L-05 | **`pipeline/`-Entwicklerwerkzeuge** mischen Produktions- und Dev-Logik | `pipeline/rebuild_dev_test_database.py` u. a. | Umzug nach `tools/dev/` in Phase 1. |
