# Implementierungshistorie – BuchungAtakan

**Stand:** 2026-07-01

---

## Neues Repository

### 2026-07-02 – Paket 07-06-PRE-REALTEST-QUALITAETSHAERTUNG (nach formal abgeschlossener Phase 7)

**Art:** Pre-Realtest-Härtung auf Basis eines Read-only-Audits von Phase 7 (Commit `cd81fbd`). Zwei bestätigte Bugs behoben, eine tote Prüfung repariert, Testlücke geschlossen. Phase-7-Abnahmestatus (HYB-01..24 erfüllt, 1088 passed/1 skip/0 failed) bleibt unverändert bestehen — dies ist eine zusätzliche Härtung danach, keine Korrektur der Abnahme selbst.

**Audit-Befund, der dieses Paket ausgelöst hat:**
- **B1 (Faktor-1000-Bug):** `"1.000"` wurde als `1.00` interpretiert, `"2.500"` als `2.50` — die Trennzeichenerkennung behandelte einen einzelnen Punkt ohne Komma nie als Tausendertrenner.
- **B2 (unmögliche Kalenderdaten):** `"31.02.2026"` wurde klaglos normalisiert und konnte zu Status `OK` führen — nur Bereichsprüfung (1-31/1-12), keine echte Kalendervalidierung.
- **R1 (tote Währungsprüfung):** `pruefe_waehrung_konsistent()` wurde in `_berechne_plausibilitaet()` nur mit dem bereits ausgewählten Einzelwert aufgerufen — ein Widerspruch zwischen Providern (EUR vs. USD) konnte die Prüfung konstruktionsbedingt nie zum Scheitern bringen.
- **T1 (Testlücke):** `hybrid_plausibilitaet.py` hatte keine einzige direkte Unit-Testdatei — alle 7 Regeln waren nur indirekt über die Statusentscheidung abgedeckt.

**Behobene Bugs:**

- **packages/core/invoice_extraction/betrag_utils.py** (neu) — `bereinige_betrag_string(value)`: neutrale, abhängigkeitsfreie Utility für die Trennzeichen-/Tausendererkennung. Deutsches Tausenderformat ohne Dezimalteil (`_TAUSENDER_OHNE_DEZIMAL`-Regex: einzelner Punkt, Gruppen von exakt 3 Ziffern, führende Gruppe ohne führende Null) wird jetzt korrekt als Tausender erkannt statt als Dezimalbruch. `"0.500"` bleibt bewusst Dezimalwert (`0.50`) — eine führende `0` vor dem Punkt ist nie eine deutsche Tausendergruppe.
- **packages/core/invoice_extraction/invoice_parser.py** — `_parse_amount()` nutzt jetzt `betrag_utils.bereinige_betrag_string()` statt einer eigenen Kopie der Logik; keine private Parser-Methode wird mehr aus Hybrid-Code aufgerufen. `_extract_date_from_string()` validiert numerische und Monatsnamen-Daten zusätzlich mit `datetime.date(jahr, monat, tag)` — unmögliche Daten (`31.02.`, `29.02.` in Nicht-Schaltjahren) werden abgelehnt, gültige Formate (inkl. Schaltjahre) bleiben unverändert erkannt.
- **packages/core/invoice_extraction/hybrid_normalisierung.py** — `normalisiere_betrag()` nutzt dieselbe zentrale Utility (keine Divergenz zwischen Parser und Hybrid-Normalisierung mehr möglich).
- **packages/core/invoice_extraction/hybrid_plausibilitaet.py** — `pruefe_rechnungsdatum_plausibel()` validiert das ISO-Datum jetzt ebenfalls über `datetime.date(...)` statt nur den Jahresbereich zu prüfen.
- **packages/core/invoice_extraction/hybrid_auswertung.py** — `_berechne_plausibilitaet()`: neue Hilfsfunktion `_alle_normalisierten_werte()` sammelt **alle** erfolgreich normalisierten Currency-Kandidaten (nicht nur den ausgewählten Gewinner) und übergibt sie **einmal** an `pruefe_waehrung_konsistent()`. Ein echter Providerwiderspruch (z. B. EUR vs. USD) führt jetzt nachweislich zu `MUSS_GEPRUEFT_WERDEN`, nie mehr unbemerkt zu `OK`. Der Befund bleibt über `HybridAuswertungsErgebnis.plausibilitaet` auditierbar.

**Neue Tests:**

- **tests/unit/test_hybrid_plausibilitaet.py** (neu, 33 Tests) — direkte Abdeckung aller 7 Plausibilitätsregeln: Betragsrelation (inkl. Toleranzgrenze `BETRAGS_TOLERANZ = 0.02` exakt auf/über der Grenze), negative Steuer, negative Netto-/Bruttowerte mit/ohne Storno-Freigabe, Währungskonsistenz (inkl. leere Liste, None-Werte), Rechnungsdatum (inkl. Schaltjahr/Nicht-Schaltjahr), Rechnungsnummer-Plausibilität (generische Werte), Anbieter bestimmbar.
- **tests/unit/test_hybrid_normalisierung.py** — 8 neue Tests für das Tausenderformat (`TestDeutschesTausenderformatOhneDezimalteil`, inkl. `"0.500"`-Gegenbeispiel) und 4 neue Tests für Kalenderdatumsvalidierung (`31.02.`, `29.02.` Schalt-/Nicht-Schaltjahr, Monatsname).
- **tests/unit/test_hybrid_auswertung_anti_false_ok.py** (neu, 10 Tests) — synthetische End-to-End-Tests durch die volle Auswertungskette (`werte_lokale_erkennung_aus()`, konstruiertes `LocalOrchestratorErgebnis`, kein Mock der Fachlogik): Happy Path → OK, ungültiges Kalenderdatum → nie OK, Faktor-1000-Betrag korrekt normalisiert (`1000.00`, nicht `1.00`) plus Folgestatus OK, EUR/USD-Konflikt → nie OK, fehlendes/widersprüchliches Pflichtfeld → nie OK, Determinismus bei kombiniertem Provider-Konflikt plus Plausibilitätsfehler.

**Nicht geändert (Fachentscheidungen, bewusst für Realtest-Auswertung zurückgestellt):**
Netto-/Steuer-Pflichtlogik, automatisches OK bei aufgelösten Mehrheitskonflikten, Confidence-Kalibrierung, allgemeine Schwellenwerte, Azure-Aktivierung, PaddleOCR-Konfiguration, alte Status-Engine (`berechne_hybrid_status`, 07-01), Architektur.

**Realtest-Vorbereitung (dokumentiert, keine Codeänderung):**
- `invoice2data` soll im kontrollierten 100-Rechnungen-Realtest bewusst per Flag aktiviert werden (Single-Provider-Betrieb würde die Konflikterkennung/-auswahl nie mit echten Daten befüllen).
- PaddleOCR nur aktivieren, wenn Modellgewichte vorher lokal gecacht sind und No-Network für den Realtestlauf nachgewiesen ist (PaddleOCR lädt Modelle sonst beim Erststart über das Netzwerk).
- Jeder Realtestlauf muss eine stabile `erkennungslauf_id` verwenden — ohne sie entfällt die Idempotenzprüfung in `persistiere_hybrid_auswertung()` und jeder Aufruf schreibt einen neuen Lauf; Mehrfachverarbeitung würde die Statistik sonst verfälschen.

**Verifiziert:** Unit+Security gesamt 910 passed, 4 skipped, 0 failed (vorher 855 passed — 55 neue Tests). Volle Suite ohne DB: 911 passed, 233 skipped, 0 failed. InvoiceParser-Regression (`test_invoice_parser_golden.py`, `test_invoice_parser_adapter.py`, `test_extraction_result.py`): 38 passed, keine Regression durch die Kalender-/Betragsänderungen.

### 2026-07-02 – Phase-7-Gap-Paket Testinfrastruktur: App-Rollen-Fixtures für echte RLS-Isolationstests

**Art:** Testinfrastruktur-Fix — keine Policy-, Migrations- oder Fachlogikänderung; neue Fixtures plus Umstellung dreier Tests auf eine bereits vorhandene, aber ungenutzte Rolle.

**Befund:** Der DB-Verifikationslauf für das HYB-07-Gap-Paket (unten) lief mit `TEST_DATABASE_URL` verbunden als `postgres` (Superuser) und zeigte 3 fehlgeschlagene Tests: `test_hybrid_extraktion.py::test_tenant_isolation_hybrid_erkennungslaeufe`, `test_hybrid_auswertung_persistenz.py::test_tenant_isolation`, `test_hybrid_audit_bewertungen.py::test_haba_tenant_b_sieht_bewertungen_von_tenant_a_nicht` — in allen drei Fällen sah Tenant B Datensätze von Tenant A. Read-only-Analyse ergab: kein Policy-Fehler. Alle drei Tests liefen über `db_session`/`sync_engine`, die direkt `TEST_DATABASE_URL` verwenden; PostgreSQL-Superuser bypassen RLS immer, auch mit FORCE ROW LEVEL SECURITY (dokumentiertes Verhalten, siehe `test_rls.py`-Docstring). Eine echte RLS-Isolationsbehauptung erfordert eine Nicht-Superuser-/Nicht-BYPASSRLS-Verbindung — dafür existierte projektweit noch keine nutzbare Fixture (`APP_DATABASE_URL` war nur in Kommentaren/Docstrings erwähnt, nie konsumiert).

Erstellte/geänderte Artefakte:

- `tests/conftest.py` — `APP_DB_URL` (aus `APP_DATABASE_URL`), `_validate_app_db_url()` (P-10-Skip ohne die Variable, kein Blocker; Namensguard exakt `buchungatakan_test` via bestehendem `pruefe_test_db_url()`; harter Fail, wenn `APP_DATABASE_URL` identisch mit `TEST_DATABASE_URL` ist — verhindert blinde Wiederverwendung einer potenziell privilegierten Verbindung), `_pruefe_rolle_nicht_privilegiert()` (Laufzeitabfrage `SELECT rolsuper, rolbypassrls FROM pg_roles WHERE rolname = current_user`, harter `pytest.fail()` bei privilegierter Rolle statt eines falsch-grünen RLS-Nachweises, keine Credentials in der Fehlermeldung), neue Fixtures `app_role_sync_engine`, `app_role_async_engine`, `app_role_session` (alle abhängig von `apply_migrations`).
- Die drei betroffenen Tests auf die neue Fixture umgestellt (`sync_engine`→`app_role_sync_engine` bzw. `db_session`→`app_role_session`). Scharfe Assertions unverändert: `assert row is None` — keine Umwandlung in tolerante Datenintegritätstests, wie ausdrücklich gefordert.
- `tests/integration/test_rls.py` — Modul- und Test-Docstring präzisiert: `test_rls_blocks_benutzer_without_tenant_context` bleibt bewusst ein **dauerhafter** Skip, auch mit korrekt konfigurierter `APP_DATABASE_URL`. Grund: Migration 003 (`003_rls_policies.py`) entzieht `buchungatakan_app` per `REVOKE ALL ON TABLE public.benutzer` jeden Direktzugriff auf diese Tabelle — Auth läuft ausschließlich über die SECURITY-DEFINER-Funktionen `auth_benutzer_by_name`/`auth_benutzer_by_id`. Eine direkte `SELECT ... FROM benutzer`-Query unter `buchungatakan_app` scheitert mit `permission denied`, nicht mit einem auswertbaren RLS-Ergebnis — eine Umstellung dieses Tests auf die App-Rolle würde keinen RLS-Nachweis liefern, sondern nur einen Berechtigungsfehler.

**Nicht angetastet (bewusst):** keine RLS-Policy geändert, keine Migration geändert, keine Rolle oder Datenbank angelegt, kein Passwort gesetzt. `buchungatakan_app` existiert bereits (wird von `apply_migrations` automatisch via `CREATE ROLE ... LOGIN` angelegt, falls fehlend) — nur das Passwort für diese Rolle bleibt ein manueller DBA-Schritt (P-09, `docs/OPEN_POINTS.md`). Doku-Inkonsistenz vermerkt: P-09 beschreibt dort die komplette Rollenanlage als manuell, tatsächlich übernimmt `apply_migrations` das (ohne Passwort) bereits automatisch.

**Verifiziert (Nutzerlauf, `TEST_DATABASE_URL` + `APP_DATABASE_URL` gegen `buchungatakan_test`):** 1088 passed, 1 skipped (P-10), 0 failed, 81,45 s. Die drei Tenant-Isolationstests liefen scharf über die Non-Superuser-App-Rolle: Tenant B sieht Tenant-A-Daten nicht bestätigt.

### 2026-07-02 – Phase-7-Gap-Paket HYB-07: Hybridpipeline-Flag-Gate

**Art:** Fix eines dokumentierten Gaps — kein neuer Provider, keine Architekturänderung; eine Signaturerweiterung plus fail-closed Gate an einem bereits vorhandenen Einstiegspunkt.

**Befund vor der Umsetzung:** `ist_hybrid_pipeline_aktiviert()` existierte bereits seit Paket 07-01 (`hybrid_auswertung.py`), der Docstring behauptete "der Aufrufer prüft das Flag vor dem Aufruf" — real prüfte kein Aufrufer projektweit dieses Flag; `werte_lokale_erkennung_aus()` selbst wurde nirgends aufgerufen und war ungetestet. Damit korrigiert dieser Eintrag den in `HYB-01..08 Einzelstatus` (Paket 07-01, unten) dokumentierten TEILWEISE-Stand für HYB-07: er ist ab jetzt ERFÜLLT. HYB-05 und HYB-08 waren zu diesem Zeitpunkt bereits über Paket 07-03 fachlich erfüllt (Konflikterkennung zwischen mehreren Providern, automatische `auswahl_grund`-Befüllung) — nur die Statusdokumente (`REQUIREMENTS.md`, `CURRENT_STATUS.md`) waren seither nicht nachgezogen worden.

Erstellte/geänderte Artefakte:

- `packages/core/invoice_extraction/hybrid_auswertung.py` — `werte_lokale_erkennung_aus()` erhält Parameter `settings: Any` und gatet sich als erste Anweisung selbst: `if not ist_hybrid_pipeline_aktiviert(settings): raise HybridPipelineDeaktiviertFehler(...)`. Neue Exception `HybridPipelineDeaktiviertFehler(RuntimeError)`.
- `packages/core/invoice_extraction/__init__.py` — `HybridPipelineDeaktiviertFehler` exportiert.
- `tests/unit/test_hybrid_auswertung.py` — 10 neue Unit-Tests (Default/`false` blockiert, `true` erlaubt, Mock-Beweis gegen nachgelagerte Normalisierungs-/Konflikt-/Auswahl-/Statuslogik, AST-Strukturbeleg, Unabhängigkeit von invoice2data-/PaddleOCR-/Azure-Flags je einzeln geprüft).

**Datenschutz-/Sicherheitsgrenzen (eingehalten):** kein Provider aktiviert, kein Netzwerkzugriff, keine Credentials, `local_provider_orchestrator.py` und alle Provider-Flags unverändert.

**Nicht im Scope (bewusst):** neue Provider, Azure-Aktivierung, Gmail, UI, Router-/Service-Änderungen.

### 2026-07-02 – Phase-7-Paket 07-04: Azure-Adapter vorbereitet, aber deaktiviert (HYB-20..24)

**Art:** Implementierung — neues Core-Modul (Port + Fake-Client), ein Config-Flag, eine Statuslogik-Erweiterung; additiv, kein Rückschritt.

Erstellte Artefakte:

- `packages/core/invoice_extraction/azure_document_intelligence_provider.py` — `AzureDocumentIntelligenceClient` (Protocol, kein SDK-Import, kein Netzwerk), `AzureAnalyseErgebnis`/`AzureFeldErgebnis` (synthetische, projekteigene Dataclasses, keine `azure.ai`-Typen), `AzureDocumentIntelligenceProvider` (implementiert bestehenden `CloudInvoiceProvider`-Port aus 07-01; fail-closed — bei `enabled=False` wird der injizierte Client nie aufgerufen), `FakeAzureDocumentIntelligenceClient` (deterministisch, protokolliert Aufrufe für Tests), `erstelle_provider(settings, client_factory)` (Factory — `client_factory` wird bei deaktiviertem Flag nie aufgerufen, kein Client entsteht). Mapping begrenzt auf `RECHNUNGS_FELDER` (bestehende Fachfeldmenge), nutzt bestehende `normalisiere_kandidat()` (HYB-14) statt neuer Normalisierungslogik.
- `apps/server/config.py` — kanonisches Flag `BUCHUNG_ATAKAN_FEATURE_AZURE_DOCUMENT_INTELLIGENCE` (default `false`); Legacy-Flag `BUCHUNG_ATAKAN_FEATURE_AZURE_DI` (07-01) bleibt unverändert bestehen, wird von diesem Modul nicht gelesen.
- `packages/core/invoice_extraction/hybrid_qualitaetsentscheidung.py` — Azure-only-Statusguard: wenn alle ausgewählten Pflichtfeld-Kandidaten ausschließlich von `azure_document_intelligence` stammen, wird ein Grund angehängt und der Status auf höchstens `MUSS_GEPRUEFT_WERDEN` begrenzt (Literal statt Modul-Import, gleiche Konvention wie bestehende Providernamen-Literale in `hybrid_konflikt.py`).
- `packages/core/invoice_extraction/provider_ports.py` — `CloudInvoiceProvider`-Docstring auf die jetzt existierende, aber deaktivierte Implementierung aktualisiert.
- `packages/core/invoice_extraction/__init__.py` — Azure-Exporttypen ergänzt.
- `tests/unit/test_azure_document_intelligence_provider.py` — 17 Unit-Tests (Flag-Default, Legacy-Flag-Entkopplung, Factory fail-closed, Fake-Client-Mapping, Determinismus, Feldbegrenzung auf `RECHNUNGS_FELDER`, Confidence-Validierung, sanitisierte Fehlercodes, keine Statusentscheidung durch Provider selbst).
- `tests/security/test_azure_document_intelligence_sanitization.py` — 11 Security-Tests (kein Netzwerkimport, kein Azure-SDK-Import via AST-Analyse, kein `DocumentAnalysisClient`/`AzureKeyCredential`, keine Credential-/Secret-/Endpoint-Strings, `.env.example` unverändert, `CloudInvoiceProvider`-Vertrag eingehalten).
- `tests/unit/test_hybrid_qualitaetsentscheidung.py` — 3 neue Tests für den Azure-only-Guard (Azure-only verhindert `OK`, Mischfall mit einem lokalen Pflichtfeld-Kandidaten erlaubt `OK`, Guard eskaliert nicht zu `NICHT_GEFUNDEN`).
- `tests/unit/test_feature_flags.py` — 3 neue Tests (kanonisches Flag default `false`/aktivierbar, Legacy-Flag beeinflusst kanonisches Flag nicht).
- `tests/security/test_hybrid_auswertung_sanitization.py` — bestehende Azure-Ausschlussprüfung um `hybrid_qualitaetsentscheidung.py` präzisiert (dieses Modul referenziert Azure seit 07-04 bewusst als Namensliteral) plus 2 neue Tests, die genau das (kein SDK-Import, kein Client) im Statusmodul verifizieren.

**Datenschutz-/Sicherheitsgrenzen (eingehalten):** kein Azure-SDK, kein Netzwerkzugriff, keine Credentials, keine Endpoint-Konfiguration, keine Dokumentinhalte in Fehlern/Logs, `.env.example` nicht um Azure-Variablen ergänzt.

**Nicht im Scope (bewusst):** echtes Azure, echte Credentials, Netzwerkzugriffe, produktive Aktivierung, allgemeine Cloud-Architektur — nur der für den Azure-only-Guard nötige minimale Statuslogik-Zusatz.

### 2026-07-02 – Phase-7-Paket 07-03B: Lokaler Excel-Export der Qualitätsstatistik (HYB-19)

**Art:** Implementierung — neues Core-Modul, ein Router-Endpoint, eine Dependency; additiv, kein Rückschritt.

Erstellte Artefakte:

- `packages/core/invoice_extraction/hybrid_statistik_export.py` — `erstelle_hybrid_statistik_workbook_bytes(gruppen, dimensionen)`: nimmt ausschließlich bereits aggregierte `StatistikGruppe`-Daten entgegen, kein DB-, kein Dateisystemzugriff, erzeugt `.xlsx`-Bytes vollständig im Speicher (`BytesIO`). Drei Sheets: `Uebersicht` (Gruppierung, Anzahl Gruppen, Status OK/LEER — keine Zeitstempel, damit deterministisch), `Statistik` (Dimensionsspalten in angeforderter Reihenfolge + je Quote Zähler/Nenner/Quote-Spalte, `0.00%`-Format, `None`-Quote als leere Zelle), `Metriken` (statische Definitionstexte je Quote, identisch zu `hybrid_statistik.py`-Docstring). Gruppen werden vor dem Schreiben nach `dimensionswerte` sortiert — Eingabereihenfolge beeinflusst das Ergebnis nicht.
- `apps/server/routers/hybrid.py` — `GET /api/v1/hybrid/statistik/export.xlsx`: `_dimensionen_aus_query()` aus dem bestehenden JSON-Statistikendpoint extrahiert (keine Duplikation der Queryvalidierung); Response mit `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`, `Content-Disposition: attachment; filename="hybrid_statistik.xlsx"` (fest, kein Nutzereingabe-Pfad), `Cache-Control: no-store`.
- `pyproject.toml` — `openpyxl==3.1.5` reproduzierbar ergänzt (war bereits transitiv installiert).
- `packages/core/invoice_extraction/__init__.py` — `erstelle_hybrid_statistik_workbook_bytes` exportiert.
- `tests/unit/test_hybrid_statistik_export.py` — 16 Unit-Tests (Sheet-Struktur, exakte Spaltenreihenfolge, Zähler/Nenner/Quoten, Prozentformat, `None`-Quote, leere Statistik, Determinismus, kein Dateisystemzugriff).
- `tests/security/test_hybrid_statistik_export_sanitization.py` — 6 Security-Tests (synthetisch sensible Strings aus allen Datenschutzgrenzen-Kategorien, Anbieter nur als angeforderter Gruppenschlüssel sichtbar).
- `tests/integration/test_hybrid_statistik_export_api.py` — 7 Integrationstests (HTTP 200, MIME-Type, `Content-Disposition`, `Cache-Control`, `openpyxl.load_workbook`-Öffnung, Queryparität mit JSON-Endpoint, Tenant-Isolation über einen frisch angelegten, garantiert leeren Mandanten statt der geteilten TENANT_A/TENANT_B-Fixtures — Lehre aus dem 07-03A-Regressionsfund, dass Tests nicht von akkumuliertem Zustand anderer Testdateien abhängen dürfen).

**Datenschutzgrenzen (eingehalten):** keine Rechnungsnummern, Rechnungsdaten, Einzelbeträge, Empfängerdaten, Dateinamen, Dateipfade, Hashes, Volltexte, OCR-Rohdaten, Kandidaten-Rohwerte, Dokumentinhalte, Secrets, Tokens, Credential-Namen, Stacktraces im Workbook. Anbietername nur als aggregierter Gruppenschlüssel, keine Pseudonymisierung in diesem Paket.

**Nicht im Scope (bewusst):** HYB-17/18 nicht neu gebaut, Azure, Gmail, echte Rechnungen, UI, Pseudonymisierung, Dateisystem-Export im Core.

### 2026-07-01 – Phase-7-Paket 07-01: Gemeinsame Extraktions- und Kandidatenarchitektur (HYB-01..08)

**Art:** Implementierung — neue Core-Module, ORM-Modelle, Migration, Feature-Flags; additiv, kein Rückschritt.

Erstellte Artefakte:

- `packages/core/invoice_extraction/hybrid_kandidat.py` — `HybridKandidat` (frozen dataclass), `AuswahlStatus` (AUSGEWAEHLT/ABGELEHNT/KONFLIKT/UNSICHER), `from_kandidat()` (Legacy-Adapter).
- `packages/core/invoice_extraction/hybrid_ergebnis.py` — `HybridStatus` (OK/MUSS_GEPRUEFT_WERDEN/NICHT_GEFUNDEN), `HybridExtractionResult`, `berechne_hybrid_status()` mit Pflichtfeld-, Konflikt-, Math- und Confidence-Regeln.
- `packages/core/invoice_extraction/provider_ports.py` — `InvoiceTextProvider`, `InvoiceCandidateProvider`, `CloudInvoiceProvider` (alle Protocol), `InvoiceProviderResult` (sanitisierter fehlercode).
- `packages/core/invoice_extraction/pdfplumber_provider.py` — `PdfplumberProvider`: bindet bestehenden `pdfplumber→InvoiceParser→InvoiceValidator`-Pfad als ersten `InvoiceCandidateProvider` ein; kein Verhalten geändert.
- `apps/server/config.py` — 5 Feature-Flags als `bool`-Settings, alle default `False`; `AZURE_DI` nie versehentlich aktiv.
- `apps/server/models/hybrid_extraktion.py` — 4 ORM-Klassen: `HybridErkennungslauf`, `HybridKandidatOrm`, `HybridKonflikt`, `HybridStatusentscheidung`.
- `migrations/versions/011_hybrid_invoice_extraction.py` — `down_revision=010`; 4 neue Tabellen; alle mit ENABLE RLS, FORCE RLS, `tenant_isolation`-Policy; erkennungslauf_id nullable (Verlinkung auf Phase-4-Läufe optional).
- `apps/server/models/__init__.py` — neue ORM-Klassen importiert, damit `alembic check` synchron bleibt.
- `packages/core/invoice_extraction/__init__.py` — neue Typen exportiert; bestehende Exporte unverändert.
- `tests/conftest.py` — 4 neue Tabellen in `_TRANSAKTIONALE_TABELLEN` (hybrid_statusentscheidungen, hybrid_konflikte, hybrid_kandidaten, hybrid_erkennungslaeufe).
- `tests/unit/test_hybrid_kandidat.py` — 20 Unit-Tests.
- `tests/unit/test_hybrid_ergebnis.py` — 13 Unit-Tests (inkl. "OK nicht allein durch gefüllte Felder", "Konflikte bei Pflichtfeldern nie still").
- `tests/unit/test_provider_ports.py` — 10 Unit-Tests.
- `tests/unit/test_feature_flags.py` — 6 Unit-Tests (Azure-Flag default False, aktivierbar via Env).
- `tests/integration/test_hybrid_extraktion.py` — 18 Integrationstests (RLS, FORCE RLS, Persistenz, Tenant-Isolation, alembic check).

**HYB-01..08 Einzelstatus:**
- HYB-01, HYB-02, HYB-03, HYB-04, HYB-06: **ERFÜLLT**.
- HYB-05: **TEILWEISE** — Konflikt-Datenmodell und Nie-still-Auflösen-Regel getestet; automatische Konflikterkennung zwischen mehreren Providern noch nicht implementiert (nur ein Provider aktiv).
- HYB-07: **TEILWEISE** — Feature-Flags angelegt und default korrekt (aus), aber noch kein Code verzweigt auf ihnen.
- HYB-08: **TEILWEISE** — Statusgründe (`gruende`) automatisch befüllt und getestet; kandidatenbezogener `auswahl_grund` nur als Datenfeld vorhanden, noch nicht automatisch befüllt.

**Nachtrag — Regressionsfix in Phase-6-Code (im Zuge der Verifikation von Paket 07-01 gefunden):**
- `packages/core/ec_sammlung/gruppierung.py`: Sortierschlüssel bei Belegen mit identischem Buchungsdatum von reiner UUID auf `(buchungsdatum, betrag_cent, id)` umgestellt. Grund: zufällige UUID-Tie-Breaks konnten bei Überdeckung den exakt passenden Beleg statt des zu großen entfernen und die gesamte Einzahlung ohne Vorschlag lassen (`test_e04_entfernte_belege_bleiben_verfuegbar` flakte in ca. 40 % der isolierten Wiederholungsläufe). Keine Migration geändert, Fachregel nicht abgeschwächt, 27 Unit-Tests in `test_ec_gruppierung.py` weiterhin grün.

**Testergebnis Phase 07-01:**
- 49 neue Unit-Tests: **49 passed, 0 failed**
- 18 neue Integrationstests: mit `TEST_DATABASE_URL` (buchungatakan_test, nicht privilegierte Rolle `buchungatakan_migrations`) verifiziert — **18 passed**, Tenant-Isolation (HY05) explizit gegen echte RLS-Durchsetzung bestätigt (kein Superuser/BYPASSRLS).
- Gesamt-Teststand, zweifach reproduziert: **810 passed, 1 skipped (P-10), 0 failed**.
- Keine echten Rechnungen, kein Realtest, kein Push, keine Azure-Credentials, kein invoice2data, kein PaddleOCR, kein Azure-SDK implementiert.

---

### 2026-07-01 – Phase-6-Abschluss: Technische Validierung buchungatakan_test, Abnahme-Dokumentation

**Art:** Abschluss-Commits — Dokumentation, Guard-Tests, technische Validierung; keine Implementierungsänderung.

Erstellte / geänderte Artefakte:

- `tests/db_guard.py`, `tests/test_db_guard.py` (commit `2f749bd`) — 14 Guard-Tests sichern, dass Pytest ausschließlich gegen `buchungatakan_test` läuft; `buchungatakan_realtest` und `buchungatakan` werden vor TRUNCATE/Teststart blockiert.
- `.planning/STATE.md`, `.planning/ROADMAP.md`, `.planning/REQUIREMENTS.md` — Phase 6 auf `ABGESCHLOSSEN / FACHLICH ABGENOMMEN` gesetzt; EC-10 mit 744 gesammelten Tests dokumentiert.
- `docs/CURRENT_STATUS.md`, `docs/IMPLEMENTATION_HISTORY.md`, `docs/TEST_HISTORY.md`, `docs/OPEN_POINTS.md` — EC-Realtest-Ergebnisse, Abnahme, Guard-Commit dokumentiert.
- `CHANGELOG.md` — v0.6.0-Eintrag mit EC-Realtest-Zusammenfassung.

**EC-Realtest März 2026 — Ergebnisse (keine echten Inhalte):**
- MT940-Reimport: 17 Dateien, 2 Bankkonten, 819 Bankbuchungen, 69 EC_EINZAHLUNG; 0 Parsefehler; zweiter Import: 0 neu, 819 dedupliziert.
- EC-Belege: 18 akzeptiert (1 negative Kulanzauszahlung fachlich ausgeschlossen); zweiter Import: 0 neu, 18 dedupliziert.
- Vorschläge: 0 STARK, 3 UNSICHER, 1 OFFENE_PERIODE; 49 Einzahlungen ohne Gruppe (begrenzter Belegzeitraum).
- Manuelle Entscheidungen: 1 Gruppe bestätigt, 1 Gruppe abgelehnt; nach Rematch Schutz beider Gruppen nachgewiesen; 10 Belege gesperrt; 2 UNSICHER, 1 OFFENE_PERIODE verbleibend.
- Datenschutz eingehalten: keine echten Dateinamen, IBANs, Kontonummern, Verwendungszwecke oder Hashes in Git/Dokumentation.

**Testergebnis (2026-07-01):**
- Gesammelt: 744 Tests (14 neue Guard-Tests via commit `2f749bd`).
- Ohne TEST_DATABASE_URL: 572 passed, 172 skipped, 0 failed.
- Mit TEST_DATABASE_URL (buchungatakan_test, technische Validierung): **743 passed, 1 skipped (P-10), 0 failed** (~75 s).
- Integration+Security: 175 passed, 1 skipped, 0 failed.
- Alle 172 zuvor übersprungenen Integrationstests laufen jetzt vollständig (172 Skips waren fehlende TEST_DATABASE_URL, kein Code-Defekt).

**Alembic-Check (buchungatakan_test):** `010 (head)` — Migration vollständig applied, keine ausstehenden Operationen.

### 2026-06-30 – Planung Phase 7: Hybride Rechnungserkennung und Qualitätsprüfung

**Art:** reine Planungsänderung, keine Implementierung.

Erstellte / geänderte Planungsartefakte:

- `.planning/phases/07-hybride-rechnungserkennung-qualitaetspruefung/07-PHASE-PLAN.md` — Masterplan.
- `.planning/phases/07-hybride-rechnungserkennung-qualitaetspruefung/07-01-PLAN.md` — gemeinsame Extraktions- und Kandidatenarchitektur.
- `.planning/phases/07-hybride-rechnungserkennung-qualitaetspruefung/07-02-PLAN.md` — lokale Erkennungsschienen.
- `.planning/phases/07-hybride-rechnungserkennung-qualitaetspruefung/07-03-PLAN.md` — Zusammenführung und Qualitätsbewertung.
- `.planning/phases/07-hybride-rechnungserkennung-qualitaetspruefung/07-04-PLAN.md` — Azure-Adapter vorbereitet, aber deaktiviert.
- `.planning/REQUIREMENTS.md` — `HYB-01..24`.
- `.planning/ROADMAP.md`, `.planning/STATE.md`, `.planning/PROJECT.md` — Phase 7 konkretisiert, Gmail/UI/OPS nach hinten verschoben.
- `docs/ENTWICKLUNGSPLAN.md`, `docs/PHASENUEBERSICHT.md`, `docs/CURRENT_STATUS.md`,
  `docs/OPEN_POINTS.md`, `docs/ARCHITECTURE.md` — Planungsstand und Sicherheitsgrenzen synchronisiert.

**Sicherheitsgrenzen eingehalten:** keine echten Rechnungen geöffnet, keine Testdaten gesucht,
keine vorhandenen Rechnungsordner verwendet, keine Azure-Aufrufe, keine Credentials, kein Commit.

### 2026-06-29 – Phase 5 Paket 3: Manuelle Zuordnungsentscheidungen (v0.5.0)

**Branch:** `phase/05-bankimport-allgemeines-matching`
**Commits:** `4af9095` (Modell + Migration 008), `024f7af` (Repository + Service + Unit-Tests), `933aada` (Router + API-Tests)

Erstellte / geänderte Dateien:

- `apps/server/models/zuordnung.py` — 3 neue Felder: entschieden_at, entschieden_von_benutzer_id, entscheidungsnotiz; Partial Unique Index `uix_zuordnung_eine_bestaetigte_pro_buchung` (BANK-05 auf DB-Ebene)
- `migrations/versions/008_zuordnung_entscheidungen.py` — ADD COLUMN × 3, FK benutzer.id, CREATE UNIQUE INDEX WHERE status = 'MANUELL_BESTAETIGT'
- `apps/server/repositories/zuordnung.py` — `bestaetigen()` (idempotent, IntegrityError → 409, BANK-05/07), `ablehnen()` (idempotent, BANK-06), `get_bestaetigte_buchung_ids()`, `get_abgelehnte_paare()`; `upsert_vorschlaege()` erweitert mit ON CONFLICT DO UPDATE WHERE status NOT IN (MANUELL_BESTAETIGT, MANUELL_ABGELEHNT)
- `apps/server/services/matching_service.py` — `rematch()` lädt bestätigte Buchungs-IDs vor Scoring (BANK-07) + abgelehnte Paare (BANK-06); `_get_matchbare_buchungen()` mit optionalem `ausschliessen`-Parameter
- `apps/server/routers/zuordnungen.py` — 2 neue Endpunkte: POST /{id}/bestaetigen, POST /{id}/ablehnen; `EntscheidungRequest` (notiz max 500); `ZuordnungsVorschlagResponse` um entschieden_at/entscheidungsnotiz erweitert; Status-Filter auf alle 4 Stati erweitert
- `tests/unit/test_zuordnung_entscheidungen.py` — 13 Unit-Tests (U1–U12): bestaetigen, ablehnen, Idempotenz, 409-Konflikt, 404-Fremde-ID, benutzer_id-Herkunft, RematchSchutz; MagicMock statt ORM-Instanz
- `tests/integration/test_zuordnung_entscheidungen_api.py` — 17 Integrationstests (E1–E12): Migration-Check, Auth-Guard, Grundoperationen, BANK-05 409, BANK-07 Rematch-Überleben, BANK-06 Ausschluss nach Rematch, Idempotenz, Tenant-Isolation

**Testergebnis:** 359 unit/security passed, 73 integration passed, 1 skipped (P-10).

---

### 2026-06-29 – Phase 5 Paket 1+2: Bankimport-Core, Klassifikation, Matching-Scorer

**Branch:** `phase/05-bankimport-allgemeines-matching`

Erstellte / geänderte Dateien (Auswahl):

- `apps/server/models/bankbuchung.py` — Bankkonto, Kontoauszugsimport, Bankbuchung (betrag_cent INTEGER, BANK-10), BuchungsKlassifikation StrEnum (BANK-11), Dedup-Fingerprint UNIQUE (BANK-02)
- `apps/server/models/zuordnung.py` (Basis) — ZuordnungsVorschlag mit score, status, positive_signale, negative_signale, matcher_version
- `packages/core/matching/signale.py` — Signal (typ, beschreibung, punkte), MatchErgebnis
- `packages/core/matching/scorer.py` — `berechne_match()`: Betragsvergleich, Datumsabstand, Rechnungsnummer, Lieferant; Score STARK/UNSICHER
- `apps/server/routers/bankbuchungen.py` — POST /api/v1/bankkonten, POST /api/v1/bankbuchungen/importe, GET /api/v1/bankbuchungen
- `migrations/versions/006_bankbuchungen.py`, `007_zuordnungen.py` — Tabellen + GRANT + FORCE RLS

**Testergebnis nach Paket 2:** 346 unit/security passed, 56 integration passed.

---

### 2026-06-28 – Phase 4 Integrationstests, Infrastruktur und Produktivfix

**Branch:** `phase/04-rechnungsimport-extraktion-validierung`
**Commits:** `0a94699` (conftest), `5eff878` (test_rechnungen + repo-fix)

Erstellte / geänderte Dateien:

- `tests/integration/conftest.py` — `_ensure_seed_data()` mit idempotenter Seed-Logik (FORCE-RLS-konform via `set_config`-Transaktion), NullPool-Patch für Windows-ProactorEventLoop-Kompatibilität (asyncpg), `render_as_string(hide_password=False)`-Fix (SQLAlchemy-Password-Masking)
- `tests/integration/test_auth_flow.py` — `test_seed_data_exists` für FORCE-RLS-Testumgebung angepasst (per-Mandant-Transaktionen, SECURITY DEFINER für benutzer)
- `tests/integration/test_rechnungen.py` — 6 neue Integrationstests: Anlegen, Liste/Detail, Versioning (neueres Datum, gleiches Datum), Mandantentrennung 404, Erkennungsläufe-Isolation, Kandidaten-Isolation
- `apps/server/repositories/rechnung.py` — **Produktivfix**: `await session.refresh(neue)` nach `session.commit()` entfernt; `flush()` lädt server-generierte Werte via RETURNING; `expire_on_commit=False` hält sie verfügbar (Fehler durch PostgreSQL-Integration reproduziert)

**Testergebnis:** 25 integration passed, 1 skipped (P-10), 253 unit/security passed.

**Architekturentscheide Phase-4-Tests:**
- NullPool für gepatchte App-Engine: pytest-asyncio erstellt je Test neuen Event-Loop; asyncpg-Pool mit pool_pre_ping reicht in geschlossenem Loop → NullPool umgeht das.
- SelectorEventLoop nicht nötig (Windows): NullPool löst das ProactorEventLoop-Problem vollständig.
- `set_config(..., true)` = transaktionslokal: kein Tenant-Kontext-Leak zwischen Test-Transaktionen.

---

### 2026-06-28 – Phase 4 Router, Repository, Auth/RLS-Härtung

**Branch:** `phase/04-rechnungsimport-extraktion-validierung`
**Commits:** `5f10289` (Repository), `325b69e` (Router + Guards), `8e1de08` (Auth-Lookups)

Erstellte / geänderte Dateien:

- `apps/server/repositories/rechnung.py` — `RechnungRepository`: Versionierungslogik `_neue_version_ist_aktiv` (RECH-08), `list_aktive`, `get_aktive_by_nummer`, `create_version` (flush vor commit), `list_erkennungslaeufe`, `list_kandidaten_fuer_rechnung`; mandantengesicherte `_get_erkennungslauf_by_id` (404 bei fremdem Lauf)
- `apps/server/routers/rechnungen.py` — 5 Endpunkte: POST (RECH-03/06/08/09), GET Liste, GET Detail, GET Erkennungsläufe, GET Kandidaten; `RechnungCreateRequest` mit `extra="forbid"` und ohne `unternehmen_id`-Feld (SRV-05); RECH-06-Guard (`_rech06_prueffall`)
- `apps/server/auth/dependencies.py` — `auth_benutzer_by_name` / `auth_benutzer_by_id` via SECURITY DEFINER; `get_rls_session` setzt `app.current_tenant` transaktionslokal; `CurrentTenantId`-Dependency

**Testergebnis:** 253 unit/security passed.

**Architekturentscheide:**
- `extra="forbid"` auf `RechnungCreateRequest`: verhindert versehentliche `unternehmen_id`-Übergabe im Body.
- PRUEFFALL statt Ablehnung bei fehlendem Identifikationssignal (RECH-06): Import bleibt möglich, manuell klärbar.
- Erkennungslauf-FK-Prüfung mandantensicher vor Rechnung-Anlage (404, nicht erst bei Commit).

---

### 2026-06-28 – Phase 4 Kern: Extraktion, Modelle, Migration 005

**Branch:** `phase/04-rechnungsimport-extraktion-validierung`
**Commits:** `1b1a8f5` (Kern), `6a3372d` (Härtung)

Erstellte / geänderte Dateien:

- `packages/core/invoice_extraction/kandidat.py` — `Kandidat` frozen dataclass + `KandidatQuelle` StrEnum (RECH-01)
- `packages/core/invoice_extraction/extraction_result.py` — `ExtractionResult` + `ExtraktionsStatus`
- `packages/core/invoice_extraction/invoice_data.py` — `InvoiceData` (Portierung Altprojekt)
- `packages/core/invoice_extraction/invoice_parser.py` — `InvoiceParser` (regex-basiert, Portierung + Fixes A-02/A-06/A-08)
- `packages/core/invoice_extraction/invoice_parser_adapter.py` — Bridge `InvoiceData → list[Kandidat]`; `validate()` verbindlich eingebunden
- `packages/core/invoice_extraction/invoice_validator.py` — `validate()` (RECH-04/05): Math-Check ±0.02 EUR, USt-ID≠Rechnungsnummer-Sperre, Pflichtfeld-Prüfung
- `packages/core/invoice_extraction/ports.py` — `InvoiceExtractionPort` Protocol (ENTWICKLUNGSPLAN §5)
- `packages/core/invoice_extraction/pdf_reader.py`, `text_cleaner.py` — Portierungen Altprojekt
- `apps/server/models/rechnung.py` — `Rechnung` (version_lfd_nr, ist_aktiv, Decimal-Beträge), `Erkennungslauf`, `RechnungsKandidat`, `RechnungsStatus`
- `migrations/versions/005_rechnungen.py` — rechnungen + erkennungslaeufe + rechnungs_kandidaten; GRANT + FORCE RLS für alle drei Tabellen; FK unternehmen_id→unternehmen(id)
- `tests/unit/test_kandidat.py`, `test_extraction_result.py`, `test_invoice_validator.py`, `test_invoice_parser_adapter.py`, `test_server_models_phase4.py` — 43 neue Unit-Tests
- `tests/unit/test_invoice_parser_golden.py` — 20 Golden-File-Tests (rechnung_standard, _amazon, _kleinunternehmer, _doppelzeile)
- `tests/fixtures/*.txt` — synthetische Rechnungs-Fixtures

**Fixes (Commit 6a3372d):**
- A-02: `_line_is_inside_recipient_block` indexbasiert statt `list.index()`.
- A-06: Englische Monate (april, august, september, november) in MONTHS-Dict ergänzt.
- A-08: `parse()` mit try/except → `InvoiceData(confidence=0.0)` statt Exception.

**Testergebnis:** 253 unit/security passed (kumulativ nach Härtung).

---

### 2026-06-27 – Phase 2 implementiert (Zentrale API, PostgreSQL, Mandantensicherheit)

**Branch:** `phase/02-zentrale-api-postgresql-mandantensicherheit`
**GSD-Pläne:** 02-01, 02-02, 02-03

Erstellte / geänderte Dateien:

- `apps/server/config.py` — pydantic-settings (DATABASE_URL, SECRET_KEY, ALGORITHM, ACCESS_TOKEN_EXPIRE_MINUTES)
- `apps/server/database.py` — async SQLAlchemy 2.x Engine + AsyncSession + DBSession-Dependency
- `apps/server/models/__init__.py`, `base.py`, `unternehmen.py`, `benutzer.py`, `installation.py`
  — DeclarativeBase, TenantMixin, Unternehmen, Benutzer (Rolle-Enum), Installation
- `migrations/env.py` — Alembic async-Konfiguration; liest DATABASE_URL aus pydantic-settings
- `migrations/versions/001_initial_schema.py` — Initial-Schema (3 Tabellen, gen_random_uuid())
- `migrations/versions/002_seed_test_data.py` — Testdaten ENV-Guard, 2 Mandanten, 3 Benutzer
- `migrations/versions/003_rls_policies.py` — buchungatakan_app-Rolle, GRANT, RLS, Policies
- `apps/server/auth/__init__.py`, `schemas.py`, `service.py`, `dependencies.py`, `router.py`
  — JWT (PyJWT), Argon2 (pwdlib), OAuth2PasswordRequestForm, RoleChecker, RLSSession-Dependency
- `apps/server/repositories/__init__.py`, `base.py`, `benutzer.py`, `unternehmen.py`
  — BaseRepository[T], BenutzerRepository (global-unique), UnternehmenRepository
- `apps/server/routers/health.py`, `unternehmen.py` — /health, /api/v1/unternehmen/me
- `apps/server/exceptions.py` — register_exception_handlers: 4xx/5xx/422/catch-all
- `apps/server/main.py` — create_app() Factory, alle Router + Exception-Handler
- `tests/unit/test_auth_service.py`, `test_role_checker.py`, `test_schemas.py` — 19 Tests
- `tests/security/test_error_sanitization.py` — 5 Security-Tests (SRV-08, T-03-01)
- `tests/integration/conftest.py`, `test_migrations.py`, `test_auth_flow.py`,
  `test_tenant_isolation.py`, `test_rls.py` — 20 Integrationstests

**Testergebnis:** 24 passed (unit + security), 20 skipped (integration ohne TEST_DATABASE_URL).

**Architekturentscheide Phase 2:**
- `benutzername` global unique (nicht per Mandant) — Login hat kein unternehmen_id-Parameter.
- `set_config('app.current_tenant', :tid, true)` — `true` = transaktionslokal (kein Pool-Leak).
- PyJWT (`import jwt`) statt python-jose; `jwt.encode()` gibt `str` zurück.
- Zwei PostgreSQL-Rollen: `buchungatakan_migrations` (DDL) und `buchungatakan_app` (Runtime).

### 2026-06-26 – Phase 0 abgeschlossen (Bestandsaufnahme, Architektur-Freeze, Migrationsplan)

**GSD-Pläne:** 01-01 (Wave 1), 01-02 (Wave 2), 01-03 (Wave 3)
**Erstellt durch:** Claude (Analyse-Agent), rein dokumentarisch (kein Anwendungscode)

Erstellte Lieferobjekte:
- `docs/phase0/BESTANDSAUFNAHME.md` — Altmodul-Inventar (14 Module, Abhängigkeiten, DB-Zugriffe, Pfadannahmen)
- `docs/phase0/MODULKLASSIFIKATION.md` — Client/Server/Shared-Core-Zuordnung, Wiederverwendungsstrategie, technische Schulden
- `docs/phase0/MIGRATIONSPLAN.md` — Tabellen-Mapping Alt-SQLite → PostgreSQL-Multi-Tenant, reversibler Migrationspfad (6 Schritte)
- `docs/phase0/API_GROBVERTRAG.md` — Identifier-Definitionen, API /api/v1/, Feature-Flag-System BUCHUNG_ATAKAN_FEATURE_*, PySide6-Entscheidung
- `docs/phase0/BASELINE_TESTS.md` — Altprojekt-Testlauf read-only: 162/162 Tests grün, Exit-Code 0
- `docs/phase0/AKZEPTANZKRITERIEN.md` — ARCH-01..11 bewertet: 10 ERFÜLLT, 1 NICHT GETESTET (ARCH-11)

**Codeänderungen:** Keine. Phase 0 ist rein analytisch und dokumentarisch.
**Architekturentscheide:** D1–D6 (siehe OPEN_POINTS.md) verbindlich dokumentiert.
**Nächste Phase:** Phase 1 — Zentrale API, PostgreSQL, Mandantensicherheit (nach ARCH-11-Freigabe).

### 2026-06-25 – Dokumentationsbasis erstellt
- Aus autoritativen Planungsdokumenten (`docs/ENTWICKLUNGSPLAN.md`,
  `docs/PHASENUEBERSICHT.md`) und Altprojekt-Kontext erstellt:
  `AGENTS.md`, `CHANGELOG.md`, `docs/PROJECT_CONTEXT.md`, `docs/BUSINESS_RULES.md`,
  `docs/ARCHITECTURE.md`, `docs/CURRENT_STATUS.md`, `docs/OPEN_POINTS.md`,
  `docs/IMPLEMENTATION_HISTORY.md`, `docs/TEST_HISTORY.md`.
- **Kein Anwendungscode.** Phase 1 nicht begonnen.

### (Vorbestand) Skelett
- Initialer Commit „Initialisiere neues BuchungAtakan-Projekt“: `apps/client`, `apps/server`,
  `packages/core` (leere `__init__.py`), `pyproject.toml` (Python 3.12), `README.md`,
  `tests/unit/test_smoke.py`, `.env.example`.

---

## Altprojekt (Referenz)

Quelle: `C:\Users\User\PycharmProjects\BuchungAtakan` und dessen Kontextpaket
`BuchungAtakan_Codex_Project_Context_v2/IMPLEMENTATION_HISTORY.md`. Einzelmandant, lokale
SQLite, Python-Desktop. **Eigene Phasennummerierung**, nicht identisch mit neuen
ENTWICKLUNGSPLAN-Phasen.

Wesentliche Implementierungsschritte (chronologisch verdichtet):

- **2026-06-24 – Gmail-Nachsuche (Alt-Phasen 4/5):**
  `src/gmail/bank_transaction_gmail_query.py`, `src/gmail/gmail_bank_followup_search.py`,
  additive Tabelle `gmail_bank_search` (idempotent), Integration in
  Initial-/Inkrementellbetrieb über `PipelineOptions` (Default aus, fehlerisoliert),
  überlappende Scan-Intervalle (`gmail_scan_intervals.py`).
- **2026-06-24 – Pfad-Konsistenz (Alt-Phase 3):** `PathConfig`/`settings` als zentrale
  Datenwurzel-Auflösung, relative Speicherung von Zuordnungs-/EC-Pfaden, DATA_ROOT-Security-
  Guards in den CLI-`__main__`-Blöcken; keine Bestandsmigration.
- **2026-06-24 – Excel-Zählung auf eindeutige Bankbuchungen umgestellt**
  (`zuordnung_report_exporter.py`).
- **2026-06-23 – `NICHT_ZU_MATCHEN`** für Bankbuchungen (Schema/Repository/Matcher/Report).
- **2026-06-22 – Monatsarchiv-Klassifikation & Dokumentinventar `files`**, zentraler
  Dev/Test-DB-Neuaufbau, sensibler TESTDATENIMPORT mit Schema-Kompatibilität.
- **2026-06-21 – Pfadarchitektur** (frei wählbare Datenwurzel; UNC-/Netzwerkstamm-Option –
  letzteres im Neuaufbau **superseded**, siehe `docs/OPEN_POINTS.md` D6).
- **2026-06-20 – Gmail-Mehrpostfach-Grundlage** (`config/gmail/<mailbox_key>`, Discovery,
  Fehlerisolierung, Dedup).
- **2026-06-19 – EC-/Telexpert-Sammelzuordnung** (Centwerte, Belegsperre, Überhang-Algorithmus,
  Blatt `EC-Sammel`); Entwicklungs-DB/Reset-Regeln; synthetischer PDF-TEST-E2E.

Beteiligte Alt-Module: `gmail/`, `ec/`, `bank/`, `matching/`, `database/`, `pipeline/`,
`reports/`, `config/`. Diese sind Wiederverwendungsquelle (D2), nicht Ist-Stand des neuen Repos.

> Vollständige Detailhistorie: Altprojekt
> `BuchungAtakan_Codex_Project_Context_v2/IMPLEMENTATION_HISTORY.md` (632 Zeilen).
