# BuchungAtakan – kurze Phasenübersicht

## Phase 0 – Bestand und Architektur
- bestehenden Code und Tests prüfen
- Module in lokalen Client, zentralen Server und Shared Core aufteilen
- Migrationsweg von aktueller DB zur zentralen PostgreSQL-Architektur planen
- noch keine großen Funktionsänderungen

## Phase 1 – Server und Mandantentrennung
- zentrale FastAPI in Aachen
- zentrale PostgreSQL-Datenbank
- Unternehmen, Benutzer und Installationen
- Login, Rollen und sichere `unternehmen_id`-Filter
- kein direkter DB-Zugriff der Clients

## Phase 2 – Lokale Dokumente und Synchronisation
- frei wählbare lokale `DATA_ROOT`
- Rechnungen, Kontoauszüge und Anhänge bleiben lokal
- zentral werden nur Metadaten, Hash und relative Pfade gespeichert
- Offline-Outbox und idempotente Synchronisation

## Phase 3 – Rechnungsverarbeitung
- PDF-Text/OCR/Parser
- Kandidaten und freigegebene Rechnungsdaten getrennt
- mathematische und formale Prüfungen
- Lieferantenerkennung, Duplikate und manuelle Prüffälle

## Phase 4 – Bank und Matching
- Kontoauszüge lokal importieren
- Bankbuchungen zentral speichern
- Rechnungen über Betrag, Partner, IBAN, Text, Nummer und Datum matchen
- sichere, unsichere und nicht gefundene Fälle

## Phase 5 – EC-/Telexpert-Logik
- EC-Kartenbelege sammeln
- Einzahlungszeiträume bilden
- neueste Belege bei Überschreitung zuerst entfernen
- verwendete Belege gegen erneute Nutzung sperren

## Phase 6 – Hybride Rechnungserkennung
- bestehender `pdfplumber`-/`InvoiceParser`-Pfad bleibt erhalten
- invoice2data-Templates für bekannte Anbieter ergänzen den eigenen Parser
- PaddleOCR verarbeitet Scan-PDFs lokal; keine Cloud-Aufrufe
- Kandidaten werden mit Quelle, Confidence, Konflikten und Auswahlgrund gespeichert
- Status `OK`, `MUSS_GEPRUEFT_WERDEN`, `NICHT_GEFUNDEN` nach Qualitätsregeln
- Qualitätsmetriken und Auditworkflow messen Vollständigkeit und Richtigkeit
- Azure-Adapter nur vorbereitet, standardmäßig deaktiviert und ohne echte Aufrufe

## Phase 7 – Gmail und Automatikbetrieb
- mehrere lokale Gmail-Postfächer
- Anhänge lokal speichern
- Scan-Historie und Intervall-Reset
- Gmail-Nachsuche für offene Buchungen
- Erstimport, Inkrementellbetrieb und Scheduler

## Phase 8 – GUI, Berichte und Installer
- Einrichtungsassistent und tägliche Benutzeroberfläche
- Prüffälle bearbeiten und lokale Dokumente öffnen
- Excel-, CSV- und JSON-Berichte
- Windows-Installer und Update-Konzept

## Phase 9 – Pilot und Härtung
- TEST/PRODUKTION sauber trennen
- zentrale DB-Backups und lokale Dokumentbackups
- Netzwerk- und Wiederanlauftests
- Sicherheits-, Last- und Mandantentests
- ausdrückliche Produktionsfreigabe

## Erst später optional
- DATEV-Export
- GoBD-orientierte Audit-, Aufbewahrungs- und WORM-Funktionen
- zentrale Dokumentkopien oder Mehrrechner-Synchronisation
- Cloud-OCR, weitere Mailanbieter und Banken
- optionale KI-Hilfe für schwierige Fälle
