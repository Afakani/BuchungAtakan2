# Architektur – BuchungAtakan (Neuaufbau)

**Stand:** 2026-06-30
**Autoritativ:** `docs/ENTWICKLUNGSPLAN.md` (§2 Betriebsarchitektur, §3 Technologierahmen),
`docs/PHASENUEBERSICHT.md`
**Legacy-Referenz:** Altprojekt-Datenmodell (`DATABASE_MODEL.md`)

---

## 1. Soll-Architektur (Zielbild)

```
[ Lokaler Client / Standort ]            [ Zentrale (Aachen) ]
  PySide6-Desktop                          FastAPI  ── PostgreSQL
  lokaler DATA_ROOT (Originale)   ── API ──►  (nur Metadaten/Hash/relative Pfade)
  Offline-Outbox / Sync                      Unternehmen, Benutzer, Rollen,
                                             Installationen
```

Kernprinzipien:
- **Zentrale PostgreSQL + FastAPI** in Aachen.
- **Kein direkter DB-Zugriff** der Clients – alles über die authentifizierte API.
- **Mandantentrennung** über `unternehmen_id`; zentrale Verwaltung von Unternehmen,
  Benutzern, Rollen und Installationen.
- **Dokumente bleiben lokal** (`DATA_ROOT`): Rechnungen, Kontoauszüge, Anhänge. Zentral nur
  strukturierte Daten, Metadaten, **Hash** und **relative** Dokument-Locator.
- **Offline-Outbox + idempotente Synchronisation** zwischen Client und Server.

## 2. Technologierahmen

| Schicht | Technologie |
|---|---|
| Lokaler Client / GUI | **PySide6** (D3) |
| Server-API | **FastAPI** |
| Zentrale DB | **PostgreSQL** |
| Sprache | Python 3.12 |
| Dokumentablage | lokales Dateisystem unter `DATA_ROOT` |

> Domänen- und Anwendungslogik bleibt **unabhängig von PySide6** (Ports/Adapter), damit später
> eine andere UI oder ein Web-Frontend andocken kann.

## 3. Repository-Struktur (Soll)

```
apps/
  client/    # PySide6-Client + Adapter (API-Client, lokales DATA_ROOT, Sync-Outbox)
  server/    # FastAPI + PostgreSQL-Adapter, Auth, Mandanten-Guards
packages/
  core/      # mandanten-/UI-unabhängige Domänen- & Anwendungslogik (Ports)
tests/
docs/
```

Wiederverwendung (D2): bestehende Fachmodule des Altprojekts werden **phasenweise** über
Ports/Adapter nach `packages/core` gehoben (siehe §6).

## 4. Mandanten- und Zugriffsmodell

- Jede fachliche Entität trägt `unternehmen_id`; alle Repository-/Query-Pfade filtern sicher.
- `installation_id` identifiziert eine konkrete lokale Installation/Standort.
- Auth + Rollen serverseitig; Tenant-Isolation ist verbindlich zu testen.

## 5. Dokument- und Pfadmodell

- `DATA_ROOT` ist die frei wählbare lokale Datenwurzel (Erststart wählbar, später änderbar;
  Auflösung: expliziter Parameter → Umgebungsvariable → JSON-Konfiguration → projektlokaler
  Fallback). Neue Variablen: `BUCHUNG_ATAKAN_*` (D4).
- Dokumente werden mit **relativen** Pfaden gegenüber `DATA_ROOT` referenziert.
- Zentrale Datensätze speichern Metadaten + Hash + relativen Locator, **nicht** die Datei selbst.
- Hyperlinks (Excel/UI) öffnen das **lokale** Dokument (`DATA_ROOT` + relativer Pfad).

> **Superseded (D6):** Die Alt-Entscheidung 2026-06-21 (zentrale UNC-/Tailscale-Dokumentablage,
> Original-PDFs einmal serverseitig, Excel-UNC-Hyperlinks) gilt **nicht** für die Kernarchitektur.
> Die frühere Intention ist nur als **„Optional C – verschlüsselte zentrale Dokumentkopie /
> Dokumentreplikation“** geparkt (kein MVP). Siehe `docs/OPEN_POINTS.md`.

## 5a. Hybride Rechnungserkennung (Phase 7)

Die Rechnungserkennung bleibt dokumentnah und lokal. Der lokale Client liest Originaldokumente
read-only aus `DATA_ROOT` und erzeugt strukturierte Kandidaten; zentral werden nur Ergebnisse,
Kandidaten, Konflikte, Providerlauf-Metadaten und Auditbewertungen gespeichert.

Geplante Provider-Schienen:

- digitale Text-PDFs: `pdfplumber` und bestehender eigener `InvoiceParser`,
- bekannte Anbieter: invoice2data-Templates auf extrahiertem Text oder einem geeigneten lokalen
  PDF-Inputreader, gegengeprüft durch den eigenen Parser,
- Scan-PDFs: lokale PaddleOCR, danach dieselbe Parser- und Validierungspipeline,
- später optional: Azure Document Intelligence nur als deaktivierter Adapter/Fallback
  (Paket 07-04: `AzureDocumentIntelligenceProvider` vorbereitet, aber nicht produktionsfähig —
  kein SDK, keine Credentials, Flag standardmäßig deaktiviert).

Architekturregeln:

- Jeder Provider liefert Kandidaten, aber keine finale Freigabe.
- `OK` erfordert Pflichtfelder, mathematische/formale Validierung, Quellen-/Confidence-Regeln,
  Anbieterregeln und Konfliktfreiheit.
- Konflikte führen zu `MUSS_GEPRUEFT_WERDEN`.
- Azure ist standardmäßig per Feature-Flag deaktiviert, benötigt keine Credentials und darf in
  Phase 7 nur über Fake-/Mock-Clients und synthetische Contract-Tests vorkommen.
- Kanonisches Azure-Flag `BUCHUNG_ATAKAN_FEATURE_AZURE_DOCUMENT_INTELLIGENCE` (Paket 07-04)
  ist die einzige Steuerung für `AzureDocumentIntelligenceProvider`; das ältere Legacy-Flag
  `BUCHUNG_ATAKAN_FEATURE_AZURE_DI` (Paket 07-01) bleibt bewusst inert. Azure-Kandidaten dürfen
  Pflichtfelder nie allein bestätigen — eine ausschließlich Azure-gestützte Pflichtfeldbasis
  erreicht höchstens `MUSS_GEPRUEFT_WERDEN`, nie `OK`. Spätere Aktivierung braucht ein eigenes
  Paket und ausdrückliche Nutzerfreigabe (siehe `docs/OPEN_POINTS.md` HYB-O-02).
- Qualitätsauswertungen messen Vollständigkeit und Richtigkeit getrennt und bleiben
  tenant-sicher.
- Lokaler Excel-Export (Paket 07-03B) liefert ausschließlich bereits aggregierte
  Statistikdaten (Gruppenschlüssel, Zähler, Nenner, Quoten) als `.xlsx`, vollständig
  im Speicher erzeugt — kein Dateisystemzugriff im Core-Modul, keine Originalinhalte.

## 6. Wiederverwendung der Altprojekt-Module (phasenweise)

Vorgehen je Modul: Alt-Implementierung + Tests prüfen → wiederverwendbare Domänenlogik
identifizieren → Infrastrukturabhängigkeiten trennen → nach `packages/core` heben → über
Ports/Adapter anbinden → Verhalten per Regressionstest sichern. **Keine** grundlose
Neuschreibung funktionierender EC-/Gmail-/Parser-/Matching-Logik.

Alt-Module (Quelle `…/BuchungAtakan/src`): `gmail/`, `ec/`, `bank/`, `matching/`,
`database/`, `pipeline/`, `reports/`, `config/`.

## 7. Altschema (Migrationsquelle – Referenz)

Aus dem Altprojekt (lokale SQLite). Dient als **Mapping-Grundlage** für das neue
PostgreSQL-Mehrmandantenschema (Migrationspfad: `docs/OPEN_POINTS.md` → D1). Tabellen müssen im
Zielschema je Datensatz um `unternehmen_id` ergänzt werden.

Tabellen:
`emails`, `invoices`, `bank_transactions`, `zuordnungen`, `unsichere_zuordnungen`,
`gmail_scan_history`, `files`, `processing_state` (+ additiv `gmail_bank_search`).

Auszug zentraler Felder:
- **`invoices`**: `vendor_name`, `invoice_number`, `invoice_date`, `total_amount`,
  `net_amount`, `tax_amount`, `currency`, `payment_method`, `file_hash`,
  `validation_status`, `validation_reasons`, relative/abs. Pfadfelder.
- **`bank_transactions`**: `booking_date`, `value_date`, `amount`, `direction`,
  `transaction_type`, `name`, `purpose`, `source_file`.
- **`zuordnungen`**: `invoice_id`, `bank_transaction_id`, `status`, `score`, `reasons_json`,
  `*_target_path`, `organized_at`.
- **`unsichere_zuordnungen`**: zusätzlich `decision_status`, `decision_note`.
- **`files`** (Dokumentinventar gemischter Monatsarchive): `file_type`, `document_type`,
  `source_category`, `source_root`, `source_relative_path`, `source_month_label`,
  `payment_category`, `import_status`, `invoice_id` (nur für echte Rechnungstypen).

> Hinweis: Das Altschema ist Einzelmandant. Es wird **nicht** 1:1 übernommen, sondern als
> Migrationsquelle abgebildet (D1).

---
*Diese Architektur folgt `docs/ENTWICKLUNGSPLAN.md`. Abweichungen sind dort zu begründen.*
