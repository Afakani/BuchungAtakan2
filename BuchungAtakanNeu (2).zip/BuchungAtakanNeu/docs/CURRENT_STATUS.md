# Aktueller Stand – BuchungAtakan

**Stand:** 2026-07-01

Dieses Dokument trennt klar zwischen dem **neuen Repository** (A) und der **Reife des
Altprojekts** (B). Die beiden Phasennummerierungen sind nicht identisch.

---

## A. Neues Repository (maßgeblich)

### Phase-6-Status: ABGESCHLOSSEN / FACHLICH ABGENOMMEN — v0.6.0

**Branch:** `phase/06-ec-telexpert-sammelzuordnung`

| Lieferobjekt | Status |
|--------------|--------|
| `apps/server/models/ec_sammlung.py` — EcBeleg, EcSammellauf, EcSammelzuordnung, EcSammelzuordnungBeleg, Status-Enums | Erledigt |
| `migrations/versions/010_ec_sammelzuordnung.py` — ec_belege, ec_sammellaeufe, ec_sammelzuordnungen, ec_sammelzuordnung_belege + RLS + Partial-Unique-Indices | Erledigt, applied |
| `packages/core/ec_sammlung/` — normalisierung.py, scorer.py, gruppierung.py (Gruppierungs-Core aus Altprojekt portiert) | Erledigt |
| `apps/server/repositories/ec_sammelzuordnung.py` — bestaetigen, ablehnen, rematch-Schutz, MANUELL_*-Unveränderlichkeit | Erledigt |
| `apps/server/services/ec_sammelzuordnung_service.py` — rematch-Algorithmus, offene Periode, ohne_vorschlag-Logik | Erledigt |
| `apps/server/routers/ec_sammelzuordnungen.py` — bestaetigen, ablehnen (begin()-konformes Session-Pattern) | Erledigt |
| `apps/server/auth/dependencies.py` — CurrentUserId-Dependency ergänzt | Erledigt |
| `tests/db_guard.py` + `tests/test_db_guard.py` — Pytest-Guard gegen Realtest-/Produktivdatenbanken | Erledigt (commit `2f749bd`) |
| Unit-Tests (EC-Gruppierung, Scoring, Normalisierung) | **555 passed** (kumulativ) |
| Security-Tests (Tenant-Isolation EC) | **7 passed** |
| Integrationstests | **175 passed**, 1 skipped (P-10), 0 failed |
| Gesamt (mit TEST_DATABASE_URL, buchungatakan_test) | **743 passed**, 1 skipped, 0 failed |
| Gesamt gesammelt (inkl. 14 Guard-Tests) | **744 gesammelt**: 572 passed, 172 skipped (ohne TEST_DATABASE_URL) |
| EC-01..10 | Alle **ERFÜLLT** — fachlich abgenommen |
| EC-Realtest März 2026 | **ABGESCHLOSSEN** — kontrolliert, echte Belege, keine Daten committed |

**Commits (Phase 6):** `e44f82d` `e47279b` (Paket 3); `2f749bd` (Pytest-Guard); `039c789` (Abnahme-Doku); Abschluss-Commit (technische Validierung buchungatakan_test)

**EC-Realtest März 2026 (Zusammenfassung):**
- MT940-Reimport: 2 Bankkonten, 819 Bankbuchungen, 69 EC_EINZAHLUNG — 0 Parsefehler; zweiter Import idempotent
- EC-Belege: 18 akzeptiert (1 negative Kulanzauszahlung fachlich ausgeschlossen); zweiter Import idempotent
- Vorschläge: 3 UNSICHER, 1 OFFENE_PERIODE, 0 STARK (begrenzter Belegzeitraum — kein falsches Hochstufen)
- Manuelle Entscheidungen: 1 bestätigt, 1 abgelehnt; nach Rematch Schutz beider Gruppen nachgewiesen
- Datenschutz: keine echten Dateinamen, IBANs, Kontonummern, Verwendungszwecke oder Hashes committed

**Sicherheitsregeln (durchgehend eingehalten):**
- `unternehmen_id` ausschließlich aus JWT; fremdes Objekt → 404
- Kein Float, Integer-Cents; kein stilles Downgrade unbekannter Kartenbegriffe
- MANUELL_BESTAETIGT/MANUELL_ABGELEHNT niemals änderbar (Partial-Unique-Index + Applikationslogik)
- Keine doppelte aktive Belegverwendung (Partial-Unique-Index `uix_ec_szb_aktive_belegverwendung`)
- Pytest-Guard (commit `2f749bd`): 14 Guard-Tests, blockiert TRUNCATE gegen `buchungatakan_realtest` und `buchungatakan`

**Technische Validierung buchungatakan_test (2026-07-01):**
- Vollständige Testsuite mit TEST_DATABASE_URL gegen buchungatakan_test: **743 passed, 1 skipped (P-10), 0 failed** (Laufzeit ~75 s)
- Integration+Security: 175 passed, 1 skipped, 0 failed
- Alle 172 zuvor übersprungenen Integrationstests laufen jetzt vollständig; nur P-10 bleibt erwartungsgemäß übersprungen
- Kein Code geändert; keine echten Daten; kein Push

**Verbindliche Reihenfolge:**
1. ~~EC-Realtest → Phase-6-Abnahme~~ **ABGESCHLOSSEN 2026-07-01**
2. Phase 7: Hybride Rechnungserkennung und Qualitätsprüfung — **nächste Phase**
3. Phase 8: Gmail/Scheduler

**Phase-7-Status: Gap-Paket HYB-07 geschlossen — formal abnahmefähig (v0.7.0-dev)**

**Branch:** `phase/07-hybride-rechnungserkennung-qualitaetspruefung`

| Lieferobjekt | Status |
|--------------|--------|
| `packages/core/invoice_extraction/hybrid_kandidat.py` — `HybridKandidat` (frozen), `AuswahlStatus`, `from_kandidat()` | Erledigt |
| `packages/core/invoice_extraction/hybrid_ergebnis.py` — `HybridStatus`, `HybridExtractionResult`, `berechne_hybrid_status()` | Erledigt |
| `packages/core/invoice_extraction/provider_ports.py` — `InvoiceTextProvider`, `InvoiceCandidateProvider`, `CloudInvoiceProvider` (Protocol), `InvoiceProviderResult` | Erledigt |
| `packages/core/invoice_extraction/pdfplumber_provider.py` — `PdfplumberProvider` wraps bestehenden `extract_from_pdf`-Pfad | Erledigt |
| `apps/server/config.py` — 5 Feature-Flags (`HYBRID_PIPELINE`, `INVOICE2DATA`, `PADDLE_OCR`, `AZURE_DI`, `QUALITAETSAUDIT`), alle default `False` | Erledigt |
| `apps/server/models/hybrid_extraktion.py` — `HybridErkennungslauf`, `HybridKandidatOrm`, `HybridKonflikt`, `HybridStatusentscheidung` | Erledigt |
| `migrations/versions/011_hybrid_invoice_extraction.py` — 4 neue Tabellen, RLS, FORCE RLS, Composite-Tenant-FKs | Erledigt |
| `tests/unit/test_hybrid_kandidat.py` — 20 Tests | Erledigt |
| `tests/unit/test_hybrid_ergebnis.py` — 13 Tests | Erledigt |
| `tests/unit/test_provider_ports.py` — 10 Tests | Erledigt |
| `tests/unit/test_feature_flags.py` — 6 Tests (Azure-Flag default False) | Erledigt |
| `tests/integration/test_hybrid_extraktion.py` — 18 Tests (Persistenz, RLS, FORCE RLS, Tenant-Isolation, alembic check) | Erledigt |
| HYB-01, HYB-02, HYB-03, HYB-04, HYB-06 | **ERFÜLLT** |
| HYB-05 (Konflikte explizit gespeichert, kein stilles Auswählen) | **ERFÜLLT** (seit Paket 07-03) — `erkenne_konflikte()` erkennt automatisch abweichende Werte zwischen mehreren Providern, `HybridKonflikt` persistiert; Pflichtfeld-Konflikte werden nie still aufgelöst |
| HYB-07 (Feature-Flags steuern Provider) | **ERFÜLLT** (Gap-Paket HYB-07) — `werte_lokale_erkennung_aus()` gatet sich selbst über `ist_hybrid_pipeline_aktiviert()`: `False` (Default) blockiert die Hybrid-Auswertung vollständig (`HybridPipelineDeaktiviertFehler`), `True` erlaubt sie; Provider-Flags (invoice2data/PaddleOCR/Azure) bleiben unabhängig und unverändert |
| HYB-08 (Auswahl-/Ablehnungsgründe auditierbar) | **ERFÜLLT** (seit Paket 07-03) — `waehle_kandidaten()` befüllt `auswahl_status`/`auswahl_grund` je Kandidat automatisch, zusätzlich zu den bereits erfüllten Statusgründen (`gruende`) |

**Paket 07-02 — Lokale Erkennungsschienen (abgeschlossen):**

| Lieferobjekt | Status |
|--------------|--------|
| `packages/core/invoice_extraction/document_classifier.py` — `DokumentKlasse` (TEXT_PDF/SCAN_PDF/SONDERFORMAT/UNBEKANNT), deterministische Schwelle | Erledigt |
| `packages/core/invoice_extraction/local_text.py` — `LocalExtractedText` (einheitliches Text-/Seitenmodell, HYB-12) | Erledigt |
| `packages/core/invoice_extraction/invoice2data_provider.py` — `Invoice2DataProvider`, nutzt bereits extrahierten pdfplumber-Text statt invoice2data-eigenem Reader; synthetisches Template `config/invoice2data_templates/synthetisch_muster_ag_v1.yml` | Erledigt |
| `packages/core/invoice_extraction/paddleocr_provider.py` — `PaddleOCRProvider`, Lazy Import, PaddleOCR nicht installiert (Fake-Engine-Tests) | Erledigt |
| `packages/core/invoice_extraction/local_provider_orchestrator.py` — `LocalInvoiceProviderOrchestrator`, wählt Provider nach Dokumentklasse+Feature-Flag, isoliert Fehler, keine finale Auswahl | Erledigt |
| `tests/unit/test_invoice_document_classifier.py`, `test_invoice2data_provider.py`, `test_paddleocr_provider.py`, `test_local_invoice_provider_orchestrator.py` — 47 neue Unit-Tests | Erledigt |
| `tests/security/test_invoice_provider_sanitization.py` — Security-Tests (keine Pfade/Volltexte/Credentials/unternehmen_id auf Provider-Ebene, kein Netzwerk) | Erledigt |
| HYB-09, HYB-10, HYB-11, HYB-12, HYB-13 | **ERFÜLLT** |

**Paket 07-03A — Audit-Booleanmodell und Qualitätsstatistik (abgeschlossen, HYB-17/18):**

| Lieferobjekt | Status |
|--------------|--------|
| `migrations/versions/012_hybrid_audit_bewertungen.py` — nullable `dokument_klasse` auf `hybrid_statusentscheidungen`, neue Tabelle `hybrid_audit_bewertungen` (append-only, RLS, FORCE RLS, Check-Constraint auf `DokumentKlasse`-Werte) | Erledigt |
| `apps/server/models/hybrid_extraktion.py` — `HybridStatusentscheidung.dokument_klasse`, neues Modell `HybridAuditBewertung` | Erledigt |
| `packages/core/invoice_extraction/hybrid_audit.py` — `AuditBewertungFelder` (6 strukturierte Booleanfelder, kein Freitext), `berechne_gesamtergebnis_korrekt()` (abgeleitet, nicht gespeichert), `waehle_neueste_bewertung()` (bewertet_am DESC, id DESC) | Erledigt |
| `packages/core/invoice_extraction/hybrid_statistik.py` — reine Gruppierungs-/Quotenlogik (Vollständigkeits-, Richtigkeits-, Automatisierungs-, Prüf-, Nichterkennungsquote; Nenner 0 → `null`), Normalisierung Anbieter/Dokumentklasse/Methode → `UNBEKANNT` | Erledigt |
| `apps/server/repositories/hybrid.py` — append-only `create_audit_bewertung`, `latest_by_statusentscheidung`, `list_statistik_zeilen` (Join Anbieter über `rechnungen.lieferant_name`, nicht `hybrid_kandidaten.vendor_name`) | Erledigt |
| `apps/server/services/hybrid_audit_service.py` — Tenant-Sicherheit (404 bei fremder Statusentscheidung), keine Freitextfelder | Erledigt |
| `apps/server/routers/hybrid.py` — `POST/GET /api/v1/hybrid/statusentscheidungen/{id}/auditbewertungen[/latest]`, `GET /api/v1/hybrid/statistik` (gruppierbar nach Anbieter/Dokumenttyp/Methode/Status) | Erledigt |
| `tests/unit/test_hybrid_audit.py`, `test_hybrid_statistik.py` — 35 Tests (inkl. Haertungstests gegen Mehrfachzaehlung bei mehreren Providern/Audits) | Erledigt |
| `tests/security/test_hybrid_audit_sanitization.py` — 10 Tests (keine Freitextfelder, kein Azure, kein Netzwerk) | Erledigt |
| `tests/integration/test_hybrid_audit_migration.py`, `test_hybrid_audit_bewertungen.py`, `test_hybrid_audit_api.py` — Migration/RLS, Append-only, Latest, Statistik, Tenant-Isolation, `dokument_klasse`-Persistenz | **Gegen `buchungatakan_test` verifiziert: 31 passed** |
| HYB-17, HYB-18 | **ERFÜLLT** — Unit/Security/Integration vollständig gegen echte Postgres-DB verifiziert |
| HYB-19, Excel, openpyxl | **Bewusst nicht Teil von 07-03A** — folgendes Paket |
| Regressionsfix `apps/server/services/hybrid_auswertung_service.py` — Idempotenzpruefung in `persistiere_hybrid_auswertung()` nur noch bei gesetzter `erkennungslauf_id`; PostgreSQL behandelt NULL in `UNIQUE(unternehmen_id, erkennungslauf_id)` als paarweise verschieden, mehrere `erkennungslauf_id=NULL`-Zeilen sind DB-seitig zulaessig — ohne `erkennungslauf_id` daher kein globaler Idempotenzschluessel, jeder Aufruf ist ein eigenstaendiger Lauf | Erledigt, `tests/integration/test_hybrid_auswertung_persistenz.py`: **6 passed** |
| Vollstaendige Suite mit `buchungatakan_test` | **1013 passed, 1 skipped (test_rls.py, separate `APP_DATABASE_URL` mit `buchungatakan_app` erforderlich), 0 failed** |

**Paket 07-04 — Azure-Adapter vorbereitet, aber deaktiviert (HYB-20..24):**

| Lieferobjekt | Status |
|--------------|--------|
| `apps/server/config.py` — kanonisches Flag `BUCHUNG_ATAKAN_FEATURE_AZURE_DOCUMENT_INTELLIGENCE` (default `false`); Legacy-Flag `BUCHUNG_ATAKAN_FEATURE_AZURE_DI` (07-01) bleibt inert, aktiviert nichts | Erledigt |
| `packages/core/invoice_extraction/azure_document_intelligence_provider.py` — `AzureDocumentIntelligenceClient` (Protocol, kein SDK), `AzureAnalyseErgebnis`/`AzureFeldErgebnis` (synthetische Dataclasses), `AzureDocumentIntelligenceProvider` (implementiert `CloudInvoiceProvider`, fail-closed), `FakeAzureDocumentIntelligenceClient`, `erstelle_provider()` (Factory, ruft `client_factory` nie bei deaktiviertem Flag auf) | Erledigt |
| `packages/core/invoice_extraction/hybrid_qualitaetsentscheidung.py` — Azure-only-Statusguard: Pflichtfelder ausschließlich von Azure bestätigt → höchstens `MUSS_GEPRUEFT_WERDEN`, nie `OK` | Erledigt |
| `packages/core/invoice_extraction/provider_ports.py` — `CloudInvoiceProvider`-Docstring auf konkrete Implementierung aktualisiert | Erledigt |
| `tests/unit/test_azure_document_intelligence_provider.py` — 17 Tests (Flag/Factory, Fake-Client-Mapping, Determinismus, Feldbegrenzung, fail-closed, sanitisierte Fehlercodes) | Erledigt |
| `tests/security/test_azure_document_intelligence_sanitization.py` — 11 Tests (kein SDK-Import, kein `DocumentAnalysisClient`/`AzureKeyCredential`, keine Secrets/Endpunkte, `.env.example` unverändert) | Erledigt |
| `tests/unit/test_hybrid_qualitaetsentscheidung.py` — 3 neue Tests für Azure-only-Guard (Azure-only → `MUSS_GEPRUEFT_WERDEN`, Mischfall mit lokalem Kandidat → `OK` möglich, Guard eskaliert nicht zu `NICHT_GEFUNDEN`) | Erledigt |
| `tests/unit/test_feature_flags.py` — 3 neue Tests (kanonisches Flag default `false`/aktivierbar, Legacy-Flag-Entkopplung) | Erledigt |
| `tests/security/test_hybrid_auswertung_sanitization.py` — Azure-Ausnahme für `hybrid_qualitaetsentscheidung.py` präzisiert (2 neue Tests: kein SDK-Import, kein Client im Statusmodul) | Erledigt |
| Kein Azure-SDK, kein Netzwerkimport, keine Credentials, kein `.env.example`-Zuwachs | Verifiziert (Security-Tests) |
| Unit+Security gesamt (ohne TEST_DATABASE_URL) | **845 passed, 4 skipped, 0 failed** (+36 gegenüber Paket 07-03B) |
| Gezielte Azure-/Feature-Flag-/Status-/Security-Tests (buchungatakan_test) | **Gegen echte Postgres-DB verifiziert: 61 passed** |
| Vollständige Suite mit `buchungatakan_test` | **1078 passed, 1 skipped (test_rls.py, separate `APP_DATABASE_URL` mit `buchungatakan_app` erforderlich), 0 failed** |
| HYB-20..24 | **ERFÜLLT** — Unit/Security/vollständige Suite gegen echte Postgres-DB verifiziert |

**Verifiziert (nicht privilegierte Testrolle):**
- Tenant-Isolation (HY05) mit `buchungatakan_migrations` (kein Superuser, kein BYPASSRLS) bestätigt — eine Superuser-Verbindung würde RLS grundsätzlich umgehen (P-10-Verhalten) und falsch-positive Ergebnisse liefern.
- EC-Tie-Breaker-Fix (Phase-6-Regression, siehe unten) mit 8 isolierten Wiederholungsläufen stabil grün.
- Gesamt-Teststand Paket 07-01 mit `buchungatakan_test`, zweifach reproduziert: 810 passed, 1 skipped (P-10), 0 failed.
- **Gesamt-Teststand Paket 07-02 mit `buchungatakan_test` (TEST_DATABASE_URL, vollständiger Lauf inkl. Integrationstests): 869 passed, 1 skipped (P-10, bekannt), 0 failed.**

**Phase-6-Regressionsfix im Zuge von Paket 07-01 gefunden und behoben:**
- `packages/core/ec_sammlung/gruppierung.py` — Sortierschlüssel um `betrag_cent` erweitert. Bei zwei Belegen mit identischem Buchungsdatum entschied bisher eine zufällige UUID über die Entfernungsreihenfolge; das konnte den exakt passenden Beleg statt des zu großen entfernen. Keine Migration geändert, Fachregel nicht abgeschwächt.

**Sicherheitsregeln (eingehalten):**
- Keine echten Rechnungen, kein Realtest, kein Push, kein Gmail, keine UI
- invoice2data (Paket 07-02) läuft ausschließlich lokal auf bereits extrahiertem Text, keine Cloud
- PaddleOCR (Paket 07-02) ist nicht installiert; Adapter vollständig implementiert (Lazy Import), kein Netzwerk, kein Cloud-Fallback
- Kein Azure-Adapter/SDK implementiert; `BUCHUNG_ATAKAN_FEATURE_AZURE_DI` default `False` — kein Azure-Aufruf, keine Credentials
- `fehlercode` in `InvoiceProviderResult` sanitisiert: nur Fehlertyp, kein Volltext, kein Dateiname
- `bbox` enthält keine sensiblen Inhalte; `gruende_json` kein Originaltext

**Gap-Paket HYB-07 — Hybridpipeline-Flag-Gate (abgeschlossen):**

| Lieferobjekt | Status |
|--------------|--------|
| `packages/core/invoice_extraction/hybrid_auswertung.py` — `werte_lokale_erkennung_aus()` gatet sich selbst über `ist_hybrid_pipeline_aktiviert()`: bei `BUCHUNG_ATAKAN_FEATURE_HYBRID_PIPELINE=False` (Default) wirft die Funktion vor jeder Normalisierungs-/Konflikt-/Auswahl-/Statuslogik `HybridPipelineDeaktiviertFehler`; bei `True` läuft die Auswertung wie zuvor | Erledigt |
| `packages/core/invoice_extraction/hybrid_auswertung.py` — neue Exception `HybridPipelineDeaktiviertFehler(RuntimeError)`, exportiert über `packages/core/invoice_extraction/__init__.py` | Erledigt |
| Keine Änderung an Providerimplementierungen, Routern, Services, `local_provider_orchestrator.py` oder bestehenden Provider-Flags (invoice2data/PaddleOCR/Azure) | Verifiziert |
| `tests/unit/test_hybrid_auswertung.py` — 10 neue Tests: Default/explizit `false` blockiert, `true` erlaubt, Mock-Beweis gegen nachgelagerte Auswertungslogik (`normalisiere_kandidat`/`erkenne_konflikte`/`waehle_kandidaten`/`berechne_finalen_status`), AST-Strukturbeleg (Gate ist erste Anweisung), Unabhängigkeit des Pipeline-Flags von Provider-Flags (invoice2data/PaddleOCR/Azure je separat geprüft), kein Aufruf von Provider-`ist_aktiviert()`-Funktionen durch das Pipeline-Gate | Erledigt |
| Bestehende Flag-Tests (`test_feature_flags.py`, `test_local_invoice_provider_orchestrator.py`, Azure-Flag-/Sanitization-Tests) | Unverändert grün |
| Unit+Security gesamt (ohne TEST_DATABASE_URL) | **855 passed, 4 skipped, 0 failed** |
| Vollständige Suite mit `TEST_DATABASE_URL` + `APP_DATABASE_URL` gegen `buchungatakan_test` | **1088 passed, 1 skipped (P-10), 0 failed** (81,45 s) |
| HYB-07 | **ERFÜLLT** |

**Sicherheitsregeln (eingehalten, Gap-Paket HYB-07):**
- Das Pipeline-Flag aktiviert keinen Provider, löst keine Netzwerkzugriffe aus, lädt keine Credentials
- invoice2data-, PaddleOCR- und Azure-Flag-Logik unverändert und unabhängig vom Pipeline-Flag (separat getestet)
- `test_hybrid_auswertung_sanitization.py` (Azure-/Netzwerk-Freiheit von `hybrid_auswertung.py`) bleibt unverändert grün

**Gap-Paket Testinfrastruktur — App-Rollen-Fixtures für echte RLS-Isolationstests (abgeschlossen):**

Befund: die drei Tenant-Isolationstests für Phase 7 liefen über `TEST_DATABASE_URL`/`db_session` bzw. `sync_engine` — verbindet diese URL als Superuser (z. B. `postgres`), bypassed PostgreSQL RLS grundsätzlich, auch mit FORCE ROW LEVEL SECURITY. Die scharfen Assertions „Tenant B sieht Tenant A nicht" waren unter dieser Rolle nicht belastbar.

| Lieferobjekt | Status |
|--------------|--------|
| `tests/conftest.py` — `APP_DB_URL`, `_validate_app_db_url()` (P-10-Skip ohne `APP_DATABASE_URL`; Namensguard exakt `buchungatakan_test`; lehnt `APP_DATABASE_URL` ab, wenn identisch mit `TEST_DATABASE_URL`), `_pruefe_rolle_nicht_privilegiert()` (Laufzeitprüfung gegen `pg_roles.rolsuper`/`rolbypassrls`, harter Fail bei privilegierter Rolle statt falsch-grün), Fixtures `app_role_sync_engine`, `app_role_async_engine`, `app_role_session` | Erledigt |
| `tests/integration/test_hybrid_extraktion.py::test_tenant_isolation_hybrid_erkennungslaeufe` — auf `app_role_sync_engine` umgestellt | Erledigt |
| `tests/integration/test_hybrid_auswertung_persistenz.py::test_tenant_isolation` — auf `app_role_session` umgestellt | Erledigt |
| `tests/integration/test_hybrid_audit_bewertungen.py::test_haba_tenant_b_sieht_bewertungen_von_tenant_a_nicht` — auf `app_role_session` umgestellt | Erledigt |
| `tests/integration/test_rls.py` — Skip-Begründung präzisiert: `test_rls_blocks_benutzer_without_tenant_context` bleibt **dauerhafter** Skip auch mit `APP_DATABASE_URL`, weil `buchungatakan_app` laut Migration 003 keinen Direktzugriff auf `benutzer` hat (REVOKE ALL, Auth nur über SECURITY-DEFINER-Funktionen) — eine direkte Query schlägt mit `permission denied` fehl, das wäre kein RLS-Nachweis | Erledigt (Dokumentation, keine Verhaltensänderung) |
| Scharfe Assertions unverändert beibehalten (`assert row is None`) — keine Umwandlung in tolerante Datenintegritätstests | Verifiziert |
| Keine RLS-Policy-Änderung, keine Migrationsänderung, keine neue Rolle/Datenbank, kein Passwort gesetzt | Verifiziert |
| Gesamt-Teststand mit `TEST_DATABASE_URL` + `APP_DATABASE_URL` (Nutzerlauf) | **1088 passed, 1 skipped (P-10), 0 failed**, 81,45 s — die drei Tenant-Isolationstests liefen scharf über die App-Rolle |

**Offener manueller Schritt (P-09, unverändert, nicht von mir ausgeführt):** `buchungatakan_app` wird von `apply_migrations` bereits automatisch angelegt (`CREATE ROLE ... LOGIN`, ohne Passwort) — ein Passwort für diese Rolle muss weiterhin einmalig durch den DB-Admin gesetzt werden, damit `APP_DATABASE_URL` sich damit authentifizieren kann. Mögliche Doku-Inkonsistenz: `docs/OPEN_POINTS.md` P-09 beschreibt die Rollenanlage als rein manuellen Schritt, tatsächlich legt `apply_migrations` die Rolle (ohne Passwort) bereits automatisch an — nur das Passwort bleibt manuell.

**Phase 7: formal abnahmefähig** (Commit `cd81fbd`) — HYB-01..24 einzeln ERFÜLLT, vollständige Suite inkl. echtem Non-Superuser-RLS-Nachweis grün (1088 passed/1 skip/0 failed), verbleibender Skip ist der dokumentierte P-10-Sonderfall (kein Blocker).

**Paket 07-06-PRE-REALTEST-QUALITAETSHAERTUNG (nach der Phase-7-Abnahme, abgeschlossen):**

Ausgelöst durch einen Read-only-Audit von Phase 7. Härtet die lokale Erkennung vor dem 100-Rechnungen-Realtest — ändert nichts am Phase-7-Abnahmestatus.

| Lieferobjekt | Status |
|--------------|--------|
| `packages/core/invoice_extraction/betrag_utils.py` (neu) — zentrale `bereinige_betrag_string()`, behebt Faktor-1000-Bug (`"1.000"` wurde als `1.00` gelesen); von `invoice_parser.py` und `hybrid_normalisierung.py` gemeinsam genutzt, keine private Parser-Methode mehr aus Hybrid-Code aufgerufen | Erledigt |
| `packages/core/invoice_extraction/invoice_parser.py`, `hybrid_plausibilitaet.py` — Kalendervalidierung per `datetime.date(...)`; unmögliche Daten (`31.02.`, `29.02.` Nicht-Schaltjahr) führen nicht mehr zu OK | Erledigt |
| `packages/core/invoice_extraction/hybrid_auswertung.py` — Währungskonsistenzprüfung berücksichtigt jetzt alle normalisierten Currency-Kandidaten statt nur den Auswahl-Gewinner; ein EUR/USD-Widerspruch blockiert OK nachweislich | Erledigt |
| `tests/unit/test_hybrid_plausibilitaet.py` (neu, 33 Tests), `test_hybrid_normalisierung.py` (+12), `test_hybrid_auswertung_anti_false_ok.py` (neu, 10 Tests) | Erledigt |
| Unit+Security gesamt | **910 passed, 4 skipped, 0 failed** (vorher 855 — 55 neue Tests) |
| Volle Suite ohne DB | **911 passed, 233 skipped, 0 failed** |
| InvoiceParser-Regression (golden/adapter/extraction-result) | **38 passed** |

**Nicht geändert (für Realtest-Auswertung zurückgestellt):** Netto-/Steuer-Pflichtlogik, automatisches OK bei aufgelösten Mehrheitskonflikten, Confidence-Kalibrierung, Schwellenwerte, Azure-Aktivierung, PaddleOCR-Konfiguration, alte Status-Engine, Architektur.

**Realtest-Vorgaben (dokumentiert):** `invoice2data` bewusst per Flag aktivieren (sonst keine Mehrprovider-Daten für Konflikterkennung); PaddleOCR nur mit lokal gecachten Modellgewichten und nachgewiesenem No-Network; jeder Lauf mit stabiler `erkennungslauf_id` (sonst keine Idempotenz, Statistik verfälscht durch Doppelverarbeitung).

**Urteil: BEREIT FÜR KONTROLLIERTEN REALTEST.**

---

### Phase-5-Status: Abgeschlossen — v0.5.0 (Integrationstests grün)

**Branch:** `phase/05-bankimport-allgemeines-matching`

| Lieferobjekt | Status |
|--------------|--------|
| `apps/server/models/bankbuchung.py` — Bankkonto, Kontoauszugsimport, Bankbuchung (betrag_cent INTEGER), BuchungsKlassifikation | Erledigt |
| `apps/server/models/zuordnung.py` — ZuordnungsVorschlag, Partial Unique Index (BANK-05), manuelle Entscheidungsfelder | Erledigt |
| `packages/core/matching/` — signale.py, scorer.py (erklärbarer Score, positive+negative Signale) | Erledigt |
| `apps/server/repositories/zuordnung.py` — upsert (ON CONFLICT WHERE), bestaetigen, ablehnen, Hilfsabfragen | Erledigt |
| `apps/server/services/matching_service.py` — rematch mit BANK-06/07-Schutz | Erledigt |
| `apps/server/routers/bankbuchungen.py` — Bankkonto, Import, Liste | Erledigt |
| `apps/server/routers/zuordnungen.py` — rematch, Liste, bestaetigen, ablehnen | Erledigt |
| `migrations/versions/006_bankbuchungen.py` — bankkonten, kontoauszugsimporte, bankbuchungen + RLS | Erledigt, applied (buchungatakan_test) |
| `migrations/versions/007_zuordnungen.py` — zuordnungsvorschlaege + UNIQUE + RLS | Erledigt, applied (buchungatakan_test) |
| `migrations/versions/008_zuordnung_entscheidungen.py` — Entscheidungsfelder + FK + Partial Unique Index | Erledigt, applied (buchungatakan_test) |
| Unit-Tests + Security-Tests | **359 passed**, 0 failed |
| Integrationstests | **73 passed**, 1 skipped (P-10), 0 failed |
| BANK-01..11 | Alle erfüllt und integrationsgetestet |

**Commits (Phase 5, Paket 3):** `4af9095` `024f7af` `933aada`

**Nächster Schritt:** Kontrollierter Realtest mit lokalen Testdateien (separater Realtest-Ordner), dann Phase 6 (EC-Sammelzuordnung).

**Offene Phase-5-Punkte (kein Blocker für Folgephasen):**
- P-10: App-Role-RLS-Test (unverändert aus Phase 4).
- P-12: RECH-10 AuditLog (unverändert aus Phase 4).

---

### Phase-4-Status: Abgeschlossen — v0.4.0 (Integrationstests grün)

**Branch:** `phase/04-rechnungsimport-extraktion-validierung`

| Lieferobjekt | Status |
|--------------|--------|
| `packages/core/invoice_extraction/` — Kandidat, ExtractionResult, InvoiceParser, InvoiceParserAdapter, InvoiceValidator, PDFReader, Ports | Erledigt |
| `apps/server/models/rechnung.py` — Rechnung, Erkennungslauf, RechnungsKandidat, RechnungsStatus | Erledigt |
| `migrations/versions/005_rechnungen.py` — rechnungen, erkennungslaeufe, rechnungs_kandidaten + GRANT + FORCE RLS | Erledigt, applied (buchungatakan_test) |
| `apps/server/repositories/rechnung.py` — Versionierungslogik RECH-08/09, mandantensichere Abfragen | Erledigt |
| `apps/server/routers/rechnungen.py` — POST, GET Liste, GET Detail, GET Erkennungsläufe, GET Kandidaten | Erledigt |
| Auth/RLS-Härtung — SECURITY DEFINER-Auth-Funktionen, RLSSession, CurrentTenantId | Erledigt |
| Produktivfix `5eff878` — `session.refresh()` nach `session.commit()` in `session.begin()`-Kontext entfernt | Erledigt |
| Unit-Tests + Security-Tests | 253 passed, 0 failed |
| Integrationstests | 25 passed, 1 skip (P-10), 0 failed |
| RECH-01..06, RECH-08, RECH-09, RECH-11 | Erfüllt und getestet |
| RECH-07 (widersprüchliche Mehrfachsignale) | Teilweise — nur ein starkes Signalfeld vorhanden |
| RECH-10 (AuditLog manueller Korrekturen) | Bewusst verschoben — kein Korrektur-Endpunkt in Phase 4 |

**Letzte Commits (Phase 4):**
- `5eff878` test(04): Rechnungs-API unter PostgreSQL und RLS absichern
- `0a94699` test(04): Integrations-Testdaten und DB-Fixtures stabilisieren
- `8e1de08` fix(04): Auth-Lookups und RLS tenant-sicher machen
- `325b69e` feat(04): Rechnungs-Router und Mandantenguards
- `5f10289` feat(04): Rechnungs-Repository mit Versionierungslogik
- `6a3372d` fix(04): Parser- und Validierungs-Härtung
- `1b1a8f5` feat(04): Rechnungs-Extraktionskern und Modelle

**Nächster Schritt:** Nutzerfreigabe Phase 4 → Phase 5 (Bankimport und Rechnungs-Matching).

**Offene Phase-4-Punkte (kein Blocker für Folgephasen):**
- RECH-10: AuditLog erst wenn manueller Korrektur-/Freigabe-Endpunkt existiert.
- RECH-07: Vollständig wenn weitere Signalfelder (USt-ID, IBAN) ergänzt werden.
- P-10: App-Role-RLS-Test mit separater `buchungatakan_app`-Verbindung (APP_DATABASE_URL).

---

### Phase-3-Status: Implementiert (Migrations- und Integrationstests abgedeckt durch Phase-4-Tests)

**Branch:** `phase/04-rechnungsimport-extraktion-validierung` (kumulativ)

| Lieferobjekt | Status |
|--------------|--------|
| `packages/core/` — PathConfig, HashUtils, MimeUtils, DocumentLocator | Erledigt |
| `apps/client/` — ClientConfig, DocumentScanner, DokumentOutbox, ApiClient, SyncService | Erledigt |
| `apps/server/models/dokument.py` | Erledigt |
| `apps/server/routers/installationen.py`, `dokumente.py` | Erledigt |
| `migrations/versions/004_documents_table.py` | Erledigt, applied (buchungatakan_test) |
| Unit-Tests CLI-01..10 | Erledigt (Teil der 253 grünen Unit-Tests) |

---

### Phase-2-Status: Implementiert und integrationsgetestet

**Branch:** `phase/04-rechnungsimport-extraktion-validierung` (kumulativ)

| Lieferobjekt | Status |
|--------------|--------|
| ORM-Modelle (`apps/server/models/`) | Erledigt |
| Alembic 001 Initial-Schema | Erledigt, applied |
| Alembic 002 Seed-Daten | Erledigt, applied |
| Alembic 003 RLS-Policies | Erledigt, applied |
| Auth-Schicht (service, schemas, deps, router) | Erledigt |
| Repositories (base, benutzer, unternehmen) | Erledigt |
| Endpunkte: /health, /api/v1/auth/login, /api/v1/unternehmen/me | Erledigt |
| Exception-Handler (SRV-08) | Erledigt |
| Integrationstests (Auth, Migrationen, Tenant-Isolation, RLS) | 25 passed (kumulativ mit Phase-4-Tests) |

---

### Phase-0-Status: Abgeschlossen

Alle Phase-0-Lieferobjekte erstellt und abgenommen:

| Lieferobjekt | Status |
|--------------|--------|
| `docs/phase0/BESTANDSAUFNAHME.md` | Erledigt (2026-06-26) |
| `docs/phase0/MODULKLASSIFIKATION.md` | Erledigt (2026-06-26) |
| `docs/phase0/MIGRATIONSPLAN.md` | Erledigt (2026-06-26) |
| `docs/phase0/API_GROBVERTRAG.md` | Erledigt (2026-06-26) |
| `docs/phase0/BASELINE_TESTS.md` | Erledigt (2026-06-26) — 162/162 Tests grün |
| `docs/phase0/AKZEPTANZKRITERIEN.md` | Erledigt (2026-06-26) — 10 ERFÜLLT, 1 NICHT GETESTET |

Akzeptanzkriterien ARCH-01..10: alle **ERFÜLLT**.
ARCH-11 (Nutzerfreigabe): **ERTEILT** (2026-06-27).

---

### Migrations-Gesamtstand (buchungatakan_realtest)

| Nr. | Migration | Status |
|-----|-----------|--------|
| 001 | Initial Schema | Applied |
| 002 | Seed-Testdaten | Applied |
| 003 | RLS-Policies | Applied |
| 004 | Dokumente-Tabelle | Applied |
| 005 | Rechnungen (rechnungen, erkennungslaeufe, rechnungs_kandidaten) | Applied |
| 006 | Bankbuchungen (bankkonten, kontoauszugsimporte, bankbuchungen) | Applied |
| 007 | Zuordnungsvorschlaege (zuordnungsvorschlaege) | Applied |
| 008 | Zuordnungsentscheidungen (entschieden_at, FK, Partial Unique Index) | Applied |
| 009 | MT940-Import (kontoauszugsimport-Erweiterungen) | Applied |
| 010 | EC-Sammelzuordnung (ec_belege, ec_sammellaeufe, ec_sammelzuordnungen, ec_sammelzuordnung_belege) | Applied |

---

## B. Altprojekt-Reife (Referenz)

Quelle: `C:\Users\User\PycharmProjects\BuchungAtakan` (Einzelmandant, lokale SQLite, Desktop).

**Umgesetzt und getestet:**
- Rechnungs-PDF-Erkennung/-Extraktion/-Import/-Ablage, Duplikat-/Versionsregel.
- Dokumentinventar gemischter Monatsarchive (`files`) mit Klassifikation.
- Kontoauszugsimport + Bankbuchungen; Matching mit sicheren/unsicheren Fällen; manuelle Prüfung.
- `NICHT_ZU_MATCHEN` für Bankbuchungen.
- EC-/Telexpert-Sammelzuordnung (dynamische Zeitfenster, Centwerte, Belegsperre, Protokoll,
  Blatt `EC-Sammel`).
- Gmail-Mehrpostfachbetrieb, Raw-PDF-Ablage mit Dedup, **Gmail-Nachsuche** für offene
  Bankbuchungen, überlappende Scan-Intervalle.
- Frei wählbare Datenwurzel + relative Pfade; DATA_ROOT-Sicherheits-Guards.
- Excel-Bericht mit Übersicht/Status-Blättern; Erst- und Inkrementellbetrieb mit gemeinsamen
  Kernmodulen; Processing State.
- Reproduzierbare synthetische Testbasis. **Zuletzt 162 Pytests grün** (Stand 2026-06-24).

**Im Altprojekt offen / später:**
- GUI/Bedienoberfläche, Zeitsteuerung/Scheduler.
- Umfassende Parseroptimierung (Spätarbeit).
- Optionale KI-Hilfe.

**Dokumentierte Altbefunde / Einschränkungen:**
- Erkannte Kontoauszugs-PDFs erzeugten zuletzt **keine** Bankbuchungen (Parsergrenze).
- Keine echte Gmail-API/OAuth in Tests (nur Fakes/temporäre DBs/synthetische Nachrichten);
  operativer Mehrpostfachlauf mit echten Credentials separat freizugeben.

---

## C. Architekturwechsel (A gegenüber B)

| Thema | Altprojekt (B) | Neu, maßgeblich (A) |
|---|---|---|
| Datenbank | SQLite, lokal | PostgreSQL, zentral |
| Zugriff | direkter DB-Zugriff | nur über FastAPI-API |
| Mandanten | Einzelbetrieb | Multi-Tenant (`unternehmen_id`) |
| Dokumente | zentrale UNC-Ablage geplant | bleiben lokal, zentral nur Metadaten |
| GUI | offen | PySide6 |

Details und offene Entscheidungen: `docs/OPEN_POINTS.md`.
