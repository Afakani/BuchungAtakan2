# BuchungAtakan – verbindlicher Entwicklungsplan für Claude

**Version:** 1.0  
**Zweck:** Technischer Entwicklungsplan für die schrittweise Weiterentwicklung des bestehenden Projekts BuchungAtakan.  
**Status:** Planungsgrundlage; jede Phase wird einzeln umgesetzt und vom Nutzer freigegeben.

---

## 1. Verbindliches Zielbild

BuchungAtakan ist ein modular erweiterbares Python-System für:

- lokalen Import und lokale Aufbewahrung von Rechnungen und sonstigen Originaldokumenten,
- lokale Extraktion von Rechnungsdaten,
- zentrale Speicherung strukturierter Daten,
- Import von Bankbewegungen,
- Zuordnung von Rechnungen und Bankbewegungen,
- EC-/Telexpert-Sammelzuordnungen,
- Gmail-Import und Gmail-Nachsuche,
- manuelle Prüfung unsicherer Fälle,
- Excel- und Datenexporte.

Das System soll zuerst den operativen Arbeitsablauf zuverlässig abbilden. DATEV, GoBD-orientierte Zusatzfunktionen, WORM-Speicherung, erweiterte Verfahrensdokumentation und ähnliche Compliance-Erweiterungen sind **nicht Bestandteil des Kern-MVP**. Sie werden als optionale, später nachrüstbare Module vorbereitet.

---

## 2. Verbindliche Betriebsarchitektur

### 2.1 Lokale Installation je Unternehmen

Jedes Unternehmen installiert einen lokalen BuchungAtakan-Client auf mindestens einem Windows-Rechner.

Der lokale Client ist verantwortlich für:

- Auswahl und Verwaltung einer lokalen `DATA_ROOT`,
- lokale Speicherung der Original-PDFs, Kontoauszüge, EC-Belege und Gmail-Anhänge,
- lokale Textextraktion und OCR,
- lokale Öffnung von Dokumenten,
- lokale Gmail-Zugangsdaten und OAuth-Tokens,
- lokalen Import- und Synchronisationspuffer,
- lokale technische Logs ohne sensible Vollinhalte.

### 2.2 Zentrale Plattform in Aachen

Auf dem Server in Aachen laufen:

- eine zentrale, versionierte HTTP-API,
- eine zentrale PostgreSQL-Datenbank,
- serverseitige Authentifizierung und Autorisierung,
- Mandantentrennung,
- zentrale Speicherung strukturierter Rechnungs-, Bank- und Zuordnungsdaten,
- zentrale Jobs, Statusinformationen und technische Audit-Ereignisse,
- zentrale Matching- und EC-Fachlogik, soweit sie keine Originaldatei benötigt.

Lokale Clients erhalten **keinen direkten PostgreSQL-Zugriff**. Jeder Zugriff erfolgt ausschließlich über die authentifizierte API.

### 2.3 Mandantentrennung

Jedes Unternehmen erhält eine unveränderliche UUID `unternehmen_id`.

Für jede mandantengebundene Tabelle gilt:

- `unternehmen_id` ist Pflichtfeld,
- die API ermittelt die zulässige `unternehmen_id` aus der authentifizierten Sitzung,
- ein Client darf durch Übermitteln einer anderen `unternehmen_id` niemals Zugriff erhalten,
- jede Repository-/Service-Abfrage erzwingt den Mandantenfilter,
- PostgreSQL Row Level Security soll als zusätzliche Schutzschicht vorgesehen werden,
- Cross-Tenant-Tests sind für alle kritischen Endpunkte verpflichtend.

### 2.4 Lokale Dokumente und zentrale Metadaten

Originaldateien werden standardmäßig **nicht auf den Server hochgeladen**. Diese aktuelle Entscheidung ersetzt ältere Planungsstände, in denen eine zentrale Windows-/UNC-Ablage der Original-PDFs vorgesehen war. Claude muss die widersprechenden Stellen in `AGENTS.md`, `CURRENT_STATUS.md`, `OPEN_POINTS.md` und weiteren Projektdokumenten in Phase 0 ausdrücklich kennzeichnen und nach Freigabe konsistent aktualisieren.

Die zentrale Datenbank speichert nur:

- `unternehmen_id`,
- `installation_id`,
- relativen Pfad innerhalb der lokalen `DATA_ROOT`,
- SHA-256-Hash,
- Dateigröße,
- MIME-Typ,
- Dokumenttyp,
- Importquelle,
- Verfügbarkeitsstatus,
- extrahierte Kandidaten und freigegebene Fachdaten.

Absolute lokale Pfade dürfen nicht zentral gespeichert werden. Der lokale Client bildet den vollständigen Pfad ausschließlich aus:

```text
lokale DATA_ROOT + relativer Dokumentpfad
```

Dokumente eines Unternehmens sind nur auf einer zugehörigen Installation direkt öffnbar. Ein späteres optionales Modul darf verschlüsselte Dokumentreplikation oder zentralen Dokumentzugriff ergänzen, ohne das Kernmodell zu verändern.

---

## 3. Technologischer Zielrahmen

### Zentrale Serverkomponenten

- Python 3.12+
- FastAPI als zentrale HTTP-API
- PostgreSQL als zentrale Produktivdatenbank
- SQLAlchemy 2.x oder vergleichbare Repository-Schicht
- Alembic oder ein gleichwertiges migrationsbasiertes Schema-Management
- Pydantic für API-Schemas und Validierung
- strukturierte JSON-Logs

### Lokaler Windows-Client

- Python 3.12+
- bestehende BuchungAtakan-Fachmodule soweit fachlich korrekt wiederverwenden
- `pathlib.Path` für alle lokalen Pfade
- lokale Konfigurationsdatei plus Umgebungsvariablen
- Windows Credential Manager oder gleichwertiger Secret Store für Tokens und Schlüssel
- HTTP-Client mit Timeout, Retry-Regeln und Offline-Warteschlange
- später als Windows-Anwendung/EXE paketierbar

### Tests

- `pytest`
- Unit-Tests für Fachlogik
- PostgreSQL-Integrationstests für Datenbank-, Migrations- und Mandantenverhalten
- temporäre lokale Datenwurzeln für Dateisystemtests
- Fake-Gmail und synthetische Dokumente
- keine echten Belege in Git oder automatisierten Tests

---

## 4. Entwicklungsregeln für Claude

Claude muss bei jedem Entwicklungsblock folgende Regeln einhalten:

1. Zuerst `AGENTS.md` sowie alle unmittelbar betroffenen Dateien vollständig lesen.
2. Bestehende funktionierende Fachlogik nicht stillschweigend ersetzen.
3. Bestehende Module für EC, Gmail, Import, Matching, Pfadkonfiguration und Tests wiederverwenden, sofern ein Regressionstest keinen Fehler nachweist.
4. Änderungen klein, migrationsfähig und nachvollziehbar halten.
5. Keine produktiven Daten löschen oder zurücksetzen.
6. Datenbankänderungen ausschließlich über additive Migrationen durchführen.
7. Test-Resets nur mit sichtbarer TEST-Kennzeichnung, Pfadanzeige und Sicherheitsbestätigung.
8. Jede Phase in einem eigenen Branch oder klar abgegrenzten Commit umsetzen.
9. Nach jeder Phase mindestens aktualisieren:
   - `CURRENT_STATUS.md`
   - `IMPLEMENTATION_HISTORY.md`
   - `TEST_HISTORY.md`
   - `OPEN_POINTS.md`
   - `CHANGELOG.md`
10. Vollständige geänderte Dateien bereitstellen, nicht nur unzusammenhängende Fragmente.
11. Keine automatische Fortsetzung in die nächste Phase. Nach Erfüllung der Akzeptanzkriterien stoppen und auf Freigabe warten.
12. Keine DATEV- oder GoBD-Konformität behaupten. Optionale Funktionen ausdrücklich als „GoBD-orientiert“ oder „DATEV-Export optional“ kennzeichnen.

---

## 5. Erweiterbare Modularchitektur

Die Fachlogik wird durch klar definierte Ports und Adapter entkoppelt.

Mindestens folgende Erweiterungspunkte sind vorzusehen:

- `DocumentStoragePort` – lokaler Speicher; später optional Server-/Cloudspeicher
- `InvoiceExtractionPort` – PDF-Text, OCR, E-Rechnung, später weitere Parser
- `BankStatementParserPort` – CAMT, MT940, CSV, PDF und weitere Formate
- `MailProviderPort` – Gmail, später weitere Postfächer
- `MatchingStrategyPort` – Standard-Matching, EC-Matching, spätere Sonderstrategien
- `ExportProviderPort` – Excel/CSV/JSON; später optional DATEV
- `NotificationPort` – lokale Meldung, E-Mail oder spätere Push-Benachrichtigung
- `OptionalCompliancePort` – spätere GoBD-orientierte Zusatzfunktionen
- `AIServicePort` – spätere optionale KI-Unterstützung für schwierige Fälle

Kernmodule dürfen keine Anbieter-spezifischen Aufrufe direkt enthalten. Anbieter werden über Adapter angebunden und über Konfiguration beziehungsweise Feature Flags aktiviert.

---

# 6. Entwicklungsphasen

## Phase 0 – Bestandsaufnahme, Architektur-Freeze und Migrationsplan

### Ziel

Den bestehenden Projektstand sichern, vorhandene Funktionen inventarisieren und den Übergang von einer lokalen Einzel-Datenbank zur neuen Client-Server-Architektur planen, ohne funktionierende Logik zu verlieren.

### Umsetzung

- vollständige Bestandsaufnahme von Quellcode, Datenmodell, Pipelines, Tests und Dokumentation,
- Zuordnung bestehender Module zu „lokaler Client“, „zentrale API“ und „gemeinsame Fachbibliothek“,
- Identifikation aller direkten SQLite-/DB-Zugriffe,
- Identifikation aller absoluten oder zentral angenommenen Dokumentpfade,
- Entscheidung über GUI-Technologie, ohne Fachlogik an die GUI zu koppeln,
- Definition der zentralen API-Versionierung,
- Definition der `unternehmen_id` und `installation_id`,
- Migrationsstrategie für bestehende Testdaten und vorhandene Module,
- Festlegung eines Feature-Flag-Systems für optionale Erweiterungen.

### Lieferobjekte

- Architekturentscheidung „lokale Clients + zentrale API/PostgreSQL + lokale Dokumente“,
- Modul- und Abhängigkeitskarte,
- Datenmigrationsplan,
- API-Grobvertrag,
- Liste wiederzuverwendender Module,
- priorisierte technische Schulden.

### Akzeptanzkriterien

- Der bestehende Teststand wurde unverändert ausgeführt und dokumentiert.
- Kein Produktivcode oder Datenbestand wurde in Phase 0 destruktiv verändert.
- Jedes bestehende Hauptmodul ist eindeutig Client, Server oder Shared Core zugeordnet.
- Alle direkten Datenbankzugriffe und alle Dokumentpfadannahmen sind inventarisiert.
- Für jede bestehende Tabelle ist dokumentiert, ob sie zentral, lokal oder abzulösen ist.
- `unternehmen_id`, `installation_id` und Dokument-Lokator sind formal definiert.
- Ein schriftlicher Migrationspfad von der bestehenden Architektur zur Zielarchitektur liegt vor.
- Der Nutzer hat die Architektur und die Reihenfolge der Folgephasen freigegeben.

---

## Phase 1 – Zentrale API, PostgreSQL und Mandantensicherheit

### Ziel

Eine zentrale, getestete Serverbasis in Aachen schaffen, auf die mehrere lokale Unternehmensinstallationen sicher zugreifen können.

### Umsetzung

- FastAPI-Projektstruktur anlegen,
- PostgreSQL-Verbindung und Alembic-Migrationen einführen,
- Tabellen für Unternehmen, Benutzer, Installationen, Sitzungen/Tokens und technische Jobs,
- sichere Benutzeranmeldung,
- Benutzer eindeutig einem Unternehmen zuordnen,
- serverseitige Mandantenfilter in Service- und Repository-Schicht,
- PostgreSQL Row Level Security als Defense-in-Depth,
- Rollen mindestens `UNTERNEHMEN_ADMIN`, `BEARBEITER`, `LESER`, `SYSTEM_ADMIN`,
- API-Versionierung, Fehlerformat, Request-ID und strukturierte Logs,
- Health- und Readiness-Endpunkte,
- keine sensiblen Inhalte in Logs.

### Akzeptanzkriterien

- Ein Unternehmen und mindestens zwei Benutzer können über Migration/Seed-Test angelegt werden.
- Ein lokaler Testclient kann sich anmelden und eine gültige Sitzung erhalten.
- Ein Benutzer von Unternehmen A kann Daten von Unternehmen B weder lesen noch verändern.
- Direkter Zugriff mit einer fremden ID liefert 403 oder 404, aber niemals fremde Daten.
- Eine vom Client mitgesendete fremde `unternehmen_id` wird ignoriert oder abgelehnt.
- Alle mandantengebundenen Tabellen besitzen `unternehmen_id` und geeignete Indizes.
- PostgreSQL-Migrationen laufen auf leerer Datenbank und bei erneutem Aufruf reproduzierbar.
- API-Fehler enthalten keine Passwörter, Tokens, SQL-Details oder fremde Mandantendaten.
- Integrationstests laufen gegen PostgreSQL und sind grün.
- Kein lokaler Client benötigt direkte PostgreSQL-Zugangsdaten.

---

## Phase 2 – Lokaler Client, DATA_ROOT und Dokumentinventar-Synchronisation

### Ziel

Die lokale Installation verwaltet Originaldokumente sicher und synchronisiert nur Metadaten mit dem Server.

### Umsetzung

- lokale Client-Konfiguration mit Server-URL, Installation-ID und frei wählbarer `DATA_ROOT`,
- Einrichtungs-/Registrierungsablauf einer Installation,
- lokale Verzeichnisinitialisierung,
- bestehende `PathConfig` und relative Pfadlogik übernehmen,
- lokaler Dokumentimport aus Dump-, Upload- und Scannerquellen,
- Hashbildung, Klassifikation und Deduplizierung,
- zentrale Tabelle `documents` mit lokalem Dokument-Lokator,
- idempotente Metadaten-Synchronisation,
- lokale Offline-Outbox für fehlgeschlagene API-Übertragungen,
- Verfügbarkeitsprüfung und Status `LOCAL_AVAILABLE`, `LOCAL_MISSING`, `UNKNOWN`,
- lokale Backup-Anleitung für die Dokumentwurzel.

### Akzeptanzkriterien

- Die `DATA_ROOT` kann auf unterschiedlichen Laufwerken gewählt und geändert werden.
- In der zentralen DB wird kein absoluter Windows-Pfad gespeichert.
- Derselbe Dateiinhalt wird bei erneutem Import nicht als neues Original dupliziert.
- Gleicher Dateiname mit anderem Inhalt wird als separates Dokument behandelt.
- SHA-256, Größe, MIME-Typ, relativer Pfad, `unternehmen_id` und `installation_id` werden korrekt gespeichert.
- Ohne Netzwerk bleiben lokale Dateien unverändert und Synchronisationsaufträge werden gepuffert.
- Nach Wiederherstellung der Verbindung wird die Outbox idempotent abgearbeitet.
- Standardmäßig werden keine Dokumentbytes an den Server gesendet.
- Unternehmen A kann keine Metadaten des Unternehmens B sehen.
- Ein lokal gelöschtes oder verschobenes Dokument wird als nicht verfügbar erkannt, ohne den zentralen Datensatz still zu löschen.

---

## Phase 3 – Rechnungsimport, Extraktion, Validierung und manuelle Prüfung

### Ziel

Lokale Rechnungsdokumente in nachvollziehbare strukturierte Rechnungsdaten überführen.

### Umsetzung

- bestehende PDF-Text- und Rechnungsparser wiederverwenden,
- Erkennungsreihenfolge: E-Rechnung/strukturierte Daten, PDF-Text, OCR, Profilparser, allgemeiner Parser,
- Kandidatenebene pro Feld mit Rohwert, Normwert, Quelle und Confidence,
- freigegebene Rechnungsebene getrennt von Kandidaten,
- mathematische Prüfung von Netto, Steuer, Versand, Rabatt und Gesamt,
- Lieferanten-/Kundenidentifikation über mehrere gewichtete Signale,
- ein einzelnes schwaches Signal darf nie automatisch einen sicheren Partner erzeugen,
- Duplikat- und Versionsregeln für Rechnungsnummer/Rechnungsdatum/importierte Version,
- manuelle Prüffälle für fehlende, widersprüchliche oder unsichere Pflichtfelder,
- lokale Dokumentöffnung aus Prüfansicht,
- zentrale Speicherung strukturierter Kandidaten und Rechnungsdaten.

### Akzeptanzkriterien

- Jeder erkannte Wert ist über Kandidat, Methode, Quelle und Confidence nachvollziehbar.
- Kein Kandidat wird ohne definierte Freigaberegel direkt zum bestätigten Fachwert.
- Rechnung, Originaldokument und Erkennungslauf sind eindeutig miteinander verknüpft.
- Netto plus Steuer plus Zusatzbeträge wird reproduzierbar gegen den Gesamtbetrag geprüft.
- Versand darf nicht als Steuerbetrag und eine USt-ID nicht als Rechnungsnummer freigegeben werden.
- Nur Name, nur Adresse oder nur Telefonnummer reichen nie für eine sichere Partneridentifikation.
- Widersprüchliche starke Signale erzeugen einen Prüffall.
- Gleiche Rechnungsnummer: neuere Rechnung ersetzt die ältere aktive Version; bei gleichem Datum gewinnt die zuletzt importierte Version.
- Ältere ersetzte Versionen werden nicht mehr für automatisches Matching verwendet.
- Manuelle Korrekturen werden mit Benutzer, Zeitpunkt, altem und neuem Wert dokumentiert.
- Ein Prüfer kann vom Rechnungsdatensatz zum lokalen Original und zu allen Kandidaten navigieren.

---

## Phase 4 – Bankimport und allgemeines Rechnungs-Matching

### Ziel

Bankbewegungen importieren, deduplizieren und nachvollziehbar mit Rechnungen zuordnen.

### Umsetzung

- lokale Bankdateien bleiben als Original lokal,
- Parseradapter für vorhandene Formate wiederverwenden und erweitern,
- strukturierte Bankbuchungen zentral speichern,
- Deduplizierung mit mehreren Signalen statt nur Betrag/Datum,
- Klassifikation `MATCHBAR`, `NICHT_ZU_MATCHEN`, `EC_EINZAHLUNG`, `MANUELL_PRUEFEN`,
- Matching-Signale: Betrag, Partner, IBAN, Verwendungszweck, Rechnungsnummerfragmente, Datum,
- erklärbarer Score und Signalprotokoll,
- Status `GEFUNDEN`, `UNSICHER`, `NICHT_GEFUNDEN`, `MANUELL_GEPRUEFT`,
- Schutz manueller Entscheidungen vor automatischem Überschreiben,
- Re-Matching nur für offene beziehungsweise unsichere Datensätze,
- Excel-/JSON-Testreport als technische Zwischenausgabe.

### Akzeptanzkriterien

- Ein vollständiger Kontoauszug verliert keine extrahierte Buchung.
- Derselbe Kontoauszug kann erneut importiert werden, ohne Buchungsduplikate zu erzeugen.
- Gleicher Betrag und gleiches Datum allein markieren unterschiedliche Buchungen nicht pauschal als Duplikat.
- Jeder Match-Vorschlag enthält die verwendeten positiven und negativen Signale.
- Eine Bankbuchung besitzt höchstens eine aktive sichere Zuordnung.
- Eine abgelehnte Zuordnung wird nicht automatisch erneut vorgeschlagen.
- Eine manuell bestätigte Zuordnung wird durch keinen Automatiklauf überschrieben.
- Neue Rechnungen können offene Buchungen erneut bewerten, ohne sichere Altzuordnungen zu verändern.
- Mandantenfremde Rechnungen werden niemals als Kandidaten berücksichtigt.
- Alle Beträge werden als Integer-Centwerte verarbeitet.

---

## Phase 5 – EC-/Telexpert-Sammelzuordnung

### Ziel

Die bestehende fachliche Sammelzuordnung produktiv in die Mandanten- und Serverarchitektur integrieren.

### Umsetzung

- `CardPayment`, `EC_Karte`, Debit, Maestro und konfigurierbare Bezeichnungen normalisieren,
- Karteneinzahlungen je Unternehmen und Bankkonto erkennen,
- Belegfenster zwischen zwei Einzahlungen bilden,
- EC-Belege chronologisch sammeln,
- bei Überschreitung die neuesten Belege zuerst entfernen,
- Belege nach finaler Verwendung sperren,
- Unterdeckung als Fehler/fehlende Belege markieren,
- mehrere mögliche exakte Kombinationen als unsicher kennzeichnen,
- vollständiges Zuordnungsprotokoll speichern,
- bestehende EC-Logik nur über Adapter/Repository auf die zentrale Datenhaltung umstellen.

### Akzeptanzkriterien

- `CardPayment` und `EC_Karte` landen in derselben Normkategorie.
- Eine exakte Belegsumme erzeugt eine sichere Sammelzuordnung.
- Bei zu hoher Summe werden nachweislich die neuesten Belege zuerst entfernt.
- Bei zu niedriger Summe entsteht kein falscher sicherer Treffer.
- Ein final verwendeter EC-Beleg kann nicht erneut verwendet werden.
- Eine Periode ohne nächste Einzahlung bleibt offen und löscht keine Belegkandidaten.
- Jeder verwendete und entfernte Beleg ist im Protokoll nachvollziehbar.
- Der zweite identische Lauf erzeugt keine zusätzliche Sammelzahlung.
- Jede Abfrage und Zuordnung ist auf `unternehmen_id` und Bankkonto begrenzt.
- Bestehende EC-Regressionstests bleiben grün.

---

## Phase 6 – Hybride Rechnungserkennung und Qualitätsprüfung

### Ziel

Die bestehende lokale Rechnungserkennung zu einer hybriden, mehrstufigen und auditierbaren
Pipeline erweitern, ohne den vorhandenen `pdfplumber`-/`InvoiceParser`-Pfad zu ersetzen.
Digitale Text-PDFs, bekannte Anbieter-Templates und lokale OCR sollen Kandidaten für dieselben
Fachfelder liefern. Azure Document Intelligence wird nur als späterer, deaktivierter Adapter
vorbereitet und darf in dieser Phase nicht echt aufgerufen werden.

### Umsetzung

- bestehende PDF-Text-Extraktion mit `pdfplumber` und eigener `InvoiceParser` bleiben erhalten,
- gemeinsame Provider-/Adapter-Schnittstellen für Text-PDF, invoice2data, PaddleOCR und spätere
  Cloud-Provider,
- gemeinsames Kandidatenmodell für Rechnungsnummer, Rechnungsdatum, Lieferant, Empfänger,
  Gesamtbetrag, Nettobetrag, Steuerbetrag, Währung, Fälligkeitsdatum, USt-ID sowie optionale
  Positions- und Referenzdaten,
- Speicherung von Wert, Methode, Quelle, Provider-/Template-Version, Confidence, Seite/Fundstelle,
  Validierungsstatus, Konflikten und Auswahl-/Ablehnungsgrund,
- invoice2data-Templates für bekannte wiederkehrende Anbieter mit synthetischen Tests und
  Gegenprüfung durch eigenen Parser,
- lokale PaddleOCR-Integration für Scan-PDFs; OCR-Text läuft durch dieselbe Parser- und
  Validierungspipeline wie eingebetteter PDF-Text,
- Kandidatenzusammenführung mit formaler, mathematischer, quellenbasierter und anbieterabhängiger
  Bewertung,
- Statusermittlung genau einer fachlichen Stufe: `OK`, `MUSS_GEPRUEFT_WERDEN`, `NICHT_GEFUNDEN`,
- Qualitätsmetriken: Vollständigkeitsquote, Richtigkeitsquote, Automatisierungsquote, Prüfquote
  und Nichterkennungsquote,
- Audit-/Prüffunktion für `OK`-Fälle und Prüffälle mit Feldrichtigkeit je Rechnung,
- lokale Auswertung und Excel-Bericht ohne sensible Originalinhalte,
- Azure-Adapter nur als deaktivierter Port mit Fake-/Mock-Client, synthetischen Contract-Tests,
  Feature-Flag default `false` und Tests gegen unbeabsichtigte echte Aufrufe.

### Akzeptanzkriterien

- Der bestehende Parserpfad ist weiterhin nutzbar und regressionsgetestet.
- Jeder Kandidat ist über Wert, Methode, Quelle, Confidence, Fundstelle, Validierung und
  Auswahl-/Ablehnungsgrund nachvollziehbar.
- Konflikte zwischen Kandidaten führen zu `MUSS_GEPRUEFT_WERDEN`; kein Wert wird still
  ausgewählt.
- `OK` entsteht nur bei vorhandenen Pflichtfeldern, bestandener mathematischer und formaler
  Validierung, ausreichender Quellen-/Confidence-Lage, Anbieterregeln und Konfliktfreiheit.
- `NICHT_GEFUNDEN` wird gesetzt, wenn Rechnung oder notwendige Pflichtwerte nicht ausreichend
  erkannt werden.
- invoice2data und PaddleOCR liefern Kandidaten in dasselbe Modell und ersetzen die eigene
  Validierung nicht.
- Qualitätsmetriken und Auditworkflow sind mit synthetischen Daten testbar und nach Anbieter,
  Dokumenttyp und Erkennungsmethode gruppierbar.
- Azure ist standardmäßig deaktiviert; kein Azure-Schlüssel ist nötig; Tests beweisen, dass bei
  deaktiviertem Feature-Flag kein echter Azure-Aufruf möglich ist.
- Realtest mit echten Rechnungen startet erst nach ausdrücklicher Nutzerfreigabe des
  Ordnerpfads und der Testmenge; keine feste Rechnungsanzahl wird vorausgesetzt.
- Ein separater Azure-Test startet erst nach weiterer ausdrücklicher Nutzerfreigabe und nur mit
  gezielt ausgewählten Fällen.
- Originaldokumente bleiben lokal, Dokumentbytes werden nicht dauerhaft zentral gespeichert,
  und Tenant-Isolation ist für Kandidaten, Konflikte, Ergebnisse, Auditdaten und Auswertungen
  getestet.

---

## Phase 7 – Gmail, Erstimport, Inkrementellbetrieb und Scheduler

### Ziel

Gmail und wiederholbare Verarbeitung zuverlässig in den lokalen Client integrieren.

### Umsetzung

- mehrere Gmail-Postfächer je Unternehmen/Installation,
- Credentials und Tokens ausschließlich lokal und verschlüsselt speichern,
- lokale Ablage der PDF-Anhänge,
- zentrale Speicherung von Mail-Metadaten und Scanintervallen,
- idempotente Scan-Historie,
- gezieltes Freigeben/Zurücksetzen von Scanintervallen,
- Gmail-Nachsuche nur für offene, matchbare Nicht-EC-Bankbuchungen,
- Gmail-Fund löst normalen Dokumentimport aus und ist selbst kein sicherer Match,
- einmaliger historischer Erstimport,
- inkrementeller Betrieb über gespeicherte erfolgreiche Marker,
- Fehlerlauf darf den letzten Erfolgsmarker nicht überschreiben,
- lokaler Scheduler beziehungsweise Windows-Aufgabenplanung,
- Status- und Fehlerübersicht.

### Akzeptanzkriterien

- Fehler in einem Postfach blockieren keine weiteren Postfächer.
- Ein erfolgreich gescanntes Intervall wird nicht still erneut verarbeitet.
- Ein fehlerhaftes oder manuell freigegebenes Intervall kann gezielt wiederholt werden.
- Identische Gmail-Nachricht oder identischer Anhang erzeugt keine doppelten Fachdatensätze.
- Tokens erscheinen weder in Logs noch in zentralen Exporten.
- Anhänge bleiben lokal und werden über denselben Importpfad wie andere Dokumente verarbeitet.
- `NICHT_ZU_MATCHEN`- und EC-Buchungen lösen keine Gmail-Nachsuche aus.
- Der Erstimport verarbeitet historische Daten chronologisch.
- Der zweite Inkrementallauf ohne neue Daten erzeugt keine neuen Datensätze.
- Ein Fehlerlauf behält den letzten erfolgreichen Verarbeitungsmarker.
- Geplante Läufe können nicht parallel denselben Datenbereich schreibend verarbeiten.

---

## Phase 8 – Benutzeroberfläche, Berichte und lokale Installation

### Ziel

Einen verständlichen Arbeitsablauf für den täglichen Betrieb bereitstellen.

### Umsetzung

- GUI-Technologie aus Phase 0 umsetzen,
- Einrichtungsassistent für Server-URL, Anmeldung, Installation und `DATA_ROOT`,
- Dashboard für Importstatus, offene Prüffälle und Fehler,
- Ansichten für Dokumente, Rechnungen, Bankbuchungen, Matches und EC-Perioden,
- manuelle Korrektur und Freigabe unsicherer Fälle,
- lokales Öffnen von Rechnungen und Kontoauszügen,
- Excel-Bericht mit allen Bankbewegungen und Statusinformationen,
- Rechnungsregister unabhängig von Banktreffern,
- CSV/JSON-Export für strukturierte Daten,
- Windows-Paket/Installer,
- Update- und Konfigurationsstrategie.

### Akzeptanzkriterien

- Ein neuer Client kann ohne Quellcodeänderung eingerichtet werden.
- Der Benutzer sieht ausschließlich Daten seines Unternehmens.
- „Dokument öffnen“ nutzt den lokalen relativen Pfad und meldet fehlende Dateien verständlich.
- Ein Prüffall kann angenommen, korrigiert oder abgelehnt werden.
- Excel-Berichte enthalten jede Bankbuchung genau einmal.
- Das Rechnungsregister enthält auch offene und noch nicht gematchte Rechnungen.
- Exporte enthalten keine Daten anderer Unternehmen.
- Normale Exporte duplizieren keine Original-PDFs.
- Die Anwendung startet nach Windows-Neustart beziehungsweise über definierte Verknüpfung zuverlässig.
- Installations-, Update- und Deinstallationsablauf sind dokumentiert.

---

## Phase 9 – Pilotbetrieb, Härtung und Produktionsfreigabe

### Ziel

Das System mit Pilotunternehmen sicher in einen stabilen Betriebszustand bringen.

### Umsetzung

- getrennte TEST- und PRODUKTIONS-Konfiguration,
- produktive Reset-Blockierung,
- zentrale PostgreSQL-Backups und Restore-Test,
- lokale Backup-Prüfung der Dokumentwurzeln,
- API-Ausfall, Netzwerkunterbrechung und Wiederanlauf testen,
- Last- und Laufzeittests mit realistischen Datenmengen,
- Sicherheitsprüfung der Mandantentrennung,
- Migrationsprobe auf einer Kopie,
- Betriebs-, Fehler- und Wiederherstellungsanleitung,
- Pilotbetrieb mit klarer Rückfallstrategie.

### Akzeptanzkriterien

- Produktivdaten können durch keinen TEST-Reset-Befehl gelöscht werden.
- Ein zentrales Datenbankbackup wurde in eine leere Testumgebung erfolgreich zurückgespielt.
- Ein lokales Dokumentbackup wurde stichprobenartig erfolgreich wiederhergestellt.
- Netzwerkunterbrechungen führen nicht zu beschädigten oder doppelten Datensätzen.
- Nach Serverneustart arbeiten Clients und wartende Synchronisationsaufträge weiter.
- Alle Cross-Tenant-Tests sind grün.
- Keine offenen kritischen oder hohen Sicherheitsfehler.
- Alle migrationsrelevanten Tests sind grün.
- Bekannte Einschränkungen sind dokumentiert.
- Der Nutzer hat die Produktionsfreigabe ausdrücklich erteilt.

---

# 7. Optionale Erweiterungen nach dem Kern-MVP

Folgende Funktionen werden architektonisch vorbereitet, aber zunächst nicht verpflichtend implementiert:

## Optional A – DATEV

- DATEV-ASCII- oder CSV-Export,
- konfigurierbare Kontenrahmen und Steuerschlüssel,
- nur freigegebene Datensätze exportieren,
- keine direkte DATEV-API im ersten Schritt.

## Optional B – GoBD-orientierte Funktionen

- erweiterte unveränderbare Audit-Spur,
- Hash-Ketten oder externe Zeitstempel,
- WORM-/Object-Lock-Speicher,
- Aufbewahrungs- und Löschregeln,
- Verfahrensdokumentations-Export,
- Vier-Augen-Prinzip für besonders kritische Änderungen.

Diese Funktionen dürfen nur als „GoBD-orientiert“ bezeichnet werden. Eine rechtliche oder steuerliche Konformitätszusage ist nicht Bestandteil der Softwareentwicklung.

## Optional C – Erweiterte Dokumentbereitstellung

- verschlüsselte zentrale Dokumentkopie,
- unternehmensinterne Mehrrechner-Synchronisation,
- Offline- oder Steuerberaterpakete,
- kontrollierte Freigabelinks.

## Optional D – Weitere Anbieter und Automatisierung

- Outlook/IMAP,
- weitere Banken und Formate,
- Cloud-OCR,
- Unternehmensregister,
- Benachrichtigungen,
- mobile Ansicht.

## Optional E – KI-Unterstützung

- nur für schwierige OCR-/Parserfälle,
- Vorschläge für unsichere Matches,
- ungewöhnliche Verwendungszwecke,
- niemals direkte automatische Freigabe eines KI-Werts.

---

# 8. Globale Definition of Done

Eine Phase ist nur abgeschlossen, wenn:

1. alle geplanten Funktionen implementiert sind,
2. alle zugehörigen Migrationen vorhanden sind,
3. Unit- und Integrationstests grün sind,
4. Mandanten- und Idempotenztests grün sind,
5. keine echten Dokumente in Git oder Testausgaben enthalten sind,
6. Dokumentation und Changelog aktualisiert sind,
7. bekannte Einschränkungen dokumentiert sind,
8. vollständige geänderte Dateien beziehungsweise ein klarer Git-Diff vorliegen,
9. der Nutzer die Phase ausdrücklich freigegeben hat.

---

# 9. Arbeitsauftrag an Claude je Phase

Für jede einzelne Phase soll Claude nach folgendem Muster arbeiten:

1. Relevante Dateien vollständig lesen.
2. Bestehenden Ist-Zustand und wiederverwendbare Module kurz zusammenfassen.
3. Konkrete Änderungsliste vorlegen.
4. Erst danach implementieren.
5. Migrationen additiv und rückwärtsverträglich gestalten.
6. Tests ausführen und Ergebnisse protokollieren.
7. Akzeptanzkriterien einzeln mit `ERFÜLLT`, `NICHT ERFÜLLT` oder `NICHT GETESTET` bewerten.
8. Dokumentationsdateien aktualisieren.
9. Nach der Phase stoppen und keine Folgephase beginnen.
