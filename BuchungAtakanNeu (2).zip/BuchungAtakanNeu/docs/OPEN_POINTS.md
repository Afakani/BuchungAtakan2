# Offene Punkte & Entscheidungen – BuchungAtakan

**Stand:** 2026-07-01 (Phase-6-Abnahme)

Drei Abschnitte: getroffene Entscheidungen (D1–D6), offene Punkte des Neuaufbaus,
übernommene offene Punkte aus dem Altprojekt.

---

## 1. Getroffene Entscheidungen (verbindlich)

| ID | Thema | Entscheidung |
|----|-------|--------------|
| **D1** | Datenmigration | Keine sofortige Blindmigration. Neue Architektur startet auf sauberer PostgreSQL-Test-DB. Phase 0 definiert einen **konkreten, testbaren und reversiblen** Migrationspfad (Alt-SQLite-Einzelmandant → PostgreSQL-Multi-Tenant). **Keine** Löschung von Produktiv-/Altdaten. Echte Migration erst nach Inventar, Mapping, Tests und ausdrücklicher Freigabe. |
| **D2** | Code-Wiederverwendung | Alte Fachmodule **phasenweise** wiederverwenden (kein Massen-Copy). Je Modul: prüfen → Domänenlogik isolieren → Infrastruktur trennen → nach `packages/core` heben → über Ports/Adapter anbinden → Regressionstests. Keine grundlose Neuschreibung von EC/Gmail/Parser/Matching. |
| **D3** | GUI-Technologie | Lokaler Windows-Client mit **PySide6**; zentrale API mit FastAPI. Domänen-/Anwendungslogik UI-unabhängig. |
| **D4** | Naming/Env | Standard `BuchungAtakan` / `BUCHUNG_ATAKAN_*`. Altnamen (`BuchungCumcu`, `BUCHUNG_CUMCU_*`) nur als dokumentierte, temporäre Migrations-Fallbacks. |
| **D5** | Doku-Sprache | Deutsch. Technische Bezeichner/Codenamen/API-Feldnamen dürfen englisch bleiben. |
| **D6** | Zentrale Dokumentablage | Alt-Entscheidung 2026-06-21 (UNC/Tailscale) **superseded**. Maßgeblich: Originale bleiben lokal; Server speichert nur strukturierte Daten/Metadaten/Hashes/relative Locator. Frühere Intention nur als **„Optional C – verschlüsselte zentrale Dokumentkopie / Dokumentreplikation“**, **kein** Kern-MVP. |

## 2. Offene Punkte – Neuaufbau

- **P-01 (D1-Folge):** Detailliertes Tabellen-/Feld-Mapping Altschema → Multi-Tenant-Zielschema
  inkl. Ergänzung `unternehmen_id` je Datensatz; Reversibilität nachweisen.
  **Status (Phase 0):** Grundlegendes Mapping in `docs/phase0/MIGRATIONSPLAN.md` dokumentiert.
  Implementierung: Phase 1.
- **P-02:** Authentifizierungs-/Rollenmodell (Server) und sichere `unternehmen_id`-Guards
  festlegen und testen. **Status (Phase 2):** ~~Offene Frage~~ **ERLEDIGT** — JWT (PyJWT/Argon2),
  OAuth2-Login, RoleChecker, RLSSession-Dependency, RLS-Policies implementiert und getestet.
- **P-03:** Offline-Outbox & idempotente Synchronisationsstrategie (Konfliktauflösung,
  Retry, Reihenfolge) spezifizieren. **Status (Phase 0):** Offene Frage; Phase 2.
- **P-04:** `installation_id`-Konzept (Registrierung lokaler Installationen) ausarbeiten.
  **Status (Phase 2):** Tabelle `installationen` mit RLS-Policy erstellt; API-Endpunkte
  (Registrierung, Deregistrierung) noch nicht implementiert — Phase 3.
- **P-05:** Konkreter Modulschnitt `apps/client` / `apps/server` / `packages/core` als
  Phase-0-Lieferobjekt. **Status (Phase 0):** ~~Offen~~ **ERLEDIGT** — `docs/phase0/MODULKLASSIFIKATION.md` (14 Module klassifiziert).
- **P-06:** Reset-/Testdaten-Befehle des Altprojekts (`src.pipeline.*`, SQLite-Pfade,
  `BUCHUNG_CUMCU_*`) auf neue Client/Server-Äquivalente und `BUCHUNG_ATAKAN_*` übertragen.
  **Status (Phase 0):** Offene Frage; Phase 1–2.
- **P-07:** Excel-/Dokument-Hyperlinks auf **lokale** Pfadöffnung umstellen (statt UNC).
  **Status (Phase 0):** Offene Frage; Phase 8/9 (UI-03 nach eingefügter Hybridphase).
- **P-08 (später):** Optional C, DATEV-Export, GoBD/WORM, Cloud-OCR, weitere Mail-/Bankanbieter,
  KI-Hilfe – außerhalb Kern-MVP. **Präzisierung 2026-06-30:** Lokale PaddleOCR in Phase 7 ist
  kein Cloud-OCR-Modul. Azure Document Intelligence bleibt nur vorbereiteter, deaktivierter
  Fallback und braucht vor jeder echten Nutzung eine ausdrückliche Nutzerfreigabe.

### Neu erkannte technische Schulden (aus Phase-0-Analyse)

Vollständige Übersicht: `docs/phase0/MODULKLASSIFIKATION.md` §§ Technische Schulden.

Hohe Priorität (blockiert Folgephasen):
- **TS-H-01:** Direkte `sqlite3.connect()`-Aufrufe (14 Stellen) — Ersatz durch API-Client Phase 1–4
- **TS-H-02:** `BUCHUNG_CUMCU_*`-Umgebungsvariablen in Kernmodulen → Umbenennung Phase 2
- **TS-H-03:** `File.file_path` speichert absoluten Pfad — auf relativen Lokator umstellen Phase 2
- **TS-H-04:** `network_document_root`-Parameter (SUPERSEDED per D6) — entfernen Phase 1–2
- **TS-H-05:** `EcSettlementService` direkte DB-Kopplung → Port/Adapter-Trennung Phase 5
- **TS-H-06:** `database/`-Repositories direkt gegen SQLite — Reimplementierung Phase 1

## 3. Übernommene offene Punkte aus dem Altprojekt (Referenz)

- **A-01:** Erkannte Kontoauszugs-PDFs erzeugen aktuell **keine** Bankbuchungen
  (Parsergrenze); dokumentiert, nicht breit optimiert, solange kein Folgeblock blockiert.
- **A-02:** Realer Gmail-API-/OAuth-Betrieb mit echten Postfächern/Credentials (Rate-Limits)
  ist separat freizugeben; bisher nur Fakes/synthetische Tests.
- **A-03:** GUI und Zeitsteuerung/Scheduler im Altprojekt offen → im Neuaufbau Teil der
  Phasen 6–7.
- **A-04:** Umfassende Parseroptimierung bleibt Spätarbeit.

## 4. Befunde aus unabhängigem Phase-0-Architektur-Review (2026-06-26)

Eingetragen nach `/gsd:execute-phase 01` + unabhängigem Reviewer-Durchlauf.
Keine dieser Erkenntnisse erfordert Änderungen an der genehmigten Architektur; alle sind Präzisierungen für Folgephasen.

- **AR-01 — Direktes `unternehmen_id` auf Kindtabellen (Phase 1/5):**
  Jede mandantengebundene Tabelle — auch Kindtabellen wie `ec_sammelzahlung_belege` —
  muss `unternehmen_id` direkt als Spalte tragen, nicht nur indirekt über FK auf Parent.
  PostgreSQL Row Level Security kann ohne direktes Tenant-Feld nicht tabellenweise erzwungen
  werden; Queries müssten sonst JOINen, was Leak-Risiko bei vergessenen JOINs erzeugt.
  **Status (Phase 2):** `TenantMixin` implementiert — alle künftigen Tabellen erben es automatisch.
  Für Kindtabellen in Folgephasen weiterhin beachten.

- **AR-02 — Repository-Query-Inventar vor Reimplementierung (Phase 1):**
  Die Phase-0-Inventur erfasst 14 `sqlite3.connect()`-Erzeugungsstellen (TS-H-01/TS-H-06).
  Vor der Reimplementierung jedes Repository als Server-Side-PostgreSQL-Pendant muss zusätzlich
  die vollständige Query-Oberfläche je Repository inventarisiert werden (alle SELECT/INSERT/
  UPDATE/DELETE-Pfade), nicht nur die connect()-Sites. Sonst können Pfade beim API-Port
  durchrutschen. **Adressieren in:** Phase 1, beim Anlegen von `apps/server/repositories/`.

- **AR-03 — `installation_id`-Eindeutigkeitsformulierung schärfen (Doku-Update Phase 1):**
  `docs/phase0/API_GROBVERTRAG.md` bezeichnet `installation_id` als „global nicht unique".
  Korrekt: UUID v4 ist global eindeutig (Kollisionswahrscheinlichkeit vernachlässigbar);
  gemeint ist „mehrere Installationen je Unternehmen möglich" (nicht unique unter
  `installationen.unternehmen_id`). Formulierung vor Phase-1-Implementierung klarstellen,
  damit Datenbankconstraints (`UNIQUE(installation_id)` global, `NOT UNIQUE` unter einem
  Mandanten) korrekt gesetzt werden. **Adressieren in:** Phase 1 Doku-Update.

- **AR-04 — Rundungsregel REAL→Integer-Cent vor Finanzdatenmigration (Phase 4):**
  `bank_transactions.amount` muss von SQLite `REAL` auf `INTEGER` (Centwerte) umgestellt werden
  (MIGRATIONSPLAN §Tabellen-Mapping + ENTWICKLUNGSPLAN §4 Akzeptanzkriterium BANK-10).
  Die Rundungsregel für Halb-Cent-Beträge (z. B. `round()` vs. `floor()` vs. Banker's Rounding)
  muss vor der Migrationsskript-Implementierung schriftlich festgelegt werden, um
  Buchungsdifferenzen im Cent-Bereich zu vermeiden. **Adressieren in:** Phase 4 (BANK-10)
  spätestens bei Erstellung von `tools/migration/migrate_sqlite_to_postgres.py`.

## 5. Offene Punkte (Phase-4-Abschluss)

- **P-09 — buchungatakan_app Passwort (Sicherheit, vor Produktion):**
  Migration 003 erstellt die Rolle `buchungatakan_app` NICHT (wurde korrigiert — keine Passwörter
  oder Platzhalter in Migrationen). Die Rolle muss einmalig manuell vom Datenbankadministrator
  erstellt werden: `CREATE ROLE buchungatakan_app LOGIN PASSWORD '<sicheres_passwort>';`
  Passwort nie im Repo committen. `DATABASE_URL` in `.env` entsprechend setzen.

- **P-10 — Vollständige RLS-Verifikation als buchungatakan_app:**
  `test_rls_blocks_benutzer_without_tenant_context` in `tests/integration/test_rls.py`
  ist mit `@pytest.mark.skip` markiert. **Kein Phase-4-Blocker.** Vollständige Verifikation
  erfordert separaten Engine-Fixture mit `buchungatakan_app`-Credentials (APP_DATABASE_URL).
  Migrations-Owner-Verbindung umgeht FORCE RLS in PostgreSQL. Adressieren in Folge-Phase.

- **P-11 — Migration 003 applyen:** ~~**ERLEDIGT**~~ — Alle Migrationen 001–005 applied
  (`buchungatakan_test`). Kein aktiver Blocker mehr.

- **P-12 — RECH-10 AuditLog manueller Korrekturen (bewusst verschoben):**
  Phase 4 implementiert keinen manuellen Korrektur-/Freigabe-Endpunkt (`PATCH /rechnungen/{id}`).
  AuditLog ohne auslösende Fachfunktion wäre ein leerer Container ohne fachlichen Wert.
  **Kein sofortiger Handlungsbedarf.** Nachholen wenn manueller Korrekturpfad existiert.
  AuditLog muss dann append-only protokollieren: Benutzer-UUID, Zeitpunkt (UTC), Rechnung-ID,
  Feld-Name, alter Wert, neuer Wert. Kein UPDATE/DELETE auf audit_log-Zeilen.
  GRANT nur INSERT + SELECT für `buchungatakan_app`. Keine Migration 006 vor dann.
  Details: `.planning/phases/04-rechnungsimport-extraktion-validierung/04-VERIFY.md` §6.

## 5a. Gelöste Blocker (Phase-4-Abschluss)

- ~~**B-01** (Migration 004 pending)~~ → **ERLEDIGT**: Migration 004 applied.
- ~~**B-02** (Integrationstests ohne TEST_DATABASE_URL)~~ → **ERLEDIGT**: 25 Integrationstests
  passed (TEST_DATABASE_URL verfügbar, conftest stabilisiert).
- ~~**B-03** (Migration 005 pending)~~ → **ERLEDIGT**: Migration 005 applied.
- ~~**P-11** (Migration 003 pending)~~ → **ERLEDIGT**: Alle Migrationen 001–005 applied.

## 5b. Phase-5-Status (Abschluss 2026-06-29)

BANK-01..11 alle erfüllt. Migrationen 006, 007, 008 applied (buchungatakan_test).
432 Tests bestanden, 0 Fehler, 1 bekannter Skip (P-10, unverändert).

Verschobene Phase-5-Punkte:
- ~~**EC-01..10** (EC-/Telexpert-Sammelzuordnung): Phase 6.~~ → **ERLEDIGT** (Phase-6-Abnahme 2026-07-01)
- **Gmail-Nachsuche für offene Buchungen**: spätere Phase.
- **GUI für Zuordnungsworkflow**: Phase 9.
- **RECH-10 AuditLog**: wartet auf PATCH-Korrekturendpunkt.
- **Vollständige IBAN-/USt-ID-Signalabdeckung im Scorer**: Folge-Iteration.

## 5c. Phase-6-Status (Abschluss / fachliche Abnahme 2026-07-01)

EC-01..10 alle erfüllt. Migrationen 001–010 applied (buchungatakan_realtest, EC-Realtest März 2026; buchungatakan_test, technische Validierung).
744 Tests gesammelt; 572 passed / 172 skipped (ohne TEST_DATABASE_URL); **743 passed / 1 skip (mit TEST_DATABASE_URL auf buchungatakan_test, 0 failed)**.
Pytest-Guard (commit `2f749bd`): 14 Guard-Tests blockieren dauerhaft TRUNCATE gegen `buchungatakan_realtest` und `buchungatakan`.
Die 172 Skips ohne DB sind kein Code-Defekt: fehlende TEST_DATABASE_URL lässt Integrationstests korrekt überspringen.
Keine echten Inhalte (Dateinamen, IBANs, Kontonummern, Verwendungszwecke, Hashes) in Git oder Dokumentation.

Gelöste Phase-6-Punkte:
- ~~**B-04** (EC-Realtest mit echten Belegen — Abnahmeblocker)~~ → **ERLEDIGT** — EC-Realtest März 2026 abgeschlossen (2026-07-01).

Offene Phase-6-Punkte (kein Blocker für Folgephasen):
- P-10: App-Role-RLS-Test (unverändert aus früheren Phasen — kein Blocker).
- P-12: RECH-10 AuditLog (wartet auf PATCH-Korrekturendpunkt — kein Blocker).

## 6. Ungelöste Widersprüche

Aktuell **keine** ungelösten Widersprüche. Alle bekannten Konflikte (DB, Dokumentablage,
Mandanten, DB-Zugriff, Excel-Hyperlinks, Naming) sind zugunsten `docs/ENTWICKLUNGSPLAN.md`
aufgelöst (siehe `docs/CURRENT_STATUS.md` §C und D1–D6).

## 7. Neue Planungsgrenzen Phase 7 – Hybride Rechnungserkennung

- **HYB-O-01 – Realtest-Freigabe offen:** Der kontrollierte Realtest der lokalen Hybridpipeline
  darf erst nach ausdrücklicher Nutzerfreigabe von Ordnerpfad und Testmenge starten. Bis dahin
  werden keine echten Rechnungen geöffnet, keine vorhandenen Rechnungsordner durchsucht, keine
  früheren Realtest-Ordner verwendet und keine Daten aus `C:\Users\User\Desktop\recnunh` genutzt.
- **HYB-O-02 – Azure-Aktivierung offen:** Azure Document Intelligence bleibt deaktiviert. Ein
  echter Azure-Test ist ein separater Schritt nach lokaler Auswertung und erneuter ausdrücklicher
  Nutzerfreigabe. Bis dahin: keine Azure-Aufrufe, keine Credentials, keine Kontingentnutzung.
  **Präzisierung Paket 07-04 (2026-07-02):** Der Adapter (`azure_document_intelligence_provider.py`,
  `AzureDocumentIntelligenceProvider`, `CloudInvoiceProvider`-Port) ist jetzt fachlich und technisch
  vorbereitet, aber **nicht produktionsfähig** — kein Azure-SDK vorhanden, keine Credentials
  vorhanden, kanonisches Feature-Flag `BUCHUNG_ATAKAN_FEATURE_AZURE_DOCUMENT_INTELLIGENCE`
  standardmäßig deaktiviert. Eine spätere Aktivierung braucht ein eigenes Paket und ausdrückliche
  Freigabe; echte Testfälle müssen dann gezielt ausgewählt werden (repräsentative
  `NICHT_GEFUNDEN`-/`MUSS_GEPRUEFT_WERDEN`-Fälle, wenige kontrollierte `OK`-Fälle, keine pauschale
  Übermittlung aller Rechnungen, Kosten-/Seitenmessung). Dieser Punkt bleibt bis dahin offen.
- **HYB-O-03 – Qualitätsziel:** Phase 7 muss Vollständigkeit und Richtigkeit getrennt messen.
  Ein `OK` ist nur gültig, wenn Pflichtfelder, Validierung, Quellen-/Confidence-Regeln und
  Konfliktfreiheit erfüllt sind.
- ~~**HYB-O-04** – Excel-Export-Verifikation offen (Paket 07-03B)~~ → **ERLEDIGT (2026-07-02):**
  Lokaler Excel-Export der Qualitätsstatistik (`hybrid_statistik_export.py`,
  `GET /api/v1/hybrid/statistik/export.xlsx`) gegen `buchungatakan_test` verifiziert —
  43 Unit-/Security-Tests, 7 API-Integrationstests passed, vollständige Suite
  1042 passed/1 skip (P-10)/0 failed. HYB-19 in `.planning/REQUIREMENTS.md` endgültig
  als erfüllt markiert.
