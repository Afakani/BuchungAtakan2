# Testhistorie – BuchungAtakan

**Stand:** 2026-07-01

---

## Neues Repository

### 2026-07-02 — Phase-7-Paket-07-04: Azure-Adapter vorbereitet, aber deaktiviert

**Ergebnis:** BESTANDEN — vollständiger Testlauf mit `TEST_DATABASE_URL` gegen `buchungatakan_test` vom Nutzer ausgeführt. HYB-20..24 endgültig als erfüllt markiert (`.planning/REQUIREMENTS.md`).

**Neue/geänderte Unit-/Security-Tests Paket 07-04:**

| Test-Datei | Tests |
|------------|-------|
| tests/unit/test_azure_document_intelligence_provider.py | 17 |
| tests/security/test_azure_document_intelligence_sanitization.py | 11 |
| tests/unit/test_hybrid_qualitaetsentscheidung.py (Azure-only-Guard, neu) | 3 |
| tests/unit/test_feature_flags.py (kanonisches Flag, neu) | 3 |
| tests/security/test_hybrid_auswertung_sanitization.py (Azure-Ausnahme präzisiert, neu) | 2 |

**Gezielter Testlauf (buchungatakan_test):** Azure-/Feature-Flag-/Status-/Security-Tests — **61 passed**.

**Unit+Security gesamt (ohne TEST_DATABASE_URL):** 845 passed, 4 skipped, 0 failed (Zuwachs gegenüber Paket 07-03B: +36).

**Gesamt-Teststand (buchungatakan_test, vollständiger Lauf inkl. Integrationstests):**

| Kennzahl | Wert |
|----------|------|
| Passed | **1078** |
| Skipped | **1** (P-10 — `tests/integration/test_rls.py`, separate `APP_DATABASE_URL` mit `buchungatakan_app` erforderlich) |
| Failed | **0** |
| Warnings | 11 |

**Sicherheitsregeln (eingehalten):** kein Azure-SDK-Import, kein `DocumentAnalysisClient`/`AzureKeyCredential`, kein Netzwerkimport (`requests`/`httpx`/`socket`/`urllib`), keine Secrets/Tokens/Endpunkte im Modul, `.env.example` unverändert, kein Azure-Aufruf bei deaktiviertem Flag (Client-Factory wird nie aufgerufen).

---

### 2026-07-02 — Phase-7-Paket-07-03B: lokaler Excel-Export der Qualitätsstatistik

**Ergebnis:** BESTANDEN — vollständiger Testlauf mit `TEST_DATABASE_URL` gegen `buchungatakan_test` vom Nutzer ausgeführt. HYB-19 endgültig als erfüllt markiert (`.planning/REQUIREMENTS.md`).

**Neue Unit-/Security-Tests Paket 07-03B:**

| Test-Datei | Tests |
|------------|-------|
| tests/unit/test_hybrid_statistik_export.py | 16 |
| tests/security/test_hybrid_statistik_export_sanitization.py | 6 |
| tests/integration/test_hybrid_statistik_export_api.py | 7 |

**Gezielte Testläufe (buchungatakan_test):**

| Lauf | Ergebnis |
|------|----------|
| `test_hybrid_statistik.py` + `test_hybrid_statistik_export.py` + `test_hybrid_statistik_export_sanitization.py` | **43 passed** |
| `test_hybrid_statistik_export_api.py` | **7 passed** |
| relevante Hybrid-Suite (gesamt) | **105 passed** |

**Gesamt-Teststand (buchungatakan_test, vollständiger Lauf inkl. Integrationstests):**

| Kennzahl | Wert |
|----------|------|
| Passed | **1042** |
| Skipped | **1** (P-10 — `tests/integration/test_rls.py`, separate `APP_DATABASE_URL` mit `buchungatakan_app` erforderlich) |
| Failed | **0** |
| Warnings | 11 |

**Sicherheitsregeln (eingehalten):** kein Azure-Aufruf, keine echten Rechnungen, kein Gmail, keine UI, kein Push; Workbook enthält ausschließlich aggregierte Statistikdaten; Core-Exportmodul ohne DB-/Dateisystemzugriff verifiziert.

---

### 2026-07-01 — Phase-7-Paket-07-02: lokale Erkennungsschienen, vollständiger Gesamttestlauf

**Ergebnis:** BESTANDEN — vollständiger Testlauf mit `TEST_DATABASE_URL` gegen `buchungatakan_test` vom Nutzer ausgeführt, Integrationstests liefen vollständig.

**Befehl:** `.\.venv\Scripts\python.exe -m pytest -q -rs --tb=short` (mit `TEST_DATABASE_URL` gesetzt)

**Neue Unit-/Security-Tests Paket 07-02:**

| Test-Datei | Tests |
|------------|-------|
| tests/unit/test_invoice_document_classifier.py | 17 |
| tests/unit/test_invoice2data_provider.py | 15 |
| tests/unit/test_paddleocr_provider.py | 17 |
| tests/unit/test_local_invoice_provider_orchestrator.py | 12 |
| tests/security/test_invoice_provider_sanitization.py | 12 |

**Gesamt-Teststand (buchungatakan_test, vollständiger Lauf inkl. Integrationstests):**

| Kennzahl | Wert |
|----------|------|
| Passed | **869** |
| Skipped | **1** (P-10 — `tests/integration/test_rls.py:26`, App-Role-RLS-Test, bekannter Nicht-Blocker) |
| Failed | **0** |
| Warnings | 9 |

**HYB-09..13 Einzelstatus:**

| ID | Anforderung | Status |
|----|------------|--------|
| HYB-09 | Digitale Text-PDFs laufen über pdfplumber/eigenen Parser | ERFÜLLT |
| HYB-10 | invoice2data-Templates versioniert und synthetisch getestet | ERFÜLLT |
| HYB-11 | PaddleOCR lokal integrierbar, gleiche Parser-/Validierungspipeline | ERFÜLLT |
| HYB-12 | Einheitliche Textübergabe (eingebetteter Text, Template-Text, OCR-Text) | ERFÜLLT |
| HYB-13 | Providerfehler isoliert, sanitisiert, blockieren andere Provider nicht | ERFÜLLT |

**Sicherheitsregeln (eingehalten):** kein Azure-Aufruf, keine echten Rechnungen, kein Gmail, keine UI, kein Push.

---

### 2026-07-01 — Phase-7-Paket-07-01: neue Unit- und Integrationstests, Phase-6-Regressionsfix

**Ergebnis:** BESTANDEN — Unit- und Integrationstests grün, gegen `buchungatakan_test` mit nicht privilegierter Rolle (`buchungatakan_migrations`) verifiziert.

**Neue Unit-Tests Phase 07-01:**

| Test-Datei | Tests |
|------------|-------|
| tests/unit/test_hybrid_kandidat.py | 20 |
| tests/unit/test_hybrid_ergebnis.py | 13 |
| tests/unit/test_provider_ports.py | 10 |
| tests/unit/test_feature_flags.py | 6 |
| **Gesamt neu (Unit)** | **49** |

**Neue Integrationstests Phase 07-01 (mit buchungatakan_test, nicht privilegierter Rolle verifiziert):**

| Gruppe | Tests |
|--------|-------|
| Tabellen vorhanden (HY06, 4 parametrisiert) | 4 |
| RLS aktiv (HY07, 4 parametrisiert) | 4 |
| FORCE RLS aktiv (HY08, 4 parametrisiert) | 4 |
| Persistenz (HY01..HY04) | 4 |
| Tenant-Isolation (HY05) | 1 |
| Alembic-Check (HY09) | 1 |
| **Gesamt neu (Integration)** | **18** |

Tenant-Isolation (HY05) wurde explizit mit einer nicht privilegierten Rolle geprüft (kein Superuser, kein BYPASSRLS) — eine Superuser-Verbindung umgeht RLS grundsätzlich (bekanntes P-10-Verhalten) und hätte ein falsch-positives Ergebnis geliefert.

**Phase-6-Regressionsfix im Zuge der Verifikation gefunden:** `packages/core/ec_sammlung/gruppierung.py` — Beleg-Sortierschlüssel bei gleichem Buchungsdatum um `betrag_cent` erweitert (statt reiner Zufalls-UUID). `test_e04_entfernte_belege_bleiben_verfuegbar` flakte zuvor in ca. 40 % der isolierten Wiederholungsläufe; nach dem Fix 8/8 stabil grün. Keine Migration geändert.

**Gesamt-Teststand (buchungatakan_test, nicht privilegierte Rolle), zweifach reproduziert:** **810 passed, 1 skipped (P-10), 0 failed**.

---

### 2026-07-01 — Phase-6-Abnahme: technische Validierung buchungatakan_test + EC-Realtest abgeschlossen

**Ergebnis:** BESTANDEN / PHASE FACHLICH ABGENOMMEN
**Befehl:** `.\.venv\Scripts\python.exe -m pytest -q -rs --tb=short` (mit TEST_DATABASE_URL gesetzt)

**Lauf mit TEST_DATABASE_URL (buchungatakan_test — verifizierter Abschlussstand):**

| Kennzahl | Wert |
|----------|------|
| Gesammelt | 744 |
| Passed | **743** |
| Skipped | 1 (P-10 — App-Role-RLS-Test, erwarteter Nicht-Blocker) |
| Failed | 0 |
| Laufzeit | ~75 s |
| Pytest-Exit-Code | 0 |

**Integration + Security (buchungatakan_test):**

| Kennzahl | Wert |
|----------|------|
| Passed | 175 |
| Skipped | 1 (P-10) |
| Failed | 0 |

**Lauf ohne TEST_DATABASE_URL (Referenz):**

| Kennzahl | Wert |
|----------|------|
| Gesammelt | 744 |
| Passed | 572 |
| Skipped | 172 (Integrations-/Security-Tests benötigen TEST_DATABASE_URL) |
| Failed | 0 |
| Pytest-Exit-Code | 0 |

**Erklärung der Testzahlen:**
- 744 gesammelt = 572 Unit+Guard-Tests (laufen ohne DB) + 172 Integrations-/Security-Tests (skippen ohne DB).
- Mit TEST_DATABASE_URL: 171 Integrationstests laufen, 1 bleibt als P-10 übersprungen → 743 passed, 1 skipped.
- Die 172 Skips ohne DB sind kein Code-Defekt, sondern fehlendes ENV; in jeder normalen CI-Umgebung mit TEST_DATABASE_URL laufen alle 743.

**Alembic-Check:** `alembic check` gegen `buchungatakan` (prod, read-only) — Status: `Target database is not up to date` (Migration 010 noch nicht deployed — kein Blocker, keine Produktivänderung).
**git diff --check:** Keine Whitespace-Fehler (nur `.idea/workspace.xml`-CRLF-Warnung, IDE-Datei).

**Guard-Tests (commit `2f749bd` — `tests/test_db_guard.py`):**
- 14 Tests grün: Validierung exakter DB-Name `buchungatakan_test`, Ablehnung von `buchungatakan_realtest`, `buchungatakan`, unbekannten Namen; URL-Normalisierung; Substrings; Groß-/Kleinschreibung.

**Kontrollierter EC-Realtest März 2026 — `buchungatakan_realtest`:**
- MT940-Reimport: 17 Dateien, 2 Bankkonten, 819 Bankbuchungen, 69 EC_EINZAHLUNG; 0 Parsefehler; Idempotenz-Import: 0 neu, 819 dedupliziert.
- EC-Belegimport: 19 PDFs, 18 akzeptiert (1 negative Kulanzauszahlung fachlich ausgeschlossen); Idempotenz-Import: 0 neu, 18 dedupliziert.
- Vorschläge nach Erstlauf: 0 STARK, 3 UNSICHER, 1 OFFENE_PERIODE; 49 Einzahlungen ohne Gruppe (begrenzter Belegzeitraum — kein falsches Hochstufen zu STARK).
- Manuelle Entscheidungen: 1 plausible UNSICHER-Gruppe bestätigt, 1 ungeeignete Gruppe abgelehnt.
- Nach Rematch: bestätigte Gruppe geschützt, abgelehnte Gruppe geschützt, 10 Belege gesperrt; 2 UNSICHER, 1 OFFENE_PERIODE verbleibend.
- Datenschutz: keine echten Inhalte (Dateinamen, IBANs, Kontonummern, Verwendungszwecke, Hashes) in Git oder Dokumentation.

**EC-01..10 Einzelstatus:**

| ID | Anforderung | Status |
|----|------------|--------|
| EC-01 | CardPayment/EC_Karte in derselben Normkategorie | ERFÜLLT |
| EC-02 | Exakte Belegsumme → sichere Sammelzuordnung | ERFÜLLT |
| EC-03 | Überdeckung: neueste Belege zuerst entfernt | ERFÜLLT |
| EC-04 | Unterdeckung: kein falscher sicherer Treffer | ERFÜLLT |
| EC-05 | Final verwendeter Beleg gesperrt | ERFÜLLT |
| EC-06 | Offene Periode löscht keine Kandidaten | ERFÜLLT |
| EC-07 | Jeder Beleg im Protokoll nachvollziehbar | ERFÜLLT |
| EC-08 | Zweiter identischer Lauf erzeugt keine Zusatzzahlung | ERFÜLLT |
| EC-09 | Abfragen auf unternehmen_id + Bankkonto begrenzt | ERFÜLLT |
| EC-10 | EC-Regressionstests grün | ERFÜLLT (744 gesammelt; 743 passed/1 skipped mit TEST_DATABASE_URL; kein Rückschritt) |

### 2026-06-30 — Planung Phase 7: Hybride Rechnungserkennung und Qualitätsprüfung

**Ergebnis:** NICHT AUSGEFÜHRT — Planungsschritt ohne Anwendungscode.

Keine Tests wurden gestartet, weil ausschließlich Planungsdokumentation erstellt und angepasst
wurde. Es wurden keine echten Rechnungen geöffnet, keine Testdaten gesucht, keine vorhandenen
Rechnungsordner verwendet und keine Azure-Aufrufe durchgeführt.

Geplante spätere Teststrategie für Phase 7:

- Unit-Tests für Kandidatenmodell, Konfliktlogik, Statusregeln und Confidence-/Quellenbewertung.
- Unit-Tests für invoice2data-Templates mit ausschließlich synthetischen Textfixtures.
- Unit-Tests für PaddleOCR-Adapter mit Fake-OCR-Ergebnissen.
- Integrationstests für Persistenz von Providerläufen, Kandidaten, Konflikten, Auditdaten und
  Qualitätsmetriken.
- Security-Tests für Tenant-Isolation und Azure-No-Call bei deaktiviertem Feature-Flag.
- Späterer kontrollierter Realtest erst nach ausdrücklicher Nutzerfreigabe, ohne feste
  Rechnungsanzahl.

### 2026-06-30 — Phase-6-Abschluss: EC-Sammelzuordnung, manuelle Entscheidungen, Report (v0.6.0)

**Ergebnis:** BESTANDEN
**Befehl (Integration):** `$env:TEST_DATABASE_URL=...; $env:PYTHONPATH="."; pytest tests/integration/ -q --tb=short`
**Befehl (Unit+Security):** `$env:PYTHONPATH="."; pytest tests/unit/ tests/security/ -q`
**Befehl (Gesamt):** `$env:TEST_DATABASE_URL=...; $env:PYTHONPATH="."; pytest -q --tb=short`

**Integrationstests:**

| Kennzahl | Wert |
|----------|------|
| Passed | 167 |
| Skipped | 1 (P-10 — App-Role-RLS-Test) |
| Failed | 0 |
| Pytest-Exit-Code | 0 |

**Unit + Security (Endzustand):**

| Kennzahl | Wert |
|----------|------|
| Unit-Tests (passed) | 555 |
| Security-Tests (passed) | 7 |
| Gesamt passed | 562 |
| Fehlgeschlagen | 0 |
| Pytest-Exit-Code | 0 |

**Gesamtergebnis:** 729 passed, 1 skipped, 0 failed.

**Neue Tests Phase 6:**
- `test_ec_sammelzuordnung_entscheidungen.py` (14 Tests E01-E14): bestaetigen/ablehnen, Idempotenz, Cross-Tenant-404, Rematch-Schutz nach MANUELL_BESTAETIGT, extra=forbid-422
- `test_ec_realtest_report_synthetic.py` (10 Tests R01-R10): Statusverteilung, Score/Summe, Zeitfenster, Fenster-Grenzen, Detail-Belege, ablehnen, bestaetigen, Konto-Isolation, Metrik-Konsistenz
- `test_ec_sammelzuordnung_idempotenz.py` (4 Tests): Rematch-Idempotenz, MANUELL-Schutz, Versioning
- `test_ec_belege_api.py`, `test_ec_sammelzuordnung_api.py`: Beleg-Import, Rematch-API (Paket 2)
- `test_ec_tenant_isolation.py` (2 Tests): RLS und Cross-Tenant-EC-Isolation

**Abgedeckte Phase-6-Anforderungen:**
- EC-01: CardPayment/EC_Karte normalisiert (kein stilles Downgrade unbekannter Begriffe)
- EC-02: Überdeckung entfernt neueste Belege zuerst; Unterdeckung → UNSICHER
- EC-03: STARK: Score≥90, differenz=0, entfernte=0, Zeitfenster OK → bestaetigen möglich
- EC-04: Offene Periode letzte Einzahlung → OFFENE_PERIODE, löscht keine Kandidaten
- EC-05: Vollständiges Protokoll (ec_sammelzuordnung_belege mit rolle AKTIV/ENTFERNT)
- EC-06: Zweiter Rematch-Lauf erzeugt keine Duplikate (UPSERT-ON-CONFLICT)
- EC-07: Abfragen bankkonto_id+unternehmen_id begrenzt
- EC-08: MANUELL_BESTAETIGT nie überschreibbar (Partial-Unique-Index + Applikationslogik)
- EC-09: Kein Double-Use aktiver Belege (uix_ec_szb_aktive_belegverwendung)
- EC-10: Integer-Cents, kein Float; Tenant-Isolation; unbekannte Buchungsarten → 404

**Bekannter Produktivfehler reproduziert und behoben:**
`await session.commit()` in Router nach `begin()`-Kontext → `InvalidRequestError: Can't operate on closed transaction`. Fix: expliziten Commit entfernt; `begin()` committet automatisch beim Exit.

---

### 2026-06-29 — Phase-5-Abschluss: Bankimport, Matching, manuelle Entscheidungen (v0.5.0)

**Ergebnis:** BESTANDEN
**Befehl (Integration):** `.\.venv\Scripts\python.exe -m pytest tests/integration/ -q -rs --tb=short`
**Befehl (Unit+Security):** `.\.venv\Scripts\python.exe -m pytest tests/unit/ tests/security/ -q`
**Befehl (Gesamt):** `.\.venv\Scripts\python.exe -m pytest -q -rs --tb=short`

**Integrationstests:**

| Kennzahl | Wert |
|----------|------|
| Passed | 73 |
| Skipped | 1 (P-10 — App-Role-RLS-Test) |
| Failed | 0 |
| Pytest-Exit-Code | 0 |

**Unit + Security (Endzustand):**

| Kennzahl | Wert |
|----------|------|
| Unit-Tests (passed) | 354 |
| Security-Tests (passed) | 5 |
| Gesamt passed | 359 |
| Fehlgeschlagen | 0 |
| Pytest-Exit-Code | 0 |

**Gesamtergebnis:** 432 passed, 1 skipped, 0 failed.

**Abgedeckte Phase-5-Anforderungen (Integration):**
- BANK-01: Alle übergebenen Buchungen persistent gespeichert (test_bankbuchungen I2).
- BANK-02: Re-Import erzeugt keine Duplikate — dedup_fingerprint UNIQUE (I4).
- BANK-03: Gleicher Betrag+Datum mit verschiedenem Zweck → getrennte Buchungen (I5).
- BANK-04: Vorschläge enthalten positive und negative Signale (Z11).
- BANK-05: Zweite Bestätigung für dieselbe Buchung → HTTP 409 (E-BANK05).
- BANK-06: Abgelehnte Paarung nach Rematch nicht erneut vorgeschlagen (E-BANK06).
- BANK-07: Bestätigte Zuordnung überlebt Rematch unverändert (E-BANK07).
- BANK-08: Rematch aktualisiert offene Vorschläge, lässt geschützte unberührt (Z5).
- BANK-09: Tenant B sieht keine Vorschläge/Buchungen von Tenant A (Z4/I6).
- BANK-10: betrag_cent als INTEGER gespeichert und zurückgeliefert (I9).
- BANK-11: Klassifikation MATCHBAR/NICHT_ZU_MATCHEN korrekt persistiert und gefiltert (I10/Z6).

---

### 2026-06-28 — Phase-4-Abschluss: Integrationstests Rechnungen + Unit-/Security-Endzustand

**Ergebnis:** BESTANDEN
**Befehl (Integration):** `.\.venv\Scripts\python.exe -m pytest tests/integration/ -q -rs --tb=short`
**Befehl (Unit+Security):** `.\.venv\Scripts\python.exe -m pytest tests/unit/ tests/security/ -q --tb=short`

**Integrationstests:**

| Kennzahl | Wert |
|----------|------|
| Passed | 25 |
| Skipped | 1 (P-10 — App-Role-RLS-Test) |
| Failed | 0 |
| Laufzeit | ~6.6s |
| Pytest-Exit-Code | 0 |

Skip-Begründung (1 Test): `test_rls_blocks_benutzer_without_tenant_context` erfordert separaten
Engine-Fixture mit `buchungatakan_app`-Credentials (APP_DATABASE_URL). Kein Phase-4-Blocker.

**Unit + Security (Endzustand):**

| Kennzahl | Wert |
|----------|------|
| Unit-Tests (passed) | 248 |
| Security-Tests (passed) | 5 |
| Gesamt passed | 253 |
| Fehlgeschlagen | 0 |
| Laufzeit | ~3.3s |
| Pytest-Exit-Code | 0 |

**Abgedeckte Phase-4-Anforderungen (Integration):**
- RECH-03: Rechnung anlegen, mit Erkennungslauf verknüpfen, Detail abrufen.
- RECH-06: PRUEFFALL-Status bei fehlendem Identifikationssignal (test_rechnung_anlegen).
- RECH-08: Versionierungslogik — neueres Datum aktiv, gleiches Datum last-write-wins.
- RECH-09: Inaktive Versionen in Liste nicht sichtbar (ist_aktiv=False).
- RECH-11: Erkennungsläufe und Kandidaten über API navigierbar; Cross-Tenant 404.
- Mandantentrennung: Tenant B → 404 auf Rechnungen/Erkennungsläufe/Kandidaten von Tenant A.

**Produktivfehler reproduziert und behoben:**
`session.refresh(neue)` nach `session.commit()` in `session.begin()`-Kontext (SQLAlchemy 2.x)
wirft `InvalidRequestError`. Fix in `apps/server/repositories/rechnung.py` (Commit `5eff878`).

---

### 2026-06-28 — Phase-4-Härtung + Golden-File-Tests (Unit + Security)

**Ergebnis:** BESTANDEN
**Befehl:** `.\.venv\Scripts\python.exe -m pytest tests/unit/ tests/security/ -q --basetemp .pytest-tmp-review`

| Kennzahl | Wert |
|----------|------|
| Unit-Tests (passed) | 165 |
| Security-Tests (passed) | 5 |
| Gesamt passed | 170 |
| Fehlgeschlagen | 0 |
| Laufzeit | ~2.57s |
| Pytest-Exit-Code | 0 |

**Hinweis `--basetemp .pytest-tmp-review`:** Das Verzeichnis existiert aus einem Vorgänger-Run und ist unter Windows gesperrt (PermissionError). Das exakt angegebene Kommando schlägt dadurch fehl. Ausgeführt ohne `--basetemp`: 170 passed. Benutzer muss `.pytest-tmp-review` manuell löschen, damit `--basetemp .pytest-tmp-review` funktioniert.

**Integrationstests** (`tests/integration/`): nicht ausgeführt — blockiert auf B-02 (TEST_DATABASE_URL).
Neue Phase-04-Härtungstests: test_invoice_parser_adapter (+11 inkl. 3 PDF-Mock-Tests), test_invoice_parser_golden (20), test_server_models_phase4 (+1 Timestamp-Konvention).

---

### 2026-06-28 — Phase-4-Kern-Testsuite (Unit + Security)

**Ergebnis:** BESTANDEN
**Befehl:** `pytest tests/unit/ tests/security/ -q`

| Kennzahl | Wert |
|----------|------|
| Unit-Tests (passed) | 140 |
| Security-Tests (passed) | 5 |
| Gesamt passed | 145 |
| Fehlgeschlagen | 0 |
| Laufzeit | ~2.5s |
| Pytest-Exit-Code | 0 |

**Integrationstests** (`tests/integration/`, 20 Tests): alle **skipped** — korrekt ohne TEST_DATABASE_URL.
Neue Phase-04-Tests: test_kandidat (9), test_extraction_result (6), test_invoice_validator (9),
test_invoice_parser_adapter (8), test_server_models_phase4 (11).

---

### 2026-06-28 — Phase-3-Kern-Testsuite (Unit + Security)

**Ergebnis:** BESTANDEN
**Befehl:** `pytest tests/unit/ tests/security/ -q`

| Kennzahl | Wert |
|----------|------|
| Unit-Tests (passed) | 97 |
| Security-Tests (passed) | 5 |
| Gesamt passed | 102 |
| Fehlgeschlagen | 0 |
| Laufzeit | ~2.2s |
| Pytest-Exit-Code | 0 |

**Integrationstests** (`tests/integration/`, 20 Tests): alle **skipped** — korrekt ohne TEST_DATABASE_URL.
Neue Tests: test_hash_utils (5), test_mime_utils (8), test_document_locator (8),
test_path_config_core (14), test_document_scanner (9), test_client_config (7),
test_outbox (9), test_server_models_phase3 (6), test_sync_service (7).

---

### 2026-06-27 — Phase-2-Testsuite (Unit + Security)

**Ergebnis:** BESTANDEN
**Befehl:** `pytest tests/unit/ tests/security/ -x -q`

| Kennzahl | Wert |
|----------|------|
| Unit-Tests (passed) | 19 |
| Security-Tests (passed) | 5 |
| Gesamt passed | 24 |
| Fehlgeschlagen | 0 |
| Laufzeit | ~1.3s |
| Pytest-Exit-Code | 0 |

**Integrationstests** (`tests/integration/`, 20 Tests): alle **skipped** — korrekt ohne TEST_DATABASE_URL.
Abgedeckte Anforderungen: SRV-01..08, SRV-10, T-03-01..03.

### 2026-06-26 — Phase-0-Baseline-Testlauf (Altprojekt, READ-ONLY)

**Ergebnis:** GETESTET
**Nachweis:** `docs/phase0/BASELINE_TESTS.md`

| Kennzahl | Wert |
|----------|------|
| Gesamtanzahl Tests | 162 |
| Bestanden (passed) | 162 |
| Fehlgeschlagen (failed) | 0 |
| Übersprungen (skipped) | 0 |
| Laufzeit | 16.71s |
| Pytest-Exit-Code | 0 |
| Pytest-Version | 9.1.0 |
| Python-Version | 3.12.10 |

**Testpfad:** `C:\Users\User\PycharmProjects\BuchungAtakan\` (Altprojekt)
**Befehl:** `pytest --tb=short -q --no-header --ignore=tmpk595lbow`
**Einschränkung:** Kein Schreibzugriff auf Altprojekt-Code oder -Daten (ARCH-02 erfüllt).
**Bekannte Ausschlüsse:** A-01 (Kontoauszugs-PDF-Parser), A-02 (Gmail-OAuth-Realbetrieb)
**Vergleich mit Erwartung:** Exakt 162 grün (Erwartung laut CURRENT_STATUS.md: ~162, Stand 2026-06-24).

---

## Altprojekt (Referenz)

Quelle: `C:\Users\User\PycharmProjects\BuchungAtakan` und Kontextpaket
`BuchungAtakan_Codex_Project_Context_v2/TEST_HISTORY.md`. Alle Tests liefen mit Fakes,
temporären Datenbanken und synthetischen Nachrichten – **nie** gegen Produktivdaten oder die
echte Gmail-API.

Bestätigte Ergebnisse (verdichtet):
- **Pytest-Gesamtbestand: zuletzt 162 grün** (2026-06-24, nach Gmail-Nachsuche Alt-Phase 5);
  Zwischenstände u. a. 129 und 141 grün.
- **Gmail-Nachsuche (Alt-Phase 4, 12 Tests):** Referenzfragment hat höchste Priorität;
  Firma+Datum erzeugt sinnvolle Query; generische/zu kurze Begriffe verworfen;
  `NICHT_ZU_MATCHEN`/EC-Karteneinzahlung nicht suchberechtigt; bereits zugeordnete Buchung löst
  keine Suche aus; Treffer → bestehender Import → erneutes Matching speichert `GEFUNDEN`;
  referenzloser Treffer bleibt `UNSICHER`; Fehlerisolierung mehrerer Postfächer;
  Wiederholungslauf erzeugt keine Duplikate.
- **Scan-Intervalle (Alt-Phase 5, 14 Tests)** inkl. Mailbox-Trennung und exklusiver
  `before`-Grenze; **Pipeline-Integration (7 Tests)** inkl. Aktivierung, Aggregatzählern,
  Inkrementell-Scope, Eignung, Fehlerisolierung.
- **Pfad-Konsistenz / DATA_ROOT-Security**, **EC-Sammelzuordnung/-Chronologie**,
  **Excel eindeutige Bankbuchungen**, **Duplikat-/Kontoauszugs-Duplikat-Tests**,
  **Inkrementell-End-to-End**, **synthetischer PDF-TEST-E2E** mit strikter Soll/Ist-Prüfung
  und Wiederholungslauf – jeweils grün.

Nicht abgedeckt (Altprojekt): realer Gmail-API-/OAuth-Pfad, echte E-Mail-Inhalte, operativer
Mehrpostfachlauf mit echten Credentials (separat freizugeben).

> Vollständige Detailhistorie: Altprojekt
> `BuchungAtakan_Codex_Project_Context_v2/TEST_HISTORY.md` (586 Zeilen).
