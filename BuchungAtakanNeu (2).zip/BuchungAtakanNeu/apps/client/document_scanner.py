from pathlib import Path

SUPPORTED_EXTENSIONS: frozenset[str] = frozenset(
    {".pdf", ".csv", ".xlsx", ".xls", ".png", ".jpg", ".jpeg", ".tiff"}
)


def scan_for_documents(
    data_root: Path,
    *,
    scan_dir: str = "dump",
    extensions: frozenset[str] = SUPPORTED_EXTENSIONS,
) -> list[Path]:
    """Gibt sortierte Liste absoluter Pfade aller Dokumente im scan_dir zurueck."""
    target = data_root / scan_dir
    if not target.exists():
        return []
    return sorted(
        p for p in target.rglob("*") if p.is_file() and p.suffix.lower() in extensions
    )


def to_relative_posix(path: Path, data_root: Path) -> str:
    """POSIX-Pfad relativ zu data_root (CLI-02: kein absoluter Windows-Pfad)."""
    return path.relative_to(data_root).as_posix()
