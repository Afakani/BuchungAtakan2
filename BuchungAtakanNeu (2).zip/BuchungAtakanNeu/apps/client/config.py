from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from uuid import UUID, uuid4

_DEFAULT_CONFIG_FILE = Path.home() / ".buchungatakan" / "client.json"
_ENV_SERVER_URL = "BUCHUNG_ATAKAN_SERVER_URL"
_ENV_DATA_ROOT = "BUCHUNG_ATAKAN_DATA_ROOT"


@dataclass
class ClientConfig:
    server_url: str
    installation_id: UUID
    data_root: Path

    @classmethod
    def load(cls, config_file: Path = _DEFAULT_CONFIG_FILE) -> ClientConfig:
        env_server = os.environ.get(_ENV_SERVER_URL)
        env_root = os.environ.get(_ENV_DATA_ROOT)

        if not config_file.exists():
            if env_server and env_root:
                return cls(
                    server_url=env_server.rstrip("/"),
                    installation_id=uuid4(),
                    data_root=Path(env_root),
                )
            raise FileNotFoundError(
                f"Keine Client-Konfiguration gefunden: {config_file}. "
                f"Erstelle die Datei oder setze {_ENV_SERVER_URL} und {_ENV_DATA_ROOT}."
            )

        with config_file.open(encoding="utf-8") as f:
            data = json.load(f)

        return cls(
            server_url=(env_server or data["server_url"]).rstrip("/"),
            installation_id=UUID(data["installation_id"]),
            data_root=Path(env_root or data["data_root"]),
        )

    def save(self, config_file: Path = _DEFAULT_CONFIG_FILE) -> None:
        config_file.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "server_url": self.server_url,
            "installation_id": str(self.installation_id),
            "data_root": str(self.data_root),
        }
        with config_file.open("w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, ensure_ascii=False)

    @classmethod
    def create_new(cls, server_url: str, data_root: Path) -> ClientConfig:
        return cls(
            server_url=server_url.rstrip("/"),
            installation_id=uuid4(),
            data_root=data_root,
        )
