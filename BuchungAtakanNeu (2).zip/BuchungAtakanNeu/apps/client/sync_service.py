from pathlib import Path
from uuid import UUID

from apps.client.api_client import BuchungAtakanClient
from apps.client.document_scanner import scan_for_documents, to_relative_posix
from apps.client.outbox import DokumentOutbox
from packages.core.hash_utils import sha256_of_file
from packages.core.mime_utils import detect_mime_type


class DokumentSyncService:
    def __init__(
        self,
        client: BuchungAtakanClient,
        data_root: Path,
        installation_id: UUID,
        outbox: DokumentOutbox,
    ) -> None:
        self._client = client
        self._data_root = data_root
        self._installation_id = installation_id
        self._outbox = outbox

    async def sync_alle_dokumente(self) -> dict[str, int]:
        """Scannt dump-Verzeichnis, sendet Metadaten oder legt in Outbox ab (CLI-06/08)."""
        paths = scan_for_documents(self._data_root)
        ergebnis: dict[str, int] = {"gesendet": 0, "outbox": 0}

        for path in paths:
            payload = self._build_payload(path)
            try:
                await self._client.dokument_sync(payload)
                ergebnis["gesendet"] += 1
            except Exception:
                self._outbox.enqueue("/api/v1/dokumente", payload)
                ergebnis["outbox"] += 1

        return ergebnis

    async def outbox_verarbeiten(self) -> dict[str, int]:
        """Verarbeitet ausstehende Outbox-Eintraege idempotent (CLI-07)."""
        pending = self._outbox.pending()
        ergebnis: dict[str, int] = {"gesendet": 0, "fehler": 0}

        for entry in pending:
            try:
                await self._client.dokument_sync(entry.payload)
                self._outbox.mark_sent(entry.id)
                ergebnis["gesendet"] += 1
            except Exception as exc:
                self._outbox.mark_failed(entry.id, str(exc))
                ergebnis["fehler"] += 1

        return ergebnis

    def _build_payload(self, path: Path) -> dict:
        return {
            "installation_id": str(self._installation_id),
            "sha256": sha256_of_file(path),
            "relative_path": to_relative_posix(path, self._data_root),
            "dateiname": path.name,
            "dateigroesse": path.stat().st_size,
            "mime_type": detect_mime_type(path),
        }
