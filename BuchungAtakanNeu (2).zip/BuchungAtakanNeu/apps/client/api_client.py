from __future__ import annotations

from types import TracebackType
from uuid import UUID

import httpx


class BuchungAtakanClient:
    def __init__(self, base_url: str, token: str | None = None) -> None:
        self._base_url = base_url.rstrip("/")
        self._token = token
        self._client: httpx.AsyncClient | None = None

    def set_token(self, token: str) -> None:
        self._token = token

    def _auth_headers(self) -> dict[str, str]:
        if self._token:
            return {"Authorization": f"Bearer {self._token}"}
        return {}

    async def __aenter__(self) -> BuchungAtakanClient:
        self._client = httpx.AsyncClient(base_url=self._base_url, timeout=30.0)
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def login(self, benutzername: str, passwort: str) -> str:
        """Authentifiziert und speichert JWT-Token. Gibt Token zurueck."""
        assert self._client is not None, "Nicht im Context-Manager"
        resp = await self._client.post(
            "/api/v1/auth/login",
            data={"username": benutzername, "password": passwort},
        )
        resp.raise_for_status()
        token: str = resp.json()["access_token"]
        self._token = token
        return token

    async def installation_registrieren(
        self,
        installation_id: UUID,
        bezeichnung: str | None = None,
    ) -> dict:
        """Idempotente Installations-Registrierung."""
        assert self._client is not None
        resp = await self._client.post(
            "/api/v1/installationen",
            json={"installation_id": str(installation_id), "bezeichnung": bezeichnung},
            headers=self._auth_headers(),
        )
        resp.raise_for_status()
        return resp.json()

    async def dokument_sync(self, payload: dict) -> dict:
        """Metadaten-Sync (kein File-Upload, CLI-08). Idempotent per sha256."""
        assert self._client is not None
        resp = await self._client.post(
            "/api/v1/dokumente",
            json=payload,
            headers=self._auth_headers(),
        )
        resp.raise_for_status()
        return resp.json()

    async def verfuegbarkeit_aktualisieren(
        self,
        dokument_id: UUID,
        verfuegbarkeit: str,
    ) -> dict:
        """Setzt Verfuegbarkeitsstatus (CLI-10: kein stilles Loeschen)."""
        assert self._client is not None
        resp = await self._client.patch(
            f"/api/v1/dokumente/{dokument_id}/verfuegbarkeit",
            json={"verfuegbarkeit": verfuegbarkeit},
            headers=self._auth_headers(),
        )
        resp.raise_for_status()
        return resp.json()
