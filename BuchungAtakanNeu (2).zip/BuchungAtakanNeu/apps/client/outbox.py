import json
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import StrEnum
from pathlib import Path
from uuid import uuid4


class OutboxStatus(StrEnum):
    PENDING = "PENDING"
    FAILED = "FAILED"


@dataclass
class OutboxEntry:
    id: str
    endpoint: str
    payload: dict
    created_at: str
    attempt_count: int
    status: OutboxStatus
    last_error: str | None


_SCHEMA = """
CREATE TABLE IF NOT EXISTS outbox (
    id TEXT PRIMARY KEY,
    endpoint TEXT NOT NULL,
    payload TEXT NOT NULL,
    created_at TEXT NOT NULL,
    attempt_count INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'PENDING',
    last_error TEXT
)
"""


class DokumentOutbox:
    def __init__(self, db_path: Path) -> None:
        self._db_path = db_path
        self._init_db()

    def _init_db(self) -> None:
        with sqlite3.connect(self._db_path) as conn:
            conn.execute(_SCHEMA)

    def enqueue(self, endpoint: str, payload: dict) -> str:
        entry_id = str(uuid4())
        now = datetime.now(tz=timezone.utc).isoformat()
        with sqlite3.connect(self._db_path) as conn:
            conn.execute(
                "INSERT INTO outbox (id, endpoint, payload, created_at) VALUES (?, ?, ?, ?)",
                (entry_id, endpoint, json.dumps(payload), now),
            )
        return entry_id

    def pending(self) -> list[OutboxEntry]:
        with sqlite3.connect(self._db_path) as conn:
            rows = conn.execute(
                "SELECT id, endpoint, payload, created_at, attempt_count, status, last_error "
                "FROM outbox WHERE status = 'PENDING' ORDER BY created_at"
            ).fetchall()
        return [
            OutboxEntry(
                id=r[0],
                endpoint=r[1],
                payload=json.loads(r[2]),
                created_at=r[3],
                attempt_count=r[4],
                status=OutboxStatus(r[5]),
                last_error=r[6],
            )
            for r in rows
        ]

    def mark_sent(self, entry_id: str) -> None:
        with sqlite3.connect(self._db_path) as conn:
            conn.execute("DELETE FROM outbox WHERE id = ?", (entry_id,))

    def mark_failed(self, entry_id: str, error: str) -> None:
        with sqlite3.connect(self._db_path) as conn:
            conn.execute(
                "UPDATE outbox SET status = 'FAILED', last_error = ?, "
                "attempt_count = attempt_count + 1 WHERE id = ?",
                (error, entry_id),
            )

    def reset_failed(self) -> int:
        with sqlite3.connect(self._db_path) as conn:
            cursor = conn.execute(
                "UPDATE outbox SET status = 'PENDING', last_error = NULL WHERE status = 'FAILED'"
            )
            return cursor.rowcount
