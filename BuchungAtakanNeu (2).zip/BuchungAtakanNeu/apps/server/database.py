from collections.abc import AsyncGenerator
from typing import Annotated

from fastapi import Depends
from sqlalchemy.engine import URL, make_url
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from apps.server.config import settings


def get_async_url() -> URL:
    return make_url(settings.DATABASE_URL).set(drivername="postgresql+asyncpg")


engine = create_async_engine(get_async_url(), echo=False, pool_pre_ping=True)
async_session_factory = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


async def get_session() -> AsyncGenerator[AsyncSession, None]:
    async with async_session_factory() as session:
        async with session.begin():
            yield session


DBSession = Annotated[AsyncSession, Depends(get_session)]
