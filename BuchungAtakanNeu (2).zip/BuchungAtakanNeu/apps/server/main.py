from fastapi import FastAPI

from apps.server.auth import router as auth_router
from apps.server.exceptions import register_exception_handlers
from apps.server.routers import bankbuchungen, dokumente, ec_sammelzuordnungen, health, hybrid, installationen, rechnungen, unternehmen, zuordnungen


def create_app() -> FastAPI:
    app = FastAPI(
        title="BuchungAtakan API",
        version="0.5.0",
        docs_url="/api/docs",
        redoc_url="/api/redoc",
    )
    register_exception_handlers(app)
    app.include_router(health.router)
    app.include_router(auth_router.router)
    app.include_router(unternehmen.router)
    app.include_router(installationen.router)
    app.include_router(dokumente.router)
    app.include_router(rechnungen.router)
    app.include_router(bankbuchungen.router)
    app.include_router(zuordnungen.router)
    app.include_router(ec_sammelzuordnungen.router)
    app.include_router(hybrid.router)
    return app


app = create_app()
