from enum import StrEnum
from uuid import UUID

from sqlalchemy import ForeignKey, Integer, Text, UniqueConstraint, text
from sqlalchemy.orm import Mapped, mapped_column

from apps.server.models.base import Base, TenantMixin, TimestampMixin


class DokumentVerfuegbarkeit(StrEnum):
    LOCAL_AVAILABLE = "LOCAL_AVAILABLE"
    LOCAL_MISSING = "LOCAL_MISSING"
    UNKNOWN = "UNKNOWN"


class Dokument(Base, TenantMixin, TimestampMixin):
    __tablename__ = "dokumente"
    __table_args__ = (
        UniqueConstraint("unternehmen_id", "sha256", name="uq_dokument_tenant_sha256"),
    )

    id: Mapped[UUID] = mapped_column(primary_key=True, server_default=text("gen_random_uuid()"))
    installation_id: Mapped[UUID] = mapped_column(
        ForeignKey("installationen.id"), nullable=False, index=True
    )
    sha256: Mapped[str] = mapped_column(Text, nullable=False)
    relative_path: Mapped[str] = mapped_column(Text, nullable=False)
    dateiname: Mapped[str] = mapped_column(Text, nullable=False)
    dateigroesse: Mapped[int] = mapped_column(Integer, nullable=False)
    mime_type: Mapped[str] = mapped_column(Text, nullable=False)
    verfuegbarkeit: Mapped[str] = mapped_column(
        Text, nullable=False, server_default="LOCAL_AVAILABLE"
    )
