"""ORM-Modelle fuer Phase-04: Rechnung, Erkennungslauf, RechnungsKandidat."""
from decimal import Decimal
from enum import StrEnum
from uuid import UUID

from sqlalchemy import Boolean, ForeignKey, Integer, Numeric, Text, UniqueConstraint, text
from sqlalchemy.orm import Mapped, mapped_column

from apps.server.models.base import Base, TenantMixin, TimestampMixin


class RechnungsStatus(StrEnum):
    NEU = "NEU"
    FREIGEGEBEN = "FREIGEGEBEN"
    PRUEFFALL = "PRUEFFALL"
    ABGELEHNT = "ABGELEHNT"


class Rechnung(Base, TenantMixin, TimestampMixin):
    __tablename__ = "rechnungen"
    __table_args__ = (
        UniqueConstraint(
            "unternehmen_id", "rechnungsnummer", "version_lfd_nr",
            name="uq_rechnung_tenant_nr_version",
        ),
    )

    id: Mapped[UUID] = mapped_column(primary_key=True, server_default=text("gen_random_uuid()"))
    dokument_id: Mapped[UUID] = mapped_column(
        ForeignKey("dokumente.id"), nullable=False, index=True
    )
    rechnungsnummer: Mapped[str | None] = mapped_column(Text, nullable=True, index=True)
    rechnungsdatum: Mapped[str | None] = mapped_column(Text, nullable=True)
    gesamtbetrag: Mapped[Decimal | None] = mapped_column(Numeric(12, 2), nullable=True)
    nettobetrag: Mapped[Decimal | None] = mapped_column(Numeric(12, 2), nullable=True)
    steuerbetrag: Mapped[Decimal | None] = mapped_column(Numeric(12, 2), nullable=True)
    waehrung: Mapped[str | None] = mapped_column(Text, nullable=True)
    zahlungsart: Mapped[str | None] = mapped_column(Text, nullable=True)
    lieferant_name: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(Text, nullable=False, server_default="NEU")
    # RECH-08: Versionsregel — neuere Rechnung ersetzt ältere aktive
    version_lfd_nr: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("1"))
    # RECH-09: ersetzte Versionen nicht mehr für Auto-Matching
    ist_aktiv: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text("true"))


class Erkennungslauf(Base, TenantMixin, TimestampMixin):
    """Traceability-Record pro Extraktionslauf (RECH-03)."""
    __tablename__ = "erkennungslaeufe"

    id: Mapped[UUID] = mapped_column(primary_key=True, server_default=text("gen_random_uuid()"))
    dokument_id: Mapped[UUID] = mapped_column(
        ForeignKey("dokumente.id"), nullable=False, index=True
    )
    rechnung_id: Mapped[UUID | None] = mapped_column(
        ForeignKey("rechnungen.id"), nullable=True, index=True
    )
    extraktion_status: Mapped[str] = mapped_column(Text, nullable=False)
    extraktion_confidence: Mapped[Decimal | None] = mapped_column(Numeric(4, 3), nullable=True)
    fehler: Mapped[str | None] = mapped_column(Text, nullable=True)


class RechnungsKandidat(Base, TenantMixin, TimestampMixin):
    """Per-Feld-Kandidat für RECH-01-Nachvollziehbarkeit."""
    __tablename__ = "rechnungs_kandidaten"

    id: Mapped[UUID] = mapped_column(primary_key=True, server_default=text("gen_random_uuid()"))
    erkennungslauf_id: Mapped[UUID] = mapped_column(
        ForeignKey("erkennungslaeufe.id"), nullable=False, index=True
    )
    feld: Mapped[str] = mapped_column(Text, nullable=False)
    rohwert: Mapped[str] = mapped_column(Text, nullable=False)
    normwert: Mapped[str | None] = mapped_column(Text, nullable=True)
    methode: Mapped[str] = mapped_column(Text, nullable=False)
    quelle: Mapped[str] = mapped_column(Text, nullable=False)
    confidence: Mapped[Decimal] = mapped_column(Numeric(4, 3), nullable=False)
