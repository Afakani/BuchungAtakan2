"""ORM-Modelle fuer Hybrid-Rechnungsextraktion Phase 07 (HYB-07/08, 17/18)."""
from datetime import datetime
from decimal import Decimal
from uuid import UUID

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, Numeric, Text, UniqueConstraint, func, text
from sqlalchemy.orm import Mapped, mapped_column

from apps.server.models.base import Base, TenantMixin, TimestampMixin


class HybridErkennungslauf(Base, TenantMixin, TimestampMixin):
    """Protokoll eines einzelnen Provider-Laufs (HYB-07)."""

    __tablename__ = "hybrid_erkennungslaeufe"

    id: Mapped[UUID] = mapped_column(primary_key=True, server_default=text("gen_random_uuid()"))
    erkennungslauf_id: Mapped[UUID | None] = mapped_column(
        ForeignKey("erkennungslaeufe.id", ondelete="CASCADE"), nullable=True, index=True
    )
    provider_name: Mapped[str] = mapped_column(Text, nullable=False)
    provider_version: Mapped[str | None] = mapped_column(Text, nullable=True)
    laufstatus: Mapped[str] = mapped_column(Text, nullable=False)
    fehlercode: Mapped[str | None] = mapped_column(Text, nullable=True)
    lauf_dauer_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    seiten_anzahl: Mapped[int | None] = mapped_column(Integer, nullable=True)


class HybridKandidatOrm(Base, TenantMixin, TimestampMixin):
    """Persistierter HybridKandidat mit vollstaendiger Provider-Herkunft (HYB-07)."""

    __tablename__ = "hybrid_kandidaten"

    id: Mapped[UUID] = mapped_column(primary_key=True, server_default=text("gen_random_uuid()"))
    hybrid_erkennungslauf_id: Mapped[UUID] = mapped_column(
        ForeignKey("hybrid_erkennungslaeufe.id", ondelete="CASCADE"), nullable=False, index=True
    )
    feld: Mapped[str] = mapped_column(Text, nullable=False)
    rohwert: Mapped[str] = mapped_column(Text, nullable=False)
    normwert: Mapped[str | None] = mapped_column(Text, nullable=True)
    methode: Mapped[str] = mapped_column(Text, nullable=False)
    provider_name: Mapped[str] = mapped_column(Text, nullable=False)
    provider_version: Mapped[str | None] = mapped_column(Text, nullable=True)
    confidence: Mapped[Decimal] = mapped_column(Numeric(4, 3), nullable=False)
    seite: Mapped[int | None] = mapped_column(Integer, nullable=True)
    bbox_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    validierungsbefund: Mapped[str | None] = mapped_column(Text, nullable=True)
    konflikt_gruppe: Mapped[str | None] = mapped_column(Text, nullable=True)
    auswahl_status: Mapped[str | None] = mapped_column(Text, nullable=True)
    auswahl_grund: Mapped[str | None] = mapped_column(Text, nullable=True)


class HybridKonflikt(Base, TenantMixin, TimestampMixin):
    """Explizit persistierter Konflikt zwischen Kandidaten (HYB-05)."""

    __tablename__ = "hybrid_konflikte"

    id: Mapped[UUID] = mapped_column(primary_key=True, server_default=text("gen_random_uuid()"))
    erkennungslauf_id: Mapped[UUID | None] = mapped_column(
        ForeignKey("erkennungslaeufe.id", ondelete="CASCADE"), nullable=True, index=True
    )
    feld: Mapped[str] = mapped_column(Text, nullable=False)
    konflikt_gruppe: Mapped[str | None] = mapped_column(Text, nullable=True)
    kandidaten_ids_json: Mapped[str | None] = mapped_column(Text, nullable=True)


class HybridStatusentscheidung(Base, TenantMixin, TimestampMixin):
    """Statusentscheidung fuer einen Erkennungslauf (HYB-06)."""

    __tablename__ = "hybrid_statusentscheidungen"
    __table_args__ = (
        UniqueConstraint(
            "unternehmen_id", "erkennungslauf_id", name="uq_hybrid_status_lauf"
        ),
    )

    id: Mapped[UUID] = mapped_column(primary_key=True, server_default=text("gen_random_uuid()"))
    erkennungslauf_id: Mapped[UUID | None] = mapped_column(
        ForeignKey("erkennungslaeufe.id", ondelete="CASCADE"), nullable=True, index=True
    )
    hybrid_status: Mapped[str] = mapped_column(Text, nullable=False)
    gruende_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    pflichtfelder_ok: Mapped[bool] = mapped_column(
        Boolean, nullable=False, server_default=text("false")
    )
    math_validierung_ok: Mapped[bool | None] = mapped_column(Boolean, nullable=True)
    konflikt_frei: Mapped[bool] = mapped_column(
        Boolean, nullable=False, server_default=text("false")
    )
    confidence_ausreichend: Mapped[bool | None] = mapped_column(Boolean, nullable=True)
    #: Nullable (07-03A) — Altzeilen bleiben NULL, kein Backfill mit erfundenen Werten.
    dokument_klasse: Mapped[str | None] = mapped_column(Text, nullable=True)


class HybridAuditBewertung(Base, TenantMixin):
    """Auditbewertung einer HybridStatusentscheidung (HYB-17). Append-only: bestehende
    Bewertungen werden nie ueberschrieben, mehrere Bewertungen pro Statusentscheidung
    sind erlaubt. Ausschliesslich strukturierte Booleanfelder -- kein Freitext, keine
    Originalwerte, keine Betraege, keine Rechnungsdaten, keine Dateinamen/Pfade/Hashes.
    """

    __tablename__ = "hybrid_audit_bewertungen"

    id: Mapped[UUID] = mapped_column(primary_key=True, server_default=text("gen_random_uuid()"))
    hybrid_statusentscheidung_id: Mapped[UUID] = mapped_column(
        ForeignKey("hybrid_statusentscheidungen.id", ondelete="CASCADE"), nullable=False, index=True
    )
    rechnungsnummer_korrekt: Mapped[bool] = mapped_column(Boolean, nullable=False)
    rechnungsdatum_korrekt: Mapped[bool] = mapped_column(Boolean, nullable=False)
    gesamtbetrag_korrekt: Mapped[bool] = mapped_column(Boolean, nullable=False)
    lieferant_korrekt: Mapped[bool] = mapped_column(Boolean, nullable=False)
    steuerwerte_korrekt: Mapped[bool] = mapped_column(Boolean, nullable=False)
    empfaenger_korrekt: Mapped[bool] = mapped_column(Boolean, nullable=False)
    bewertet_am: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
