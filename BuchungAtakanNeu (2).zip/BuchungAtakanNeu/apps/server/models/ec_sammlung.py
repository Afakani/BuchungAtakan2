"""ORM-Modelle fuer Phase-06: EC-Sammelzuordnung.

Neue Tabellen (Migration 010):
  ec_belege                  — Einzelne EC-Kartenbelege (Paket 2: +bankkonto_id, +import_fingerprint)
  ec_sammellaeufe            — Protokoll eines Gruppierungslaufs
  ec_sammelzuordnungen       — Ergebnis (Vorschlag oder Entscheidung) (Paket 2: +gruppen_fingerprint, +signale)
  ec_sammelzuordnung_belege  — Bruecke: Zuordnung ↔ Belege (mit Rolle)

Alle Tabellen:
  - ENABLE RLS / FORCE RLS
  - Composite FKs (id, unternehmen_id) fuer Cross-Tenant-Sicherheit
  - Integer-Cents (kein Float)
"""
from datetime import date, datetime
from typing import Any
from uuid import UUID

from sqlalchemy import (
    Date,
    DateTime,
    ForeignKey,
    ForeignKeyConstraint,
    Index,
    Integer,
    JSON,
    Text,
    UniqueConstraint,
    func,
    text,
)
from sqlalchemy.orm import Mapped, mapped_column

from apps.server.models.base import Base, TenantMixin, TimestampMixin


class EcBeleg(Base, TenantMixin, TimestampMixin):
    """Einzelner EC-Kartenbeleg aus dem Kassensystem."""
    __tablename__ = "ec_belege"
    __table_args__ = (
        UniqueConstraint("id", "unternehmen_id", name="uq_ec_belege_id_unternehmen"),
        UniqueConstraint("unternehmen_id", "import_fingerprint", name="uq_ec_beleg_import_fingerprint"),
        ForeignKeyConstraint(
            ["bankkonto_id", "unternehmen_id"],
            ["bankkonten.id", "bankkonten.unternehmen_id"],
            name="fk_ec_belege_bankkonto_tenant",
        ),
    )

    id: Mapped[UUID] = mapped_column(primary_key=True, server_default=text("gen_random_uuid()"))
    bankkonto_id: Mapped[UUID] = mapped_column(ForeignKey("bankkonten.id"), nullable=False, index=True)
    betrag_cent: Mapped[int] = mapped_column(Integer, nullable=False)
    buchungsdatum: Mapped[date] = mapped_column(Date, nullable=False, index=True)
    zahlungskategorie: Mapped[str] = mapped_column(
        Text, nullable=False, server_default=text("'UNBEKANNT'"), index=True
    )
    original_kategorie: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(
        Text, nullable=False, server_default=text("'VERFUEGBAR'"), index=True
    )
    waehrung: Mapped[str] = mapped_column(Text, nullable=False, server_default=text("'EUR'"))
    import_fingerprint: Mapped[str] = mapped_column(Text, nullable=False)
    quelldatei: Mapped[str | None] = mapped_column(Text, nullable=True)
    quell_position: Mapped[str | None] = mapped_column(Text, nullable=True)
    transaktionsreferenz: Mapped[str | None] = mapped_column(Text, nullable=True)
    terminal_id: Mapped[str | None] = mapped_column(Text, nullable=True)
    belegzeit: Mapped[str | None] = mapped_column(Text, nullable=True)
    dokument_id: Mapped[UUID | None] = mapped_column(ForeignKey("dokumente.id"), nullable=True)
    externe_id: Mapped[str | None] = mapped_column(Text, nullable=True)


class EcSammellauf(Base, TenantMixin, TimestampMixin):
    """Protokoll eines Gruppierungslaufs fuer eine EC-Einzahlung."""
    __tablename__ = "ec_sammellaeufe"
    __table_args__ = (
        UniqueConstraint("id", "unternehmen_id", name="uq_ec_sammellaeufe_id_unternehmen"),
        ForeignKeyConstraint(
            ["bankbuchung_id", "unternehmen_id"],
            ["bankbuchungen.id", "bankbuchungen.unternehmen_id"],
            name="fk_ec_sammellaeufe_bankbuchung_tenant",
        ),
    )

    id: Mapped[UUID] = mapped_column(primary_key=True, server_default=text("gen_random_uuid()"))
    bankbuchung_id: Mapped[UUID] = mapped_column(
        ForeignKey("bankbuchungen.id"), nullable=False, index=True
    )
    matcher_version: Mapped[str] = mapped_column(Text, nullable=False)
    lauf_zeitpunkt: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )


class EcSammelzuordnung(Base, TenantMixin, TimestampMixin):
    """Vorgeschlagene oder bestaetigte EC-Sammelzuordnung."""
    __tablename__ = "ec_sammelzuordnungen"
    __table_args__ = (
        UniqueConstraint("id", "unternehmen_id", name="uq_ec_sammelzuordnungen_id_unternehmen"),
        ForeignKeyConstraint(
            ["sammellauf_id", "unternehmen_id"],
            ["ec_sammellaeufe.id", "ec_sammellaeufe.unternehmen_id"],
            name="fk_ec_sammelzuordnungen_sammellauf_tenant",
        ),
        ForeignKeyConstraint(
            ["bankbuchung_id", "unternehmen_id"],
            ["bankbuchungen.id", "bankbuchungen.unternehmen_id"],
            name="fk_ec_sammelzuordnungen_bankbuchung_tenant",
        ),
        ForeignKeyConstraint(
            ["bankkonto_id", "unternehmen_id"],
            ["bankkonten.id", "bankkonten.unternehmen_id"],
            name="fk_ec_sammelzuordnungen_bankkonto_tenant",
        ),
        Index(
            "uix_ec_sammelz_eine_bestaetigte_pro_buchung",
            "unternehmen_id",
            "bankbuchung_id",
            unique=True,
            postgresql_where=text("status = 'MANUELL_BESTAETIGT'"),
        ),
        Index(
            "uix_ec_sammelz_eine_auto_pro_buchung",
            "unternehmen_id",
            "bankbuchung_id",
            unique=True,
            postgresql_where=text("status NOT IN ('MANUELL_BESTAETIGT', 'MANUELL_ABGELEHNT')"),
        ),
    )

    id: Mapped[UUID] = mapped_column(primary_key=True, server_default=text("gen_random_uuid()"))
    sammellauf_id: Mapped[UUID] = mapped_column(
        ForeignKey("ec_sammellaeufe.id"), nullable=False, index=True
    )
    bankbuchung_id: Mapped[UUID] = mapped_column(
        ForeignKey("bankbuchungen.id"), nullable=False, index=True
    )
    bankkonto_id: Mapped[UUID] = mapped_column(
        ForeignKey("bankkonten.id"), nullable=False, index=True
    )
    gruppen_fingerprint: Mapped[str] = mapped_column(Text, nullable=False, server_default=text("''"))
    score: Mapped[int] = mapped_column(Integer, nullable=False)
    status: Mapped[str] = mapped_column(Text, nullable=False, index=True)
    summe_cent: Mapped[int] = mapped_column(Integer, nullable=False)
    einzahlung_cent: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("0"))
    differenz_cent: Mapped[int] = mapped_column(Integer, nullable=False)
    positive_signale: Mapped[Any] = mapped_column(
        JSON, nullable=False, server_default=text("'[]'::json")
    )
    negative_signale: Mapped[Any] = mapped_column(
        JSON, nullable=False, server_default=text("'[]'::json")
    )
    matcher_version: Mapped[str] = mapped_column(Text, nullable=False)
    max_verzoegerung_tage: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("2"))
    fenster_von: Mapped[date | None] = mapped_column(Date, nullable=True)
    fenster_bis: Mapped[date | None] = mapped_column(Date, nullable=True)
    entschieden_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    entschieden_von_benutzer_id: Mapped[UUID | None] = mapped_column(ForeignKey("benutzer.id"), nullable=True)
    entscheidungsnotiz: Mapped[str | None] = mapped_column(Text, nullable=True)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )


class EcSammelzuordnungBeleg(Base, TenantMixin, TimestampMixin):
    """Bruecke zwischen EC-Sammelzuordnung und einzelnen EC-Belegen."""
    __tablename__ = "ec_sammelzuordnung_belege"
    __table_args__ = (
        UniqueConstraint(
            "unternehmen_id", "zuordnung_id", "beleg_id",
            name="uq_ec_szb_zuordnung_beleg",
        ),
        ForeignKeyConstraint(
            ["zuordnung_id", "unternehmen_id"],
            ["ec_sammelzuordnungen.id", "ec_sammelzuordnungen.unternehmen_id"],
            name="fk_ec_szb_zuordnung_tenant",
        ),
        ForeignKeyConstraint(
            ["beleg_id", "unternehmen_id"],
            ["ec_belege.id", "ec_belege.unternehmen_id"],
            name="fk_ec_szb_beleg_tenant",
        ),
        Index(
            "uix_ec_szb_aktive_belegverwendung",
            "unternehmen_id",
            "beleg_id",
            unique=True,
            postgresql_where=text("rolle = 'AKTIV'"),
        ),
    )

    id: Mapped[UUID] = mapped_column(primary_key=True, server_default=text("gen_random_uuid()"))
    zuordnung_id: Mapped[UUID] = mapped_column(
        ForeignKey("ec_sammelzuordnungen.id"), nullable=False, index=True
    )
    beleg_id: Mapped[UUID] = mapped_column(
        ForeignKey("ec_belege.id"), nullable=False, index=True
    )
    rolle: Mapped[str] = mapped_column(Text, nullable=False)
