from uuid import UUID

from sqlalchemy import Text, text
from sqlalchemy.orm import Mapped, mapped_column

from apps.server.models.base import Base, TenantMixin, TimestampMixin


class Installation(Base, TenantMixin, TimestampMixin):
    __tablename__ = "installationen"

    id: Mapped[UUID] = mapped_column(primary_key=True, server_default=text("gen_random_uuid()"))
    bezeichnung: Mapped[str | None] = mapped_column(Text, nullable=True)
