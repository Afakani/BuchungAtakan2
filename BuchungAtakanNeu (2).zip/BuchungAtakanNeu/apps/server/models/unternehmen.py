from uuid import UUID

from sqlalchemy import Text, text
from sqlalchemy.orm import Mapped, mapped_column

from apps.server.models.base import Base, TimestampMixin


class Unternehmen(Base, TimestampMixin):
    __tablename__ = "unternehmen"

    id: Mapped[UUID] = mapped_column(primary_key=True, server_default=text("gen_random_uuid()"))
    name: Mapped[str] = mapped_column(Text, nullable=False)
