"""ORM-Modelle fuer Phase-05: Bankkonto, Kontoauszugsimport, Bankbuchung."""
from datetime import date
from enum import StrEnum
from uuid import UUID

from sqlalchemy import Boolean, Date, ForeignKey, ForeignKeyConstraint, Integer, Text, UniqueConstraint, text
from sqlalchemy.orm import Mapped, mapped_column

from apps.server.models.base import Base, TenantMixin, TimestampMixin


class BuchungsKlassifikation(StrEnum):
    MATCHBAR = "MATCHBAR"
    NICHT_ZU_MATCHEN = "NICHT_ZU_MATCHEN"
    EC_EINZAHLUNG = "EC_EINZAHLUNG"
    MANUELL_PRUEFEN = "MANUELL_PRUEFEN"


class Bankkonto(Base, TenantMixin, TimestampMixin):
    __tablename__ = "bankkonten"
    __table_args__ = (
        UniqueConstraint("id", "unternehmen_id", name="uq_bankkonten_id_unternehmen"),
    )

    id: Mapped[UUID] = mapped_column(primary_key=True, server_default=text("gen_random_uuid()"))
    anzeigename: Mapped[str] = mapped_column(Text, nullable=False)
    iban_masked: Mapped[str | None] = mapped_column(Text, nullable=True)
    bic: Mapped[str | None] = mapped_column(Text, nullable=True)
    ist_aktiv: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text("true"))


class Kontoauszugsimport(Base, TenantMixin, TimestampMixin):
    __tablename__ = "kontoauszugsimporte"
    __table_args__ = (
        UniqueConstraint("id", "unternehmen_id", name="uq_kontoauszugsimporte_id_unternehmen"),
        ForeignKeyConstraint(
            ["bankkonto_id", "unternehmen_id"],
            ["bankkonten.id", "bankkonten.unternehmen_id"],
            name="fk_kontoauszugsimporte_bankkonto_tenant",
        ),
    )

    id: Mapped[UUID] = mapped_column(primary_key=True, server_default=text("gen_random_uuid()"))
    bankkonto_id: Mapped[UUID] = mapped_column(
        ForeignKey("bankkonten.id"), nullable=False, index=True
    )
    quell_referenz: Mapped[str | None] = mapped_column(Text, nullable=True)
    import_fingerprint: Mapped[str | None] = mapped_column(Text, nullable=True)
    zeitraum_von: Mapped[date | None] = mapped_column(Date, nullable=True)
    zeitraum_bis: Mapped[date | None] = mapped_column(Date, nullable=True)
    buchungen_uebergeben: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("0"))
    buchungen_uebernommen: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("0"))


class Bankbuchung(Base, TenantMixin, TimestampMixin):
    __tablename__ = "bankbuchungen"
    __table_args__ = (
        UniqueConstraint("dedup_fingerprint", name="uq_bankbuchung_fingerprint"),
        UniqueConstraint("id", "unternehmen_id", name="uq_bankbuchungen_id_unternehmen"),
        ForeignKeyConstraint(
            ["bankkonto_id", "unternehmen_id"],
            ["bankkonten.id", "bankkonten.unternehmen_id"],
            name="fk_bankbuchungen_bankkonto_tenant",
        ),
        ForeignKeyConstraint(
            ["import_id", "unternehmen_id"],
            ["kontoauszugsimporte.id", "kontoauszugsimporte.unternehmen_id"],
            name="fk_bankbuchungen_import_tenant",
        ),
    )

    id: Mapped[UUID] = mapped_column(primary_key=True, server_default=text("gen_random_uuid()"))
    bankkonto_id: Mapped[UUID] = mapped_column(
        ForeignKey("bankkonten.id"), nullable=False, index=True
    )
    import_id: Mapped[UUID] = mapped_column(
        ForeignKey("kontoauszugsimporte.id"), nullable=False, index=True
    )
    buchungsdatum: Mapped[date] = mapped_column(Date, nullable=False, index=True)
    wertstellungsdatum: Mapped[date | None] = mapped_column(Date, nullable=True)
    betrag_cent: Mapped[int] = mapped_column(Integer, nullable=False)
    waehrung: Mapped[str] = mapped_column(Text, nullable=False, server_default=text("'EUR'"))
    verwendungszweck: Mapped[str | None] = mapped_column(Text, nullable=True)
    gegenpartei_name: Mapped[str | None] = mapped_column(Text, nullable=True)
    gegenpartei_iban: Mapped[str | None] = mapped_column(Text, nullable=True)
    gegenpartei_bic: Mapped[str | None] = mapped_column(Text, nullable=True)
    externe_buchungs_id: Mapped[str | None] = mapped_column(Text, nullable=True)
    dedup_fingerprint: Mapped[str] = mapped_column(Text, nullable=False)
    klassifikation: Mapped[str] = mapped_column(
        Text, nullable=False, server_default=text("'MATCHBAR'"), index=True
    )
