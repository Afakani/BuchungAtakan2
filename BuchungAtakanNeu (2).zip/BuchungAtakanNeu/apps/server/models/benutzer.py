from enum import StrEnum
from uuid import UUID

from sqlalchemy import Boolean, Enum, Index, Text, text
from sqlalchemy.orm import Mapped, mapped_column

from apps.server.models.base import Base, TenantMixin, TimestampMixin


class Rolle(StrEnum):
    SYSTEM_ADMIN = "SYSTEM_ADMIN"
    UNTERNEHMEN_ADMIN = "UNTERNEHMEN_ADMIN"
    BEARBEITER = "BEARBEITER"
    LESER = "LESER"


class Benutzer(Base, TenantMixin, TimestampMixin):
    __tablename__ = "benutzer"
    __table_args__ = (
        # ix_benutzer_unternehmen_id wird durch TenantMixin index=True erzeugt
        Index("ix_benutzer_benutzername", "benutzername", unique=True),
    )

    id: Mapped[UUID] = mapped_column(primary_key=True, server_default=text("gen_random_uuid()"))
    benutzername: Mapped[str] = mapped_column(Text, nullable=False)
    email: Mapped[str | None] = mapped_column(Text, nullable=True)
    hashed_password: Mapped[str] = mapped_column(Text, nullable=False)
    rolle: Mapped[Rolle] = mapped_column(
        Enum(Rolle, name="benutzer_rolle"), nullable=False
    )
    aktiv: Mapped[bool] = mapped_column(Boolean, server_default="true", nullable=False)
