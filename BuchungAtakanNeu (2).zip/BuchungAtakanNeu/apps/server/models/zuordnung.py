"""ORM-Modell fuer Zuordnungsvorschlaege (Phase-05, BANK-04/05/06/07/08/09).

Statusmodell (einziges status-Feld):
  STARK              — automatisch, hohe Verlässlichkeit (score >= 80)
  UNSICHER           — automatisch, schwach (score 40-79)
  MANUELL_BESTAETIGT — manuell bestätigt (BANK-07: kein Automatiklauf ueberschreibt)
  MANUELL_ABGELEHNT  — manuell abgelehnt (BANK-06: nie erneut als aktiver Vorschlag)

BANK-05 wird durch Partial Unique Index erzwungen:
  uix_zuordnung_eine_bestaetigte_pro_buchung
  ON (unternehmen_id, bankbuchung_id) WHERE status = 'MANUELL_BESTAETIGT'
"""
from datetime import datetime
from typing import Any
from uuid import UUID

from sqlalchemy import DateTime, ForeignKey, Index, Integer, JSON, Text, UniqueConstraint, func, text
from sqlalchemy.orm import Mapped, mapped_column

from apps.server.models.base import Base, TenantMixin


class ZuordnungsVorschlag(Base, TenantMixin):
    __tablename__ = "zuordnungsvorschlaege"
    __table_args__ = (
        UniqueConstraint(
            "unternehmen_id", "bankbuchung_id", "rechnung_id",
            name="uq_zuordnung_tenant_buchung_rechnung",
        ),
        # BANK-05: hoechstens eine MANUELL_BESTAETIGT pro Bankbuchung und Mandant
        Index(
            "uix_zuordnung_eine_bestaetigte_pro_buchung",
            "unternehmen_id",
            "bankbuchung_id",
            unique=True,
            postgresql_where=text("status = 'MANUELL_BESTAETIGT'"),
        ),
    )

    id: Mapped[UUID] = mapped_column(primary_key=True, server_default=text("gen_random_uuid()"))
    bankbuchung_id: Mapped[UUID] = mapped_column(
        ForeignKey("bankbuchungen.id"), nullable=False, index=True
    )
    rechnung_id: Mapped[UUID] = mapped_column(
        ForeignKey("rechnungen.id"), nullable=False, index=True
    )
    score: Mapped[int] = mapped_column(Integer, nullable=False)
    status: Mapped[str] = mapped_column(Text, nullable=False, index=True)
    positive_signale: Mapped[Any] = mapped_column(
        JSON, nullable=False, server_default=text("'[]'::json")
    )
    negative_signale: Mapped[Any] = mapped_column(
        JSON, nullable=False, server_default=text("'[]'::json")
    )
    matcher_version: Mapped[str] = mapped_column(Text, nullable=False)
    # Manuelle Entscheidungsfelder (Paket 3, BANK-05/06/07)
    entschieden_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    entschieden_von_benutzer_id: Mapped[UUID | None] = mapped_column(
        ForeignKey("benutzer.id"), nullable=True
    )
    entscheidungsnotiz: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
