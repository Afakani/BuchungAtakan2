"""HybridAuditRepository — Append-only Auditbewertungen und Statistikdaten (HYB-17/18)."""
from __future__ import annotations

from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from apps.server.models.hybrid_extraktion import (
    HybridAuditBewertung,
    HybridErkennungslauf,
    HybridStatusentscheidung,
)
from apps.server.models.rechnung import Erkennungslauf, Rechnung
from apps.server.repositories.base import BaseRepository
from packages.core.invoice_extraction.hybrid_audit import (
    AuditBewertungFelder,
    BewertungEintrag,
    berechne_gesamtergebnis_korrekt,
    waehle_neueste_bewertung,
)
from packages.core.invoice_extraction.hybrid_statistik import (
    StatistikZeile,
    normalisiere_anbieter,
    normalisiere_dokument_klasse,
    normalisiere_methode,
)


class HybridStatusentscheidungRepository(BaseRepository[HybridStatusentscheidung]):
    model = HybridStatusentscheidung


class HybridAuditRepository:
    async def create_audit_bewertung(
        self,
        session: AsyncSession,
        unternehmen_id: UUID,
        hybrid_statusentscheidung_id: UUID,
        felder: AuditBewertungFelder,
    ) -> HybridAuditBewertung:
        """Fuegt eine neue Auditbewertung hinzu -- append-only, kein Update/Delete.

        Prueft die Tenant-Zugehoerigkeit der Statusentscheidung nicht selbst;
        der Aufrufer (Service) prueft dies vorab ueber
        HybridStatusentscheidungRepository.get_by_id (404 bei fremder/fehlender ID).
        """
        bewertung = HybridAuditBewertung(
            unternehmen_id=unternehmen_id,
            hybrid_statusentscheidung_id=hybrid_statusentscheidung_id,
            rechnungsnummer_korrekt=felder.rechnungsnummer_korrekt,
            rechnungsdatum_korrekt=felder.rechnungsdatum_korrekt,
            gesamtbetrag_korrekt=felder.gesamtbetrag_korrekt,
            lieferant_korrekt=felder.lieferant_korrekt,
            steuerwerte_korrekt=felder.steuerwerte_korrekt,
            empfaenger_korrekt=felder.empfaenger_korrekt,
        )
        session.add(bewertung)
        await session.commit()
        return bewertung

    async def latest_by_statusentscheidung(
        self,
        session: AsyncSession,
        unternehmen_id: UUID,
        hybrid_statusentscheidung_id: UUID,
    ) -> HybridAuditBewertung | None:
        """Neueste Bewertung: bewertet_am DESC, bei Gleichstand id DESC (append-only)."""
        stmt = (
            select(HybridAuditBewertung)
            .where(
                HybridAuditBewertung.unternehmen_id == unternehmen_id,
                HybridAuditBewertung.hybrid_statusentscheidung_id == hybrid_statusentscheidung_id,
            )
            .order_by(HybridAuditBewertung.bewertet_am.desc(), HybridAuditBewertung.id.desc())
            .limit(1)
        )
        result = await session.execute(stmt)
        return result.scalar_one_or_none()

    async def list_statistik_zeilen(
        self, session: AsyncSession, unternehmen_id: UUID
    ) -> list[StatistikZeile]:
        """Laedt Rohdaten fuer Statistik -- mandantengefiltert.

        Join-Pfad Anbieter: HybridStatusentscheidung.erkennungslauf_id -> Erkennungslauf
        -> Erkennungslauf.rechnung_id -> Rechnung.lieferant_name (bestehender, fachlich
        korrekter Pfad -- ausdruecklich nicht hybrid_kandidaten.vendor_name).
        Join-Pfad Methode: HybridErkennungslauf.erkennungslauf_id == derselbe Erkennungslauf
        -- eine Statusentscheidung kann mehrere Provider/Methoden beteiligt haben, daher
        Explosion in mehrere StatistikZeile mit identischem statusentscheidung_id.
        """
        entscheidungen = (await session.execute(
            select(HybridStatusentscheidung).where(
                HybridStatusentscheidung.unternehmen_id == unternehmen_id,
            )
        )).scalars().all()
        if not entscheidungen:
            return []

        erkennungslauf_ids = {
            e.erkennungslauf_id for e in entscheidungen if e.erkennungslauf_id is not None
        }

        anbieter_je_erkennungslauf: dict[UUID, str | None] = {}
        if erkennungslauf_ids:
            rows = (await session.execute(
                select(Erkennungslauf.id, Rechnung.lieferant_name)
                .join(Rechnung, Rechnung.id == Erkennungslauf.rechnung_id, isouter=True)
                .where(
                    Erkennungslauf.id.in_(erkennungslauf_ids),
                    Erkennungslauf.unternehmen_id == unternehmen_id,
                )
            )).all()
            anbieter_je_erkennungslauf = {row[0]: row[1] for row in rows}

        provider_je_erkennungslauf: dict[UUID, list[str]] = {}
        if erkennungslauf_ids:
            rows = (await session.execute(
                select(HybridErkennungslauf.erkennungslauf_id, HybridErkennungslauf.provider_name)
                .where(
                    HybridErkennungslauf.erkennungslauf_id.in_(erkennungslauf_ids),
                    HybridErkennungslauf.unternehmen_id == unternehmen_id,
                )
                .distinct()
            )).all()
            for lauf_id, provider_name in rows:
                provider_je_erkennungslauf.setdefault(lauf_id, []).append(provider_name)

        statusentscheidung_ids = [e.id for e in entscheidungen]
        audit_rows = (await session.execute(
            select(HybridAuditBewertung).where(
                HybridAuditBewertung.unternehmen_id == unternehmen_id,
                HybridAuditBewertung.hybrid_statusentscheidung_id.in_(statusentscheidung_ids),
            )
        )).scalars().all()
        bewertungen_je_entscheidung: dict[UUID, list[BewertungEintrag]] = {}
        for row in audit_rows:
            bewertungen_je_entscheidung.setdefault(row.hybrid_statusentscheidung_id, []).append(
                BewertungEintrag(
                    id=row.id,
                    bewertet_am=row.bewertet_am,
                    felder=AuditBewertungFelder(
                        rechnungsnummer_korrekt=row.rechnungsnummer_korrekt,
                        rechnungsdatum_korrekt=row.rechnungsdatum_korrekt,
                        gesamtbetrag_korrekt=row.gesamtbetrag_korrekt,
                        lieferant_korrekt=row.lieferant_korrekt,
                        steuerwerte_korrekt=row.steuerwerte_korrekt,
                        empfaenger_korrekt=row.empfaenger_korrekt,
                    ),
                )
            )

        zeilen: list[StatistikZeile] = []
        for e in entscheidungen:
            anbieter = normalisiere_anbieter(
                anbieter_je_erkennungslauf.get(e.erkennungslauf_id) if e.erkennungslauf_id else None
            )
            dokument_klasse = normalisiere_dokument_klasse(e.dokument_klasse)
            methoden = provider_je_erkennungslauf.get(e.erkennungslauf_id) if e.erkennungslauf_id else None
            methoden = sorted(set(methoden)) if methoden else [None]

            neueste = waehle_neueste_bewertung(bewertungen_je_entscheidung.get(e.id, []))
            audit_korrekt = berechne_gesamtergebnis_korrekt(neueste.felder) if neueste else None

            for methode in methoden:
                zeilen.append(StatistikZeile(
                    statusentscheidung_id=str(e.id),
                    anbieter=anbieter,
                    dokument_klasse=dokument_klasse,
                    methode=normalisiere_methode(methode),
                    status=e.hybrid_status,
                    pflichtfelder_ok=e.pflichtfelder_ok,
                    audit_korrekt=audit_korrekt,
                ))
        return zeilen
