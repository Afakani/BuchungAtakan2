"""BankbuchungRepository — mandantensicherer Import und Abfrage (BANK-01/02/03)."""
from datetime import date
from uuid import UUID

from fastapi import HTTPException, status
from sqlalchemy import select, text
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.ext.asyncio import AsyncSession

from apps.server.models.bankbuchung import Bankbuchung, Bankkonto, Kontoauszugsimport
from apps.server.repositories.base import BaseRepository


class BankkontoRepository(BaseRepository[Bankkonto]):
    model = Bankkonto

    async def create(
        self,
        session: AsyncSession,
        unternehmen_id: UUID,
        anzeigename: str,
        iban_masked: str | None = None,
        bic: str | None = None,
    ) -> Bankkonto:
        konto = Bankkonto(
            unternehmen_id=unternehmen_id,
            anzeigename=anzeigename,
            iban_masked=iban_masked,
            bic=bic,
        )
        session.add(konto)
        await session.flush()
        return konto

    async def list_aktive(
        self, session: AsyncSession, unternehmen_id: UUID
    ) -> list[Bankkonto]:
        stmt = select(Bankkonto).where(
            Bankkonto.unternehmen_id == unternehmen_id,
            Bankkonto.ist_aktiv.is_(True),
        )
        result = await session.execute(stmt)
        return list(result.scalars().all())


class BankbuchungRepository:
    """Repository fuer atomaren Import und mandantengefilterte Abfragen."""

    async def _get_bankkonto(
        self, session: AsyncSession, bankkonto_id: UUID, unternehmen_id: UUID
    ) -> Bankkonto:
        """Mandantensicher; 404 bei fremd oder fehlend."""
        stmt = select(Bankkonto).where(
            Bankkonto.id == bankkonto_id,
            Bankkonto.unternehmen_id == unternehmen_id,
        )
        result = await session.execute(stmt)
        obj = result.scalar_one_or_none()
        if obj is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Bankkonto nicht gefunden",
            )
        return obj

    async def importiere(
        self,
        session: AsyncSession,
        unternehmen_id: UUID,
        bankkonto_id: UUID,
        buchungen_daten: list[dict],
        quell_referenz: str | None = None,
        zeitraum_von: date | None = None,
        zeitraum_bis: date | None = None,
    ) -> tuple[Kontoauszugsimport, int, int]:
        """Atomarer Import aller Buchungen in einer Transaktion.

        Returns:
            (import_record, anzahl_neu, anzahl_dedupliziert)

        Deduplizierung via ON CONFLICT DO NOTHING auf dedup_fingerprint.
        BANK-01: keine Buchung verloren (alle gueltigen werden versucht).
        BANK-02: Re-Import idempotent (Duplikate uebersprungen, nicht Fehler).
        """
        await self._get_bankkonto(session, bankkonto_id, unternehmen_id)

        uebergeben = len(buchungen_daten)

        import_record = Kontoauszugsimport(
            unternehmen_id=unternehmen_id,
            bankkonto_id=bankkonto_id,
            quell_referenz=quell_referenz,
            zeitraum_von=zeitraum_von,
            zeitraum_bis=zeitraum_bis,
            buchungen_uebergeben=uebergeben,
            buchungen_uebernommen=0,
        )
        session.add(import_record)
        await session.flush()

        uebernommen = 0
        if buchungen_daten:
            for bd in buchungen_daten:
                bd["unternehmen_id"] = unternehmen_id
                bd["bankkonto_id"] = bankkonto_id
                bd["import_id"] = import_record.id

            stmt = (
                pg_insert(Bankbuchung)
                .values(buchungen_daten)
                .on_conflict_do_nothing(constraint="uq_bankbuchung_fingerprint")
                .returning(Bankbuchung.id)
            )
            result = await session.execute(stmt)
            uebernommen = len(result.fetchall())

        import_record.buchungen_uebernommen = uebernommen
        await session.flush()

        return import_record, uebernommen, uebergeben - uebernommen

    async def list_buchungen(
        self,
        session: AsyncSession,
        unternehmen_id: UUID,
        bankkonto_id: UUID | None = None,
        klassifikation: str | None = None,
        datum_von: date | None = None,
        datum_bis: date | None = None,
    ) -> list[Bankbuchung]:
        """Mandantengefilterte Liste. Fremde Mandantendaten niemals sichtbar."""
        stmt = select(Bankbuchung).where(Bankbuchung.unternehmen_id == unternehmen_id)

        if bankkonto_id is not None:
            stmt = stmt.where(Bankbuchung.bankkonto_id == bankkonto_id)
        if klassifikation is not None:
            stmt = stmt.where(Bankbuchung.klassifikation == klassifikation)
        if datum_von is not None:
            stmt = stmt.where(Bankbuchung.buchungsdatum >= datum_von)
        if datum_bis is not None:
            stmt = stmt.where(Bankbuchung.buchungsdatum <= datum_bis)

        stmt = stmt.order_by(Bankbuchung.buchungsdatum.desc())
        result = await session.execute(stmt)
        return list(result.scalars().all())
