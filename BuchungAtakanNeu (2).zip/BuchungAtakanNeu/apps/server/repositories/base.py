from uuid import UUID

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession


class BaseRepository[T]:
    """Generisches Repository mit Mandantenfilter-Guard.
    Ergebnis leer -> 404 (SRV-04: niemals fremde Daten zurueckgeben)."""

    model: type[T]

    async def get_by_id(
        self,
        session: AsyncSession,
        id: UUID,
        unternehmen_id: UUID,
    ) -> T:
        stmt = select(self.model).where(
            self.model.id == id,
            self.model.unternehmen_id == unternehmen_id,
        )
        result = await session.execute(stmt)
        obj = result.scalar_one_or_none()
        if obj is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Nicht gefunden",
            )
        return obj
