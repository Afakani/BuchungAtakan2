"""EC-Sammelzuordnung Repository — Phase 06, Paket 2.

Zwei Repository-Klassen:
  ECBelegRepository            — Beleg-Import, -Liste, -Detail
  ECSammelzuordnungRepository  — EC-Einzahlungen, Rematch-Support, Zuordnungen

Mandantensicherheit:
  Alle Queries filtern auf unternehmen_id.
  Composite FKs sichern Cross-Tenant-Safety auf DB-Ebene.
  Fremde Bankkonto-IDs → 404 (nie 403, um Tenant-Existenz nicht zu leaken).

Batch-Safety:
  asyncpg-Limit: 32767 Bind-Parameter pro Query.
  Batchgroesse _MAX_BATCH_BELEGE = 500 (15 Spalten × 500 = 7500 < 32767).
  Batchgroesse _MAX_BATCH_SZB = 2000 (4 Spalten × 2000 = 8000 < 32767).
"""
import hashlib
from datetime import date, datetime, timedelta, timezone
from uuid import UUID

from fastapi import HTTPException, status
from sqlalchemy import delete, func, select, text as sa_text, update as sa_update
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from apps.server.models.bankbuchung import Bankbuchung, Bankkonto, BuchungsKlassifikation
from apps.server.models.ec_sammlung import (
    EcBeleg,
    EcSammellauf,
    EcSammelzuordnung,
    EcSammelzuordnungBeleg,
)

_MAX_BATCH_BELEGE = 500
_MAX_BATCH_SZB = 2000

_GESCHUETZTE_STATI = frozenset(["MANUELL_BESTAETIGT", "MANUELL_ABGELEHNT"])


def berechne_import_fingerprint(
    unternehmen_id: UUID,
    bankkonto_id: UUID,
    betrag_cent: int,
    buchungsdatum: date,
    waehrung: str,
    quell_position: str | None,
    transaktionsreferenz: str | None,
) -> str:
    komponenten = "|".join([
        str(unternehmen_id),
        str(bankkonto_id),
        str(betrag_cent),
        str(buchungsdatum),
        waehrung,
        quell_position or "",
        transaktionsreferenz or "",
    ])
    return hashlib.sha256(komponenten.encode()).hexdigest()


def berechne_gruppen_fingerprint(bankbuchung_id: UUID, aktive_beleg_ids: list[UUID]) -> str:
    sorted_ids = sorted(str(bid) for bid in aktive_beleg_ids)
    komponenten = "|".join([str(bankbuchung_id)] + sorted_ids)
    return hashlib.sha256(komponenten.encode()).hexdigest()


class ECBelegRepository:
    """Mandantensicherer Import und Zugriff auf EC-Kartenbelege."""

    async def _get_bankkonto(
        self, session: AsyncSession, bankkonto_id: UUID, unternehmen_id: UUID
    ) -> Bankkonto:
        stmt = select(Bankkonto).where(
            Bankkonto.id == bankkonto_id,
            Bankkonto.unternehmen_id == unternehmen_id,
        )
        result = await session.execute(stmt)
        obj = result.scalar_one_or_none()
        if obj is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Bankkonto nicht gefunden")
        return obj

    async def importiere_belege(
        self,
        session: AsyncSession,
        unternehmen_id: UUID,
        bankkonto_id: UUID,
        quell_referenz: str,
        belege_daten: list[dict],
    ) -> tuple[int, int]:
        """Idempotenter Import via ON CONFLICT DO NOTHING auf uq_ec_beleg_import_fingerprint.

        Returns: (uebergeben, neu)
        """
        await self._get_bankkonto(session, bankkonto_id, unternehmen_id)

        uebergeben = len(belege_daten)
        neu_gesamt = 0

        for i in range(0, uebergeben, _MAX_BATCH_BELEGE):
            batch = belege_daten[i : i + _MAX_BATCH_BELEGE]
            rows = [
                {
                    **d,
                    "unternehmen_id": unternehmen_id,
                    "bankkonto_id": bankkonto_id,
                    "quelldatei": quell_referenz,
                    "import_fingerprint": berechne_import_fingerprint(
                        unternehmen_id=unternehmen_id,
                        bankkonto_id=bankkonto_id,
                        betrag_cent=d["betrag_cent"],
                        buchungsdatum=d["buchungsdatum"],
                        waehrung=d["waehrung"],
                        quell_position=d.get("quell_position"),
                        transaktionsreferenz=d.get("transaktionsreferenz"),
                    ),
                }
                for d in batch
            ]
            stmt = (
                pg_insert(EcBeleg)
                .values(rows)
                .on_conflict_do_nothing(constraint="uq_ec_beleg_import_fingerprint")
                .returning(EcBeleg.id)
            )
            result = await session.execute(stmt)
            neu_gesamt += len(result.fetchall())

        return uebergeben, neu_gesamt

    async def list_belege(
        self,
        session: AsyncSession,
        unternehmen_id: UUID,
        bankkonto_id: UUID | None = None,
        datum_von: date | None = None,
        datum_bis: date | None = None,
    ) -> list[EcBeleg]:
        stmt = select(EcBeleg).where(EcBeleg.unternehmen_id == unternehmen_id)
        if bankkonto_id is not None:
            stmt = stmt.where(EcBeleg.bankkonto_id == bankkonto_id)
        if datum_von is not None:
            stmt = stmt.where(EcBeleg.buchungsdatum >= datum_von)
        if datum_bis is not None:
            stmt = stmt.where(EcBeleg.buchungsdatum <= datum_bis)
        stmt = stmt.order_by(EcBeleg.buchungsdatum.desc())
        result = await session.execute(stmt)
        return list(result.scalars().all())

    async def get_beleg_by_id(
        self, session: AsyncSession, unternehmen_id: UUID, beleg_id: UUID
    ) -> EcBeleg | None:
        stmt = select(EcBeleg).where(
            EcBeleg.id == beleg_id,
            EcBeleg.unternehmen_id == unternehmen_id,
        )
        result = await session.execute(stmt)
        return result.scalar_one_or_none()


class ECSammelzuordnungRepository:
    """Mandantensicheres Repository fuer EC-Sammelzuordnungen und Rematch-Support."""

    async def get_bankkonto(
        self, session: AsyncSession, bankkonto_id: UUID, unternehmen_id: UUID
    ) -> Bankkonto:
        stmt = select(Bankkonto).where(
            Bankkonto.id == bankkonto_id,
            Bankkonto.unternehmen_id == unternehmen_id,
        )
        result = await session.execute(stmt)
        obj = result.scalar_one_or_none()
        if obj is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Bankkonto nicht gefunden")
        return obj

    async def list_ec_einzahlungen(
        self, session: AsyncSession, unternehmen_id: UUID, bankkonto_id: UUID
    ) -> list[Bankbuchung]:
        stmt = (
            select(Bankbuchung)
            .where(
                Bankbuchung.unternehmen_id == unternehmen_id,
                Bankbuchung.bankkonto_id == bankkonto_id,
                Bankbuchung.klassifikation == BuchungsKlassifikation.EC_EINZAHLUNG,
            )
            .order_by(Bankbuchung.buchungsdatum.asc())
        )
        result = await session.execute(stmt)
        return list(result.scalars().all())

    async def get_offene_ec_belege(
        self, session: AsyncSession, unternehmen_id: UUID, bankkonto_id: UUID
    ) -> list[EcBeleg]:
        stmt = (
            select(EcBeleg)
            .where(
                EcBeleg.unternehmen_id == unternehmen_id,
                EcBeleg.bankkonto_id == bankkonto_id,
                EcBeleg.status == "VERFUEGBAR",
            )
            .order_by(EcBeleg.buchungsdatum.asc())
        )
        result = await session.execute(stmt)
        return list(result.scalars().all())

    async def get_geschuetzte_beleg_ids(
        self, session: AsyncSession, unternehmen_id: UUID
    ) -> frozenset[UUID]:
        """Beleg-IDs, die in MANUELL_BESTAETIGT-Zuordnungen als AKTIV verwendet werden."""
        stmt = (
            select(EcSammelzuordnungBeleg.beleg_id)
            .join(
                EcSammelzuordnung,
                (EcSammelzuordnung.id == EcSammelzuordnungBeleg.zuordnung_id)
                & (EcSammelzuordnung.unternehmen_id == EcSammelzuordnungBeleg.unternehmen_id),
            )
            .where(
                EcSammelzuordnungBeleg.unternehmen_id == unternehmen_id,
                EcSammelzuordnungBeleg.rolle == "AKTIV",
                EcSammelzuordnung.status == "MANUELL_BESTAETIGT",
            )
        )
        result = await session.execute(stmt)
        return frozenset(row[0] for row in result.fetchall())

    async def get_abgelehnte_fingerprints(
        self, session: AsyncSession, unternehmen_id: UUID, bankkonto_id: UUID
    ) -> frozenset[str]:
        """Gruppen-Fingerprints aus MANUELL_ABGELEHNT-Zuordnungen fuer dieses Bankkonto."""
        stmt = select(EcSammelzuordnung.gruppen_fingerprint).where(
            EcSammelzuordnung.unternehmen_id == unternehmen_id,
            EcSammelzuordnung.bankkonto_id == bankkonto_id,
            EcSammelzuordnung.status == "MANUELL_ABGELEHNT",
        )
        result = await session.execute(stmt)
        return frozenset(row[0] for row in result.fetchall())

    async def get_bestaetigte_bankbuchung_ids(
        self, session: AsyncSession, unternehmen_id: UUID, bankkonto_id: UUID
    ) -> frozenset[UUID]:
        """Bankbuchung-IDs, die bereits MANUELL_BESTAETIGT haben (nicht erneut matchen)."""
        stmt = select(EcSammelzuordnung.bankbuchung_id).where(
            EcSammelzuordnung.unternehmen_id == unternehmen_id,
            EcSammelzuordnung.bankkonto_id == bankkonto_id,
            EcSammelzuordnung.status == "MANUELL_BESTAETIGT",
        )
        result = await session.execute(stmt)
        return frozenset(row[0] for row in result.fetchall())

    async def speichere_sammellauf(
        self,
        session: AsyncSession,
        unternehmen_id: UUID,
        bankbuchung_id: UUID,
        matcher_version: str,
    ) -> UUID:
        lauf = EcSammellauf(
            unternehmen_id=unternehmen_id,
            bankbuchung_id=bankbuchung_id,
            matcher_version=matcher_version,
        )
        session.add(lauf)
        await session.flush()
        return lauf.id

    async def upsert_automatische_vorschlaege(
        self,
        session: AsyncSession,
        unternehmen_id: UUID,
        vorschlaege: list[dict],
    ) -> None:
        """Upsert von Auto-Vorschlaegen per Partial-Index-Conflict.

        Jeder Vorschlag ist ein dict mit:
          sammellauf_id, bankbuchung_id, bankkonto_id, gruppen_fingerprint,
          score, status, summe_cent, einzahlung_cent, differenz_cent,
          positive_signale, negative_signale, matcher_version,
          max_verzoegerung_tage, fenster_von, fenster_bis,
          aktive_beleg_ids: list[UUID], entfernte_beleg_ids: list[UUID]

        ON CONFLICT DO UPDATE: aktualisiert Auto-Zeilen, schreibt NIEMALS
        MANUELL_BESTAETIGT oder MANUELL_ABGELEHNT.
        """
        if not vorschlaege:
            return

        # Sammelzuordnungen upserten, IDs zurueckbekommen
        sz_rows = [
            {
                "unternehmen_id": unternehmen_id,
                "sammellauf_id": v["sammellauf_id"],
                "bankbuchung_id": v["bankbuchung_id"],
                "bankkonto_id": v["bankkonto_id"],
                "gruppen_fingerprint": v["gruppen_fingerprint"],
                "score": v["score"],
                "status": v["status"],
                "summe_cent": v["summe_cent"],
                "einzahlung_cent": v["einzahlung_cent"],
                "differenz_cent": v["differenz_cent"],
                "positive_signale": v["positive_signale"],
                "negative_signale": v["negative_signale"],
                "matcher_version": v["matcher_version"],
                "max_verzoegerung_tage": v["max_verzoegerung_tage"],
                "fenster_von": v["fenster_von"],
                "fenster_bis": v["fenster_bis"],
            }
            for v in vorschlaege
        ]

        # index_where muss exakt dem Partial-Index-Praedikat entsprechen (ohne Tabellenqualifikation)
        _INDEX_WHERE = sa_text("status NOT IN ('MANUELL_BESTAETIGT', 'MANUELL_ABGELEHNT')")
        # where im DO UPDATE muss qualifiziert sein (status ist ambiguous zw. Zeile und EXCLUDED)
        _UPDATE_WHERE = sa_text(
            "ec_sammelzuordnungen.status NOT IN ('MANUELL_BESTAETIGT', 'MANUELL_ABGELEHNT')"
        )

        stmt = pg_insert(EcSammelzuordnung).values(sz_rows)
        stmt = stmt.on_conflict_do_update(
            index_elements=["unternehmen_id", "bankbuchung_id"],
            index_where=_INDEX_WHERE,
            set_={
                "sammellauf_id": stmt.excluded.sammellauf_id,
                "gruppen_fingerprint": stmt.excluded.gruppen_fingerprint,
                "bankkonto_id": stmt.excluded.bankkonto_id,
                "score": stmt.excluded.score,
                "status": stmt.excluded.status,
                "summe_cent": stmt.excluded.summe_cent,
                "einzahlung_cent": stmt.excluded.einzahlung_cent,
                "differenz_cent": stmt.excluded.differenz_cent,
                "positive_signale": stmt.excluded.positive_signale,
                "negative_signale": stmt.excluded.negative_signale,
                "matcher_version": stmt.excluded.matcher_version,
                "max_verzoegerung_tage": stmt.excluded.max_verzoegerung_tage,
                "fenster_von": stmt.excluded.fenster_von,
                "fenster_bis": stmt.excluded.fenster_bis,
                "updated_at": func.now(),
            },
            where=_UPDATE_WHERE,
        ).returning(EcSammelzuordnung.id, EcSammelzuordnung.bankbuchung_id)

        result = await session.execute(stmt)
        zuordnung_id_by_buchung: dict[UUID, UUID] = {row[1]: row[0] for row in result.fetchall()}

        if not zuordnung_id_by_buchung:
            return

        # Alte Beleg-Eintraege fuer upgedatete Zuordnungen loeschen
        zuordnung_ids = list(zuordnung_id_by_buchung.values())
        await session.execute(
            delete(EcSammelzuordnungBeleg).where(
                EcSammelzuordnungBeleg.unternehmen_id == unternehmen_id,
                EcSammelzuordnungBeleg.zuordnung_id.in_(zuordnung_ids),
            )
        )
        await session.flush()

        # Neue Beleg-Eintraege einfuegen
        szb_rows: list[dict] = []
        for v in vorschlaege:
            buchung_id = v["bankbuchung_id"]
            zuordnung_id = zuordnung_id_by_buchung.get(buchung_id)
            if zuordnung_id is None:
                continue
            for bid in v["aktive_beleg_ids"]:
                szb_rows.append({
                    "unternehmen_id": unternehmen_id,
                    "zuordnung_id": zuordnung_id,
                    "beleg_id": bid,
                    "rolle": "AKTIV",
                })
            for bid in v["entfernte_beleg_ids"]:
                szb_rows.append({
                    "unternehmen_id": unternehmen_id,
                    "zuordnung_id": zuordnung_id,
                    "beleg_id": bid,
                    "rolle": "ENTFERNT_VERSCHOBEN",
                })

        for i in range(0, len(szb_rows), _MAX_BATCH_SZB):
            batch = szb_rows[i : i + _MAX_BATCH_SZB]
            if batch:
                await session.execute(pg_insert(EcSammelzuordnungBeleg).values(batch))

    async def list_sammelzuordnungen(
        self,
        session: AsyncSession,
        unternehmen_id: UUID,
        bankkonto_id: UUID | None = None,
    ) -> list[EcSammelzuordnung]:
        stmt = (
            select(EcSammelzuordnung)
            .where(EcSammelzuordnung.unternehmen_id == unternehmen_id)
        )
        if bankkonto_id is not None:
            stmt = stmt.where(EcSammelzuordnung.bankkonto_id == bankkonto_id)
        stmt = stmt.order_by(EcSammelzuordnung.created_at.desc())
        result = await session.execute(stmt)
        return list(result.scalars().all())

    async def get_sammelzuordnung_detail(
        self,
        session: AsyncSession,
        unternehmen_id: UUID,
        zuordnung_id: UUID,
    ) -> tuple[EcSammelzuordnung, list[dict], list[dict]]:
        """Liefert (zuordnung, enthaltene_belege, entfernte_belege) oder wirft 404."""
        stmt = select(EcSammelzuordnung).where(
            EcSammelzuordnung.id == zuordnung_id,
            EcSammelzuordnung.unternehmen_id == unternehmen_id,
        )
        result = await session.execute(stmt)
        zuordnung = result.scalar_one_or_none()
        if zuordnung is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Sammelzuordnung nicht gefunden")

        stmt2 = (
            select(
                EcSammelzuordnungBeleg.beleg_id,
                EcSammelzuordnungBeleg.rolle,
                EcBeleg.betrag_cent,
                EcBeleg.buchungsdatum,
            )
            .join(
                EcBeleg,
                (EcBeleg.id == EcSammelzuordnungBeleg.beleg_id)
                & (EcBeleg.unternehmen_id == EcSammelzuordnungBeleg.unternehmen_id),
            )
            .where(
                EcSammelzuordnungBeleg.zuordnung_id == zuordnung_id,
                EcSammelzuordnungBeleg.unternehmen_id == unternehmen_id,
            )
        )
        belege_result = await session.execute(stmt2)
        belege_rows = belege_result.fetchall()

        enthaltene = [
            {"beleg_id": row[0], "rolle": row[1], "betrag_cent": row[2], "buchungsdatum": row[3]}
            for row in belege_rows
            if row[1] == "AKTIV"
        ]
        entfernte = [
            {"beleg_id": row[0], "rolle": row[1], "betrag_cent": row[2], "buchungsdatum": row[3]}
            for row in belege_rows
            if row[1] == "ENTFERNT_VERSCHOBEN"
        ]

        return zuordnung, enthaltene, entfernte

    async def bestaetigen(
        self,
        session: AsyncSession,
        unternehmen_id: UUID,
        zuordnung_id: UUID,
        benutzer_id: UUID,
        notiz: str | None,
    ) -> EcSammelzuordnung:
        """Setzt Status auf MANUELL_BESTAETIGT.

        Idempotent wenn bereits bestaetigt. 409 wenn bereits abgelehnt.
        Setzt enthaltene Belege (rolle='AKTIV') auf status='ZUGEORDNET'.
        Entfernte Belege (rolle='ENTFERNT_VERSCHOBEN') bleiben unveraendert.
        Catch IntegrityError (zweite bestaetigte Gruppe / doppelte Belegnutzung) → 409.
        """
        stmt = select(EcSammelzuordnung).where(
            EcSammelzuordnung.id == zuordnung_id,
            EcSammelzuordnung.unternehmen_id == unternehmen_id,
        )
        result = await session.execute(stmt)
        z = result.scalar_one_or_none()
        if z is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Sammelzuordnung nicht gefunden")

        if z.status == "MANUELL_BESTAETIGT":
            return z

        if z.status == "MANUELL_ABGELEHNT":
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Sammelzuordnung wurde bereits abgelehnt und kann nicht bestaetigt werden",
            )

        aktive_stmt = select(EcSammelzuordnungBeleg.beleg_id).where(
            EcSammelzuordnungBeleg.zuordnung_id == zuordnung_id,
            EcSammelzuordnungBeleg.unternehmen_id == unternehmen_id,
            EcSammelzuordnungBeleg.rolle == "AKTIV",
        )
        aktive_result = await session.execute(aktive_stmt)
        aktive_beleg_ids = [row[0] for row in aktive_result.fetchall()]

        jetzt = datetime.now(timezone.utc)
        z.status = "MANUELL_BESTAETIGT"
        z.entschieden_at = jetzt
        z.entschieden_von_benutzer_id = benutzer_id
        z.entscheidungsnotiz = notiz
        z.updated_at = jetzt

        if aktive_beleg_ids:
            await session.execute(
                sa_update(EcBeleg)
                .where(
                    EcBeleg.id.in_(aktive_beleg_ids),
                    EcBeleg.unternehmen_id == unternehmen_id,
                )
                .values(status="ZUGEORDNET")
            )

        try:
            await session.flush()
        except IntegrityError as exc:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Constraint-Verletzung: Bankbuchung hat bereits eine bestaetigte Gruppe oder Beleg wird anderweitig aktiv verwendet",
            ) from exc

        return z

    async def ablehnen(
        self,
        session: AsyncSession,
        unternehmen_id: UUID,
        zuordnung_id: UUID,
        benutzer_id: UUID,
        notiz: str | None,
    ) -> EcSammelzuordnung:
        """Setzt Status auf MANUELL_ABGELEHNT.

        Idempotent wenn bereits abgelehnt. 409 wenn bereits bestaetigt.
        Gruppenfingerprint bleibt erhalten (verhindert Neuvorschlag bei Rematch).
        AKTIV-Eintraege in Junction werden entfernt, damit Belege wieder frei sind.
        """
        stmt = select(EcSammelzuordnung).where(
            EcSammelzuordnung.id == zuordnung_id,
            EcSammelzuordnung.unternehmen_id == unternehmen_id,
        )
        result = await session.execute(stmt)
        z = result.scalar_one_or_none()
        if z is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Sammelzuordnung nicht gefunden")

        if z.status == "MANUELL_ABGELEHNT":
            return z

        if z.status == "MANUELL_BESTAETIGT":
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Sammelzuordnung wurde bereits bestaetigt und kann nicht abgelehnt werden",
            )

        jetzt = datetime.now(timezone.utc)
        z.status = "MANUELL_ABGELEHNT"
        z.entschieden_at = jetzt
        z.entschieden_von_benutzer_id = benutzer_id
        z.entscheidungsnotiz = notiz
        z.updated_at = jetzt

        # AKTIV-Eintraege loeschen, damit diese Belege in zukuenftigen Gruppen wieder verwendbar sind
        await session.execute(
            delete(EcSammelzuordnungBeleg).where(
                EcSammelzuordnungBeleg.zuordnung_id == zuordnung_id,
                EcSammelzuordnungBeleg.unternehmen_id == unternehmen_id,
                EcSammelzuordnungBeleg.rolle == "AKTIV",
            )
        )

        await session.flush()
        return z
