"""ZuordnungRepository — Upsert, manuelle Entscheidungen, Rematch-Schutz.

BANK-05: Partial Unique Index erzwingt hoechstens 1 MANUELL_BESTAETIGT pro Buchung.
BANK-06: MANUELL_ABGELEHNT-Zeilen werden vom Upsert nie ueberschrieben.
BANK-07: MANUELL_BESTAETIGT-Zeilen werden vom Upsert nie ueberschrieben.
"""
from datetime import datetime, timezone
from uuid import UUID

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from apps.server.models.zuordnung import ZuordnungsVorschlag
from packages.core.matching.signale import MatchErgebnis

# Status-Konstanten fuer Lesbarkeit und um String-Typos zu vermeiden
STATUS_STARK = "STARK"
STATUS_UNSICHER = "UNSICHER"
STATUS_MANUELL_BESTAETIGT = "MANUELL_BESTAETIGT"
STATUS_MANUELL_ABGELEHNT = "MANUELL_ABGELEHNT"

_GESCHUETZTE_STATI = {STATUS_MANUELL_BESTAETIGT, STATUS_MANUELL_ABGELEHNT}

# asyncpg limit: 32 767 bind-parameter pro Query.
# ZuordnungsVorschlag hat 8 INSERT-Spalten → max. 32767 // 8 = 4095 Zeilen je Batch.
# 500 lässt reichlich Spielraum für künftige Spalten.
_MAX_BATCH = 500


class ZuordnungRepository:
    async def upsert_vorschlaege(
        self,
        session: AsyncSession,
        unternehmen_id: UUID,
        ergebnisse: list[MatchErgebnis],
    ) -> tuple[int, int]:
        """UPSERT-Batch: nur offene automatische Vorschlaege werden aktualisiert.

        BANK-07/06: ON CONFLICT DO UPDATE WHERE status NOT IN geschuetzte_stati.
        Wenn eine Zeile MANUELL_BESTAETIGT oder MANUELL_ABGELEHNT ist, wird der
        DO UPDATE-Ausdruck durch die WHERE-Bedingung uebersprungen.
        Die Zeile bleibt unveraendert; kein Fehler, kein stilles Ueberschreiben.
        """
        if not ergebnisse:
            return 0, 0

        rows = [
            {
                "unternehmen_id": unternehmen_id,
                "bankbuchung_id": e.bankbuchung_id,
                "rechnung_id": e.rechnung_id,
                "score": e.score,
                "status": e.status,
                "positive_signale": [s.als_dict() for s in e.positive_signale],
                "negative_signale": [s.als_dict() for s in e.negative_signale],
                "matcher_version": e.matcher_version,
            }
            for e in ergebnisse
            if e.ist_kandidat
        ]

        if not rows:
            return 0, 0

        total = 0
        for i in range(0, len(rows), _MAX_BATCH):
            batch = rows[i : i + _MAX_BATCH]
            ins = pg_insert(ZuordnungsVorschlag)
            stmt = (
                ins
                .values(batch)
                .on_conflict_do_update(
                    constraint="uq_zuordnung_tenant_buchung_rechnung",
                    set_={
                        "score": ins.excluded.score,
                        "status": ins.excluded.status,
                        "positive_signale": ins.excluded.positive_signale,
                        "negative_signale": ins.excluded.negative_signale,
                        "matcher_version": ins.excluded.matcher_version,
                        "updated_at": ins.excluded.updated_at,
                    },
                    # BANK-06/07: geschuetzte Zeilen unveraendert lassen
                    where=ZuordnungsVorschlag.status.not_in(list(_GESCHUETZTE_STATI)),
                )
                .returning(ZuordnungsVorschlag.id)
            )
            result = await session.execute(stmt)
            await session.flush()
            total += len(result.scalars().all())
        return total, 0

    async def get_by_id(
        self,
        session: AsyncSession,
        vorschlag_id: UUID,
        unternehmen_id: UUID,
    ) -> ZuordnungsVorschlag:
        """Mandantensicher; 404 bei fremd oder fehlend."""
        stmt = select(ZuordnungsVorschlag).where(
            ZuordnungsVorschlag.id == vorschlag_id,
            ZuordnungsVorschlag.unternehmen_id == unternehmen_id,
        )
        result = await session.execute(stmt)
        obj = result.scalar_one_or_none()
        if obj is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Zuordnungsvorschlag nicht gefunden",
            )
        return obj

    async def bestaetigen(
        self,
        session: AsyncSession,
        vorschlag_id: UUID,
        unternehmen_id: UUID,
        benutzer_id: UUID,
        notiz: str | None,
    ) -> ZuordnungsVorschlag:
        """Setzt Vorschlag auf MANUELL_BESTAETIGT (BANK-07).

        Idempotent: bereits bestaetigt → unveraendert zurueckgeben.
        BANK-05: IntegrityError bei zweiter Bestaetigung fuer dieselbe Buchung → 409.
        Nicht bestaetigbar: MANUELL_ABGELEHNT → 409.
        """
        vorschlag = await self.get_by_id(session, vorschlag_id, unternehmen_id)

        if vorschlag.status == STATUS_MANUELL_BESTAETIGT:
            return vorschlag  # idempotent

        if vorschlag.status == STATUS_MANUELL_ABGELEHNT:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Abgelehnte Zuordnung kann nicht bestaetigt werden",
            )

        vorschlag.status = STATUS_MANUELL_BESTAETIGT
        vorschlag.entschieden_at = datetime.now(tz=timezone.utc)
        vorschlag.entschieden_von_benutzer_id = benutzer_id
        vorschlag.entscheidungsnotiz = notiz
        vorschlag.updated_at = datetime.now(tz=timezone.utc)

        try:
            await session.flush()
        except IntegrityError:
            await session.rollback()
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Fuer diese Bankbuchung existiert bereits eine bestaetigte Zuordnung (BANK-05)",
            )

        return vorschlag

    async def ablehnen(
        self,
        session: AsyncSession,
        vorschlag_id: UUID,
        unternehmen_id: UUID,
        benutzer_id: UUID,
        notiz: str | None,
    ) -> ZuordnungsVorschlag:
        """Setzt Vorschlag auf MANUELL_ABGELEHNT (BANK-06).

        Idempotent: bereits abgelehnt → unveraendert zurueckgeben.
        Bereits bestaetigt → ablehnen erlaubt (Benutzer kann Entscheidung korrigieren).
        """
        vorschlag = await self.get_by_id(session, vorschlag_id, unternehmen_id)

        if vorschlag.status == STATUS_MANUELL_ABGELEHNT:
            return vorschlag  # idempotent

        vorschlag.status = STATUS_MANUELL_ABGELEHNT
        vorschlag.entschieden_at = datetime.now(tz=timezone.utc)
        vorschlag.entschieden_von_benutzer_id = benutzer_id
        vorschlag.entscheidungsnotiz = notiz
        vorschlag.updated_at = datetime.now(tz=timezone.utc)
        await session.flush()

        return vorschlag

    async def get_bestaetigte_buchung_ids(
        self,
        session: AsyncSession,
        unternehmen_id: UUID,
    ) -> set[UUID]:
        """Alle bankbuchung_ids mit MANUELL_BESTAETIGT-Zuordnung des Mandanten."""
        stmt = select(ZuordnungsVorschlag.bankbuchung_id).where(
            ZuordnungsVorschlag.unternehmen_id == unternehmen_id,
            ZuordnungsVorschlag.status == STATUS_MANUELL_BESTAETIGT,
        )
        result = await session.execute(stmt)
        return set(result.scalars().all())

    async def get_abgelehnte_paare(
        self,
        session: AsyncSession,
        unternehmen_id: UUID,
    ) -> set[tuple[UUID, UUID]]:
        """Alle (bankbuchung_id, rechnung_id)-Paare mit MANUELL_ABGELEHNT."""
        stmt = select(
            ZuordnungsVorschlag.bankbuchung_id,
            ZuordnungsVorschlag.rechnung_id,
        ).where(
            ZuordnungsVorschlag.unternehmen_id == unternehmen_id,
            ZuordnungsVorschlag.status == STATUS_MANUELL_ABGELEHNT,
        )
        result = await session.execute(stmt)
        return {(row[0], row[1]) for row in result.all()}

    async def list_vorschlaege(
        self,
        session: AsyncSession,
        unternehmen_id: UUID,
        bankbuchung_id: UUID | None = None,
        rechnung_id: UUID | None = None,
        status: str | None = None,
    ) -> list[ZuordnungsVorschlag]:
        """Tenant-gefilterte Liste — unternehmen_id aus RLS-Kontext gesichert."""
        q = select(ZuordnungsVorschlag).where(
            ZuordnungsVorschlag.unternehmen_id == unternehmen_id
        )
        if bankbuchung_id:
            q = q.where(ZuordnungsVorschlag.bankbuchung_id == bankbuchung_id)
        if rechnung_id:
            q = q.where(ZuordnungsVorschlag.rechnung_id == rechnung_id)
        if status:
            q = q.where(ZuordnungsVorschlag.status == status)
        result = await session.execute(q)
        return list(result.scalars().all())
