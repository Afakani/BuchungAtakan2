from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from apps.server.models.unternehmen import Unternehmen


class UnternehmenRepository:
    async def get_by_id(
        self,
        session: AsyncSession,
        id: UUID,
    ) -> Unternehmen | None:
        """Kein Tenant-Filter -- unternehmen ist die Root-Tabelle ohne unternehmen_id-Spalte."""
        stmt = select(Unternehmen).where(Unternehmen.id == id)
        result = await session.execute(stmt)
        return result.scalar_one_or_none()
