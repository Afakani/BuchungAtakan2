from uuid import UUID

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from apps.server.models.benutzer import Benutzer, Rolle
from apps.server.repositories.base import BaseRepository


class BenutzerRepository(BaseRepository[Benutzer]):
    model = Benutzer

    async def get_by_benutzername(
        self,
        session: AsyncSession,
        benutzername: str,
    ) -> Benutzer | None:
        """Login-Lookup via SECURITY DEFINER — bypasses benutzer FORCE RLS."""
        row = (await session.execute(
            text("SELECT * FROM auth_benutzer_by_name(:name)"),
            {"name": benutzername},
        )).mappings().one_or_none()
        if row is None:
            return None
        return Benutzer(
            id=row["id"],
            hashed_password=row["hashed_password"],
            unternehmen_id=row["unternehmen_id"],
            rolle=Rolle(row["rolle"]),
            aktiv=row["aktiv"],
        )

    async def get_by_id_raw(
        self,
        session: AsyncSession,
        id: UUID,
        unternehmen_id: UUID,
    ) -> Benutzer | None:
        """Token-Validierung via SECURITY DEFINER — prueft id + unternehmen_id + aktiv."""
        row = (await session.execute(
            text("SELECT * FROM auth_benutzer_by_id(:id, :unternehmen_id)"),
            {"id": id, "unternehmen_id": unternehmen_id},
        )).mappings().one_or_none()
        if row is None:
            return None
        return Benutzer(
            id=row["id"],
            unternehmen_id=row["unternehmen_id"],
            rolle=Rolle(row["rolle"]),
            aktiv=row["aktiv"],
        )
