"""RechnungRepository — Versionierungslogik und Mandantenfilter (RECH-08/09)."""
from datetime import datetime
from uuid import UUID

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from apps.server.models.rechnung import Erkennungslauf, Rechnung, RechnungsKandidat, RechnungsStatus
from apps.server.repositories.base import BaseRepository


def _parse_datum(datum: str | None) -> datetime | None:
    """Parse DD.MM.YYYY. None bei fehlendem oder ungültigem Wert."""
    if not datum:
        return None
    try:
        return datetime.strptime(datum.strip(), "%d.%m.%Y")
    except ValueError:
        return None


def _neue_version_ist_aktiv(
    vorhandenes_datum: datetime | None,
    neues_datum: datetime | None,
) -> bool:
    """
    True  → neue Version aktiv setzen, alte deaktivieren.
    False → neue Version als inaktive Historienzeile anlegen.

    Regel (RECH-08):
    - neues Datum > vorhandenes       : True  (neueres Datum gewinnt)
    - gleiches gültiges Datum         : True  (last-write-wins)
    - neues Datum < vorhandenes       : False (älteres nicht aktiv setzen)
    - neues Datum fehlt, vorhandenes
      hat gültiges Datum              : False (Schutz der aktiven Version)
    - neues Datum vorhanden, vorhan-
      denes fehlt                     : True  (neue Version hat Datum, alte nicht)
    - beide None                      : True  (last-write-wins, kein Vergleich möglich)
    """
    if neues_datum is None and vorhandenes_datum is None:
        return True
    if neues_datum is None:
        # Vorhandene hat gültiges Datum → aktive Version schützen
        return False
    if vorhandenes_datum is None:
        # Neue hat Datum, vorhandene nicht → neue gewinnt
        return True
    return neues_datum >= vorhandenes_datum


class RechnungRepository(BaseRepository[Rechnung]):
    model = Rechnung

    async def list_aktive(
        self, session: AsyncSession, unternehmen_id: UUID
    ) -> list[Rechnung]:
        """RECH-09: nur ist_aktiv=True für Matching verwendbar."""
        stmt = select(Rechnung).where(
            Rechnung.unternehmen_id == unternehmen_id,
            Rechnung.ist_aktiv.is_(True),
        )
        result = await session.execute(stmt)
        return list(result.scalars().all())

    async def get_aktive_by_nummer(
        self, session: AsyncSession, nummer: str, unternehmen_id: UUID
    ) -> Rechnung | None:
        stmt = select(Rechnung).where(
            Rechnung.unternehmen_id == unternehmen_id,
            Rechnung.rechnungsnummer == nummer,
            Rechnung.ist_aktiv.is_(True),
        )
        result = await session.execute(stmt)
        return result.scalar_one_or_none()

    async def _get_erkennungslauf_by_id(
        self, session: AsyncSession, erkennungslauf_id: UUID, unternehmen_id: UUID
    ) -> Erkennungslauf:
        """Mandantengefilterte Erkennungslauf-Abfrage. 404 bei fremdem oder fehlendem Lauf."""
        stmt = select(Erkennungslauf).where(
            Erkennungslauf.id == erkennungslauf_id,
            Erkennungslauf.unternehmen_id == unternehmen_id,
        )
        result = await session.execute(stmt)
        obj = result.scalar_one_or_none()
        if obj is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Erkennungslauf nicht gefunden",
            )
        return obj

    def _baue_neue_version(
        self,
        unternehmen_id: UUID,
        dokument_id: UUID,
        felder: dict,
        initial_status: RechnungsStatus,
        vorhandene: Rechnung | None,
    ) -> tuple[Rechnung, bool]:
        """
        Reine Logik — kein DB-Zugriff.
        Returns: (neue_rechnung, alte_deaktivieren).
        """
        if vorhandene is None:
            neue = Rechnung(
                unternehmen_id=unternehmen_id,
                dokument_id=dokument_id,
                version_lfd_nr=1,
                ist_aktiv=True,
                status=str(initial_status),
                **felder,
            )
            return neue, False

        neues_datum = _parse_datum(felder.get("rechnungsdatum"))
        vorhandenes_datum = _parse_datum(vorhandene.rechnungsdatum)
        aktiv = _neue_version_ist_aktiv(vorhandenes_datum, neues_datum)

        neue = Rechnung(
            unternehmen_id=unternehmen_id,
            dokument_id=dokument_id,
            version_lfd_nr=vorhandene.version_lfd_nr + 1,
            ist_aktiv=aktiv,
            status=str(initial_status),
            **felder,
        )
        return neue, aktiv

    async def create_version(
        self,
        session: AsyncSession,
        unternehmen_id: UUID,
        dokument_id: UUID,
        felder: dict,
        initial_status: RechnungsStatus = RechnungsStatus.NEU,
        erkennungslauf_id: UUID | None = None,
    ) -> Rechnung:
        """
        RECH-08/09: Versionierungslogik.

        felder: Rechnungsfelder ohne id, unternehmen_id, status, version_lfd_nr,
                ist_aktiv, dokument_id.
        initial_status: vom Router gesetzt (PRUEFFALL bei RECH-06, sonst NEU).
        erkennungslauf_id: wenn angegeben, Erkennungslauf mandantensicher prüfen
                           und nach Erstellung mit Rechnung verknüpfen.

        Ersetzte Versionen bleiben als Zeilen mit ist_aktiv=False erhalten.
        list_aktive() und Matching-Queries filtern ist_aktiv=True.
        """
        # Erkennungslauf vorab prüfen (404 bevor Rechnung erzeugt wird)
        erkennungslauf: Erkennungslauf | None = None
        if erkennungslauf_id is not None:
            erkennungslauf = await self._get_erkennungslauf_by_id(
                session, erkennungslauf_id, unternehmen_id
            )

        rechnungsnummer = felder.get("rechnungsnummer")
        vorhandene: Rechnung | None = None
        if rechnungsnummer:
            vorhandene = await self.get_aktive_by_nummer(
                session, rechnungsnummer, unternehmen_id
            )

        neue, alte_deaktivieren = self._baue_neue_version(
            unternehmen_id, dokument_id, felder, initial_status, vorhandene
        )

        if alte_deaktivieren and vorhandene is not None:
            vorhandene.ist_aktiv = False

        session.add(neue)
        await session.flush()  # erzeugt neue.id und server_defaults via RETURNING

        if erkennungslauf is not None:
            erkennungslauf.rechnung_id = neue.id

        await session.commit()
        return neue

    async def list_erkennungslaeufe(
        self, session: AsyncSession, rechnung_id: UUID, unternehmen_id: UUID
    ) -> list[Erkennungslauf]:
        """Mandantengefilterte Erkennungsläufe für eine Rechnung (RECH-03/11)."""
        stmt = select(Erkennungslauf).where(
            Erkennungslauf.rechnung_id == rechnung_id,
            Erkennungslauf.unternehmen_id == unternehmen_id,
        )
        result = await session.execute(stmt)
        return list(result.scalars().all())

    async def list_kandidaten_fuer_rechnung(
        self, session: AsyncSession, rechnung_id: UUID, unternehmen_id: UUID
    ) -> list[RechnungsKandidat]:
        """
        Kandidaten über zugehörige Erkennungsläufe laden — mandantengefiltert (RECH-11).
        Erst Rechnung prüfen (get_by_id), dann Läufe, dann Kandidaten.
        """
        laeufe = await self.list_erkennungslaeufe(session, rechnung_id, unternehmen_id)
        if not laeufe:
            return []
        lauf_ids = [lauf.id for lauf in laeufe]
        stmt = select(RechnungsKandidat).where(
            RechnungsKandidat.erkennungslauf_id.in_(lauf_ids),
            RechnungsKandidat.unternehmen_id == unternehmen_id,
        )
        result = await session.execute(stmt)
        return list(result.scalars().all())
