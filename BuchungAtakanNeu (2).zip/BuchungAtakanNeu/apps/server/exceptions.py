import logging
import traceback
import uuid

from fastapi import FastAPI
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.requests import Request

logger = logging.getLogger("buchungatakan.server")


def register_exception_handlers(app: FastAPI) -> None:
    @app.exception_handler(StarletteHTTPException)
    async def http_exception_handler(
        request: Request, exc: StarletteHTTPException
    ) -> JSONResponse:
        if exc.status_code >= 500:
            ref_id = str(uuid.uuid4())
            logger.error(
                "[%s] Server-Fehler %s auf %s",
                ref_id, exc.status_code, request.url.path,
            )
            return JSONResponse(
                {"detail": "Interner Serverfehler", "reference_id": ref_id},
                status_code=exc.status_code,
            )
        return JSONResponse({"detail": exc.detail}, status_code=exc.status_code)

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(
        request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        errors = [
            {"field": ".".join(str(loc) for loc in e["loc"]), "message": e["msg"]}
            for e in exc.errors()
        ]
        return JSONResponse({"detail": errors}, status_code=422)

    @app.exception_handler(Exception)
    async def unhandled_exception_handler(
        request: Request, exc: Exception
    ) -> JSONResponse:
        ref_id = str(uuid.uuid4())
        logger.error(
            "[%s] Unerwarteter Fehler auf %s %s:\n%s",
            ref_id, request.method, request.url.path, traceback.format_exc(),
        )
        return JSONResponse(
            {"detail": "Interner Serverfehler", "reference_id": ref_id},
            status_code=500,
        )
