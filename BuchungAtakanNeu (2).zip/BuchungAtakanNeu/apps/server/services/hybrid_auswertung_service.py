"""Persistenz der Mehrprovider-Auswertung (HYB-14..16) in bestehende 07-01-Tabellen.

Idempotent: existiert bereits eine HybridStatusentscheidung fuer eine konkrete
erkennungslauf_id, wird nicht erneut geschrieben -- schuetzt bestehende/manuell
entschiedene Ergebnisse vor ungefragtem Ueberschreiben. Der Schluessel dafuer ist
UNIQUE(unternehmen_id, erkennungslauf_id) (Migration 011) -- eindeutig nur, wenn
erkennungslauf_id gesetzt ist. PostgreSQL behandelt NULL in UNIQUE-Constraints als
paarweise verschieden (SQL-Standard); mehrere Zeilen mit erkennungslauf_id=NULL fuer
denselben Mandanten sind also DB-seitig ausdruecklich zulaessig. Ohne erkennungslauf_id
gibt es daher keinen eindeutigen fachlichen Schluessel -- jeder solche Aufruf ist ein
eigenstaendiger Lauf und wird immer geschrieben, nie ueber IS NULL dedupliziert.
Keine neue Migration -- kandidaten_ids_json (Text) traegt die zusaetzlichen
Konfliktdetails (Werte, Provider, Konfliktart, Begruendung, Schweregrad,
Aufloesungsstatus) als JSON.
"""
from __future__ import annotations

import json
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from apps.server.models.hybrid_extraktion import (
    HybridErkennungslauf,
    HybridKandidatOrm,
    HybridKonflikt,
    HybridStatusentscheidung,
)
from packages.core.invoice_extraction.hybrid_auswertung import HybridAuswertungsErgebnis
from packages.core.invoice_extraction.hybrid_ergebnis import PFLICHT_FELDER
from packages.core.invoice_extraction.hybrid_kandidat import AuswahlStatus


async def persistiere_hybrid_auswertung(
    session: AsyncSession,
    unternehmen_id: UUID,
    erkennungslauf_id: UUID | None,
    auswertung: HybridAuswertungsErgebnis,
) -> bool:
    """Schreibt Erkennungslaeufe, Kandidaten, Konflikte und Statusentscheidung.

    Gibt True zurueck wenn geschrieben, False wenn fuer eine konkrete erkennungslauf_id
    bereits eine Statusentscheidung existiert (idempotenter No-Op). Ohne erkennungslauf_id
    (None) gibt es keinen eindeutigen Schluessel -- die Idempotenzpruefung entfaellt,
    jeder Aufruf schreibt einen eigenstaendigen Lauf.
    """
    if erkennungslauf_id is not None:
        bestehend = await session.execute(
            select(HybridStatusentscheidung).where(
                HybridStatusentscheidung.unternehmen_id == unternehmen_id,
                HybridStatusentscheidung.erkennungslauf_id == erkennungslauf_id,
            )
        )
        if bestehend.scalar_one_or_none() is not None:
            return False

    lauf_id_je_provider: dict[str, UUID] = {}

    async def _lauf_id_fuer(provider_name: str, provider_version: str | None) -> UUID:
        if provider_name not in lauf_id_je_provider:
            lauf = HybridErkennungslauf(
                unternehmen_id=unternehmen_id,
                erkennungslauf_id=erkennungslauf_id,
                provider_name=provider_name,
                provider_version=provider_version,
                laufstatus="success",
                fehlercode=None,
            )
            session.add(lauf)
            await session.flush()
            lauf_id_je_provider[provider_name] = lauf.id
        return lauf_id_je_provider[provider_name]

    for provider_ergebnis in auswertung.provider_ergebnisse:
        lauf = HybridErkennungslauf(
            unternehmen_id=unternehmen_id,
            erkennungslauf_id=erkennungslauf_id,
            provider_name=provider_ergebnis.provider_name,
            provider_version=provider_ergebnis.provider_version,
            laufstatus=provider_ergebnis.laufstatus,
            fehlercode=provider_ergebnis.fehlercode,
            lauf_dauer_ms=provider_ergebnis.lauf_dauer_ms,
            seiten_anzahl=provider_ergebnis.seiten_anzahl,
        )
        session.add(lauf)
        await session.flush()
        lauf_id_je_provider[provider_ergebnis.provider_name] = lauf.id

    for kandidat in auswertung.kandidaten:
        hybrid_lauf_id = await _lauf_id_fuer(kandidat.provider_name, kandidat.provider_version)
        session.add(HybridKandidatOrm(
            unternehmen_id=unternehmen_id,
            hybrid_erkennungslauf_id=hybrid_lauf_id,
            feld=kandidat.feld,
            rohwert=kandidat.rohwert,
            normwert=kandidat.normwert,
            methode=kandidat.methode,
            provider_name=kandidat.provider_name,
            provider_version=kandidat.provider_version,
            confidence=kandidat.confidence,
            seite=kandidat.seite,
            bbox_json=json.dumps(kandidat.bbox) if kandidat.bbox else None,
            validierungsbefund=kandidat.validierungsbefund,
            konflikt_gruppe=kandidat.konflikt_gruppe,
            auswahl_status=str(kandidat.auswahl_status) if kandidat.auswahl_status else None,
            auswahl_grund=kandidat.auswahl_grund,
        ))

    for konflikt in auswertung.konflikte:
        session.add(HybridKonflikt(
            unternehmen_id=unternehmen_id,
            erkennungslauf_id=erkennungslauf_id,
            feld=konflikt.feld,
            konflikt_gruppe=konflikt.feld,
            kandidaten_ids_json=json.dumps({
                "werte": list(konflikt.werte),
                "provider": list(konflikt.provider),
                "konfliktart": konflikt.konfliktart,
                "begruendung": konflikt.begruendung,
                "schweregrad": konflikt.schweregrad,
                "aufloesungsstatus": konflikt.aufloesungsstatus,
            }),
        ))

    ausgewaehlte_felder = {
        k.feld for k in auswertung.kandidaten if k.auswahl_status == AuswahlStatus.AUSGEWAEHLT
    }
    betragsrelation_befunde = [b for b in auswertung.plausibilitaet if b.regel == "betragsrelation"]
    math_validierung_ok = betragsrelation_befunde[0].bestanden if betragsrelation_befunde else None

    session.add(HybridStatusentscheidung(
        unternehmen_id=unternehmen_id,
        erkennungslauf_id=erkennungslauf_id,
        hybrid_status=str(auswertung.status),
        gruende_json=json.dumps(auswertung.gruende),
        pflichtfelder_ok=not bool(PFLICHT_FELDER - ausgewaehlte_felder),
        math_validierung_ok=math_validierung_ok,
        konflikt_frei=not any(k.feld in PFLICHT_FELDER for k in auswertung.konflikte),
        confidence_ausreichend=None,
        dokument_klasse=str(auswertung.dokument_klasse) if auswertung.dokument_klasse else None,
    ))

    await session.commit()
    return True
