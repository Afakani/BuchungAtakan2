"""EC-Sammelzuordnung Service — Phase 06, Paket 2.

Orchestriert den mandantensicheren Rematch-Lauf:
  1. Bankkonto pruefen (404 bei fremdem Konto)
  2. EC_EINZAHLUNG-Buchungen laden (chronologisch)
  3. Offene EC-Belege laden (VERFUEGBAR, selbes Bankkonto)
  4. Geschuetzte Beleg-IDs (MANUELL_BESTAETIGT) laden → niemals ueberschreiben
  5. Abgelehnte Fingerprints (MANUELL_ABGELEHNT) laden → keine Neuvorschlaege mit gleichem Fingerprint
  6. Bestaetigte Bankbuchung-IDs laden → ueberspringen
  7. Fuer jede EC_EINZAHLUNG (chronologisch):
     - Uebersprungen wenn schon MANUELL_BESTAETIGT
     - verfuegbare Belege = offene Belege − geschuetzte − schon verbrauchte
     - gruppiere_belege() aufrufen (letzte Einzahlung: offene_periode=True)
     - gruppen_fingerprint berechnen
     - Uebersprungen wenn Fingerprint abgelehnt
     - Aktive Belege als verbraucht markieren (nicht entfernte)
  8. EcSammellaeufe erzeugen
  9. Vorschlaege upserten (inkl. Beleg-Eintraege)
 10. Metriken zurueckgeben
"""
from datetime import timedelta
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from apps.server.repositories.ec_sammelzuordnung import (
    ECSammelzuordnungRepository,
    berechne_gruppen_fingerprint,
)
from packages.core.ec_sammlung.gruppierung import gruppiere_belege
from packages.core.ec_sammlung.scorer import MATCHER_VERSION
from packages.core.ec_sammlung.typen import EcBeleg as CoreEcBeleg, EcSammelStatus


class ECSammelzuordnungService:
    def __init__(self) -> None:
        self._repo = ECSammelzuordnungRepository()

    async def rematch(
        self,
        session: AsyncSession,
        unternehmen_id: UUID,
        bankkonto_id: UUID,
        max_verzoegerung_tage: int = 2,
    ) -> dict:
        """Fuehrt mandantensicheren Rematch durch.

        Returns dict mit Metriken:
          bankbuchungen_geprueft, ec_einzahlungen_geprueft,
          ec_belege_geprueft, vorschlaege_gesamt, stark, unsicher,
          ohne_vorschlag, matcher_version
        """
        await self._repo.get_bankkonto(session, bankkonto_id, unternehmen_id)

        einzahlungen = await self._repo.list_ec_einzahlungen(session, unternehmen_id, bankkonto_id)
        offene_belege = await self._repo.get_offene_ec_belege(session, unternehmen_id, bankkonto_id)
        geschuetzte_beleg_ids = await self._repo.get_geschuetzte_beleg_ids(session, unternehmen_id)
        abgelehnte_fingerprints = await self._repo.get_abgelehnte_fingerprints(session, unternehmen_id, bankkonto_id)
        bestaetigte_buchung_ids = await self._repo.get_bestaetigte_bankbuchung_ids(session, unternehmen_id, bankkonto_id)

        # Core-Beleg-Dataclasses aus ORM-Objekten, Geschuetzte und negative Betraege herausfiltern
        freie_belege = [
            b for b in offene_belege
            if b.id not in geschuetzte_beleg_ids and b.betrag_cent > 0
        ]
        core_beleg_map: dict[UUID, CoreEcBeleg] = {
            b.id: CoreEcBeleg(id=b.id, betrag_cent=b.betrag_cent, buchungsdatum=b.buchungsdatum)
            for b in freie_belege
        }

        # Letzten zu verarbeitenden Index bestimmen (→ offene_periode)
        letzte_zu_verarbeitende_idx: int | None = None
        for idx, e in enumerate(einzahlungen):
            if e.id not in bestaetigte_buchung_ids:
                letzte_zu_verarbeitende_idx = idx

        verbrauchte_beleg_ids: set[UUID] = set()
        vorschlaege: list[dict] = []
        ohne_vorschlag = 0

        for idx, einzahlung in enumerate(einzahlungen):
            if einzahlung.id in bestaetigte_buchung_ids:
                ohne_vorschlag += 1
                continue

            ist_letzte = (idx == letzte_zu_verarbeitende_idx)

            verfuegbare_core_belege = [
                b for bid, b in core_beleg_map.items()
                if bid not in verbrauchte_beleg_ids
            ]

            if not verfuegbare_core_belege and not ist_letzte:
                ohne_vorschlag += 1
                continue

            ergebnis = gruppiere_belege(
                einzahlung_cent=einzahlung.betrag_cent,
                belege=verfuegbare_core_belege,
                einzahlungsdatum=einzahlung.buchungsdatum,
                max_verzoegerung_tage=max_verzoegerung_tage,
                offene_periode=ist_letzte,
            )

            if not ergebnis.aktive_belege and not ist_letzte:
                ohne_vorschlag += 1
                continue

            aktive_ids = [b.id for b in ergebnis.aktive_belege]
            entfernte_ids = [b.id for b in ergebnis.entfernte_belege]
            fingerprint = berechne_gruppen_fingerprint(einzahlung.id, aktive_ids)

            if fingerprint in abgelehnte_fingerprints:
                ohne_vorschlag += 1
                continue

            # Nur aktive als verbraucht markieren — entfernte bleiben fuer spaetere Einzahlungen
            for bid in aktive_ids:
                verbrauchte_beleg_ids.add(bid)

            sammellauf_id = await self._repo.speichere_sammellauf(
                session, unternehmen_id, einzahlung.id, MATCHER_VERSION
            )

            fenster_bis = einzahlung.buchungsdatum
            fenster_von = fenster_bis - timedelta(days=max_verzoegerung_tage)

            vorschlaege.append({
                "sammellauf_id": sammellauf_id,
                "bankbuchung_id": einzahlung.id,
                "bankkonto_id": bankkonto_id,
                "gruppen_fingerprint": fingerprint,
                "score": ergebnis.score,
                "status": ergebnis.status,
                "summe_cent": ergebnis.summe_cent,
                "einzahlung_cent": einzahlung.betrag_cent,
                "differenz_cent": ergebnis.differenz_cent,
                "positive_signale": [s.als_dict() for s in ergebnis.positive_signale],
                "negative_signale": [s.als_dict() for s in ergebnis.negative_signale],
                "matcher_version": MATCHER_VERSION,
                "max_verzoegerung_tage": max_verzoegerung_tage,
                "fenster_von": fenster_von,
                "fenster_bis": fenster_bis,
                "aktive_beleg_ids": aktive_ids,
                "entfernte_beleg_ids": entfernte_ids,
            })

        await self._repo.upsert_automatische_vorschlaege(session, unternehmen_id, vorschlaege)
        await session.commit()

        stark = sum(1 for v in vorschlaege if v["status"] == EcSammelStatus.STARK)
        unsicher = sum(1 for v in vorschlaege if v["status"] != EcSammelStatus.STARK)

        return {
            "bankbuchungen_geprueft": len(einzahlungen),
            "ec_einzahlungen_geprueft": len(einzahlungen),
            "ec_belege_geprueft": len(freie_belege),
            "vorschlaege_gesamt": len(vorschlaege),
            "stark": stark,
            "unsicher": unsicher,
            "ohne_vorschlag": ohne_vorschlag,
            "matcher_version": MATCHER_VERSION,
        }
