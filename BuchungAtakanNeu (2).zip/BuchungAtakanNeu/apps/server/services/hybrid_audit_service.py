"""HybridAuditService — Validierung, Tenant-Sicherheit, Auswahl neuester Bewertung (HYB-17/18).

Audit-Bewertungen sind append-only: Erstellung ist die einzige Schreiboperation,
kein Update, kein Delete. Tenant-Sicherheit wird vor jedem Zugriff auf eine
HybridStatusentscheidung geprueft (404 bei fremder/fehlender ID) -- ein Tenant kann
weder Bewertungen einer fremden Statusentscheidung lesen noch eine fremde bewerten.
"""
from __future__ import annotations

from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from apps.server.models.hybrid_extraktion import HybridAuditBewertung
from apps.server.repositories.hybrid import (
    HybridAuditRepository,
    HybridStatusentscheidungRepository,
)
from packages.core.invoice_extraction.hybrid_audit import AuditBewertungFelder
from packages.core.invoice_extraction.hybrid_statistik import (
    ALLE_DIMENSIONEN,
    StatistikGruppe,
    gruppiere_statistik,
)


class HybridAuditService:
    def __init__(self) -> None:
        self._statusentscheidung_repo = HybridStatusentscheidungRepository()
        self._audit_repo = HybridAuditRepository()

    async def bewerte(
        self,
        session: AsyncSession,
        unternehmen_id: UUID,
        hybrid_statusentscheidung_id: UUID,
        felder: AuditBewertungFelder,
    ) -> HybridAuditBewertung:
        """Legt eine neue Auditbewertung an -- append-only, ueberschreibt nie."""
        await self._statusentscheidung_repo.get_by_id(
            session, hybrid_statusentscheidung_id, unternehmen_id
        )
        return await self._audit_repo.create_audit_bewertung(
            session, unternehmen_id, hybrid_statusentscheidung_id, felder
        )

    async def neueste_bewertung(
        self,
        session: AsyncSession,
        unternehmen_id: UUID,
        hybrid_statusentscheidung_id: UUID,
    ) -> HybridAuditBewertung | None:
        await self._statusentscheidung_repo.get_by_id(
            session, hybrid_statusentscheidung_id, unternehmen_id
        )
        return await self._audit_repo.latest_by_statusentscheidung(
            session, unternehmen_id, hybrid_statusentscheidung_id
        )

    async def statistik(
        self,
        session: AsyncSession,
        unternehmen_id: UUID,
        dimensionen: tuple[str, ...] = ALLE_DIMENSIONEN,
    ) -> list[StatistikGruppe]:
        zeilen = await self._audit_repo.list_statistik_zeilen(session, unternehmen_id)
        return gruppiere_statistik(zeilen, dimensionen)
