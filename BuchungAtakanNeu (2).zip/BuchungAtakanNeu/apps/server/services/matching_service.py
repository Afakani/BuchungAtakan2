"""MatchingService — koordiniert Scorer und ZuordnungRepository.

Rematch-Schutz (BANK-06/07/08):
- Buchungen mit MANUELL_BESTAETIGT-Zuordnung werden vom Rematch ausgeschlossen (BANK-07).
- Abgelehnte (buchung_id, rechnung_id)-Paare werden beim Scoring uebersprungen (BANK-06).
- Offene automatische Vorschlaege duerfen weiter aktualisiert werden (BANK-08).
- Nur MATCHBAR-Buchungen erhalten Vorschlaege (BANK-11).
- Nur aktive Rechnungen des eigenen Mandanten als Kandidaten (BANK-09).
"""
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from apps.server.models.bankbuchung import Bankbuchung
from apps.server.models.rechnung import Rechnung
from apps.server.repositories.zuordnung import ZuordnungRepository
from packages.core.matching.scorer import berechne_match
from packages.core.matching.signale import MatchErgebnis


class MatchingService:
    def __init__(self) -> None:
        self._zuordnung_repo = ZuordnungRepository()

    async def rematch(
        self,
        session: AsyncSession,
        unternehmen_id: UUID,
    ) -> dict:
        """Vollstaendiges Rematch fuer den Mandanten.

        1. Buchungen mit bestaetigter Zuordnung ausschliessen (BANK-07).
        2. Abgelehnte Paare ausschliessen (BANK-06).
        3. Nur MATCHBAR-Buchungen und aktive Rechnungen bewerten.
        4. Kandidaten per Upsert speichern; Upsert-WHERE schützt manuelle Zeilen.
        """
        # BANK-07: buchungen_ids mit bestaetigter Zuordnung ermitteln
        bestaetigte_buchung_ids = await self._zuordnung_repo.get_bestaetigte_buchung_ids(
            session, unternehmen_id
        )

        # BANK-06: abgelehnte Paare ermitteln
        abgelehnte_paare = await self._zuordnung_repo.get_abgelehnte_paare(
            session, unternehmen_id
        )

        buchungen = await self._get_matchbare_buchungen(
            session, unternehmen_id, ausschliessen=bestaetigte_buchung_ids
        )
        rechnungen = await self._get_aktive_rechnungen(session, unternehmen_id)

        if not buchungen or not rechnungen:
            return {
                "buchungen_geprueft": len(buchungen),
                "rechnungen_kandidaten": len(rechnungen),
                "vorschlaege_gesamt": 0,
            }

        alle_ergebnisse: list[MatchErgebnis] = []
        for buchung in buchungen:
            for rechnung in rechnungen:
                # BANK-06: abgelehnte Paarung ueberspringen
                if (buchung.id, rechnung.id) in abgelehnte_paare:
                    continue

                ergebnis = berechne_match(
                    bankbuchung_id=buchung.id,
                    bank_betrag_cent=buchung.betrag_cent,
                    bank_buchungsdatum=buchung.buchungsdatum,
                    bank_verwendungszweck=buchung.verwendungszweck,
                    bank_gegenpartei_name=buchung.gegenpartei_name,
                    rechnung_id=rechnung.id,
                    rechnung_gesamtbetrag=rechnung.gesamtbetrag,
                    rechnung_datum=rechnung.rechnungsdatum,
                    rechnung_nummer=rechnung.rechnungsnummer,
                    rechnung_lieferant=rechnung.lieferant_name,
                )
                if ergebnis.ist_kandidat:
                    alle_ergebnisse.append(ergebnis)

        gesamt, _ = await self._zuordnung_repo.upsert_vorschlaege(
            session, unternehmen_id, alle_ergebnisse
        )

        return {
            "buchungen_geprueft": len(buchungen),
            "rechnungen_kandidaten": len(rechnungen),
            "vorschlaege_gesamt": gesamt,
        }

    async def _get_matchbare_buchungen(
        self,
        session: AsyncSession,
        unternehmen_id: UUID,
        ausschliessen: set[UUID] | None = None,
    ) -> list[Bankbuchung]:
        """Nur MATCHBAR-Buchungen; optional bestaetigte Buchungen ausschliessen."""
        stmt = select(Bankbuchung).where(
            Bankbuchung.unternehmen_id == unternehmen_id,
            Bankbuchung.klassifikation == "MATCHBAR",
        )
        result = await session.execute(stmt)
        alle = list(result.scalars().all())

        if ausschliessen:
            alle = [b for b in alle if b.id not in ausschliessen]

        return alle

    async def _get_aktive_rechnungen(
        self, session: AsyncSession, unternehmen_id: UUID
    ) -> list[Rechnung]:
        """Nur aktive Rechnungen des GLEICHEN Mandanten (BANK-09)."""
        stmt = select(Rechnung).where(
            Rechnung.unternehmen_id == unternehmen_id,
            Rechnung.ist_aktiv.is_(True),
        )
        result = await session.execute(stmt)
        return list(result.scalars().all())
