from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    DATABASE_URL: str
    SECRET_KEY: str
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    ENVIRONMENT: str = "development"
    BUCHUNG_ATAKAN_SEED_TEST_DATA: str = "0"

    # Feature-Flags Phase 07 (HYB-01) — alle default False
    BUCHUNG_ATAKAN_FEATURE_HYBRID_PIPELINE: bool = False
    BUCHUNG_ATAKAN_FEATURE_INVOICE2DATA: bool = False
    BUCHUNG_ATAKAN_FEATURE_PADDLE_OCR: bool = False
    BUCHUNG_ATAKAN_FEATURE_AZURE_DI: bool = False  # Legacy (07-01) — inert, aktiviert nichts mehr
    BUCHUNG_ATAKAN_FEATURE_QUALITAETSAUDIT: bool = False
    # Kanonisches Azure-Flag Paket 07-04 (HYB-20) — einzige Steuerung fuer
    # AzureDocumentIntelligenceProvider; das Legacy-Flag oben bleibt bewusst wirkungslos.
    BUCHUNG_ATAKAN_FEATURE_AZURE_DOCUMENT_INTELLIGENCE: bool = False

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )


settings = Settings()
