from uuid import UUID

from fastapi import APIRouter, status
from pydantic import BaseModel
from sqlalchemy import select

from apps.server.auth.dependencies import CurrentTenantId, RLSSession
from apps.server.models.installationen import Installation

router = APIRouter(prefix="/api/v1/installationen", tags=["installationen"])


class InstallationRegistrierenRequest(BaseModel):
    model_config = {"extra": "forbid"}

    installation_id: UUID
    bezeichnung: str | None = None


class InstallationResponse(BaseModel):
    id: UUID
    unternehmen_id: UUID
    bezeichnung: str | None


@router.post("", status_code=status.HTTP_201_CREATED, response_model=InstallationResponse)
async def installation_registrieren(
    request: InstallationRegistrierenRequest,
    unternehmen_id: CurrentTenantId,
    session: RLSSession,
) -> InstallationResponse:
    """Registriert oder gibt bestehende Installation zurueck (idempotent per installation_id)."""
    stmt = select(Installation).where(Installation.id == request.installation_id)
    result = await session.execute(stmt)
    existing = result.scalar_one_or_none()
    if existing is not None:
        return InstallationResponse(
            id=existing.id,
            unternehmen_id=existing.unternehmen_id,
            bezeichnung=existing.bezeichnung,
        )
    installation = Installation(
        id=request.installation_id,
        unternehmen_id=unternehmen_id,
        bezeichnung=request.bezeichnung,
    )
    session.add(installation)
    await session.commit()
    await session.refresh(installation)
    return InstallationResponse(
        id=installation.id,
        unternehmen_id=installation.unternehmen_id,
        bezeichnung=installation.bezeichnung,
    )
