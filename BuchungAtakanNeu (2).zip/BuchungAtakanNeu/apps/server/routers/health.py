from fastapi import APIRouter

router = APIRouter(tags=["health"])


@router.get("/health")
async def liveness() -> dict:
    return {"status": "ok"}


@router.get("/api/v1/readiness")
async def readiness() -> dict:
    return {"status": "ready"}
