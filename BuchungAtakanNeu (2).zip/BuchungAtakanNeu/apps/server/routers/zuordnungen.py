"""Zuordnungen-Router — Rematch, Liste, manuelle Entscheidungen (BANK-04..09)."""
from datetime import datetime
from uuid import UUID

from fastapi import APIRouter, Query
from pydantic import BaseModel, Field

from apps.server.auth.dependencies import CurrentTenantId, CurrentUser, RLSSession
from apps.server.repositories.zuordnung import ZuordnungRepository
from apps.server.services.matching_service import MatchingService

router = APIRouter(prefix="/api/v1", tags=["zuordnungen"])
_zuordnung_repo = ZuordnungRepository()
_matching_service = MatchingService()

# Gueltiger Status-Wertebereich fuer GET-Filter
_STATUS_PATTERN = "^(STARK|UNSICHER|MANUELL_BESTAETIGT|MANUELL_ABGELEHNT)$"


# ── Schemas ───────────────────────────────────────────────────────────────────

class RematchResponse(BaseModel):
    buchungen_geprueft: int
    rechnungen_kandidaten: int
    vorschlaege_gesamt: int


class EntscheidungRequest(BaseModel):
    model_config = {"extra": "forbid"}
    notiz: str | None = Field(default=None, max_length=500)


class ZuordnungsVorschlagResponse(BaseModel):
    model_config = {"from_attributes": True}

    id: UUID
    bankbuchung_id: UUID
    rechnung_id: UUID
    score: int
    status: str
    positive_signale: list[dict]
    negative_signale: list[dict]
    matcher_version: str
    entschieden_at: datetime | None
    entscheidungsnotiz: str | None
    created_at: datetime
    updated_at: datetime


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.post(
    "/zuordnungen/rematch",
    response_model=RematchResponse,
    status_code=200,
    summary="Alle MATCHBAR-Buchungen mit aktiven Rechnungen abgleichen (BANK-08)",
)
async def rematch(
    session: RLSSession,
    unternehmen_id: CurrentTenantId,
) -> RematchResponse:
    """Loest vollstaendiges Rematch aus.

    BANK-07: bestaetigte Zuordnungen werden nicht veraendert.
    BANK-06: abgelehnte Paarungen erscheinen nicht erneut.
    BANK-08: offene Vorschlaege werden aktualisiert.
    """
    ergebnis = await _matching_service.rematch(session, unternehmen_id)
    return RematchResponse(**ergebnis)


@router.get(
    "/zuordnungen",
    response_model=list[ZuordnungsVorschlagResponse],
    summary="Zuordnungsvorschlaege mandantengefiltert abrufen",
)
async def list_zuordnungen(
    session: RLSSession,
    unternehmen_id: CurrentTenantId,
    bankbuchung_id: UUID | None = Query(default=None),
    rechnung_id: UUID | None = Query(default=None),
    status: str | None = Query(default=None, pattern=_STATUS_PATTERN),
) -> list[ZuordnungsVorschlagResponse]:
    """Listet Zuordnungsvorschlaege des Mandanten.

    Filter (alle optional): bankbuchung_id, rechnung_id, status.
    """
    vorschlaege = await _zuordnung_repo.list_vorschlaege(
        session,
        unternehmen_id,
        bankbuchung_id=bankbuchung_id,
        rechnung_id=rechnung_id,
        status=status,
    )
    return [ZuordnungsVorschlagResponse.model_validate(v) for v in vorschlaege]


@router.post(
    "/zuordnungen/{vorschlag_id}/bestaetigen",
    response_model=ZuordnungsVorschlagResponse,
    status_code=200,
    summary="Zuordnungsvorschlag manuell bestaetigen (BANK-05/07)",
)
async def bestaetigen(
    vorschlag_id: UUID,
    body: EntscheidungRequest,
    session: RLSSession,
    unternehmen_id: CurrentTenantId,
    current_user: CurrentUser,
) -> ZuordnungsVorschlagResponse:
    """Bestaetigt einen Zuordnungsvorschlag manuell.

    BANK-05: Scheitert mit 409 wenn Buchung bereits eine bestaetigte Zuordnung hat.
    BANK-07: Bestaetigte Zuordnung wird danach von keinem Automatiklauf ueberschrieben.
    Idempotent: Wiederholte Bestaetigung desselben Vorschlags ist stabil.
    Benutzer-ID ausschliesslich aus JWT, nie aus Request-Body.
    """
    vorschlag = await _zuordnung_repo.bestaetigen(
        session,
        vorschlag_id,
        unternehmen_id,
        benutzer_id=current_user.id,
        notiz=body.notiz,
    )
    return ZuordnungsVorschlagResponse.model_validate(vorschlag)


@router.post(
    "/zuordnungen/{vorschlag_id}/ablehnen",
    response_model=ZuordnungsVorschlagResponse,
    status_code=200,
    summary="Zuordnungsvorschlag manuell ablehnen (BANK-06)",
)
async def ablehnen(
    vorschlag_id: UUID,
    body: EntscheidungRequest,
    session: RLSSession,
    unternehmen_id: CurrentTenantId,
    current_user: CurrentUser,
) -> ZuordnungsVorschlagResponse:
    """Lehnt einen Zuordnungsvorschlag manuell ab.

    BANK-06: Abgelehnte Paarung erscheint bei keinem zukuenftigen Rematch erneut.
    Idempotent: Wiederholte Ablehnung desselben Vorschlags ist stabil.
    Benutzer-ID ausschliesslich aus JWT, nie aus Request-Body.
    """
    vorschlag = await _zuordnung_repo.ablehnen(
        session,
        vorschlag_id,
        unternehmen_id,
        benutzer_id=current_user.id,
        notiz=body.notiz,
    )
    return ZuordnungsVorschlagResponse.model_validate(vorschlag)
