"""EC-Sammelzuordnung Router — Phase 06, Paket 2+3.

Endpunkte:
  POST /api/v1/ec/belege/importe                        — EC-Belege importieren (idempotent)
  GET  /api/v1/ec/belege                                — EC-Belege auflisten
  POST /api/v1/ec/sammelzuordnungen/rematch             — Automatisches Matching starten
  GET  /api/v1/ec/sammelzuordnungen                     — Sammelzuordnungen auflisten
  GET  /api/v1/ec/sammelzuordnungen/{id}                — Sammelzuordnung mit Belegen (Detail)
  POST /api/v1/ec/sammelzuordnungen/{id}/bestaetigen    — Manuelle Bestaetigung
  POST /api/v1/ec/sammelzuordnungen/{id}/ablehnen       — Manuelle Ablehnung

Sicherheit:
  - unternehmen_id IMMER aus Auth-Kontext (CurrentTenantId)
  - extra="forbid" auf allen Request-Schemas
  - kein Float: betrag_cent muss int sein
  - Waehrung: genau 3 ASCII-Grossbuchstaben
  - Stabiles Quellsignal: quell_position ODER transaktionsreferenz
  - Unbekannte Kartenbegriffe nie still als EC_KARTE klassifiziert
"""
import re
from datetime import date, datetime
from typing import Any
from uuid import UUID

from fastapi import APIRouter, HTTPException, Query, status
from pydantic import BaseModel, field_validator, model_validator

from apps.server.auth.dependencies import CurrentTenantId, CurrentUserId, RLSSession
from apps.server.repositories.ec_sammelzuordnung import ECBelegRepository
from apps.server.services.ec_sammelzuordnung_service import ECSammelzuordnungService
from packages.core.ec_sammlung.normalisierung import normalisiere_zahlungskategorie

router = APIRouter(prefix="/api/v1/ec", tags=["ec-sammelzuordnungen"])

_beleg_repo = ECBelegRepository()
_service = ECSammelzuordnungService()

_WAEHRUNG_RE = re.compile(r"^[A-Z]{3}$")


# ── Request-Schemas ────────────────────────────────────────────────────────────

class EcBelegImportItem(BaseModel):
    """Ein einzelner zu importierender EC-Kartenbeleg.

    betrag_cent: int (Centwert); float wird abgelehnt; muss != 0 sein.
    Stabiles Signal: quell_position ODER transaktionsreferenz erforderlich.
    """
    model_config = {"extra": "forbid"}

    buchungsdatum: date
    belegzeit: str | None = None
    betrag_cent: int
    waehrung: str = "EUR"
    zahlungskategorie_roh: str | None = None
    terminal_id: str | None = None
    transaktionsreferenz: str | None = None
    quell_position: str | None = None
    dokument_id: UUID | None = None

    @field_validator("betrag_cent", mode="before")
    @classmethod
    def kein_float(cls, v: Any) -> int:
        if isinstance(v, float):
            raise ValueError("betrag_cent darf kein float sein; Integer (Centwert) verwenden")
        return v

    @field_validator("betrag_cent")
    @classmethod
    def nicht_null(cls, v: int) -> int:
        if v == 0:
            raise ValueError("betrag_cent darf nicht 0 sein")
        return v

    @field_validator("waehrung")
    @classmethod
    def validiere_waehrung(cls, v: str) -> str:
        normalized = v.strip().upper()
        if not _WAEHRUNG_RE.match(normalized):
            raise ValueError(f"Ungueltige Waehrung '{v}': genau 3 ASCII-Grossbuchstaben erforderlich")
        return normalized

    @model_validator(mode="after")
    def stabiles_signal_erforderlich(self) -> "EcBelegImportItem":
        if self.quell_position is None and self.transaktionsreferenz is None:
            raise ValueError(
                "Stabiles Quellsignal fehlt: quell_position oder transaktionsreferenz muss angegeben werden"
            )
        return self


class EcBelegImportRequest(BaseModel):
    model_config = {"extra": "forbid"}

    bankkonto_id: UUID
    quell_referenz: str
    belege: list[EcBelegImportItem]

    @model_validator(mode="after")
    def mindestens_ein_beleg(self) -> "EcBelegImportRequest":
        if not self.belege:
            raise ValueError("belege darf nicht leer sein")
        return self


class EcRematchRequest(BaseModel):
    model_config = {"extra": "forbid"}

    bankkonto_id: UUID
    max_verzoegerung_tage: int = 2


class EcEntscheidungRequest(BaseModel):
    """Manuelle Entscheidung (Bestaetigung oder Ablehnung).

    benutzer_id im Body wird ignoriert — ID kommt ausschliesslich aus JWT (CurrentUserId).
    """
    model_config = {"extra": "forbid"}

    notiz: str | None = None


# ── Response-Schemas ───────────────────────────────────────────────────────────

class EcBelegImportResponse(BaseModel):
    uebergeben: int
    neu: int
    dedupliziert: int


class EcBelegResponse(BaseModel):
    model_config = {"from_attributes": True}

    id: UUID
    bankkonto_id: UUID
    buchungsdatum: date
    betrag_cent: int
    waehrung: str
    zahlungskategorie: str
    original_kategorie: str | None
    status: str
    belegzeit: str | None
    terminal_id: str | None
    quell_position: str | None
    transaktionsreferenz: str | None
    quelldatei: str | None
    created_at: datetime


class EcRematchResponse(BaseModel):
    bankbuchungen_geprueft: int
    ec_einzahlungen_geprueft: int
    ec_belege_geprueft: int
    vorschlaege_gesamt: int
    stark: int
    unsicher: int
    ohne_vorschlag: int
    matcher_version: str


class EcSammelzuordnungListItem(BaseModel):
    model_config = {"from_attributes": True}

    id: UUID
    bankbuchung_id: UUID
    bankkonto_id: UUID
    status: str
    score: int
    summe_cent: int
    einzahlung_cent: int
    differenz_cent: int
    matcher_version: str
    created_at: datetime
    updated_at: datetime


class EcBelegInGruppe(BaseModel):
    beleg_id: UUID
    betrag_cent: int
    buchungsdatum: date
    rolle: str


class EcSammelzuordnungDetail(BaseModel):
    model_config = {"from_attributes": True}

    id: UUID
    bankbuchung_id: UUID
    bankkonto_id: UUID
    status: str
    score: int
    summe_cent: int
    einzahlung_cent: int
    differenz_cent: int
    fenster_von: date | None
    fenster_bis: date | None
    max_verzoegerung_tage: int
    positive_signale: list[Any]
    negative_signale: list[Any]
    matcher_version: str
    entschieden_at: datetime | None
    entschieden_von_benutzer_id: UUID | None
    entscheidungsnotiz: str | None
    enthaltene_belege: list[EcBelegInGruppe]
    entfernte_belege: list[EcBelegInGruppe]
    created_at: datetime
    updated_at: datetime


# ── Endpunkte ──────────────────────────────────────────────────────────────────

@router.post(
    "/belege/importe",
    status_code=status.HTTP_201_CREATED,
    response_model=EcBelegImportResponse,
)
async def importiere_ec_belege(
    request: EcBelegImportRequest,
    unternehmen_id: CurrentTenantId,
    session: RLSSession,
) -> EcBelegImportResponse:
    """Importiert EC-Kartenbelege idempotent (Fingerprint-Deduplizierung)."""
    belege_daten = []
    for item in request.belege:
        kat = normalisiere_zahlungskategorie(item.zahlungskategorie_roh)
        belege_daten.append({
            "buchungsdatum": item.buchungsdatum,
            "betrag_cent": item.betrag_cent,
            "waehrung": item.waehrung,
            "zahlungskategorie": str(kat),
            "original_kategorie": item.zahlungskategorie_roh,
            "belegzeit": item.belegzeit,
            "terminal_id": item.terminal_id,
            "transaktionsreferenz": item.transaktionsreferenz,
            "quell_position": item.quell_position,
            "dokument_id": item.dokument_id,
        })

    uebergeben, neu = await _beleg_repo.importiere_belege(
        session=session,
        unternehmen_id=unternehmen_id,
        bankkonto_id=request.bankkonto_id,
        quell_referenz=request.quell_referenz,
        belege_daten=belege_daten,
    )
    await session.commit()

    return EcBelegImportResponse(
        uebergeben=uebergeben,
        neu=neu,
        dedupliziert=uebergeben - neu,
    )


@router.get("/belege", response_model=list[EcBelegResponse])
async def liste_ec_belege(
    unternehmen_id: CurrentTenantId,
    session: RLSSession,
    bankkonto_id: UUID | None = Query(default=None),
    datum_von: date | None = Query(default=None),
    datum_bis: date | None = Query(default=None),
) -> list[EcBelegResponse]:
    """Listet EC-Belege des Mandanten (mandantensicher)."""
    belege = await _beleg_repo.list_belege(
        session=session,
        unternehmen_id=unternehmen_id,
        bankkonto_id=bankkonto_id,
        datum_von=datum_von,
        datum_bis=datum_bis,
    )
    return [EcBelegResponse.model_validate(b) for b in belege]


@router.post(
    "/sammelzuordnungen/rematch",
    status_code=status.HTTP_200_OK,
    response_model=EcRematchResponse,
)
async def rematch(
    request: EcRematchRequest,
    unternehmen_id: CurrentTenantId,
    session: RLSSession,
) -> EcRematchResponse:
    """Fuehrt automatisches EC-Sammelmatching fuer ein Bankkonto aus."""
    metriken = await _service.rematch(
        session=session,
        unternehmen_id=unternehmen_id,
        bankkonto_id=request.bankkonto_id,
        max_verzoegerung_tage=request.max_verzoegerung_tage,
    )
    return EcRematchResponse(**metriken)


@router.get("/sammelzuordnungen", response_model=list[EcSammelzuordnungListItem])
async def liste_sammelzuordnungen(
    unternehmen_id: CurrentTenantId,
    session: RLSSession,
    bankkonto_id: UUID | None = Query(default=None),
) -> list[EcSammelzuordnungListItem]:
    """Listet EC-Sammelzuordnungen des Mandanten."""
    from apps.server.repositories.ec_sammelzuordnung import ECSammelzuordnungRepository
    repo = ECSammelzuordnungRepository()
    zuordnungen = await repo.list_sammelzuordnungen(
        session=session,
        unternehmen_id=unternehmen_id,
        bankkonto_id=bankkonto_id,
    )
    return [EcSammelzuordnungListItem.model_validate(z) for z in zuordnungen]


@router.get("/sammelzuordnungen/{zuordnung_id}", response_model=EcSammelzuordnungDetail)
async def get_sammelzuordnung_detail(
    zuordnung_id: UUID,
    unternehmen_id: CurrentTenantId,
    session: RLSSession,
) -> EcSammelzuordnungDetail:
    """Liefert EC-Sammelzuordnung mit enthaltenen und entfernten Belegen."""
    from apps.server.repositories.ec_sammelzuordnung import ECSammelzuordnungRepository
    repo = ECSammelzuordnungRepository()
    zuordnung, enthaltene, entfernte = await repo.get_sammelzuordnung_detail(
        session=session,
        unternehmen_id=unternehmen_id,
        zuordnung_id=zuordnung_id,
    )
    return EcSammelzuordnungDetail(
        id=zuordnung.id,
        bankbuchung_id=zuordnung.bankbuchung_id,
        bankkonto_id=zuordnung.bankkonto_id,
        status=zuordnung.status,
        score=zuordnung.score,
        summe_cent=zuordnung.summe_cent,
        einzahlung_cent=zuordnung.einzahlung_cent,
        differenz_cent=zuordnung.differenz_cent,
        fenster_von=zuordnung.fenster_von,
        fenster_bis=zuordnung.fenster_bis,
        max_verzoegerung_tage=zuordnung.max_verzoegerung_tage,
        positive_signale=zuordnung.positive_signale or [],
        negative_signale=zuordnung.negative_signale or [],
        matcher_version=zuordnung.matcher_version,
        entschieden_at=zuordnung.entschieden_at,
        entschieden_von_benutzer_id=zuordnung.entschieden_von_benutzer_id,
        entscheidungsnotiz=zuordnung.entscheidungsnotiz,
        enthaltene_belege=[EcBelegInGruppe(**b) for b in enthaltene],
        entfernte_belege=[EcBelegInGruppe(**b) for b in entfernte],
        created_at=zuordnung.created_at,
        updated_at=zuordnung.updated_at,
    )


@router.post(
    "/sammelzuordnungen/{zuordnung_id}/bestaetigen",
    status_code=status.HTTP_200_OK,
    response_model=EcSammelzuordnungDetail,
)
async def bestaetigen(
    zuordnung_id: UUID,
    request: EcEntscheidungRequest,
    unternehmen_id: CurrentTenantId,
    benutzer_id: CurrentUserId,
    session: RLSSession,
) -> EcSammelzuordnungDetail:
    """Bestaetigt eine EC-Sammelzuordnung manuell.

    Idempotent wenn bereits bestaetigt. 409 wenn bereits abgelehnt oder
    DB-Constraint verletzt (zweite bestaetigte Gruppe / doppelte Belegnutzung).
    Benutzer-ID kommt ausschliesslich aus JWT.
    """
    from apps.server.repositories.ec_sammelzuordnung import ECSammelzuordnungRepository
    repo = ECSammelzuordnungRepository()
    z = await repo.bestaetigen(
        session=session,
        unternehmen_id=unternehmen_id,
        zuordnung_id=zuordnung_id,
        benutzer_id=benutzer_id,
        notiz=request.notiz,
    )
    zuordnung, enthaltene, entfernte = await repo.get_sammelzuordnung_detail(
        session=session,
        unternehmen_id=unternehmen_id,
        zuordnung_id=z.id,
    )
    return EcSammelzuordnungDetail(
        id=zuordnung.id,
        bankbuchung_id=zuordnung.bankbuchung_id,
        bankkonto_id=zuordnung.bankkonto_id,
        status=zuordnung.status,
        score=zuordnung.score,
        summe_cent=zuordnung.summe_cent,
        einzahlung_cent=zuordnung.einzahlung_cent,
        differenz_cent=zuordnung.differenz_cent,
        fenster_von=zuordnung.fenster_von,
        fenster_bis=zuordnung.fenster_bis,
        max_verzoegerung_tage=zuordnung.max_verzoegerung_tage,
        positive_signale=zuordnung.positive_signale or [],
        negative_signale=zuordnung.negative_signale or [],
        matcher_version=zuordnung.matcher_version,
        entschieden_at=zuordnung.entschieden_at,
        entschieden_von_benutzer_id=zuordnung.entschieden_von_benutzer_id,
        entscheidungsnotiz=zuordnung.entscheidungsnotiz,
        enthaltene_belege=[EcBelegInGruppe(**b) for b in enthaltene],
        entfernte_belege=[EcBelegInGruppe(**b) for b in entfernte],
        created_at=zuordnung.created_at,
        updated_at=zuordnung.updated_at,
    )


@router.post(
    "/sammelzuordnungen/{zuordnung_id}/ablehnen",
    status_code=status.HTTP_200_OK,
    response_model=EcSammelzuordnungDetail,
)
async def ablehnen(
    zuordnung_id: UUID,
    request: EcEntscheidungRequest,
    unternehmen_id: CurrentTenantId,
    benutzer_id: CurrentUserId,
    session: RLSSession,
) -> EcSammelzuordnungDetail:
    """Lehnt eine EC-Sammelzuordnung manuell ab.

    Idempotent wenn bereits abgelehnt. 409 wenn bereits bestaetigt.
    Gruppenfingerprint bleibt erhalten (kein Rematch-Neuvorschlag).
    Benutzer-ID kommt ausschliesslich aus JWT.
    """
    from apps.server.repositories.ec_sammelzuordnung import ECSammelzuordnungRepository
    repo = ECSammelzuordnungRepository()
    z = await repo.ablehnen(
        session=session,
        unternehmen_id=unternehmen_id,
        zuordnung_id=zuordnung_id,
        benutzer_id=benutzer_id,
        notiz=request.notiz,
    )
    zuordnung, enthaltene, entfernte = await repo.get_sammelzuordnung_detail(
        session=session,
        unternehmen_id=unternehmen_id,
        zuordnung_id=z.id,
    )
    return EcSammelzuordnungDetail(
        id=zuordnung.id,
        bankbuchung_id=zuordnung.bankbuchung_id,
        bankkonto_id=zuordnung.bankkonto_id,
        status=zuordnung.status,
        score=zuordnung.score,
        summe_cent=zuordnung.summe_cent,
        einzahlung_cent=zuordnung.einzahlung_cent,
        differenz_cent=zuordnung.differenz_cent,
        fenster_von=zuordnung.fenster_von,
        fenster_bis=zuordnung.fenster_bis,
        max_verzoegerung_tage=zuordnung.max_verzoegerung_tage,
        positive_signale=zuordnung.positive_signale or [],
        negative_signale=zuordnung.negative_signale or [],
        matcher_version=zuordnung.matcher_version,
        entschieden_at=zuordnung.entschieden_at,
        entschieden_von_benutzer_id=zuordnung.entschieden_von_benutzer_id,
        entscheidungsnotiz=zuordnung.entscheidungsnotiz,
        enthaltene_belege=[EcBelegInGruppe(**b) for b in enthaltene],
        entfernte_belege=[EcBelegInGruppe(**b) for b in entfernte],
        created_at=zuordnung.created_at,
        updated_at=zuordnung.updated_at,
    )
