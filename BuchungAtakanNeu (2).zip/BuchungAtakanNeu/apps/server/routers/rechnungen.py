"""Rechnungs-Router — Import, Versionierung, Navigation (RECH-03/06/08/09/11)."""
from decimal import Decimal
from uuid import UUID

from fastapi import APIRouter, status
from pydantic import BaseModel

from apps.server.auth.dependencies import CurrentTenantId, RLSSession
from apps.server.models.rechnung import Erkennungslauf, Rechnung, RechnungsKandidat, RechnungsStatus
from apps.server.repositories.rechnung import RechnungRepository

router = APIRouter(prefix="/api/v1/rechnungen", tags=["rechnungen"])
_repo = RechnungRepository()


# ── Schemas ──────────────────────────────────────────────────────────────────

class RechnungCreateRequest(BaseModel):
    """POST-Body für Rechnungsimport. unternehmen_id kommt ausschließlich aus JWT."""

    model_config = {"extra": "forbid"}

    dokument_id: UUID
    erkennungslauf_id: UUID | None = None
    rechnungsnummer: str | None = None
    rechnungsdatum: str | None = None
    gesamtbetrag: Decimal | None = None
    nettobetrag: Decimal | None = None
    steuerbetrag: Decimal | None = None
    waehrung: str | None = None
    zahlungsart: str | None = None
    lieferant_name: str | None = None


class RechnungResponse(BaseModel):
    """unternehmen_id wird intern verwendet, darf aber nicht über die API ausgegeben werden."""

    model_config = {"from_attributes": True}

    id: UUID
    dokument_id: UUID
    rechnungsnummer: str | None
    rechnungsdatum: str | None
    gesamtbetrag: Decimal | None
    nettobetrag: Decimal | None
    steuerbetrag: Decimal | None
    waehrung: str | None
    zahlungsart: str | None
    lieferant_name: str | None
    status: str
    version_lfd_nr: int
    ist_aktiv: bool


class ErkennungslaufResponse(BaseModel):
    model_config = {"from_attributes": True}

    id: UUID
    dokument_id: UUID
    rechnung_id: UUID | None
    extraktion_status: str
    extraktion_confidence: Decimal | None
    fehler: str | None


class RechnungsKandidatResponse(BaseModel):
    model_config = {"from_attributes": True}

    id: UUID
    erkennungslauf_id: UUID
    feld: str
    rohwert: str
    normwert: str | None
    methode: str
    quelle: str
    confidence: Decimal


# ── RECH-06 Guard ─────────────────────────────────────────────────────────────

def _hat_starke_partnersignale(req: RechnungCreateRequest) -> bool:
    """
    True wenn mindestens ein starkes Partneridentifikationssignal vorhanden.

    Starke Signale: rechnungsnummer (eindeutig einem Geschäftspartner zuordenbar).
    Beträge (gesamtbetrag, nettobetrag, steuerbetrag) und Metadaten (waehrung,
    zahlungsart) sind KEINE Identifikationssignale (RECH-06).
    USt-ID, IBAN, Partnerkennung sind im aktuellen Modell noch nicht vorhanden.
    """
    return bool(req.rechnungsnummer)


def _rech06_prueffall(req: RechnungCreateRequest) -> bool:
    """RECH-06: Lieferantenname ohne starkes Identifikationssignal → PRUEFFALL."""
    return bool(req.lieferant_name and not _hat_starke_partnersignale(req))


# ── Helpers ───────────────────────────────────────────────────────────────────

def _rechnung_zu_response(r: Rechnung) -> RechnungResponse:
    return RechnungResponse.model_validate(r)


def _erkennungslauf_zu_response(e: Erkennungslauf) -> ErkennungslaufResponse:
    return ErkennungslaufResponse.model_validate(e)


def _kandidat_zu_response(k: RechnungsKandidat) -> RechnungsKandidatResponse:
    return RechnungsKandidatResponse.model_validate(k)


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.post("", status_code=status.HTTP_201_CREATED, response_model=RechnungResponse)
async def rechnung_importieren(
    body: RechnungCreateRequest,
    session: RLSSession,
    unternehmen_id: CurrentTenantId,
) -> RechnungResponse:
    """
    Rechnung aus Erkennungslauf anlegen (RECH-03/08/09).
    unternehmen_id wird ausschließlich aus JWT gezogen — kein Body-Feld (SRV-05).
    RECH-06: Lieferantenname ohne starkes Signal → status=PRUEFFALL.
    erkennungslauf_id: mandantensicher geprüft; 404 bei fremd oder fehlt.
    """
    initial_status = RechnungsStatus.PRUEFFALL if _rech06_prueffall(body) else RechnungsStatus.NEU

    felder: dict = {
        "rechnungsnummer": body.rechnungsnummer,
        "rechnungsdatum": body.rechnungsdatum,
        "gesamtbetrag": body.gesamtbetrag,
        "nettobetrag": body.nettobetrag,
        "steuerbetrag": body.steuerbetrag,
        "waehrung": body.waehrung,
        "zahlungsart": body.zahlungsart,
        "lieferant_name": body.lieferant_name,
    }

    rechnung = await _repo.create_version(
        session,
        unternehmen_id,
        body.dokument_id,
        felder,
        initial_status,
        erkennungslauf_id=body.erkennungslauf_id,
    )
    return _rechnung_zu_response(rechnung)


@router.get("", response_model=list[RechnungResponse])
async def rechnungen_liste(
    session: RLSSession,
    unternehmen_id: CurrentTenantId,
) -> list[RechnungResponse]:
    """Nur aktive Rechnungen des Mandanten (RECH-09/11). RLS sichert Trennung zusätzlich."""
    rechnungen = await _repo.list_aktive(session, unternehmen_id)
    return [_rechnung_zu_response(r) for r in rechnungen]


@router.get("/{rechnung_id}", response_model=RechnungResponse)
async def rechnung_detail(
    rechnung_id: UUID,
    session: RLSSession,
    unternehmen_id: CurrentTenantId,
) -> RechnungResponse:
    """Einzelne Rechnung des eigenen Mandanten oder 404."""
    rechnung = await _repo.get_by_id(session, rechnung_id, unternehmen_id)
    return _rechnung_zu_response(rechnung)


@router.get("/{rechnung_id}/erkennungslaeufe", response_model=list[ErkennungslaufResponse])
async def erkennungslaeufe_liste(
    rechnung_id: UUID,
    session: RLSSession,
    unternehmen_id: CurrentTenantId,
) -> list[ErkennungslaufResponse]:
    """Erkennungsläufe zur Rechnung — erst Rechnung mandantengefiltert prüfen (RECH-03/11)."""
    await _repo.get_by_id(session, rechnung_id, unternehmen_id)
    laeufe = await _repo.list_erkennungslaeufe(session, rechnung_id, unternehmen_id)
    return [_erkennungslauf_zu_response(e) for e in laeufe]


@router.get("/{rechnung_id}/kandidaten", response_model=list[RechnungsKandidatResponse])
async def kandidaten_liste(
    rechnung_id: UUID,
    session: RLSSession,
    unternehmen_id: CurrentTenantId,
) -> list[RechnungsKandidatResponse]:
    """Kandidaten zur Rechnung — mandantengefiltert über Erkennungsläufe (RECH-11)."""
    await _repo.get_by_id(session, rechnung_id, unternehmen_id)
    kandidaten = await _repo.list_kandidaten_fuer_rechnung(session, rechnung_id, unternehmen_id)
    return [_kandidat_zu_response(k) for k in kandidaten]
