"""Bankbuchungen-Router — Import und Liste (BANK-01..03/BANK-10/BANK-11)."""
import re
from datetime import date
from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Form, HTTPException, Query, UploadFile, status
from pydantic import BaseModel, field_validator, model_validator

from apps.server.auth.dependencies import CurrentTenantId, RLSSession
from apps.server.models.bankbuchung import Bankbuchung, BuchungsKlassifikation, Bankkonto, Kontoauszugsimport
from apps.server.repositories.bankbuchung import BankkontoRepository, BankbuchungRepository
from packages.core.bank_import.cent_konvertierung import parse_betrag_cent
from packages.core.bank_import.fingerprint import berechne_fingerprint
from packages.core.bank_import.klassifikation import klassifiziere_buchung
from packages.core.bank_import.normalisierung import maskiere_iban
from packages.core.bank_import.mt940_parser import (
    MT940FormatFehler,
    parse_mt940,
)

router = APIRouter(prefix="/api/v1", tags=["bankbuchungen"])
_konto_repo = BankkontoRepository()
_buchung_repo = BankbuchungRepository()

_WAEHRUNG_RE = re.compile(r"^[A-Z]{3}$")


# ── Bankkonto-Schemas ─────────────────────────────────────────────────────────

class BankkontoCreateRequest(BaseModel):
    model_config = {"extra": "forbid"}

    anzeigename: str
    iban_masked: str | None = None
    bic: str | None = None

    @field_validator("iban_masked")
    @classmethod
    def maskiere_iban_eingabe(cls, v: str | None) -> str | None:
        if v is None:
            return None
        return maskiere_iban(v)


class BankkontoResponse(BaseModel):
    model_config = {"from_attributes": True}

    id: UUID
    anzeigename: str
    iban_masked: str | None
    bic: str | None
    ist_aktiv: bool


# ── Import-Schemas ────────────────────────────────────────────────────────────

class BuchungImportItem(BaseModel):
    """Eine einzelne zu importierende Bankbuchung.

    betrag_cent: int (Centwert) oder str (Dezimalstring, max. 2 Nachkommastellen).
    float wird abgelehnt.

    Stabile Quellkennung (mind. eines erforderlich wenn keine externe_buchungs_id):
      quell_position: 0-basierter Index der Transaktion in der Quelldatei/-liste.
    """
    model_config = {"extra": "forbid"}

    buchungsdatum: date
    wertstellungsdatum: date | None = None
    betrag_cent: int | str
    waehrung: str = "EUR"
    verwendungszweck: str | None = None
    gegenpartei_name: str | None = None
    gegenpartei_iban: str | None = None
    gegenpartei_bic: str | None = None
    externe_buchungs_id: str | None = None
    quell_position: int | None = None

    @field_validator("betrag_cent", mode="before")
    @classmethod
    def validiere_betrag(cls, v):
        if isinstance(v, float):
            raise ValueError(
                "betrag_cent darf kein float sein. Integer (Cent) oder Dezimalstring verwenden."
            )
        try:
            return parse_betrag_cent(v)
        except (TypeError, ValueError) as e:
            raise ValueError(str(e)) from e

    @field_validator("waehrung")
    @classmethod
    def validiere_waehrung(cls, v: str) -> str:
        normalized = v.strip().upper()
        if not _WAEHRUNG_RE.match(normalized):
            raise ValueError(
                f"Ungueltige Waehrung '{v}': genau 3 ASCII-Grossbuchstaben erforderlich (z.B. EUR)."
            )
        return normalized

    @model_validator(mode="after")
    def stabiles_quellsignal_erforderlich(self) -> "BuchungImportItem":
        if self.externe_buchungs_id is None and self.quell_position is None:
            raise ValueError(
                "Stabiles Quellsignal fehlt: externe_buchungs_id oder quell_position muss "
                "angegeben werden. Ohne Quellenposition sind identische echte Buchungen "
                "nicht von Duplikaten unterscheidbar."
            )
        return self


class BankbuchungsImportRequest(BaseModel):
    model_config = {"extra": "forbid"}

    bankkonto_id: UUID
    quell_referenz: str | None = None
    zeitraum_von: date | None = None
    zeitraum_bis: date | None = None
    buchungen: list[BuchungImportItem]

    @model_validator(mode="after")
    def validiere_mindestens_eine_buchung(self):
        if not self.buchungen:
            raise ValueError("buchungen darf nicht leer sein.")
        return self


class BankbuchungsImportResponse(BaseModel):
    import_id: UUID
    buchungen_uebergeben: int
    buchungen_neu: int
    buchungen_dedupliziert: int


class MT940ImportResponse(BankbuchungsImportResponse):
    parse_fehler: int = 0
    parse_fehler_details: list[str] = []

_MT940_MAX_BYTES = 10 * 1024 * 1024  # 10 MB


# ── Buchungs-Schemas ──────────────────────────────────────────────────────────

class BankbuchungResponse(BaseModel):
    model_config = {"from_attributes": True}

    id: UUID
    bankkonto_id: UUID
    import_id: UUID
    buchungsdatum: date
    wertstellungsdatum: date | None
    betrag_cent: int
    waehrung: str
    verwendungszweck: str | None
    gegenpartei_name: str | None
    gegenpartei_iban: str | None
    klassifikation: str


# ── Hilfs-Funktionen ──────────────────────────────────────────────────────────

def _buchung_zu_response(b: Bankbuchung) -> BankbuchungResponse:
    return BankbuchungResponse.model_validate(b)


def _konto_zu_response(k: Bankkonto) -> BankkontoResponse:
    return BankkontoResponse.model_validate(k)


def _baue_buchungs_daten(
    item: BuchungImportItem,
    unternehmen_id: UUID,
    bankkonto_id: UUID,
    quell_referenz: str | None = None,
) -> dict:
    """Konvertiert Import-Item in DB-Insert-Dict inkl. Fingerprint und Klassifikation.

    Fingerprint verwendet volle (unmaskierte) gegenpartei_iban fuer korrekte Dedup.
    Gespeichert wird die maskierte Version.
    """
    fp = berechne_fingerprint(
        unternehmen_id=unternehmen_id,
        bankkonto_id=bankkonto_id,
        buchungsdatum=str(item.buchungsdatum),
        betrag_cent=item.betrag_cent,
        waehrung=item.waehrung,
        verwendungszweck=item.verwendungszweck,
        gegenpartei_name=item.gegenpartei_name,
        gegenpartei_iban=item.gegenpartei_iban,
        wertstellungsdatum=str(item.wertstellungsdatum) if item.wertstellungsdatum else None,
        externe_buchungs_id=item.externe_buchungs_id,
        quell_referenz=quell_referenz,
        quell_position=item.quell_position,
    )
    klasse = klassifiziere_buchung(item.verwendungszweck, item.gegenpartei_name)
    return {
        "buchungsdatum": item.buchungsdatum,
        "wertstellungsdatum": item.wertstellungsdatum,
        "betrag_cent": item.betrag_cent,
        "waehrung": item.waehrung,
        "verwendungszweck": item.verwendungszweck,
        "gegenpartei_name": item.gegenpartei_name,
        "gegenpartei_iban": maskiere_iban(item.gegenpartei_iban),
        "gegenpartei_bic": item.gegenpartei_bic,
        "externe_buchungs_id": item.externe_buchungs_id,
        "dedup_fingerprint": fp,
        "klassifikation": str(klasse),
    }


# ── Endpunkte ─────────────────────────────────────────────────────────────────

@router.post(
    "/bankkonten",
    status_code=status.HTTP_201_CREATED,
    response_model=BankkontoResponse,
    tags=["bankkonten"],
)
async def bankkonto_anlegen(
    body: BankkontoCreateRequest,
    session: RLSSession,
    unternehmen_id: CurrentTenantId,
) -> BankkontoResponse:
    """Bankkonto fuer den eigenen Mandanten anlegen.
    unternehmen_id ausschliesslich aus JWT.
    """
    konto = await _konto_repo.create(
        session,
        unternehmen_id=unternehmen_id,
        anzeigename=body.anzeigename,
        iban_masked=body.iban_masked,
        bic=body.bic,
    )
    return _konto_zu_response(konto)


@router.post(
    "/bankbuchungen/importe",
    status_code=status.HTTP_201_CREATED,
    response_model=BankbuchungsImportResponse,
)
async def bankbuchungen_importieren(
    body: BankbuchungsImportRequest,
    session: RLSSession,
    unternehmen_id: CurrentTenantId,
) -> BankbuchungsImportResponse:
    """Strukturierten Kontoauszug atomar importieren.

    - unternehmen_id aus JWT, nicht aus Request-Body.
    - Alle Buchungen validiert (422 bei jeder ungueltigen Buchung — atomarer Import).
    - Duplikate (gleicher Fingerprint) werden still gezaehlt und uebersprungen.
    - Keine Originaldatei-Bytes akzeptiert.
    """
    buchungen_daten = [
        _baue_buchungs_daten(item, unternehmen_id, body.bankkonto_id, body.quell_referenz)
        for item in body.buchungen
    ]

    import_record, neu, dedupliziert = await _buchung_repo.importiere(
        session,
        unternehmen_id=unternehmen_id,
        bankkonto_id=body.bankkonto_id,
        buchungen_daten=buchungen_daten,
        quell_referenz=body.quell_referenz,
        zeitraum_von=body.zeitraum_von,
        zeitraum_bis=body.zeitraum_bis,
    )

    return BankbuchungsImportResponse(
        import_id=import_record.id,
        buchungen_uebergeben=len(body.buchungen),
        buchungen_neu=neu,
        buchungen_dedupliziert=dedupliziert,
    )


@router.post(
    "/bankbuchungen/mt940-import",
    status_code=status.HTTP_201_CREATED,
    response_model=MT940ImportResponse,
)
async def bankbuchungen_mt940_importieren(
    datei: UploadFile,
    bankkonto_id: Annotated[UUID, Form()],
    session: RLSSession,
    unternehmen_id: CurrentTenantId,
) -> MT940ImportResponse:
    """MT940-Kontoauszug als Datei hochladen und importieren.

    - bankkonto_id als Formularfeld
    - datei als Datei-Upload (multipart/form-data)
    - unternehmen_id ausschliesslich aus JWT
    - Datei wird nicht gespeichert; nur geparste Buchungsdaten werden importiert
    """
    rohbytes = await datei.read()

    if len(rohbytes) > _MT940_MAX_BYTES:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail=f"Datei zu gross. Maximum: {_MT940_MAX_BYTES // (1024 * 1024)} MB.",
        )
    if not rohbytes:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Leere Datei.",
        )

    try:
        ergebnis = parse_mt940(rohbytes)
    except MT940FormatFehler as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Kein gueltiges MT940-Format: {exc}",
        )

    # MT940Buchung → BuchungImportItem-Daten (dict fuer _baue_buchungs_daten)
    buchungen_daten = []
    for b in ergebnis.buchungen:
        item = BuchungImportItem(
            buchungsdatum=b.buchungsdatum,
            wertstellungsdatum=b.wertstellungsdatum,
            betrag_cent=b.betrag_cent,
            waehrung=b.waehrung or "EUR",
            verwendungszweck=b.verwendungszweck,
            gegenpartei_name=b.gegenpartei_name,
            gegenpartei_iban=b.gegenpartei_iban,
            gegenpartei_bic=b.gegenpartei_bic,
            quell_position=b.quell_position,
        )
        buchungen_daten.append(
            _baue_buchungs_daten(item, unternehmen_id, bankkonto_id, ergebnis.quell_fingerprint)
        )

    if not buchungen_daten and not ergebnis.fehler:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Keine Buchungen in MT940-Datei gefunden.",
        )

    if buchungen_daten:
        import_record, neu, dedupliziert = await _buchung_repo.importiere(
            session,
            unternehmen_id=unternehmen_id,
            bankkonto_id=bankkonto_id,
            buchungen_daten=buchungen_daten,
            quell_referenz=ergebnis.quell_fingerprint,
        )
    else:
        # Nur Fehler, keine erfolgreichen Buchungen
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Alle {len(ergebnis.fehler)} Buchungen fehlerhaft. Erste Fehler: "
                   + "; ".join(f.meldung for f in ergebnis.fehler[:3]),
        )

    return MT940ImportResponse(
        import_id=import_record.id,
        buchungen_uebergeben=len(ergebnis.buchungen),
        buchungen_neu=neu,
        buchungen_dedupliziert=dedupliziert,
        parse_fehler=len(ergebnis.fehler),
        parse_fehler_details=[f.meldung for f in ergebnis.fehler],
    )


@router.get("/bankbuchungen", response_model=list[BankbuchungResponse])
async def bankbuchungen_liste(
    session: RLSSession,
    unternehmen_id: CurrentTenantId,
    bankkonto_id: UUID | None = Query(default=None),
    klassifikation: str | None = Query(default=None),
    datum_von: date | None = Query(default=None),
    datum_bis: date | None = Query(default=None),
) -> list[BankbuchungResponse]:
    """Mandantengefilterte Buchungsliste. Fremde Mandantendaten niemals sichtbar."""
    if klassifikation is not None:
        try:
            BuchungsKlassifikation(klassifikation)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"Unbekannte Klassifikation: {klassifikation}",
            )

    buchungen = await _buchung_repo.list_buchungen(
        session,
        unternehmen_id=unternehmen_id,
        bankkonto_id=bankkonto_id,
        klassifikation=klassifikation,
        datum_von=datum_von,
        datum_bis=datum_bis,
    )
    return [_buchung_zu_response(b) for b in buchungen]
