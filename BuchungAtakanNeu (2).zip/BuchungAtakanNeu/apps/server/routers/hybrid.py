"""Hybrid-Audit- und Statistik-Router (HYB-17/18).

Auditbewertungen sind append-only und enthalten ausschliesslich strukturierte
Booleanfelder -- kein Freitext, keine Originalwerte, keine Rechnungsnummer, keine
Betraege, keine Rechnungsdaten, keine Dateinamen, keine Pfade, keine Hashes.
"""
from __future__ import annotations

from datetime import datetime
from uuid import UUID

from fastapi import APIRouter, HTTPException, Query, Response, status
from pydantic import BaseModel

from apps.server.auth.dependencies import CurrentTenantId, RLSSession
from apps.server.models.hybrid_extraktion import HybridAuditBewertung
from apps.server.services.hybrid_audit_service import HybridAuditService
from packages.core.invoice_extraction.hybrid_audit import (
    AuditBewertungFelder,
    berechne_gesamtergebnis_korrekt,
)
from packages.core.invoice_extraction.hybrid_statistik import ALLE_DIMENSIONEN, StatistikGruppe
from packages.core.invoice_extraction.hybrid_statistik_export import (
    erstelle_hybrid_statistik_workbook_bytes,
)

_XLSX_MEDIA_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
_XLSX_DATEINAME = "hybrid_statistik.xlsx"

router = APIRouter(prefix="/api/v1/hybrid", tags=["hybrid"])
_service = HybridAuditService()


# ── Schemas ──────────────────────────────────────────────────────────────────

class AuditBewertungRequest(BaseModel):
    """POST-Body fuer eine Auditbewertung. unternehmen_id kommt ausschliesslich aus
    JWT (SRV-05); ausschliesslich strukturierte Booleanfelder, kein Freitext."""

    model_config = {"extra": "forbid"}

    rechnungsnummer_korrekt: bool
    rechnungsdatum_korrekt: bool
    gesamtbetrag_korrekt: bool
    lieferant_korrekt: bool
    steuerwerte_korrekt: bool
    empfaenger_korrekt: bool


class AuditBewertungResponse(BaseModel):
    id: UUID
    hybrid_statusentscheidung_id: UUID
    rechnungsnummer_korrekt: bool
    rechnungsdatum_korrekt: bool
    gesamtbetrag_korrekt: bool
    lieferant_korrekt: bool
    steuerwerte_korrekt: bool
    empfaenger_korrekt: bool
    bewertet_am: datetime
    gesamtergebnis_korrekt: bool


class QuoteResponse(BaseModel):
    zaehler: int
    nenner: int
    quote: float | None


class StatistikGruppeResponse(BaseModel):
    dimensionen: dict[str, str]
    anzahl: int
    vollstaendigkeitsquote: QuoteResponse
    richtigkeitsquote: QuoteResponse
    automatisierungsquote: QuoteResponse
    pruefquote: QuoteResponse
    nichterkennungsquote: QuoteResponse


# ── Helpers ───────────────────────────────────────────────────────────────────

def _felder_aus_request(body: AuditBewertungRequest) -> AuditBewertungFelder:
    return AuditBewertungFelder(
        rechnungsnummer_korrekt=body.rechnungsnummer_korrekt,
        rechnungsdatum_korrekt=body.rechnungsdatum_korrekt,
        gesamtbetrag_korrekt=body.gesamtbetrag_korrekt,
        lieferant_korrekt=body.lieferant_korrekt,
        steuerwerte_korrekt=body.steuerwerte_korrekt,
        empfaenger_korrekt=body.empfaenger_korrekt,
    )


def _bewertung_zu_response(b: HybridAuditBewertung) -> AuditBewertungResponse:
    felder = AuditBewertungFelder(
        rechnungsnummer_korrekt=b.rechnungsnummer_korrekt,
        rechnungsdatum_korrekt=b.rechnungsdatum_korrekt,
        gesamtbetrag_korrekt=b.gesamtbetrag_korrekt,
        lieferant_korrekt=b.lieferant_korrekt,
        steuerwerte_korrekt=b.steuerwerte_korrekt,
        empfaenger_korrekt=b.empfaenger_korrekt,
    )
    return AuditBewertungResponse(
        id=b.id,
        hybrid_statusentscheidung_id=b.hybrid_statusentscheidung_id,
        rechnungsnummer_korrekt=b.rechnungsnummer_korrekt,
        rechnungsdatum_korrekt=b.rechnungsdatum_korrekt,
        gesamtbetrag_korrekt=b.gesamtbetrag_korrekt,
        lieferant_korrekt=b.lieferant_korrekt,
        steuerwerte_korrekt=b.steuerwerte_korrekt,
        empfaenger_korrekt=b.empfaenger_korrekt,
        bewertet_am=b.bewertet_am,
        gesamtergebnis_korrekt=berechne_gesamtergebnis_korrekt(felder),
    )


def _dimensionen_aus_query(gruppieren_nach: list[str] | None) -> tuple[str, ...]:
    """Gemeinsame Queryvalidierung fuer JSON- und Excel-Statistikendpoint (HYB-18/19).

    Ohne Query-Parameter: Gruppierung nach allen vier Dimensionen. Unbekannte
    Dimension(en) -> 400.
    """
    if gruppieren_nach is None:
        return ALLE_DIMENSIONEN

    unbekannt = set(gruppieren_nach) - set(ALLE_DIMENSIONEN)
    if unbekannt:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unbekannte Dimension(en): {sorted(unbekannt)}. Erlaubt: {list(ALLE_DIMENSIONEN)}",
        )
    return tuple(gruppieren_nach)


def _gruppe_zu_response(g: StatistikGruppe) -> StatistikGruppeResponse:
    return StatistikGruppeResponse(
        dimensionen=dict(zip(g.dimensionen, g.dimensionswerte)),
        anzahl=g.anzahl,
        vollstaendigkeitsquote=QuoteResponse(**g.vollstaendigkeitsquote.__dict__),
        richtigkeitsquote=QuoteResponse(**g.richtigkeitsquote.__dict__),
        automatisierungsquote=QuoteResponse(**g.automatisierungsquote.__dict__),
        pruefquote=QuoteResponse(**g.pruefquote.__dict__),
        nichterkennungsquote=QuoteResponse(**g.nichterkennungsquote.__dict__),
    )


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.post(
    "/statusentscheidungen/{hybrid_statusentscheidung_id}/auditbewertungen",
    status_code=status.HTTP_201_CREATED,
    response_model=AuditBewertungResponse,
)
async def auditbewertung_anlegen(
    hybrid_statusentscheidung_id: UUID,
    body: AuditBewertungRequest,
    session: RLSSession,
    unternehmen_id: CurrentTenantId,
) -> AuditBewertungResponse:
    """Legt eine neue Auditbewertung an (HYB-17) -- append-only, ueberschreibt nie
    eine bestehende Bewertung. 404 bei fremder oder fehlender Statusentscheidung."""
    bewertung = await _service.bewerte(
        session, unternehmen_id, hybrid_statusentscheidung_id, _felder_aus_request(body)
    )
    return _bewertung_zu_response(bewertung)


@router.get(
    "/statusentscheidungen/{hybrid_statusentscheidung_id}/auditbewertungen/latest",
    response_model=AuditBewertungResponse,
)
async def neueste_auditbewertung(
    hybrid_statusentscheidung_id: UUID,
    session: RLSSession,
    unternehmen_id: CurrentTenantId,
) -> AuditBewertungResponse:
    """Neueste Auditbewertung: bewertet_am DESC, bei Gleichstand id DESC."""
    bewertung = await _service.neueste_bewertung(session, unternehmen_id, hybrid_statusentscheidung_id)
    if bewertung is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Keine Auditbewertung vorhanden",
        )
    return _bewertung_zu_response(bewertung)


@router.get("/statistik", response_model=list[StatistikGruppeResponse])
async def statistik(
    session: RLSSession,
    unternehmen_id: CurrentTenantId,
    gruppieren_nach: list[str] | None = Query(default=None),
) -> list[StatistikGruppeResponse]:
    """Qualitaetsstatistik gruppierbar nach Anbieter, Dokumenttyp, Erkennungsmethode
    und Status (HYB-18). Ohne Query-Parameter: Gruppierung nach allen vier Dimensionen."""
    dimensionen = _dimensionen_aus_query(gruppieren_nach)
    gruppen = await _service.statistik(session, unternehmen_id, dimensionen)
    return [_gruppe_zu_response(g) for g in gruppen]


@router.get("/statistik/export.xlsx")
async def statistik_export_xlsx(
    session: RLSSession,
    unternehmen_id: CurrentTenantId,
    gruppieren_nach: list[str] | None = Query(default=None),
) -> Response:
    """Excel-Export der Qualitaetsstatistik (HYB-19) -- dieselbe Queryvalidierung und
    Gruppierungssemantik wie /statistik. Enthaelt ausschliesslich aggregierte
    Statistikdaten, keine Originalinhalte. Workbook wird vollstaendig im Speicher
    erzeugt, kein Dateisystemzugriff."""
    dimensionen = _dimensionen_aus_query(gruppieren_nach)
    gruppen = await _service.statistik(session, unternehmen_id, dimensionen)
    workbook_bytes = erstelle_hybrid_statistik_workbook_bytes(gruppen, dimensionen)
    return Response(
        content=workbook_bytes,
        media_type=_XLSX_MEDIA_TYPE,
        headers={
            "Content-Disposition": f'attachment; filename="{_XLSX_DATEINAME}"',
            "Cache-Control": "no-store",
        },
    )
