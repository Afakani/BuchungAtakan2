from uuid import UUID

from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel
from sqlalchemy import select

from apps.server.auth.dependencies import CurrentTenantId, RLSSession
from apps.server.models.dokument import Dokument, DokumentVerfuegbarkeit

router = APIRouter(prefix="/api/v1/dokumente", tags=["dokumente"])


class DokumentMetadatenRequest(BaseModel):
    """CLI-08: kein File-Upload, nur Metadaten."""

    model_config = {"extra": "forbid"}

    installation_id: UUID
    sha256: str
    relative_path: str
    dateiname: str
    dateigroesse: int
    mime_type: str


class VerfuegbarkeitUpdateRequest(BaseModel):
    model_config = {"extra": "forbid"}

    verfuegbarkeit: DokumentVerfuegbarkeit


class DokumentResponse(BaseModel):
    id: UUID
    unternehmen_id: UUID
    installation_id: UUID
    sha256: str
    relative_path: str
    dateiname: str
    dateigroesse: int
    mime_type: str
    verfuegbarkeit: str


def _to_response(d: Dokument) -> DokumentResponse:
    return DokumentResponse(
        id=d.id,
        unternehmen_id=d.unternehmen_id,
        installation_id=d.installation_id,
        sha256=d.sha256,
        relative_path=d.relative_path,
        dateiname=d.dateiname,
        dateigroesse=d.dateigroesse,
        mime_type=d.mime_type,
        verfuegbarkeit=d.verfuegbarkeit,
    )


@router.post("", status_code=status.HTTP_201_CREATED, response_model=DokumentResponse)
async def dokument_sync(
    request: DokumentMetadatenRequest,
    unternehmen_id: CurrentTenantId,
    session: RLSSession,
) -> DokumentResponse:
    """Idempotenter Metadaten-Sync (CLI-07). Gleicher sha256 + Mandant -> bestehenden zurueck."""
    stmt = select(Dokument).where(
        Dokument.sha256 == request.sha256,
        Dokument.unternehmen_id == unternehmen_id,
    )
    result = await session.execute(stmt)
    existing = result.scalar_one_or_none()
    if existing is not None:
        return _to_response(existing)

    dok = Dokument(
        unternehmen_id=unternehmen_id,
        installation_id=request.installation_id,
        sha256=request.sha256,
        relative_path=request.relative_path,
        dateiname=request.dateiname,
        dateigroesse=request.dateigroesse,
        mime_type=request.mime_type,
        verfuegbarkeit=DokumentVerfuegbarkeit.LOCAL_AVAILABLE,
    )
    session.add(dok)
    await session.commit()
    await session.refresh(dok)
    return _to_response(dok)


@router.patch(
    "/{dokument_id}/verfuegbarkeit",
    status_code=status.HTTP_200_OK,
    response_model=DokumentResponse,
)
async def update_verfuegbarkeit(
    dokument_id: UUID,
    request: VerfuegbarkeitUpdateRequest,
    unternehmen_id: CurrentTenantId,
    session: RLSSession,
) -> DokumentResponse:
    """Aktualisiert Verfuegbarkeitsstatus (CLI-10: kein stilles Loeschen)."""
    stmt = select(Dokument).where(
        Dokument.id == dokument_id,
        Dokument.unternehmen_id == unternehmen_id,
    )
    result = await session.execute(stmt)
    dok = result.scalar_one_or_none()
    if dok is None:
        raise HTTPException(status_code=404, detail="Dokument nicht gefunden")
    dok.verfuegbarkeit = request.verfuegbarkeit
    await session.commit()
    await session.refresh(dok)
    return _to_response(dok)


@router.get("", response_model=list[DokumentResponse])
async def list_dokumente(
    unternehmen_id: CurrentTenantId,
    session: RLSSession,
) -> list[DokumentResponse]:
    """Liste aller Dokumente des Mandanten. RLS garantiert Mandantentrennung (CLI-09)."""
    result = await session.execute(select(Dokument))
    return [_to_response(d) for d in result.scalars().all()]
