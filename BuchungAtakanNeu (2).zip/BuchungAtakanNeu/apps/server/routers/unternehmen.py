from fastapi import APIRouter, HTTPException

from apps.server.auth.dependencies import CurrentTenantId, RLSSession
from apps.server.repositories.unternehmen import UnternehmenRepository

router = APIRouter(prefix="/api/v1/unternehmen", tags=["unternehmen"])
_repo = UnternehmenRepository()


@router.get("/me")
async def get_eigenes_unternehmen(
    unternehmen_id: CurrentTenantId,
    session: RLSSession,
) -> dict:
    """Gibt das eigene Unternehmen zurueck (aus JWT, nicht vom Client setzbar)."""
    unternehmen = await _repo.get_by_id(session, unternehmen_id)
    if unternehmen is None:
        raise HTTPException(status_code=404, detail="Unternehmen nicht gefunden")
    return {"id": str(unternehmen.id), "name": unternehmen.name}
