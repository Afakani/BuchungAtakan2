from pydantic import BaseModel, ConfigDict


class TokenResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    access_token: str
    token_type: str = "bearer"


class TokenData(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sub: str
    unternehmen_id: str
    rolle: str
    exp: int
