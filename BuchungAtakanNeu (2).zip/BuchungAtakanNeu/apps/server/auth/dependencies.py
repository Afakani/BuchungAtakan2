from typing import Annotated, AsyncGenerator
from uuid import UUID

import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from apps.server.auth.service import decode_access_token
from apps.server.database import get_session
from apps.server.models.benutzer import Benutzer, Rolle

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")

_CREDENTIALS_EXCEPTION = HTTPException(
    status_code=status.HTTP_401_UNAUTHORIZED,
    detail="Token konnte nicht validiert werden",
    headers={"WWW-Authenticate": "Bearer"},
)


async def get_current_unternehmen_id(
    token: Annotated[str, Depends(oauth2_scheme)],
) -> UUID:
    """Extrahiert unternehmen_id aus JWT ohne DB-Zugriff."""
    try:
        payload = decode_access_token(token)
        uid_str: str | None = payload.get("unternehmen_id")
        if uid_str is None:
            raise _CREDENTIALS_EXCEPTION
        return UUID(uid_str)
    except (jwt.InvalidTokenError, ValueError):
        raise _CREDENTIALS_EXCEPTION


async def get_current_unternehmen_id_optional(
    token: Annotated[
        str | None,
        Depends(OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login", auto_error=False)),
    ],
) -> UUID | None:
    """Wie get_current_unternehmen_id, aber None wenn kein Token vorhanden."""
    if token is None:
        return None
    try:
        payload = decode_access_token(token)
        uid_str: str | None = payload.get("unternehmen_id")
        return UUID(uid_str) if uid_str else None
    except (jwt.InvalidTokenError, ValueError):
        return None


async def get_current_user(
    token: Annotated[str, Depends(oauth2_scheme)],
    session: Annotated[AsyncSession, Depends(get_session)],
) -> Benutzer:
    """Validiert Token und laedt Benutzer. Prueft sub + unternehmen_id aus JWT."""
    try:
        payload = decode_access_token(token)
        sub: str | None = payload.get("sub")
        uid_str: str | None = payload.get("unternehmen_id")
        if sub is None or uid_str is None:
            raise _CREDENTIALS_EXCEPTION
    except jwt.InvalidTokenError:
        raise _CREDENTIALS_EXCEPTION
    from apps.server.repositories.benutzer import BenutzerRepository
    repo = BenutzerRepository()
    user = await repo.get_by_id_raw(session, UUID(sub), UUID(uid_str))
    if user is None:
        raise _CREDENTIALS_EXCEPTION
    return user


async def get_rls_session(
    session: Annotated[AsyncSession, Depends(get_session)],
    unternehmen_id: Annotated[UUID, Depends(get_current_unternehmen_id)],
) -> AsyncGenerator[AsyncSession, None]:
    """Session mit transaktionslokales RLS-Kontext (set_config TRUE = tx-lokal)."""
    await session.execute(
        text("SELECT set_config('app.current_tenant', :tid, true)"),
        {"tid": str(unternehmen_id)},
    )
    yield session


class RoleChecker:
    """Callable-Dependency fuer Rollenpruefung am Route-Decorator."""

    def __init__(self, allowed_roles: list[Rolle]) -> None:
        self.allowed_roles = allowed_roles

    def __call__(
        self,
        current_user: Annotated[Benutzer, Depends(get_current_user)],
    ) -> Benutzer:
        if current_user.rolle not in self.allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Unzureichende Rechte",
            )
        return current_user


async def get_current_user_id(
    token: Annotated[str, Depends(oauth2_scheme)],
) -> UUID:
    """Extrahiert Benutzer-ID (sub) aus JWT ohne DB-Zugriff."""
    try:
        payload = decode_access_token(token)
        sub: str | None = payload.get("sub")
        if sub is None:
            raise _CREDENTIALS_EXCEPTION
        return UUID(sub)
    except (jwt.InvalidTokenError, ValueError):
        raise _CREDENTIALS_EXCEPTION


CurrentUser = Annotated[Benutzer, Depends(get_current_user)]
CurrentTenantId = Annotated[UUID, Depends(get_current_unternehmen_id)]
CurrentUserId = Annotated[UUID, Depends(get_current_user_id)]
RLSSession = Annotated[AsyncSession, Depends(get_rls_session)]
