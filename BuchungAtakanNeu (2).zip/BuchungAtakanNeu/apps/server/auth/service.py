from datetime import datetime, timedelta, timezone

import jwt
from pwdlib import PasswordHash

from apps.server.config import settings

_ph = PasswordHash.recommended()
_DUMMY_HASH: str = _ph.hash("dummy_password_for_timing_protection")


def hash_password(plain: str) -> str:
    return _ph.hash(plain)


def verify_password(plain: str, hashed: str | None) -> bool:
    """Timing-sicher: Dummy-Verify wenn hashed=None (User nicht gefunden)."""
    if hashed is None:
        _ph.verify(plain, _DUMMY_HASH)
        return False
    return _ph.verify(plain, hashed)


def create_access_token(
    sub: str,
    unternehmen_id: str,
    rolle: str,
    expires_delta: timedelta | None = None,
) -> str:
    expire = datetime.now(timezone.utc) + (
        expires_delta or timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    payload = {
        "sub": sub,
        "unternehmen_id": unternehmen_id,
        "rolle": rolle,
        "exp": expire,
    }
    return jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


def decode_access_token(token: str) -> dict:
    """Wirft jwt.InvalidTokenError bei ungueltigem/abgelaufenem Token."""
    return jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
