from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm

from apps.server.auth.schemas import TokenResponse
from apps.server.auth.service import create_access_token, verify_password
from apps.server.database import DBSession
from apps.server.repositories.benutzer import BenutzerRepository

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])
_benutzer_repo = BenutzerRepository()


@router.post("/login", response_model=TokenResponse)
async def login(
    form_data: Annotated[OAuth2PasswordRequestForm, Depends()],
    session: DBSession,
) -> TokenResponse:
    """POST /api/v1/auth/login -- form-encoded: username + password."""
    user = await _benutzer_repo.get_by_benutzername(session, form_data.username)
    if not verify_password(form_data.password, user.hashed_password if user else None):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Ungueltige Anmeldedaten",
            headers={"WWW-Authenticate": "Bearer"},
        )
    if not user.aktiv:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Konto deaktiviert",
        )
    token = create_access_token(
        sub=str(user.id),
        unternehmen_id=str(user.unternehmen_id),
        rolle=user.rolle.value,
    )
    return TokenResponse(access_token=token)
